# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "/home/user")
from build_digest import *

from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT

doc = Document()
sec = doc.sections[0]
sec.left_margin = Inches(0.7); sec.right_margin = Inches(0.7)
sec.top_margin = Inches(0.7); sec.bottom_margin = Inches(0.6)

st = doc.styles["Normal"]; st.font.name = "Calibri"; st.font.size = Pt(11)


def set_font(run, size=11, bold=False, italic=False, mono=False, color=None):
    run.font.size = Pt(size); run.bold = bold; run.italic = italic
    run.font.name = "Consolas" if mono else "Calibri"
    if color: run.font.color.rgb = color
    return run


def para(text="", size=11, bold=False, italic=False, align=None, mono=False,
         space_before=0, space_after=4, color=None):
    p = doc.add_paragraph()
    if align == "c": p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    elif align == "j": p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p.paragraph_format.space_before = Pt(space_before)
    p.paragraph_format.space_after = Pt(space_after)
    if text: set_font(p.add_run(text), size, bold, italic, mono, color)
    return p


def rule():
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(6); p.paragraph_format.space_before = Pt(2)
    set_font(p.add_run("_" * 78), 9, color=RGBColor(0x99, 0x99, 0x99))


def add_table(headers, rows, widths=None, size=9, head_size=9):
    t = doc.add_table(rows=1, cols=len(headers)); t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, h in enumerate(headers):
        c = t.rows[0].cells[i]; c.text = ""
        p = c.paragraphs[0]; p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_font(p.add_run(str(h)), head_size, bold=True)
    for row in rows:
        cells = t.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = ""
            p = cells[i].paragraphs[0]; p.paragraph_format.space_after = Pt(1)
            set_font(p.add_run(str(v)), size)
    if widths:
        for r_ in t.rows:
            for i, w in enumerate(widths): r_.cells[i].width = Inches(w)
    return t


def draw_diagram(lines, caption):
    t = doc.add_table(rows=2, cols=1); t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = t.rows[0].cells[0]
    for k, line in enumerate(lines):
        p = cell.paragraphs[0] if k == 0 else cell.add_paragraph()
        p.paragraph_format.space_after = Pt(0); p.paragraph_format.space_before = Pt(0)
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_font(p.add_run(line), 10, mono=True)
    c2 = t.rows[1].cells[0].paragraphs[0]
    c2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_font(c2.add_run(caption), 9, italic=True)
    t.rows[0].cells[0].width = Inches(6.6)
    t.rows[1].cells[0].width = Inches(6.6)


# ============================================================= TITLE BLOCK
para(SCHOOL, size=15, bold=True, align="c", space_after=2)
para(SUBJECT, size=13, bold=True, align="c", space_after=2)
para(EXAM, size=12, bold=True, align="c", space_after=2)
para(YEAR, size=10, italic=True, align="c", space_after=8)

info = doc.add_table(rows=1, cols=3); info.style = "Table Grid"
info.alignment = WD_TABLE_ALIGNMENT.CENTER
for i, v in enumerate([f"Class: {CLASS}", f"Time: {TIME}", f"Total Marks: {MARKS}"]):
    c = info.rows[0].cells[i]; c.text = ""
    set_font(c.paragraphs[0].add_run(v), 10, bold=True)
para("", space_after=6)

para("INSTRUCTIONS", size=11, bold=True, space_after=3)
for txt in [
    "1. Write your name and class clearly in the spaces provided on your answer sheet.",
    "2. This paper has TWO sections: Section A and Section B.",
    "3. Answer ALL the questions in both sections.",
    "4. Section A has 40 multiple-choice questions. Each question carries 1 mark. Choose the best answer "
    "(A, B, C or D) and record it on the answer sheet provided.",
    "5. Section B has 7 theory questions totalling 60 marks. Write your answers clearly and neatly in your "
    "answer booklet. Draw and label diagrams or tables where you are asked to.",
    "6. Read every question carefully before you answer it.",
    "7. Do not use correction fluid. Cancel any mistake neatly with a single line.",
    "8. Hand in your answer sheet and your answer booklet at the end of the examination.",
]:
    para(txt, size=10.5, space_after=2)
rule()

# =============================================================== SECTION A
para("SECTION A - OBJECTIVE TEST (40 marks)", size=12, bold=True, align="c", space_after=2)
para("Answer ALL questions. Each question carries 1 mark. Choose the BEST answer and write its letter "
     "(A, B, C or D) against the question number on your answer sheet.",
     size=10, italic=True, align="c", space_after=8)

for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(1); p.paragraph_format.space_before = Pt(4)
    set_font(p.add_run(f"{i}. {q}"), 10.5)
    for j, o in enumerate(opts):
        p2 = doc.add_paragraph()
        p2.paragraph_format.left_indent = Inches(0.28)
        p2.paragraph_format.space_after = Pt(0); p2.paragraph_format.space_before = Pt(0)
        set_font(p2.add_run(f"{'ABCD'[j]}. {o}"), 10.5)

doc.add_page_break()

# =============================================================== SECTION B
para("SECTION B - THEORY (60 marks)", size=12, bold=True, align="c", space_after=2)
para("Answer ALL questions. Write your answers in your answer booklet. The marks for each question are "
     "shown in brackets.", size=10, italic=True, align="c", space_after=8)

for qb in SECTION_B:
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(8); p.paragraph_format.space_after = Pt(2)
    set_font(p.add_run(f"Question {qb['num']}"), 11, bold=True)
    set_font(p.add_run(f"  [{qb['total']} marks]"), 10, bold=True, italic=True)
    para(qb["stem"], size=10.5, space_after=4)
    if qb.get("diagram"):
        draw_diagram(DIGESTIVE_SYSTEM, "Fig. 1: The human digestive system (not drawn to scale)")
        para("", space_after=2)
    if qb.get("table") == "endproducts":
        add_table(END_HEADERS, END_ROWS, widths=[3.0, 2.6], size=9, head_size=9)
        para("Table 1: End products of digestion", size=9, italic=True, align="c", space_after=6)
        para("", space_after=2)
    if qb.get("table") == "foodtests":
        add_table(TEST_HEADERS, TEST_ROWS, widths=[1.5, 2.3, 2.2], size=8.5, head_size=8.5)
        para("Table 2: Food tests", size=9, italic=True, align="c", space_after=6)
        para("", space_after=2)
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Inches(0.25)
        p.paragraph_format.space_after = Pt(3); p.paragraph_format.space_before = Pt(2)
        set_font(p.add_run(f"{lab} {text}  "), 10.5)
        set_font(p.add_run(f"[{mk} mark{'s' if mk > 1 else ''}]"), 10, bold=True)

doc.add_page_break()

# ============================================================== ANSWER KEY
para("ANSWER KEY", size=13, bold=True, align="c", space_after=6)
para("SECTION A - OBJECTIVE TEST", size=11, bold=True, space_after=4)
rows = [[i, ans, TOPIC[tp], cog] for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1)]
add_table(["Question", "Answer", "Curriculum Area (Topic)", "Cognitive Level"],
          rows, widths=[0.8, 0.7, 3.6, 1.5], size=9)
counts = {L: sum(1 for q in MCQ if q[2] == L) for L in "ABCD"}
para("", space_after=4)
para("Correct-answer distribution: " + ", ".join(f"{L} = {counts[L]}" for L in "ABCD") + " (30 items).",
     size=9, italic=True)

para("", space_after=8)
para("SECTION B - THEORY (summary answers; see the Marking Scheme for full detail)",
     size=11, bold=True, space_after=4)
sba = [
 ("1 (a)", "Food is any substance, solid or liquid, that a living thing takes in and that provides "
  "nutrients for growth, energy and health. Nutrients: carbohydrates, proteins, fats and oils, "
  "vitamins, mineral salts and water.", "7.1", "Understand"),
 ("1 (b)", "Any three of: to provide energy; to build the body and repair worn-out parts; to protect "
  "the body against disease; to keep the body warm; to supply water for body processes.", "7.1",
  "Understand"),
 ("1 (c)", "Yes, in part - it supplies sugar, which gives energy - but it is not a complete food, "
  "because it contains no protein, fat, vitamins or mineral salts.", "7.1", "Evaluate"),
 ("2 (a)", "The starved person looks thin with the ribs and bones showing, weak and tired, with dry "
  "pale skin and dull hair; a starved child may have a swollen belly. The well-fed person looks well "
  "covered with firm muscles, bright eyes and healthy skin, and is active and strong.", "7.2",
  "Analyse"),
 ("2 (b)", "Any three of: to give energy; to build and repair the body; to help the body grow; to keep "
  "the body healthy and protect it from disease; to keep the body warm.", "7.2", "Understand"),
 ("2 (c)", "Without enough food the body has no energy and cannot fight disease; without the right "
  "nutrients it cannot build new tissue, so the child grows slowly; lack of vitamins and mineral salts "
  "lowers protection against illness.", "7.2", "Analyse"),
 ("3 (a)", "1 = mouth; 2 = oesophagus (gullet); 3 = stomach; 4 = small intestine; 5 = large intestine.",
  "7.3", "Remember"),
 ("3 (b)", "Any two of: the liver - makes bile, which helps digest fats and oils; the pancreas - makes "
  "pancreatic juice, which helps digest starch, protein and fat; the salivary glands - make saliva, "
  "which begins the digestion of starch.", "7.3", "Understand"),
 ("3 (c)", "Any three of: the food is churned by the muscular walls; it is mixed with gastric juice; "
  "the digestion of protein begins; it becomes a thick semi-liquid mass; it is released a little at a "
  "time into the small intestine.", "7.3", "Understand"),
 ("4 (a)", "The teeth cut and chew the yam into small pieces; saliva mixes with it to moisten it and "
  "make it easy to swallow; the saliva begins to digest the starch into sugar; the tongue rolls it "
  "into a ball for swallowing.", "7.4", "Understand"),
 ("4 (b)", "The food is churned and squeezed by the muscular walls of the stomach; it is mixed with "
  "gastric juice; the digestion of the protein in the meat begins; it becomes a thick semi-liquid mass "
  "and is released a little at a time into the small intestine.", "7.4", "Understand"),
 ("4 (c)", "The meat would be digested more slowly, because large pieces give the juices less surface "
  "to act on, and some of it may pass through without being fully digested.", "7.4", "Apply"),
 ("5 (a)", "(i) simple sugars such as glucose; (ii) amino acids; (iii) fatty acids and glycerol.",
  "7.5", "Understand"),
 ("5 (b)", "Any protein food: egg, meat, fish, beans, groundnuts, milk, cheese, soya. Use: the amino "
  "acids are used to build the body - for growth and for repairing worn-out parts.", "7.5", "Apply"),
 ("5 (c)", "The molecules in starch, protein and fat are far too large to pass through the wall of the "
  "small intestine into the blood; digestion breaks them into small soluble molecules - glucose, amino "
  "acids, fatty acids and glycerol - which can pass through.", "7.5", "Analyse"),
 ("6 (a)", "The inner wall of the small intestine is covered with tiny finger-like villi; the small "
  "soluble molecules pass through the thin wall of the villi into the blood vessels inside them; the "
  "blood carries the food to the liver and round the body.", "7.6", "Understand"),
 ("6 (b)", "Any three of: it is long; its inner wall is folded and covered with thousands of villi, "
  "which give a very large surface area; its wall is only one cell thick; it has a rich blood supply "
  "that carries the food away quickly.", "7.6", "Analyse"),
 ("6 (c)", "The undigested part - mostly roughage or fibre - passes into the large intestine, where "
  "most of the remaining water is absorbed; the rest becomes faeces, which are stored in the rectum "
  "and pass out through the anus.", "7.6", "Understand"),
 ("7 (a)", "(i) a blue-black colour; (ii) Benedict's solution, heated in a water bath (Fehling's "
  "solution is also accepted); (iii) a violet (purple) colour; (iv) rub a little of the food on a "
  "piece of paper - the grease-spot test.", "7.7", "Understand"),
 ("7 (b)", "Crush each sample into a separate labelled tube or dish; add iodine to the gari - "
  "blue-black means starch is present; add Biuret solution to the beans - violet means protein is "
  "present; rub palm oil on paper - a translucent spot means fat is present; keep one untreated "
  "control; record results in a table. Safety: do not taste any sample, handle iodine and Biuret "
  "solution with care, heat only in a water bath, wash hands afterwards.", "7.7", "Create"),
]
add_table(["Question", "Expected Answer", "Curriculum Area", "Cognitive Level"],
          [list(r) for r in sba], widths=[0.8, 4.2, 1.2, 1.2], size=9)

doc.add_page_break()

# =========================================================== MARKING SCHEME
para("MARKING SCHEME - SECTION B (60 marks)", size=13, bold=True, align="c", space_after=4)
para("General rules: (1) Accept any other correct and relevant answer. (2) Award marks for correct points, "
     "not for repeating the question. (3) For procedures, award method marks. (4) Do not deduct marks for "
     "spelling unless the meaning is changed. (5) Where a candidate gives more answers than are asked for, "
     "mark only the first ones up to the number required.",
     size=9.5, italic=True, space_after=8)

for qb in SECTION_B:
    n = qb["num"]
    para(f"Question {n}  ({qb['total']} marks)", size=11, bold=True, space_before=8, space_after=3)
    for (lab, points, note) in MARKING[n]:
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(2)
        set_font(p.add_run(f"{lab} "), 10.5, bold=True)
        mkv = [p_[2] for p_ in qb["parts"] if p_[0] == lab]
        if mkv: set_font(p.add_run(f"[{mkv[0]} mark{'s' if mkv[0] > 1 else ''}]"), 10, bold=True)
        for pt in points:
            pp = doc.add_paragraph()
            pp.paragraph_format.left_indent = Inches(0.35); pp.paragraph_format.space_after = Pt(1)
            set_font(pp.add_run("- " + pt), 10.5)
        pp = doc.add_paragraph()
        pp.paragraph_format.left_indent = Inches(0.35); pp.paragraph_format.space_after = Pt(6)
        set_font(pp.add_run("Marking note: " + note), 9.5, italic=True)

doc.add_page_break()

# ================================================================ BLUEPRINT
para("CURRICULUM ASSESSMENT BLUEPRINT", size=13, bold=True, align="c", space_after=3)
para(f"Strand: {STRAND}   |   Sub-strand: {SUBSTRAND}   |   Class: {CLASS}",
     size=10, italic=True, align="c", space_after=3)
para(f"Content Standard: {CS} - {CS_TEXT}", size=9, italic=True, align="c", space_after=3)
para("Source: NaCCA Science Common Core Programme Curriculum (B7/JHS1-B9/JHS3), September 2020, "
     "Strand 3: Systems, Sub-strand 1: The Human Body System, pp. 16-18. Indicators are quoted, "
     "not invented.",
     size=9, italic=True, space_after=8)

hdr = ["Qn", "Sub-strand", "Content Standard", "Indicator (NaCCA) - Indicator Text", "Topic / Content",
       "Cognitive Level", "Marks"]

rows = [[f"A{i}", SUBSTRAND, CS_BY_TOPIC[tp], f"{IND[tp]} - {IND_TEXT[tp]}", TOPIC[tp], cog, 1]
        for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1)]
add_table(hdr, rows, widths=[0.35, 0.75, 0.75, 1.75, 1.4, 0.8, 0.35], size=7, head_size=7.5)

para("", space_after=8)
rows = []
for qb in SECTION_B:
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        key = tp if tp in TOPIC else tp.split(",")[0].strip()
        rows.append([f"B{qb['num']}{lab.strip('()')}", SUBSTRAND, CS_BY_TOPIC[key],
                     f"{IND[key]} - {IND_TEXT[key]}", TOPIC[key], cog, mk])
add_table(hdr, rows, widths=[0.35, 0.75, 0.75, 1.75, 1.4, 0.8, 0.35], size=7, head_size=7.5)

doc.add_page_break()

# ----------------------------------------------------------------- helpers
def topic_totals():
    m = {k: 0 for k in TOPIC}; it = {k: 0 for k in TOPIC}
    for q in MCQ:
        m[q[3]] += 1; it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk; it[key] += 1
    return m, it

def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}; b = {k: 0 for k in order}
    for q in MCQ: a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: b[cog] += mk
    return order, a, b

def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ: d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: d[diff] += mk
    return d

m, it = topic_totals(); diff = difficulty_totals(); order, ca, cb = cognitive_by_section()

para("SUMMARY 1 - COVERAGE BY CURRICULUM AREA (TOPIC)", size=12, bold=True, space_after=4)
rows = [[TOPIC[k], it[k], m[k], f"{(m[k]/100)*100:.1f}%", CC[k]] for k in TOPIC]
rows.append(["TOTAL", sum(it.values()), sum(m.values()), "100%", "-"])
add_table(["Topic / Content Area", "No. of Items", "Marks", "% of Total Marks", "Core Competencies"],
          rows, widths=[2.7, 0.8, 0.6, 1.0, 1.1], size=8.5)
para("CC = Communication and Collaboration; CP = Critical Thinking and Problem Solving; "
     "DL = Digital Literacy; CI = Creativity and Innovation.", size=8.5, italic=True, space_after=2)

para("", space_after=8)
para("SUMMARY 2 - COGNITIVE-LEVEL DISTRIBUTION (Bloom's Taxonomy)", size=12, bold=True, space_after=4)
rows = []
for lv in order:
    tot = ca[lv] + cb[lv]
    rows.append([lv, ca[lv], cb[lv], tot, f"{(tot/100)*100:.1f}%"])
rows.append(["TOTAL", sum(ca.values()), sum(cb.values()), sum(ca.values()) + sum(cb.values()), "100%"])
add_table(["Cognitive Level", "Section A Marks", "Section B Marks", "Total Marks", "% of Total"],
          rows, widths=[1.6, 1.3, 1.3, 1.1, 1.1], size=9.5)

para("", space_after=8)
para("SUMMARY 3 - DIFFICULTY DISTRIBUTION", size=12, bold=True, space_after=4)
rows = [[k, v, f"{(v/100)*100:.1f}%"] for k, v in diff.items()]
rows.append(["TOTAL", sum(diff.values()), "100%"])
add_table(["Difficulty", "Marks", "% of Total Marks"], rows, widths=[2.0, 1.2, 1.5], size=9.5)
para("Target in the master prompt: approximately 30% easy / 50% moderate / 20% challenging.",
     size=9, italic=True, space_after=2)

para("", space_after=8)
para("SUMMARY 4 - SECTION WEIGHTING", size=12, bold=True, space_after=4)
add_table(["Section", "Question Type", "Items", "Marks", "% of Total"],
          [["A", "Objective (multiple choice)", 40, 40, "40%"],
           ["B", "Theory / constructed response", 20, 60, "60%"],
           ["TOTAL", "-", 60, 100, "100%"]],
          widths=[0.9, 2.4, 0.8, 0.8, 1.0], size=9.5)

doc.add_page_break()

# ===================================================== QUALITY-CONTROL
para("QUALITY-CONTROL SUMMARY", size=13, bold=True, align="c", space_after=4)
para("Carried out against the 14-point validation list in the master prompt before the examination was "
     "finalised.", size=9.5, italic=True, space_after=8)

qc = [
 ("Does every question belong to the supplied curriculum scope?",
  "Yes. All 46 items trace to Strand 3 (Systems), Sub-Strand 1 (The Human Body System), topics 7.1-7.7, "
  "and to the three official B7 indicators (B7/JHS1.3.1.1.1, B7/JHS1.3.1.1.2 and B7/JHS1.3.1.1.3). "
  "Enzyme names, hormone control, peristalsis detail, the lymphatic system and other body systems "
  "appear only as distractors, never as things pupils must answer on."),
 ("Is the examination appropriate for the stated class?",
  "Yes. The B7 curriculum requires learners to explain what food is and why we eat, identify and draw "
  "the alimentary canal, describe what happens in the mouth, stomach and intestines, state the end "
  "products of starch, protein and oil digestion, describe absorption, and perform food tests. No "
  "named enzymes, no pH chemistry and no villus histology are tested, as these fall outside the B7 "
  "indicator."),
 ("Are the questions genuinely BECE-style?",
  "Yes: Section A is 40 four-option objectives worth 1 mark each, and Section B is structured theory "
  "with sub-questions carrying printed mark allocations. A labelled digestive-system diagram and two "
  "completion tables are included, matching the BECE science convention and the indicator's own "
  "exemplars, which ask pupils to identify and draw the system and to perform food tests."),
 ("Are there enough application and reasoning questions?",
  "Yes. 31 of 100 marks (31%) are at Apply level or above (Apply 11, Analyse 14, Evaluate 3, Create 3). "
  "Analyse is well represented because the exemplars ask pupils to compare, deduce and explain, and "
  "Create appears through the food-test investigation plan in Question 7(b)."),
 ("Are the MCQ distractors plausible?",
  "Yes. Distractors are drawn from the same content family as the key: the wrong nutrient (A3, A4), the "
  "wrong end product (A25-A27), the wrong organ or stage (A14, A21, A23), and the wrong reagent or "
  "result in the food tests (A36-A38)."),
 ("Is there only one best answer for each MCQ?",
  "Yes. Every item was reviewed for a single defensible key. Special care was taken with A5, where "
  "sugar is also a carbohydrate, so the stem asks specifically for the best source of STARCH."),
 ("Are the marks internally consistent?",
  "Yes. Section A = 40 items x 1 mark = 40. Section B = 8 + 9 + 10 + 9 + 8 + 9 + 7 = 60. "
  "Each Section B sub-question's printed marks match its marking-scheme allocation."),
 ("Does the total add up correctly?",
  "Yes: 40 + 60 = 100 marks, matching the stated total on the front page."),
 ("Are the answers in the answer key correct?",
  "Yes. All 40 objective keys and all 20 Section B answers were verified against the marking scheme."),
 ("Does the marking scheme match the questions?",
  "Yes. Every Section B sub-question has an expected-answer list and a marking note covering partial "
  "credit, acceptable alternatives, common wrong answers and method marks. The diagram key (1-5), both "
  "completion tables and the investigation plan have explicit marking grids so they can be marked "
  "consistently across a class."),
 ("Are the questions free from unnecessary ambiguity?",
  "Yes. Open items are anchored with 'state three', 'name two' and the mark allocation. Question 5(a) "
  "and Question 7(a) number every blank, (i) to (iv), so there is no doubt which answer belongs where, "
  "and Question 7(b) spells out the three things the plan must contain."),
 ("Are Ghanaian contexts used naturally and accurately?",
  "Yes: boiled yam, gari, plantain, cassava, beans, groundnuts, palm oil and palm soup, meat and fish, "
  "a school water bath, and the starved-versus-well-fed comparison drawn from the curriculum's own "
  "exemplar. Question 4 follows the exemplar's own list of foods eaten in Ghana."),
 ("Has any content outside the supplied curriculum been introduced?",
  "No. Every item sits inside topics 7.1-7.7. Question 2 is built on exemplars 2 and 3 of "
  "B7/JHS1.3.1.1.1; Question 3 on exemplars 1 and 3 of B7/JHS1.3.1.1.2; Question 4 on exemplar 2; "
  "Question 5 on exemplar 2 of B7/JHS1.3.1.1.3; Question 6 on exemplar 1; and Question 7 on "
  "exemplar 3, the practical food tests."),
 ("Are the questions sufficiently varied?",
  "Yes. Item types include definition, listing, judgement, comparison of appearance, diagram labelling, "
  "naming associated organs, describing each digestive stage, explaining surface area, completing two "
  "tables, explaining a mechanism, and designing an investigation."),
]
for i, (q, a) in enumerate(qc, start=1):
    p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(2)
    set_font(p.add_run(f"{i}. {q}"), 10.5, bold=True)
    p2 = doc.add_paragraph()
    p2.paragraph_format.left_indent = Inches(0.3); p2.paragraph_format.space_after = Pt(6)
    set_font(p2.add_run(a), 10)

para("", space_after=8)
para("EXAMINER NOTES (for the teacher, not for candidates)", size=11, bold=True, space_after=4)
for n in [
 "Question 3 is the 'identify and draw the digestive system' exemplar. The diagram is drawn with text "
 "characters inside a Word table: enlarge it, redraw it with real boxes, or paste in a hand-drawn "
 "figure - the numbering (1-5) is what the questions depend on. Key: 1 mouth, 2 oesophagus, "
 "3 stomach, 4 small intestine, 5 large intestine.",
 "Question 3(b) is a common trip-up. The stomach and intestines are part of the alimentary canal, so "
 "they are NOT accepted here; the expected answers are the liver, the pancreas and the salivary "
 "glands.",
 "Question 7 is the practical food-test exemplar. If you can, run it before the mock: iodine on gari "
 "or bread, Biuret on beans or egg white, and the grease-spot test with palm oil. Pupils who have seen "
 "the colours answer far better.",
 "Safety for any practical follow-up: no tasting of unknown samples, iodine and Biuret solution are "
 "irritants, Benedict's solution must be heated in a water bath and never over a naked flame, and "
 "hands must be washed afterwards. The marking note withholds credit from a plan that tells pupils to "
 "taste an unknown sample.",
 "The paper deliberately does NOT name enzymes. B7 expects 'saliva begins the digestion of starch' and "
 "'gastric juice begins the digestion of protein' - do not reward answers that go beyond this, and do "
 "not penalise pupils for not using the words amylase or pepsin.",
 "Topic 7.7 carries 12 of 100 marks, the lightest weighting, only because it is the last topic and "
 "much of it is practical. If you have a well-equipped laboratory and want a more practical paper, "
 "move marks from Question 6 to Question 7.",
 "The digestive-system diagram and both tables are laid out for A4 portrait. Check the page break "
 "before Question 3 and before Question 7 when you print.",
 "Edit the school name, academic year and examination title on page 1 before printing.",
 "This is an original, teacher-made mock. It is not a reproduction of any WAEC or NaCCA examination "
 "paper.",
]:
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Inches(0.3); p.paragraph_format.space_after = Pt(3)
    set_font(p.add_run("- " + n), 10)

doc.save("/home/user/Basic7_Integrated_Science_Mock_Strand3_HumanBodyDigestion.docx")
print("docx written")

print("Section A:", len(MCQ), "items")
print("Section B total:", sum(q["total"] for q in SECTION_B))
print("Topic marks:", m, "sum", sum(m.values()))
print("Difficulty:", diff, "sum", sum(diff.values()))
print("Cognitive A:", ca)
print("Cognitive B:", cb)
print("Answer counts:", counts)
print("Totals:", sum(m.values()), sum(diff.values()),
      sum(ca.values()) + sum(cb.values()))
