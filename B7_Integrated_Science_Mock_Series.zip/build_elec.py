# -*- coding: utf-8 -*-
"""Basic 7 Integrated Science mock - Strand 4 Sub-strand 2: ELECTRICITY AND ELECTRONICS. 100 marks.
Indicators sourced from the official NaCCA Science CCP curriculum (B7/JHS1-B9/JHS3, Sept 2020),
Strand 4: Forces and Energy, Sub-strand 2: Electricity and Electronics, printed pages 30-32."""

SCHOOL = "[SCHOOL NAME]"
SUBJECT = "INTEGRATED SCIENCE (SCIENCE)"
EXAM = "END-OF-TERM MOCK EXAMINATION"
CLASS = "Basic 7 (JHS 1)"
TIME = "2 hours (Suggested: Section A - 40 min; Section B - 80 min)"
MARKS = "100"
YEAR = "2025/2026 Academic Year"

STRAND = "Forces and Energy"
SUBSTRAND = "Electricity and Electronics"

TOPIC = {
    "12.1": "12.1 Forms of Electricity Generation",
    "12.2": "12.2 Impact on the Environment",
    "12.3": "12.3 Basic Electronic Components",
    "12.4": "12.4 Assembling a Simple Circuit",
    "12.5": "12.5 The P-N Junction Diode",
    "12.6": "12.6 Functions and Interdependence",
}

CS = "B7/JHS1.4.2.1 / B7/JHS1.4.2.2"
CS_BY_TOPIC = {
    "12.1": "B7/JHS1.4.2.1", "12.2": "B7/JHS1.4.2.1",
    "12.3": "B7/JHS1.4.2.2", "12.4": "B7/JHS1.4.2.2",
    "12.5": "B7/JHS1.4.2.2", "12.6": "B7/JHS1.4.2.2",
}
CS_TEXT = ("Demonstrate understanding of forms of electricity, its generation and effects on the "
           "environment; demonstrate knowledge of how to assemble and explain the functions of "
           "basic electronic components and their interdependence in an electronic circuit")

IND = {
    "12.1": "B7/JHS1.4.2.1.1 (Ex. 1)",
    "12.2": "B7/JHS1.4.2.1.2 (Ex. 1)",
    "12.3": "B7/JHS1.4.2.2.1 (Ex. 1)",
    "12.4": "B7/JHS1.4.2.2.2 (Ex. 2, 3)",
    "12.5": "B7/JHS1.4.2.2.2 (Ex. 2)",
    "12.6": "B7/JHS1.4.2.2.2 (Ex. 1); B7/JHS1.4.2.2.3 (Ex. 1, 2)",
}
IND_TEXT = {
    "12.1": "Describe the various forms of electricity generation. Ex. 1: Search for and discuss "
            "information about the nature and generation of thermal and nuclear electricity and "
            "produce reports, posters, diagrams and charts about your findings.",
    "12.2": "Explain the impact of electricity generation on the environment. Ex. 1: Debate the "
            "negative effects of both thermal and nuclear electricity generation on the "
            "environment and how to reduce the effects; create posters or leaflets of the outcome "
            "of the debate.",
    "12.3": "Demonstrate how to assemble basic electronic components in an electronic circuit. "
            "Ex. 1: Examine electronic components such as types of LEDs, P-N junction diodes, "
            "colour code resistors and capacitors, and arrange them in an electronic circuit.",
    "12.4": "Discuss the function of each electronic component and their interdependence with each "
            "other. Ex. 2, 3: Identify the Positive (P) region and Negative (N) region of the P-N "
            "junction diode and construct a simple electronic circuit comprising a 3V battery made "
            "of two dry cells in series with a switch and an LED; explain what happens when the "
            "switch in an electronic circuit is closed and when it is opened.",
    "12.5": "Discuss the function of each electronic component and their interdependence with each "
            "other. Ex. 2: Identify the Positive (P) region and Negative (N) region of the P-N "
            "junction diode and construct a simple electronic circuit comprising a 3V battery made "
            "of two dry cells in series with a switch and an LED.",
    "12.6": "Discuss the function of each electronic component and their interdependence with each "
            "other; discuss the function of each electronic component such as resistor, diode and "
            "inductor, and their interdependence for the functioning of an electronic gadget. "
            "Ex. 1: Dismantle and assemble spoilt electronic gadgets and name the parts. "
            "Ex. 1, 2 of B7/JHS1.4.2.2.3: Discuss the roles and significance of the LED, the "
            "resistor, the diode and the inductor in a circuit and how they affect each other; "
            "explain changes in brightness in an LED in relation to addition of resistors, diodes "
            "and inductors.",
}
CC = {
    "12.1": "DL, CC", "12.2": "CC, CP, CI", "12.3": "DL, CI",
    "12.4": "CC, CI", "12.5": "CC, CI", "12.6": "CC, CI, CP",
}

# ---------------------------------------------------------------- SECTION A
# (question, [A,B,C,D], answer, topic, cognitive, difficulty)
MCQ = [
 ("Electricity generated in a power station by burning coal, oil or natural gas to boil water is "
  "called",
  ["solar electricity", "nuclear electricity", "thermal electricity", "hydro electricity"],
  "C", "12.1", "Remember", "Easy"),
 ("The fuel used in a nuclear power station to produce heat is",
  ["uranium", "coal", "natural gas", "petrol"], "A", "12.1", "Remember", "Easy"),
 ("In a thermal power station, the steam that is produced is used to",
  ["cool the generator down", "wash the coal before it is burnt", "heat the water again",
   "turn a turbine which turns the generator"],
  "D", "12.1", "Understand", "Moderate"),
 ("The main difference between a thermal power station and a nuclear power station is",
  ["the size of the building",
   "the source of the heat that is used to boil the water",
   "the kind of generator that is used",
   "the way the electricity is sent along the wires"],
  "B", "12.1", "Understand", "Moderate"),
 ("Which of these is a fuel used in a thermal power station?",
  ["coal", "uranium", "water", "steam"], "A", "12.1", "Remember", "Easy"),
 ("In a nuclear power station the great heat that is needed is obtained by",
  ["burning large amounts of coal", "using the heat of the sun",
   "splitting atoms inside a nuclear reactor", "burning natural gas"],
  "C", "12.1", "Understand", "Challenging"),
 ("In both a thermal power station and a nuclear power station, the electricity itself is finally "
  "produced by",
  ["the boiler", "a generator turned by a turbine", "the cooling tower", "the fuel store"],
  "B", "12.1", "Understand", "Challenging"),

 ("Burning coal to generate electricity releases into the air mainly",
  ["oxygen and nitrogen", "pure water vapour only", "helium",
   "carbon dioxide, smoke and sulphur dioxide"],
  "D", "12.2", "Remember", "Easy"),
 ("Which of these is a negative effect of thermal electricity generation on the environment?",
  ["it makes the rain pure", "it cools the air around the station",
   "it pollutes the air with smoke and gases", "it makes the soil richer"],
  "C", "12.2", "Understand", "Easy"),
 ("Acid rain, which damages crops and buildings, is caused mainly by",
  ["sulphur dioxide released when coal is burnt", "the water used to cool the station",
   "the noise made by the generators", "radioactive waste"],
  "A", "12.2", "Understand", "Moderate"),
 ("The dangerous waste produced by a nuclear power station is",
  ["plastic waste", "radioactive waste", "paper waste", "food waste"],
  "B", "12.2", "Remember", "Easy"),
 ("Which of these is a negative effect of nuclear electricity generation?",
  ["it produces a lot of smoke every day", "it uses up all the coal in the country",
   "it makes a noise that can be heard for many kilometres",
   "it produces radioactive waste that stays dangerous for a very long time"],
  "D", "12.2", "Understand", "Moderate"),
 ("One way of reducing the harm done by a thermal power station is to",
  ["fit filters in the chimney to remove the smoke and the gases",
   "burn even more coal so that the station works faster",
   "pump the warm cooling water straight into the river",
   "cut down all the trees around the station"],
  "A", "12.2", "Apply", "Moderate"),
 ("Warm water from a power station is pumped into a nearby river. The most likely effect is that",
  ["the fish will grow much faster", "the river will dry up completely",
   "the fish may die, because warm water holds less oxygen than cold water",
   "the water will become safe to drink"],
  "C", "12.2", "Analyse", "Challenging"),

 ("An LED is",
  ["a type of resistor", "a diode that gives out light when current flows through it",
   "a small battery", "a kind of switch"],
  "B", "12.3", "Remember", "Easy"),
 ("The component used to limit or control the current flowing in a circuit is the",
  ["capacitor", "switch", "dry cell", "resistor"], "D", "12.3", "Remember", "Easy"),
 ("A component that allows electric current to flow in one direction only is a",
  ["diode", "resistor", "capacitor", "switch"], "A", "12.3", "Remember", "Easy"),
 ("The component that stores an electric charge and releases it when it is needed is a",
  ["resistor", "diode", "capacitor", "switch"], "C", "12.3", "Remember", "Moderate"),
 ("The coloured bands painted on a resistor are used to",
  ["make the resistor look attractive", "show the resistance value of the resistor",
   "show which end of the resistor is positive", "stop the resistor from getting hot"],
  "B", "12.3", "Understand", "Moderate"),
 ("Which of these components gives out light when current passes through it?",
  ["a resistor", "a capacitor", "a switch", "an LED"], "D", "12.3", "Remember", "Easy"),

 ("A complete path through which electric current can flow is called",
  ["a circuit", "a resistor", "a battery", "a generator"], "A", "12.4", "Remember", "Easy"),
 ("When the switch in a circuit is opened, the circuit is",
  ["short-circuited", "made stronger", "broken, so no current flows",
   "able to carry more current"],
  "C", "12.4", "Understand", "Easy"),
 ("Two dry cells, each of 1.5 V, are connected in series. The voltage of the battery is",
  ["1.5 V", "3.0 V", "0.75 V", "6.0 V"], "B", "12.4", "Apply", "Moderate"),
 ("Which of these is needed to build a simple circuit that lights an LED?",
  ["a magnet only", "a bulb and a mirror", "a coil of wire only",
   "a battery, a switch, a resistor, an LED and connecting wires"],
  "D", "12.4", "Understand", "Easy"),
 ("An LED has two legs of different lengths. The longer leg is",
  ["the negative leg", "the leg that must be earthed", "the positive leg, called the anode",
   "the leg that must be joined to the switch"],
  "C", "12.4", "Understand", "Moderate"),
 ("A resistor is put in series with an LED mainly to",
  ["limit the current so that the LED is not damaged", "make the LED brighter",
   "store electricity for later use", "change the colour of the light"],
  "A", "12.4", "Understand", "Moderate"),
 ("In a circuit, the part that is used to open and to close the circuit is the",
  ["battery", "resistor", "LED", "switch"], "D", "12.4", "Remember", "Easy"),
 ("A pupil builds a circuit with a good battery, a good LED and a good switch, but the LED does "
  "not light. The most likely reason is that",
  ["the LED is facing the wrong way in the room",
   "there is a break in the circuit, such as a loose wire",
   "the connecting wires are too short", "the switch is made of plastic"],
  "B", "12.4", "Analyse", "Challenging"),

 ("The letters P and N in a P-N junction diode stand for",
  ["Positive and Negative", "Power and Neutral", "Pressure and Number", "Primary and Negative"],
  "A", "12.5", "Remember", "Easy"),
 ("A P-N junction diode allows current to pass through it easily when it is",
  ["painted black", "joined to a very long wire",
   "connected the right way round, with the P side to the positive of the battery",
   "connected the wrong way round"],
  "C", "12.5", "Understand", "Moderate"),
 ("The negative end of a diode, called the cathode, is usually marked with",
  ["a long leg", "a red spot", "a screw thread", "a band or ring round the body"],
  "D", "12.5", "Remember", "Moderate"),
 ("A diode is connected the wrong way round in a circuit with a battery, a resistor and an LED. "
  "The LED will",
  ["shine more brightly", "not light, because the diode blocks the current",
   "light for a short time and then go out", "change colour"],
  "B", "12.5", "Apply", "Challenging"),
 ("Which of these components has a positive region and a negative region joined together?",
  ["a resistor", "a capacitor", "a P-N junction diode", "a switch"],
  "C", "12.5", "Remember", "Easy"),
 ("The P region of a P-N junction diode is also called the",
  ["anode", "cathode", "resistor", "base"], "A", "12.5", "Remember", "Moderate"),
 ("A diode is used in a circuit mainly to",
  ["store electric charge", "make the current bigger", "open and close the circuit",
   "allow current to flow in one direction only"],
  "D", "12.5", "Remember", "Easy"),
 ("Which statement about a P-N junction diode is correct?",
  ["it lets current flow equally well in both directions",
   "it conducts when the P side is joined to the positive of the battery and the N side to the "
   "negative",
   "it conducts only when it is very cold",
   "it stores electricity just like a small battery"],
  "B", "12.5", "Analyse", "Challenging"),

 ("The component that stores energy in a magnetic field and opposes changes in the current is the",
  ["capacitor", "resistor", "inductor", "diode"], "C", "12.6", "Remember", "Moderate"),
 ("Electronic components in a circuit are said to depend on one another because",
  ["they are all made in the same factory", "they are all the same size",
   "they all cost the same amount of money",
   "if one of them is missing or faulty, the whole circuit stops working"],
  "D", "12.6", "Understand", "Moderate"),
 ("Another resistor is added in series with an LED in a circuit. The LED becomes",
  ["brighter, because there is more resistance", "dimmer, because less current flows",
   "brighter, because more current flows", "no different at all"],
  "B", "12.6", "Apply", "Challenging"),
 ("Which of these best explains why a battery, a resistor and an LED must work together in a "
  "circuit?",
  ["the battery pushes the current, the resistor controls how much flows and the LED changes it "
   "into light",
   "the battery stores the light, the resistor makes the heat and the LED stores the current",
   "the LED pushes the current, the battery controls it and the resistor gives the light",
   "each one works on its own and none of them affects the others"],
  "A", "12.6", "Analyse", "Challenging"),
]

# --------------------------------------- SECTION B DIAGRAM (Q6) + TABLE (Q3)
CIRCUIT = [
    "        (1)             (2)",
    "       SWITCH        RESISTOR",
    "   +-----/ /----------[======]----+",
    "   |                              |",
    "   |                              |",
    "   |                              |",
    "   |     (3)         (4)          |",
    "   +-----| |---------->|----------+",
    "       BATTERY          LED",
    "   (two dry cells in series)",
]
CIRCUIT_KEY = "1 = switch, 2 = resistor, 3 = battery (two dry cells in series), 4 = LED"

CMP_HEADERS = ["Component", "What it does in a circuit", "One gadget where it is found"]
CMP_ROWS = [
 ["LED", "(i)", "the indicator light on a television set"],
 ["Resistor", "(ii)", "a radio"],
 ["Diode", "allows current to flow in one direction only", "(iii)"],
 ["Capacitor", "stores an electric charge and releases it when it is needed", "(iv)"],
 ["Inductor", "(v)", "a radio or a mobile phone charger"],
 ["Switch", "(vi)", "every electrical gadget in the home"],
]

# ---------------------------------------------------------------- SECTION B
SECTION_B = [
 dict(
   num=1, total=9, topic="12.1",
   stem="Ghana generates electricity from the Akosombo Dam and from thermal plants. Some other "
        "countries use nuclear power stations.",
   parts=[
     ("(a)", "Explain what is meant by thermal electricity generation, and name the fuel used.",
      3, "Understand", "12.1", "Moderate"),
     ("(b)", "Explain what is meant by nuclear electricity generation, and name the fuel used.",
      3, "Understand", "12.1", "Moderate"),
     ("(c)", "State three differences between a thermal power station and a nuclear power station.",
      3, "Analyse", "12.1", "Moderate"),
   ]),
 dict(
   num=2, total=9, topic="12.2",
   stem="Generating electricity has effects on the environment around the power station and beyond.",
   parts=[
     ("(a)", "State three negative effects of thermal electricity generation on the environment.",
      3, "Understand", "12.2", "Moderate"),
     ("(b)", "State three negative effects of nuclear electricity generation on the environment.",
      3, "Understand", "12.2", "Moderate"),
     ("(c)", "Your district must choose between building a thermal plant or a nuclear plant. Which "
             "one would you support? Give three reasons for your choice.",
      3, "Evaluate", "12.2", "Challenging"),
   ]),
 dict(
   num=3, total=10, topic="12.3",
   stem="Your class has been given a box of electronic components to examine. Study the incomplete "
        "table below and answer the questions that follow.",
   table="components",
   parts=[
     ("(a)", "Copy and complete the table.", 6, "Understand", "12.3", "Moderate"),
     ("(b)", "State two reasons why an LED is often used instead of an ordinary bulb in electronic "
             "gadgets.", 2, "Understand", "12.3", "Moderate"),
     ("(c)", "A resistor has coloured bands painted on it. Explain what the coloured bands are for "
             "and how a technician would use them.", 2, "Apply", "12.3", "Moderate"),
   ]),
 dict(
   num=4, total=9, topic="12.4",
   stem="Your class has been asked to build a simple electronic circuit using a 3 V battery made of "
        "two dry cells in series, a switch, a resistor and an LED.",
   parts=[
     ("(a)", "Describe how you would build this circuit. Name the items you would use and say how "
             "you would join them together.", 4, "Create", "12.4", "Challenging"),
     ("(b)", "Explain what happens in the circuit when the switch is closed and when it is opened.",
      3, "Understand", "12.4", "Easy"),
     ("(c)", "State two reasons why the resistor is needed in this circuit.",
      2, "Understand", "12.4", "Easy"),
   ]),
 dict(
   num=5, total=8, topic="12.5",
   stem="A P-N junction diode is one of the components your class examined.",
   parts=[
     ("(a)", "Explain what is meant by the P region and by the N region of a P-N junction diode.",
      3, "Understand", "12.5", "Moderate"),
     ("(b)", "State two ways of telling which end of a diode is the negative end.",
      2, "Understand", "12.5", "Moderate"),
     ("(c)", "Describe what happens when the diode is connected the right way round in a circuit "
             "with a battery, a resistor and an LED, and then what happens when it is connected "
             "the wrong way round.", 3, "Apply", "12.5", "Challenging"),
   ]),
 dict(
   num=6, total=8, topic="12.6",
   stem="Fig. 1 shows a simple electronic circuit. Study it and answer the questions that follow.",
   diagram=True,
   parts=[
     ("(a)", "Name the parts labelled 1, 2, 3 and 4 in Fig. 1, and state what each one does.",
      4, "Understand", "12.6", "Easy"),
     ("(b)", "Explain why these components are said to depend on one another.",
      2, "Analyse", "12.6", "Moderate"),
     ("(c)", "Explain what happens to the brightness of the LED when another resistor is added in "
             "series with it, and give a reason for your answer.",
      2, "Apply", "12.6", "Challenging"),
   ]),
 dict(
   num=7, total=7, topic="12.6",
   stem="Your class is given a spoilt radio to dismantle as part of a project.",
   parts=[
     ("(a)", "Name four components you would expect to find inside the radio, and state what each "
             "one does.", 4, "Remember", "12.6", "Easy"),
     ("(b)", "Explain why the components inside the radio are said to depend on one another.",
      3, "Analyse", "12.6", "Moderate"),
   ]),
]

# ------------------------------------------------------- MARKING SCHEME
MARKING = {
 1: [
   ("(a)", ["Thermal electricity is generated by burning a fuel to produce heat.",
            "The fuel is coal, oil or natural gas.",
            "The heat boils water to make steam, and the steam turns a turbine which turns the "
            "generator.",
            "A thermal power station changes the chemical energy in the fuel into heat, then into "
            "movement, then into electricity."],
    "1 mark each for any THREE correct points (3 marks). The fuel must be named for full marks: "
    "coal, oil or natural gas. Accept the description of a named Ghanaian thermal plant. Do NOT "
    "accept 'uranium' as the fuel here."),
   ("(b)", ["Nuclear electricity is generated using the heat released when atoms are split inside "
            "a nuclear reactor.",
            "The fuel is uranium.",
            "The heat boils water to make steam, and the steam turns a turbine which turns the "
            "generator.",
            "No fuel is burnt, so no smoke is produced."],
    "1 mark each for any THREE correct points (3 marks). The fuel must be named for full marks: "
    "uranium. The key idea is splitting atoms (nuclear fission) in a reactor. Do NOT accept "
    "'coal' or 'gas' as the fuel here."),
   ("(c)", ["A thermal station burns coal, oil or gas; a nuclear station uses uranium.",
            "A thermal station produces a lot of smoke and carbon dioxide; a nuclear station "
            "produces almost none.",
            "A thermal station produces ash and ordinary waste; a nuclear station produces "
            "radioactive waste.",
            "A thermal station can be built and run more cheaply; a nuclear station costs a great "
            "deal to build and to make safe.",
            "A thermal station needs a regular supply of fuel; a nuclear station needs very little "
            "fuel but very careful control.",
            "Both use steam to turn a turbine, so that is a similarity, not a difference."],
    "1 mark each for any THREE correct differences (3 marks). Each point must state a DIFFERENCE, "
    "not just describe one station; award at most 2 marks if the answers describe the two stations "
    "separately without comparing them."),
 ],
 2: [
   ("(a)", ["It pollutes the air with smoke, carbon dioxide and sulphur dioxide.",
            "The sulphur dioxide causes acid rain, which damages crops, buildings and water "
            "bodies.",
            "The carbon dioxide adds to global warming.",
            "Ash and dust from the station settle on houses, crops and water.",
            "Warm water pumped into a river can kill fish, because warm water holds less oxygen.",
            "Cutting down trees to clear the site, or mining the coal, damages the land."],
    "1 mark each for any THREE correct negative effects (3 marks). Accept any sensible "
    "environmental harm caused by thermal generation."),
   ("(b)", ["It produces radioactive waste that stays dangerous for thousands of years and is very "
            "hard to store safely.",
            "An accident at the station could release radiation over a wide area and harm people, "
            "animals and crops for a long time.",
            "Warm water pumped into a river or the sea can harm fish and other water life.",
            "Mining uranium damages the land where the mine is.",
            "The heavy concrete and steel used to build the station use up a lot of materials and "
            "energy.",
            "The station is very expensive to close down safely at the end of its life."],
    "1 mark each for any THREE correct negative effects (3 marks). The two things to look for "
    "first are the radioactive waste and the danger of an accident."),
   ("(c)", ["Either choice is acceptable, provided the reasons are sensible and about the "
            "environment.",
            "Supporting the thermal plant: it is cheaper and quicker to build, the fuel is easier "
            "to get, and the waste is easier to manage than radioactive waste.",
            "Supporting the nuclear plant: it produces almost no smoke or carbon dioxide, so it "
            "does not pollute the air or add to global warming.",
            "Supporting the nuclear plant: a very small amount of fuel produces a very large "
            "amount of electricity.",
            "Against the nuclear plant: the radioactive waste is dangerous for a very long time "
            "and is difficult and costly to store.",
            "Against the thermal plant: the smoke and sulphur dioxide pollute the air and cause "
            "acid rain."],
    "1 mark for a clear choice and 1 mark each for any TWO correct reasons that support it "
    "(3 marks). Both choices are valid. Award the reasons only if they support the choice made. "
    "Accept 'neither - we should use solar or hydro power', provided two sensible reasons are "
    "given."),
 ],
 3: [
   ("(a)", ["(i) gives out light when current flows through it; it changes electrical energy into "
            "light",
            "(ii) limits or controls the amount of current flowing in the circuit",
            "(iii) a battery charger, a radio, an adapter or a solar charge controller",
            "(iv) a radio, a television set, a mobile phone charger or a camera flash",
            "(v) stores energy in a magnetic field and opposes changes in the current flowing "
            "through it",
            "(vi) opens and closes the circuit, so it switches the current on and off"],
    "1 mark each for any SIX correct entries (6 marks). The blank number must be matched to the "
    "answer. For (iii) and (iv) accept any gadget that genuinely contains that component. For (v) "
    "accept 'opposes changes in the current' or 'stores energy in a magnetic field'."),
   ("(b)", ["An LED uses much less current than an ordinary bulb, so the battery lasts longer.",
            "An LED does not get hot the way an ordinary bulb does.",
            "An LED is much smaller, so it fits into small gadgets such as a mobile phone or a "
            "remote control.",
            "An LED lasts far longer and does not easily break.",
            "An LED lights up at once and does not have a filament that can burn out."],
    "1 mark each for any TWO correct reasons (2 marks). Accept any sensible advantage of an LED "
    "over an ordinary filament bulb."),
   ("(c)", ["The coloured bands show the resistance value of the resistor, measured in ohms.",
            "A technician reads the bands in order and uses a colour code chart to find the "
            "resistance.",
            "This lets the technician choose the right resistor without having to measure it "
            "first."],
    "1 mark for saying that the bands show the resistance value and 1 mark for explaining how a "
    "technician would use them (2 marks). Accept 'the bands tell you how many ohms the resistor "
    "is'. B7 pupils are NOT expected to remember the colour code chart itself."),
 ],
 4: [
   ("(a)", ["Items needed: two 1.5 V dry cells, a cell holder, a switch, a resistor, an LED and "
            "connecting wires.",
            "Put the two dry cells in the holder in series - the positive of one touching the "
            "negative of the other - to make a 3 V battery.",
            "Join the positive end of the battery to one leg of the switch with a wire.",
            "Join the other leg of the switch to one end of the resistor, then join the other end "
            "of the resistor to the LONGER (positive) leg of the LED.",
            "Join the shorter (negative) leg of the LED back to the negative end of the battery to "
            "complete the loop.",
            "Close the switch to test the circuit - the LED should light."],
    "1 mark for naming the items, 1 mark for connecting the cells in series, 1 mark for joining "
    "the components in one loop that includes the resistor and the LED, and 1 mark for a correct "
    "final check such as closing the switch to see whether the LED lights (4 marks). This is a "
    "design task: award method marks for any workable plan that is clearly described."),
   ("(b)", ["When the switch is CLOSED the circuit is complete, so current flows round the circuit "
            "and the LED lights.",
            "When the switch is OPENED there is a break in the circuit, so no current can flow and "
            "the LED goes out.",
            "The switch therefore controls the circuit without having to disconnect any wires."],
    "1 mark each for any THREE correct points (3 marks). The pupil must deal with BOTH closing and "
    "opening to earn full marks; award at most 2 marks if only one of the two is described."),
   ("(c)", ["The resistor limits the current so that too much does not flow through the LED.",
            "Without the resistor the LED would be damaged or burnt out.",
            "The resistor protects the battery from being drained too quickly.",
            "It also helps to control the brightness of the LED."],
    "1 mark each for any TWO correct reasons (2 marks). The single most important reason is that "
    "the resistor protects the LED from too much current."),
 ],
 5: [
   ("(a)", ["The P region is the positive region, and it is called the anode.",
            "The N region is the negative region, and it is called the cathode.",
            "The two regions are joined together inside the diode at the junction, and this is what "
            "makes the diode allow current to flow in one direction only.",
            "P stands for Positive and N stands for Negative."],
    "1 mark each for any THREE correct points (3 marks). At least one point must describe the P "
    "region and at least one the N region; award at most 2 marks if only one is described."),
   ("(b)", ["The negative end is marked with a band or a ring painted round the body of the diode.",
            "The leg at the negative end is the shorter of the two legs.",
            "The flat side of some diode packages marks the negative end."],
    "1 mark each for any TWO correct ways (2 marks). The band or ring is the answer to look for "
    "first."),
   ("(c)", ["Connected the right way round (P side to the positive of the battery), the diode "
            "allows current to flow, so the LED lights.",
            "Connected the wrong way round, the diode blocks the current, so the LED does not "
            "light.",
            "Nothing is damaged - the LED simply stays off until the diode is turned round.",
            "This shows that a diode conducts in one direction only, which is its main use in a "
            "circuit."],
    "1 mark each for any THREE correct points (3 marks). The pupil must describe BOTH the right "
    "way round and the wrong way round to earn full marks; award at most 2 marks if only one is "
    "described. Do NOT accept 'the diode breaks' or 'the battery is spoilt'."),
 ],
 6: [
   ("(a)", ["1 - switch: it opens and closes the circuit, so it switches the current on and off.",
            "2 - resistor: it limits or controls the amount of current flowing in the circuit.",
            "3 - battery (two dry cells in series): it provides the voltage that pushes the "
            "current round the circuit.",
            "4 - LED: it changes electrical energy into light, and shows that current is flowing."],
    "1 mark each for all FOUR parts correctly named AND their functions stated (4 marks). A "
    "correctly named part with no function earns only half a mark each. Accept 'two dry cells' for "
    "3. Accept 'lamp that gives light' for 4, but 'LED' is the expected answer."),
   ("(b)", ["Each component has a job to do and the circuit only works if every one of them does "
            "its job.",
            "The battery alone cannot light the LED - it needs wires and a closed switch to carry "
            "the current.",
            "The resistor controls how much current reaches the LED, so it decides how bright the "
            "LED is and whether the LED is damaged.",
            "If any one part is missing, faulty or disconnected, the loop is broken and the whole "
            "circuit stops working."],
    "1 mark each for any TWO correct points (2 marks). The key idea is that the parts form one "
    "loop and each one affects what the others can do."),
   ("(c)", ["The LED becomes dimmer.",
            "Adding another resistor increases the total resistance in the circuit.",
            "More resistance means less current flows, and less current makes the LED dimmer.",
            "If enough resistors were added, the LED would eventually go out."],
    "1 mark for saying that the LED becomes dimmer and 1 mark for the reason that the extra "
    "resistance reduces the current (2 marks). Accept 'it gets less bright'. Do NOT accept 'it "
    "becomes brighter'."),
 ],
 7: [
   ("(a)", ["Resistors - they limit or control the current in the different parts of the radio.",
            "Capacitors - they store electric charge and release it when it is needed.",
            "Diodes - they allow current to flow in one direction only.",
            "LEDs - they show that the radio is switched on, or they light up the display.",
            "Inductors (coils of wire) - they store energy in a magnetic field and help to tune "
            "the radio to a station.",
            "A switch or a volume control - it opens, closes or varies the circuit.",
            "Connecting wires or a circuit board - they join all the other parts together."],
    "1 mark each for any FOUR components correctly named with what each one does (4 marks). A "
    "correctly named component with no function earns only half a mark each. Accept any component "
    "that would genuinely be found inside a radio."),
   ("(b)", ["The parts form one circuit, so each one depends on the others to do its job.",
            "The battery or power supply alone cannot make the radio work - the current must reach "
            "every part through the wires and the circuit board.",
            "The resistors and capacitors set the conditions in which the diodes and the "
            "transistors can work.",
            "If one part is missing, faulty or disconnected, the radio stops working even though "
            "all the other parts are still in place.",
            "This is what is meant by interdependence: the gadget works only when the parts work "
            "together."],
    "1 mark each for any THREE correct points (3 marks). The key idea is that the gadget works "
    "only when all the parts work together, and that one faulty part stops the whole thing."),
 ],
}


# --------------------------------------------- derive summary statistics
def topic_totals():
    m = {k: 0 for k in TOPIC}
    it = {k: 0 for k in TOPIC}
    for q in MCQ:
        m[q[3]] += 1
        it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk
            it[key] += 1
    return m, it


def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}
    b = {k: 0 for k in order}
    for q in MCQ:
        a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            b[cog] += mk
    return order, a, b


def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ:
        d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            d[diff] += mk
    return d
