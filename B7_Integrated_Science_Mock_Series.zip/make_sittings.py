# -*- coding: utf-8 -*-
"""Splits the Special Mock into two separately-sat papers.

  Paper 1 - Objective Test : 100 MCQ, 1 h 30 min, 200 marks
  Paper 2 - Essay          : 20 questions, 2 h, 200 marks
"""
import sys
sys.path.insert(0, "/home/user")
from build_special import *

from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT

AM, BM, AI, BI = topic_totals_by_section()
SAM, SBM, SAI, SBI = strand_totals_by_section()
ORDER, CA, CB = cognitive_by_section()
DA, DB = difficulty_by_section()
TOT_A, TOT_B = 200, 200
NB = sum(len(q["parts"]) for q in SECTION_B)

P1_INSTR = [
 "INSTRUCTIONS TO CANDIDATES",
 "1. This paper has 100 multiple-choice questions. Answer ALL of them.",
 "2. Each question carries 2 marks. The paper is marked out of 200.",
 "3. Answer on the separate answer sheet provided. Nothing written in this question paper "
 "will be marked.",
 "4. For each question choose the BEST answer and write its letter (A, B, C or D) in the box "
 "marked with the same number as the question.",
 "5. Write clearly. If you change an answer, rub out the first one completely and there is no "
 "need to initial the change.",
 "6. You are advised to spend about 50 seconds on each question and to use any time left at "
 "the end to check your work.",
]

P2_INSTR = [
 "INSTRUCTIONS TO CANDIDATES",
 "1. This paper has 20 essay questions with sub-questions. Answer ALL of them.",
 "2. The marks for each question are printed beside it. The paper is marked out of 200.",
 "3. Write your answers in the spaces provided in this question paper, or in the answer book "
 "if one is given to you.",
 "4. Number your answers exactly as the questions are numbered, and answer the sub-questions "
 "in the order given.",
 "5. Where a question asks for a stated number of points, give that number. Any extra answers "
 "will not be marked.",
 "6. Marks are awarded for correct points, not for repeating the question. Write clearly and "
 "show all your working.",
]

P1_QC = [
 ("Does every question belong to the supplied curriculum scope?",
  "Yes. All 100 items trace to the Basic 7 Integrated Science curriculum, Strands 1 to 5, all "
  "22 sub-strands, each carrying a content standard and an official indicator code."),
 ("Is the paper appropriate for the stated class?",
  "Yes. Every item is set at B7 depth. No calculation is harder than simple arithmetic and no "
  "classification goes beyond what the curriculum names."),
 ("Is the paper genuinely BECE-style?",
  "Yes: 100 four-option objectives answered on a separate sheet, in the BECE Paper 1 format."),
 ("Are there enough application and reasoning questions?",
  "Yes. 58 marks are at Apply level and 10 at Analyse, 68 of 200 (34%). These are the items "
  "where a pupil must work something out rather than recall it."),
 ("Are the distractors plausible?",
  "Yes. Each is drawn from the same content family as the key: a real process at the wrong "
  "stage, a real organism in the wrong habitat, a real component doing the wrong job. None is "
  "obviously absurd."),
 ("Is there only one best answer for each question?",
  "Yes. Every item was reviewed for a single defensible key, and all 100 were machine-checked "
  "so the declared key sits on the correct answer."),
 ("Are the marks internally consistent?",
  "Yes. 100 items x 2 marks = 200, and the strand, sub-strand, cognitive and difficulty tables "
  "all sum to the same figure."),
 ("Does the total add up correctly?",
  "Yes: 200 marks, matching the figure printed on the front page."),
 ("Are the answers in the answer key correct?",
  "Yes. All 100 keys were verified, and re-derived from first principles as a cross-check."),
 ("Is the answer key well balanced?",
  "Yes: 25 of each letter A, B, C and D across the paper, and 5 of each letter in every block "
  "of 20 questions, with no two consecutive answers the same letter."),
 ("Are the questions free from unnecessary ambiguity?",
  "Yes. Completion-style items are written so that only one option completes the sentence "
  "correctly, and question-style items are anchored with a single clear demand."),
 ("Are Ghanaian contexts used naturally and accurately?",
  "Yes: maize and cocoa, streams and boreholes, tro-tro travel, sachet water, iodised salt, "
  "the Kwahu Plateau and a village pond."),
 ("Has any content outside the curriculum been introduced?",
  "No. Every item sits inside the 22 sub-strands. Where a term such as 'malleable' or 'inertia' "
  "appears, it is one the B7 syllabus itself uses."),
 ("Are the questions sufficiently varied?",
  "Yes: definitions, cause-and-effect, ordering, classification, choosing a material for a "
  "purpose, identifying a process from a description, and applying an idea to a new situation."),
]

P2_QC = [
 ("Does every question belong to the supplied curriculum scope?",
  "Yes. All 46 sub-questions trace to the Basic 7 Integrated Science curriculum, Strands 1 to "
  "5, all 22 sub-strands, each carrying a content standard and an official indicator code."),
 ("Is the paper appropriate for the stated class?",
  "Yes. Tasks ask for the number of points a JHS 1 pupil can reasonably produce in two hours - "
  "no more than four separate points in any one sub-question."),
 ("Is the paper genuinely BECE-style?",
  "Yes: 20 essay questions with sub-questions, each carrying a printed mark allocation, in the "
  "BECE Paper 2 format."),
 ("Are there enough application and reasoning questions?",
  "Yes. 48 marks are Apply, 2 Analyse, 6 Evaluate and 4 Create - 60 of 200 (30%). The Create "
  "item is Question 7(b), a fair-test experiment; the Evaluate items are 12(b) and 14(c)."),
 ("Are the marks for each question fitted to its sub-questions?",
  "Yes. Three-part questions carry 12; two-part questions carry 10 or 8 according to how much "
  "each part demands. Every N-mark sub-question asks for N things."),
 ("Does each question's total match the sum of its parts?",
  "Yes. All 20 were machine-checked: the printed total equals the sum of the sub-question "
  "marks in every case."),
 ("Are the marks internally consistent?",
  "Yes. The 20 totals are 12, 10, 10 and 8 repeated five times, giving 200, and the strand, "
  "sub-strand, cognitive and difficulty tables all agree."),
 ("Does the total add up correctly?",
  "Yes: 200 marks, matching the figure printed on the front page."),
 ("Are the answers in the marking scheme correct?",
  "Yes. All 46 sub-questions have expected answers and a marking note, each checked against "
  "the question it belongs to."),
 ("Does the marking scheme give usable guidance?",
  "Yes. Every note covers partial credit, acceptable alternatives, common wrong answers and "
  "method marks. Notes that bite: the alimentary canal stops at the first sequence error; a "
  "food chain starting with an animal scores 0; 'sunlight' is not accepted for germination."),
 ("Are the questions free from unnecessary ambiguity?",
  "Yes. Open items are anchored with 'name four', 'state three', 'explain TWO' and 'give ONE' "
  "plus the mark allocation, so a pupil can see exactly how much to write."),
 ("Are Ghanaian contexts used naturally and accurately?",
  "Yes: one farmer with a single small plot, a village pond, unsafe stream water, a Ghanaian "
  "factory choosing its energy source, and local landforms."),
 ("Has any content outside the curriculum been introduced?",
  "No. Every sub-question sits inside the 22 sub-strands, and nothing is tested that the B7 "
  "syllabus does not name."),
 ("Are the questions sufficiently varied?",
  "Yes: explaining, comparing, describing a process, ordering, designing an experiment, "
  "evaluating a choice, tracing an energy change and justifying a decision."),
]

P1_NOTES = [
 "Sit this paper separately from Paper 2. One hour thirty minutes is about 50 seconds per "
 "question, which is enough if the class has practised working at speed.",
 "The questions here are deliberately different from the 22 sub-strand papers - no item is "
 "repeated from any of them, so a class can sit both without seeing the same question twice.",
 "Print the answer sheet separately. The key is balanced at 25 of each letter and 5 of each "
 "letter in every block of 20, so a pupil cannot gain anything by guessing a pattern.",
 "The hardest items are the Apply and Analyse ones, 68 marks in total. They are where a pupil "
 "must work something out rather than recall it, and they are identified in the source module, "
 "not on the paper.",
 "If you need a shorter test, draw a block of 20 questions - each block covers all five strands "
 "and has a balanced answer key, so any block stands alone as a fair 40-mark test.",
]

P2_NOTES = [
 "Sit this paper separately from Paper 1. Two hours for 46 sub-questions is about two and a "
 "half minutes each, which is comfortable but not generous - pupils who rewrite the question "
 "will run out of time.",
 "The marks are fitted to the sub-questions: three-part questions carry 12, two-part questions "
 "carry 10 or 8. Tell the class this so they can budget their time by marks rather than by "
 "question count.",
 "Question 7(b) is the only Create item and the one pupils find hardest. They can name the "
 "conditions a seed needs but cannot set up a fair test. The marking note requires two groups, "
 "one difference, the expected result and a conclusion - teach that shape explicitly.",
 "Questions 12(b) and 14(c) are the Evaluate items and both are capped at 1 mark if the pupil "
 "makes a choice with no reason. There is no single right answer to either.",
 "Question 9(a) is marked in order and stops at the first part that is out of sequence - warn "
 "the class, it is the easiest place to lose 5 marks through carelessness.",
 "Question 11(b) scores 0 if the food chain begins with an animal, and 0 again if the arrows "
 "point the wrong way. The arrow means 'is eaten by' and the chain always starts with a plant.",
]


# ------------------------------------------------------------------ DOCX ----
def new_doc():
    d = Document()
    s = d.sections[0]
    s.left_margin = Inches(0.7); s.right_margin = Inches(0.7)
    s.top_margin = Inches(0.7); s.bottom_margin = Inches(0.6)
    st = d.styles["Normal"]; st.font.name = "Calibri"; st.font.size = Pt(11)
    return d


def _sf(run, size=11, bold=False, italic=False, mono=False, color=None):
    run.font.size = Pt(size); run.bold = bold; run.italic = italic
    run.font.name = "Consolas" if mono else "Calibri"
    if color: run.font.color.rgb = color
    return run


class W:
    def __init__(self, doc): self.doc = doc

    def p(self, text="", size=11, bold=False, italic=False, align=None, mono=False,
          sb=0, sa=4, left=None):
        p = self.doc.add_paragraph()
        if align == "c": p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        elif align == "j": p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        if left: p.paragraph_format.left_indent = Inches(left)
        p.paragraph_format.space_before = Pt(sb); p.paragraph_format.space_after = Pt(sa)
        if text: _sf(p.add_run(text), size, bold, italic, mono)
        return p

    def rule(self):
        p = self.doc.add_paragraph()
        p.paragraph_format.space_after = Pt(6); p.paragraph_format.space_before = Pt(2)
        _sf(p.add_run("_" * 88), 9, color=RGBColor(0x99, 0x99, 0x99))

    def table(self, headers, rows, widths=None, size=9):
        t = self.doc.add_table(rows=1, cols=len(headers)); t.style = "Table Grid"
        t.alignment = WD_TABLE_ALIGNMENT.CENTER
        for i, h in enumerate(headers):
            c = t.rows[0].cells[i]; c.text = ""
            pp = c.paragraphs[0]; pp.alignment = WD_ALIGN_PARAGRAPH.CENTER
            _sf(pp.add_run(str(h)), size, bold=True)
        for row in rows:
            cs = t.add_row().cells
            for i, v in enumerate(row):
                cs[i].text = ""
                pp = cs[i].paragraphs[0]; pp.paragraph_format.space_after = Pt(1)
                _sf(pp.add_run(str(v)), size)
        if widths:
            for r in t.rows:
                for i, wd in enumerate(widths): r.cells[i].width = Inches(wd)


def front(w, title, sub, time_, marks, instr):
    w.p(SCHOOL, 14, True, align="c", sa=2)
    w.p(SUBJECT, 12, True, align="c", sa=2)
    w.p(EXAM, 12, True, align="c", sa=2)
    w.p(title, 12, True, align="c", sa=6)
    w.rule()
    w.p(sub, 10, True, align="c", sa=4)
    w.p("CLASS: %s" % CLASS, 10, align="c", sa=1)
    w.p("TIME: %s" % time_, 10, align="c", sa=1)
    w.p("MARKS: %s          %s" % (marks, YEAR), 10, True, align="c", sa=4)
    w.rule()
    for i, t in enumerate(instr):
        w.p(t, 9.5, bold=(i == 0), sa=2)
    w.rule()


def blueprint(w, marks, items, smarks, sitems, cog, diff_, total, label):
    w.p("BLUEPRINT / TEST SPECIFICATION - %s" % label, 13, True, align="c", sa=4)
    w.p("Summary 1 - Coverage by Strand", 11, True, sb=4, sa=3)
    rows = [[STRAND_NAME[k], k, sitems[k], smarks[k], "%.1f%%" % (100.0 * smarks[k] / total)]
            for k in sorted(smarks)]
    rows.append(["TOTAL", "-", sum(sitems.values()), sum(smarks.values()), "100%"])
    w.table(["Strand", "Code", "No. of Items", "Marks", "% of Marks"], rows,
            [3.0, 0.7, 1.0, 0.8, 1.1])
    w.p("Summary 2 - Coverage by Sub-strand", 11, True, sb=8, sa=3)
    rows = [[TOPIC[k], CS_BY_TOPIC[k], items[k], marks[k], "%.1f%%" % (100.0 * marks[k] / total)]
            for k in sorted(marks, key=lambda x: (x[1:2], float(x[2:])))]
    rows.append(["TOTAL", "-", sum(items.values()), sum(marks.values()), "100%"])
    w.table(["Sub-strand / Content Area", "Content Standard", "No. of Items", "Marks",
             "% of Marks"], rows, [2.9, 1.9, 0.8, 0.7, 0.9], 8)
    w.p("Summary 3 - Cognitive Level", 11, True, sb=8, sa=3)
    rows = [[k, cog[k], "%.1f%%" % (100.0 * cog[k] / total)] for k in ORDER]
    rows.append(["TOTAL", sum(cog.values()), "100%"])
    w.table(["Cognitive Level", "Marks", "% of Marks"], rows, [1.8, 1.0, 1.1])
    w.p("Summary 4 - Difficulty", 11, True, sb=8, sa=3)
    rows = [[k, diff_[k], "%.1f%%" % (100.0 * diff_[k] / total)]
            for k in ("Easy", "Moderate", "Challenging")]
    rows.append(["TOTAL", sum(diff_.values()), "100%"])
    w.table(["Difficulty", "Marks", "% of Marks"], rows, [1.8, 1.0, 1.1])


def qc_block(w, qc, notes):
    w.p("QUALITY-CONTROL SUMMARY", 13, True, align="c", sa=4)
    w.p("Every question was checked against the following fourteen points.",
        9.5, italic=True, align="c", sa=6)
    for i, (q_, a_) in enumerate(qc, 1):
        w.p("%d. %s" % (i, q_), 10, bold=True, sa=2, left=0.28)
        w.p(a_, 10, sa=5, left=0.28)
    w.p("EXAMINER NOTES (for the teacher, not for candidates)", 11, True, sb=8, sa=4)
    for n in notes:
        w.p("- " + n, 10, sa=3, left=0.3)


# ---------------------------------------------------------- PAPER 1 ---------
def paper1_docx(path):
    d = new_doc(); w = W(d)
    front(w, "PAPER 1 - OBJECTIVE TEST",
          "Answer ALL 100 questions on the separate answer sheet.",
          "1 hour 30 minutes", "200", P1_INSTR)
    w.p("SECTION A - OBJECTIVE TEST (100 questions)", 13, True, align="c", sa=2)
    w.p("Each question carries 2 marks. Total = 200 marks. Choose the BEST answer and write "
        "its letter (A, B, C or D) against the question number on your answer sheet.",
        10, italic=True, align="c", sa=6)
    for i, (q, opts, ans, tp, cog, dl) in enumerate(MCQ, 1):
        w.p("%d. %s" % (i, q), 10.5, sa=2)
        for L, o in zip("ABCD", opts):
            w.p("%s. %s" % (L, o), 10, sa=0, left=0.28)
    d.add_page_break()
    w.p("ANSWER KEY - PAPER 1", 13, True, align="c", sa=4)
    w.p("Each question carries 2 marks.", 9.5, italic=True, align="c", sa=6)
    rows = []
    for r0 in range(25):
        row = []
        for k in range(4):
            n = r0 + 25 * k + 1
            row += [n, MCQ[n - 1][2]] if n <= 100 else ["", ""]
        rows.append(row)
    w.table(["Q", "Ans", "Q", "Ans", "Q", "Ans", "Q", "Ans"], rows,
            [0.45, 0.5, 0.45, 0.5, 0.45, 0.5, 0.45, 0.5])
    d.add_page_break()
    blueprint(w, AM, AI, SAM, SAI, CA, DA, TOT_A, "PAPER 1 (200 marks)")
    d.add_page_break()
    qc_block(w, P1_QC, P1_NOTES)
    d.save(path)


# ---------------------------------------------------------- PAPER 2 ---------
def paper2_docx(path):
    d = new_doc(); w = W(d)
    front(w, "PAPER 2 - ESSAY",
          "Answer ALL 20 questions. The marks for each are printed beside it.",
          "2 hours", "200", P2_INSTR)
    w.p("SECTION B - ESSAY QUESTIONS (20 questions)", 13, True, align="c", sa=2)
    w.p("Answer ALL questions. The marks for each question are printed beside it. "
        "Total = 200 marks.", 10, italic=True, align="c", sa=6)
    for qb in SECTION_B:
        w.p("Question %d   [%d marks]   %s" % (qb["num"], qb["total"], TOPIC[qb["topic"]]),
            11, True, sb=8, sa=3)
        w.p(qb["stem"], 10.5, sa=4)
        for (lab, text, mk, cog, tp, dl) in qb["parts"]:
            p = d.add_paragraph()
            p.paragraph_format.left_indent = Inches(0.25)
            p.paragraph_format.space_after = Pt(3)
            _sf(p.add_run("%s  %s" % (lab, text)), 10.5)
            _sf(p.add_run("   [%d mark%s]" % (mk, "" if mk == 1 else "s")), 10, bold=True)
        w.rule()
    d.add_page_break()
    w.p("MARKING SCHEME - PAPER 2 (200 marks)", 13, True, align="c", sa=4)
    w.p("General rules: (1) Accept any other correct and relevant answer. (2) Award marks for "
        "correct points, not for repeating the question. (3) For procedures, award method marks. "
        "(4) Do not deduct marks for spelling unless the meaning is changed. (5) Where a "
        "candidate gives more answers than are asked for, mark only the first ones up to the "
        "number asked for. (6) Each sub-question is marked out of the figure printed beside it.",
        9, italic=True, sa=6)
    for qb in SECTION_B:
        w.p("Question %d   [%d marks]" % (qb["num"], qb["total"]), 11, True, sb=8, sa=3)
        for (lab, ans_list, note) in MARKING[qb["num"]]:
            w.p(lab, 10.5, True, sb=3, sa=2)
            for a_ in ans_list:
                w.p("- " + a_, 10, sa=2, left=0.3)
            w.p("Marking note: " + note, 9.5, italic=True, sa=4, left=0.3)
        w.rule()
    d.add_page_break()
    blueprint(w, BM, BI, SBM, SBI, CB, DB, TOT_B, "PAPER 2 (200 marks)")
    d.add_page_break()
    qc_block(w, P2_QC, P2_NOTES)
    d.save(path)


# ------------------------------------------------------------------ MD ------
def paper1_md(path):
    o = []
    a = o.append
    a("# %s" % SCHOOL); a(SUBJECT)
    a("## %s" % EXAM); a("### PAPER 1 - OBJECTIVE TEST")
    a("**Class:** %s   **Time:** 1 hour 30 minutes   **Marks:** 200   **%s**" % (CLASS, YEAR))
    a(""); a("---"); a("")
    for t in P1_INSTR:
        a(("**%s**" % t) if t.isupper() else t)
        a("")
    a("---"); a("")
    a("## SECTION A - OBJECTIVE TEST (100 questions)"); a("")
    a("*Each question carries 2 marks. Total = 200 marks.*"); a("")
    for i, (q, opts, ans, tp, cog, dl) in enumerate(MCQ, 1):
        a("%d. %s" % (i, q)); a("")
        for L, opt in zip("ABCD", opts): a("   %s. %s" % (L, opt))
        a("")
    a("---"); a("")
    a("## ANSWER KEY - PAPER 1"); a("")
    a("| Q | Ans | Q | Ans | Q | Ans | Q | Ans |"); a("|---|---|---|---|---|---|---|---|")
    for r0 in range(25):
        row = []
        for k in range(4):
            n = r0 + 25 * k + 1
            row += [str(n), MCQ[n - 1][2]] if n <= 100 else ["", ""]
        a("| " + " | ".join(row) + " |")
    a(""); a("---"); a("")
    md_blueprint(a, AM, AI, SAM, SAI, CA, DA, TOT_A, "PAPER 1 (200 marks)")
    md_qc(a, P1_QC, P1_NOTES)
    open(path, "w", encoding="utf-8").write("\n".join(o) + "\n")


def paper2_md(path):
    o = []
    a = o.append
    a("# %s" % SCHOOL); a(SUBJECT)
    a("## %s" % EXAM); a("### PAPER 2 - ESSAY")
    a("**Class:** %s   **Time:** 2 hours   **Marks:** 200   **%s**" % (CLASS, YEAR))
    a(""); a("---"); a("")
    for t in P2_INSTR:
        a(("**%s**" % t) if t.isupper() else t)
        a("")
    a("---"); a("")
    a("## SECTION B - ESSAY QUESTIONS (20 questions)"); a("")
    a("*Answer ALL questions. The marks for each are printed beside it. Total = 200 marks.*")
    a("")
    for qb in SECTION_B:
        a("### Question %d  [%d marks]  %s" % (qb["num"], qb["total"], TOPIC[qb["topic"]]))
        a(""); a(qb["stem"]); a("")
        for (lab, text, mk, cog, tp, dl) in qb["parts"]:
            a("- **%s** %s  *[%d mark%s]*" % (lab, text, mk, "" if mk == 1 else "s"))
        a("")
    a("---"); a("")
    a("## MARKING SCHEME - PAPER 2 (200 marks)"); a("")
    a("*General rules: (1) Accept any other correct and relevant answer. (2) Award marks for "
      "correct points, not for repeating the question. (3) For procedures, award method marks. "
      "(4) Do not deduct marks for spelling unless the meaning is changed. (5) Where a "
      "candidate gives more answers than are asked for, mark only the first ones up to the "
      "number asked for. (6) Each sub-question is marked out of the figure printed beside it.*")
    a("")
    for qb in SECTION_B:
        a("### Question %d  [%d marks]" % (qb["num"], qb["total"])); a("")
        for (lab, ans_list, note) in MARKING[qb["num"]]:
            a("**%s**" % lab); a("")
            for x in ans_list: a("- %s" % x)
            a(""); a("*Marking note: %s*" % note); a("")
        a("---"); a("")
    md_blueprint(a, BM, BI, SBM, SBI, CB, DB, TOT_B, "PAPER 2 (200 marks)")
    md_qc(a, P2_QC, P2_NOTES)
    open(path, "w", encoding="utf-8").write("\n".join(o) + "\n")


def md_blueprint(a, marks, items, smarks, sitems, cog, diff_, total, label):
    a("## BLUEPRINT / TEST SPECIFICATION - %s" % label); a("")
    a("### Summary 1 - Coverage by Strand"); a("")
    a("| Strand | Code | No. of Items | Marks | % of Marks |"); a("|---|---|---|---|---|")
    for k in sorted(smarks):
        a("| %s | %s | %d | %d | %.1f%% |" % (STRAND_NAME[k], k, sitems[k], smarks[k],
                                              100.0 * smarks[k] / total))
    a("| **TOTAL** | - | **%d** | **%d** | **100%%** |" % (sum(sitems.values()),
                                                           sum(smarks.values())))
    a(""); a("### Summary 2 - Coverage by Sub-strand"); a("")
    a("| Sub-strand / Content Area | Content Standard | No. of Items | Marks | % of Marks |")
    a("|---|---|---|---|---|")
    for k in sorted(marks, key=lambda x: (x[1:2], float(x[2:]))):
        a("| %s | %s | %d | %d | %.1f%% |" % (TOPIC[k], CS_BY_TOPIC[k], items[k], marks[k],
                                              100.0 * marks[k] / total))
    a("| **TOTAL** | - | **%d** | **%d** | **100%%** |" % (sum(items.values()),
                                                           sum(marks.values())))
    a(""); a("### Summary 3 - Cognitive Level"); a("")
    a("| Cognitive Level | Marks | % of Marks |"); a("|---|---|---|")
    for k in ORDER:
        a("| %s | %d | %.1f%% |" % (k, cog[k], 100.0 * cog[k] / total))
    a("| **TOTAL** | **%d** | **100%%** |" % sum(cog.values()))
    a(""); a("### Summary 4 - Difficulty"); a("")
    a("| Difficulty | Marks | % of Marks |"); a("|---|---|---|")
    for k in ("Easy", "Moderate", "Challenging"):
        a("| %s | %d | %.1f%% |" % (k, diff_[k], 100.0 * diff_[k] / total))
    a("| **TOTAL** | **%d** | **100%%** |" % sum(diff_.values()))
    a(""); a("---"); a("")


def md_qc(a, qc, notes):
    a("## QUALITY-CONTROL SUMMARY"); a("")
    a("*Every question was checked against the following fourteen points.*"); a("")
    for i, (q_, ans_) in enumerate(qc, 1):
        a("**%d. %s**" % (i, q_)); a(""); a(ans_); a("")
    a("---"); a("")
    a("## EXAMINER NOTES (for the teacher, not for candidates)"); a("")
    for n in notes: a("- %s" % n); a("")


if __name__ == "__main__":
    base = "/home/user/Basic7_SPECIAL_MOCK"
    paper1_docx(base + "_PAPER1_Objectives.docx")
    paper2_docx(base + "_PAPER2_Essay.docx")
    paper1_md(base + "_PAPER1_Objectives.md")
    paper2_md(base + "_PAPER2_Essay.md")
    print("Paper 1 : 100 MCQ, 1 h 30 min, 200 marks")
    print("Paper 2 : 20 essays / %d sub-parts, 2 h, 200 marks" % NB)
    print("strand marks P1:", dict(sorted(SAM.items())), "=", sum(SAM.values()))
    print("strand marks P2:", dict(sorted(SBM.items())), "=", sum(SBM.values()))
    print("keys:", {L: sum(1 for q in MCQ if q[2] == L) for L in "ABCD"})
