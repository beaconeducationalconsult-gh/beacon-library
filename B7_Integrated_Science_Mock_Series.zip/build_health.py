# -*- coding: utf-8 -*-
"""Basic 7 Integrated Science mock - Strand 5 Sub-strand 2: HUMAN HEALTH, part 1 of 2.
Covers topics 17.1 to 17.3 (food nutrients and the human body; deficiency diseases, their
causes, symptoms, effects and prevention; and night blindness, rickets, scurvy, kwashiorkor and
anaemia). 100 marks.
Indicators sourced from the official NaCCA Science CCP curriculum (B7/JHS1-B9/JHS3, Sept 2020),
Strand 5: Humans and the Environment, Sub-strand 2: Human Health, printed page 45.
Content standard: B7/JHS1.5.2.1. Viral diseases (B7/JHS1.5.2.2) are in the companion paper."""

SCHOOL = "[SCHOOL NAME]"
SUBJECT = "INTEGRATED SCIENCE (SCIENCE)"
EXAM = "END-OF-TERM MOCK EXAMINATION"
CLASS = "Basic 7 (JHS 1)"
TIME = "2 hours (Suggested: Section A - 40 min; Section B - 80 min)"
MARKS = "100"
YEAR = "2025/2026 Academic Year"

STRAND = "Humans and the Environment"
SUBSTRAND = "Human Health (Part 1: Food Nutrients and Deficiency Diseases)"

TOPIC = {
    "17.1": "17.1 Food Nutrients and the Human Body",
    "17.2": "17.2 Deficiency Diseases: Causes, Symptoms, Effects and Prevention",
    "17.3": "17.3 Night Blindness, Rickets, Scurvy, Kwashiorkor and Anaemia",
}

CS = "B7/JHS1.5.2.1"
CS_BY_TOPIC = {k: "B7/JHS1.5.2.1" for k in ["17.1", "17.2", "17.3"]}
CS_TEXT = ("Demonstrate knowledge of common deficiency diseases of humans, their causes, "
           "symptoms, effects and prevention")

IND = {
    "17.1": "B7/JHS1.5.2.1.1 (Ex. 1)",
    "17.2": "B7/JHS1.5.2.1.1 (Ex. 2, 3)",
    "17.3": "B7/JHS1.5.2.1.1 (Ex. 3, 4)",
}
IND_TEXT = {
    "17.1": "Explain the relationship between food nutrients and common deficiency diseases and "
            "how they affect humans. Ex. 1: Name and analyse food nutrients such as "
            "carbohydrates, proteins, fatty acids, and their uses in the human body.",
    "17.2": "Explain the relationship between food nutrients and common deficiency diseases and "
            "how they affect humans. Ex. 2, 3: Discuss and make presentations on deficiency "
            "diseases associated with lack of food nutrients such as carbohydrates, proteins, "
            "fatty acids, vitamins and others in the human body; relate the nutrients they gain "
            "or lack to the foods they normally eat, e.g. lack of protein leads to kwashiorkor, "
            "lack of iron leads to anaemia.",
    "17.3": "Explain the relationship between food nutrients and common deficiency diseases and "
            "how they affect humans. Ex. 3, 4: Relate the nutrients they gain or lack to the "
            "foods they normally eat; describe symptoms, effects and prevention of common "
            "deficiency diseases such as night blindness, rickets, scurvy, kwashiorkor and "
            "others.",
}
CC = {"17.1": "CP, CC, DL, CI", "17.2": "CP, CC, DL, CI", "17.3": "CP, CC, DL, CI"}

# ---------------------------------------------------------------- SECTION A
# (question, [A,B,C,D], answer, topic, cognitive, difficulty)
MCQ = [
 ("Carbohydrates are needed by the body mainly to",
  ["build muscles", "carry oxygen in the blood", "provide energy", "fight disease"],
  "C", "17.1", "Remember", "Easy"),
 ("Which of these is a good source of carbohydrate?",
  ["rice", "fish", "palm oil", "orange"],
  "A", "17.1", "Remember", "Easy"),
 ("Proteins are needed by the body mainly for",
  ["keeping the body warm", "providing energy quickly", "fighting infection only",
   "growth and the repair of worn-out tissues"],
  "D", "17.1", "Understand", "Moderate"),
 ("Which of these foods is richest in protein?",
  ["cassava", "beans", "sugar", "cooking oil"],
  "B", "17.1", "Apply", "Easy"),
 ("Fats and oils in the diet",
  ["provide energy and help to keep the body warm", "build teeth and bones only",
   "help the blood to clot", "prevent night blindness"],
  "A", "17.1", "Understand", "Moderate"),
 ("Which of these is a good source of fat or oil?",
  ["plantain", "salt", "groundnut oil", "cabbage"],
  "C", "17.1", "Remember", "Easy"),
 ("Vitamin A is important because it",
  ["heals wounds", "makes blood", "builds bones",
   "keeps the eyes healthy and helps vision in dim light"],
  "D", "17.1", "Understand", "Moderate"),
 ("Vitamin C is needed to",
  ["prevent rickets", "keep the gums healthy and heal wounds", "prevent anaemia",
   "make the hair grow"],
  "B", "17.1", "Understand", "Moderate"),
 ("Vitamin D helps the body to",
  ["see in the dark", "fight malaria",
   "absorb calcium so that bones and teeth grow hard", "clot the blood"],
  "C", "17.1", "Understand", "Moderate"),
 ("Iron is needed in the diet to",
  ["make haemoglobin, which carries oxygen in the blood", "make the teeth white",
   "prevent scurvy", "give the body energy"],
  "A", "17.1", "Understand", "Moderate"),
 ("Calcium and phosphorus are needed mainly to",
  ["make the skin soft", "carry oxygen", "provide energy", "build strong bones and teeth"],
  "D", "17.1", "Understand", "Moderate"),
 ("A meal or a diet that contains all the classes of food nutrients in the right amounts is "
  "called",
  ["a staple food", "a balanced diet", "a deficiency food", "a processed food"],
  "B", "17.1", "Remember", "Moderate"),

 ("A deficiency disease is",
  ["a disease caused by germs", "a disease caught from another person",
   "a disease caused by a lack of an essential nutrient in the diet",
   "a disease caused by too much exercise"],
  "C", "17.2", "Understand", "Moderate"),
 ("A person who does not eat enough protein may develop",
  ["kwashiorkor", "night blindness", "scurvy", "rickets"],
  "A", "17.2", "Apply", "Moderate"),
 ("The lack of vitamin A in the diet causes",
  ["beriberi", "goitre", "anaemia", "night blindness"],
  "D", "17.2", "Apply", "Moderate"),
 ("Goitre, a swelling in the front of the neck, is caused by a lack of",
  ["iron", "iodine", "calcium", "vitamin C"],
  "B", "17.2", "Understand", "Moderate"),
 ("Which of these is NOT a cause of deficiency diseases?",
  ["eating too much fruit", "not eating enough of one nutrient",
   "eating only one kind of food all the time", "a poor and unbalanced diet"],
  "A", "17.2", "Analyse", "Challenging"),
 ("The symptoms of a deficiency disease are",
  ["the drugs used to treat it", "the foods that prevent it",
   "the signs a doctor or a nurse looks for in the patient", "the germs that cause it"],
  "C", "17.2", "Remember", "Easy"),
 ("One effect of a deficiency disease on a child is that it",
  ["makes the child grow taller", "makes the child run faster", "makes the child's hair black",
   "slows down growth and leaves the child weak and ill"],
  "D", "17.2", "Apply", "Easy"),
 ("Deficiency diseases can be prevented mainly by",
  ["taking antibiotics", "eating a balanced diet with all the needed nutrients",
   "sleeping for ten hours every night", "drinking only water"],
  "B", "17.2", "Understand", "Easy"),
 ("Eating only one kind of food all the time can lead to a deficiency disease because",
  ["one food does not contain all the nutrients the body needs",
   "the body gets bored with the food", "the food becomes poisonous", "the food costs too much"],
  "A", "17.2", "Understand", "Moderate"),
 ("Which of the following is a mineral deficiency?",
  ["scurvy", "kwashiorkor", "anaemia caused by lack of iron", "night blindness"],
  "C", "17.2", "Apply", "Moderate"),
 ("A child who always looks pale and tires very easily may be suffering from",
  ["rickets", "scurvy", "night blindness", "anaemia"],
  "D", "17.2", "Apply", "Challenging"),
 ("Which nutrient deficiency causes rickets?",
  ["iron", "vitamin D, together with calcium", "vitamin C", "protein"],
  "B", "17.2", "Remember", "Easy"),
 ("Scurvy is caused by a lack of",
  ["vitamin C", "vitamin A", "vitamin D", "iron"],
  "A", "17.2", "Remember", "Easy"),
 ("Which of these meals would best help to prevent kwashiorkor?",
  ["gari and sugar", "palm oil and salt", "beans, fish and eggs", "cassava and plantain"],
  "C", "17.2", "Apply", "Moderate"),
 ("A nurse wants to prevent night blindness in a village. The best advice is to eat more",
  ["rice and bread", "red palm oil, eggs and dark green leafy vegetables", "sugar and salt",
   "cooking oil and flour"],
  "B", "17.2", "Apply", "Moderate"),

 ("Night blindness is the inability to",
  ["hear properly at night", "sleep at night", "walk at night",
   "see clearly in dim light or at night"],
  "D", "17.3", "Understand", "Easy"),
 ("The sign that shows a child has night blindness is that the child",
  ["cries all night", "cannot sleep at all",
   "bumps into things and cannot find the way when it is dark", "snores loudly"],
  "C", "17.3", "Understand", "Easy"),
 ("Rickets affects mainly",
  ["the eyes", "the bones", "the hair", "the teeth only"],
  "B", "17.3", "Understand", "Easy"),
 ("A child with rickets is likely to have",
  ["bow legs and soft, bent bones", "bleeding gums", "a swollen belly", "a very high fever"],
  "A", "17.3", "Understand", "Easy"),
 ("Scurvy causes",
  ["bow legs", "night blindness", "a swollen stomach",
   "bleeding and swollen gums and slow healing of wounds"],
  "D", "17.3", "Understand", "Easy"),
 ("Kwashiorkor is caused by a lack of",
  ["vitamin A", "iron", "protein", "vitamin D"],
  "C", "17.3", "Remember", "Easy"),
 ("A child with kwashiorkor often has",
  ["very long legs", "a swollen belly, thin arms and legs, and reddish hair", "blue eyes",
   "a very high fever only"],
  "B", "17.3", "Understand", "Moderate"),
 ("Anaemia is caused mainly by a lack of",
  ["iron", "calcium", "vitamin A", "vitamin C"],
  "A", "17.3", "Remember", "Easy"),
 ("A person with anaemia feels tired and weak because",
  ["the heart beats too slowly", "the muscles are too small", "the food is not digested",
   "the blood cannot carry enough oxygen to the body"],
  "D", "17.3", "Understand", "Challenging"),
 ("Scurvy can be prevented by eating",
  ["more rice", "more sugar", "oranges, mangoes, tomatoes and other fruits", "more salt"],
  "C", "17.3", "Apply", "Moderate"),
 ("Rickets can be prevented by",
  ["drinking more water",
   "eating foods with vitamin D and calcium and getting some sunlight on the skin",
   "sleeping longer", "eating more sugar"],
  "B", "17.3", "Apply", "Moderate"),
 ("Anaemia can be prevented by eating foods rich in iron such as",
  ["liver, beans and dark green leafy vegetables", "sugar and salt", "white bread and rice",
   "cooking oil"],
  "A", "17.3", "Apply", "Moderate"),
 ("Which of these would best prevent kwashiorkor in a community?",
  ["building more roads", "giving everyone an injection", "closing the schools",
   "teaching families to add beans, fish or eggs to children's meals"],
  "D", "17.3", "Apply", "Challenging"),
]

# ------------------------------------------------------------------- TABLES
NUTRIENT_HEADERS = ["Food nutrient", "One source in Ghanaian foods", "What it does in the body"]
NUTRIENT_ROWS = [
 ["Carbohydrate", "(i)", "provides energy for work, play and keeping warm"],
 ["Protein", "(ii)", "(iii)"],
 ["Fat and oil", "(iv)", "(v)"],
 ["Vitamin A", "(vi)", "keeps the eyes healthy and helps vision in dim light"],
]

# ---------------------------------------------------------------- SECTION B
SECTION_B = [
 dict(
   num=1, total=10, topic="17.1",
   stem="The food we eat contains several classes of nutrients, and the body needs all of them.",
   parts=[
     ("(a)", "Name the five main classes of food nutrients.",
      5, "Remember", "17.1", "Easy"),
     ("(b)", "Choose three of the classes you named in (a) and state one use of each in the "
             "body.", 3, "Understand", "17.1", "Easy"),
     ("(c)", "Explain why a growing child needs plenty of protein in the diet.",
      2, "Understand", "17.1", "Challenging"),
   ]),
 dict(
   num=2, total=8, topic="17.1",
   stem="The table below shows some of the food nutrients the body needs. Study it and answer "
        "the questions that follow.",
   table="nutrient",
   parts=[
     ("(a)", "Copy and complete the table.", 6, "Understand", "17.1", "Challenging"),
     ("(b)", "Name two mineral nutrients needed by the body and state one food source of each.",
      2, "Apply", "17.1", "Moderate"),
   ]),
 dict(
   num=3, total=9, topic="17.2",
   stem="A person can eat until the stomach is full and still become ill from what is missing.",
   parts=[
     ("(a)", "Explain what is meant by a deficiency disease.",
      3, "Understand", "17.2", "Moderate"),
     ("(b)", "State three causes of deficiency diseases.", 3, "Understand", "17.2", "Easy"),
     ("(c)", "Explain why eating only one kind of food can cause a deficiency disease.",
      3, "Understand", "17.2", "Moderate"),
   ]),
 dict(
   num=4, total=8, topic="17.2",
   stem="Doctors and nurses talk about the symptoms of a disease and the effects it has on the "
        "patient.",
   parts=[
     ("(a)", "Explain the difference between the symptoms and the effects of a disease.",
      4, "Understand", "17.2", "Moderate"),
     ("(b)", "Some schools give children vitamin tablets. Do you think that is better than "
             "teaching families to eat a balanced diet? Give two reasons for your answer.",
      4, "Evaluate", "17.2", "Moderate"),
   ]),
 dict(
   num=5, total=9, topic="17.3",
   stem="Night blindness, rickets and scurvy are three common deficiency diseases.",
   parts=[
     ("(a)", "For each of the following diseases, name the nutrient whose lack causes it: night "
             "blindness; rickets; scurvy.", 3, "Understand", "17.3", "Moderate"),
     ("(b)", "State one symptom of each of the following: night blindness; rickets; scurvy.",
      3, "Remember", "17.3", "Easy"),
     ("(c)", "Explain how rickets can be prevented.", 3, "Apply", "17.3", "Moderate"),
   ]),
 dict(
   num=6, total=8, topic="17.3",
   stem="Kwashiorkor and anaemia are two deficiency diseases often seen in young children.",
   parts=[
     ("(a)", "State the nutrient whose lack causes kwashiorkor, and state two symptoms of the "
             "disease.", 3, "Understand", "17.3", "Moderate"),
     ("(b)", "Explain why a child with anaemia is always tired and weak.",
      3, "Analyse", "17.3", "Moderate"),
     ("(c)", "State two foods that would help to prevent anaemia.",
      2, "Remember", "17.3", "Moderate"),
   ]),
 dict(
   num=7, total=8, topic="17.3",
   stem="Your class visits a village where several children look unwell.",
   parts=[
     ("(a)", "In the village, some children have swollen bellies, thin arms and legs and "
             "reddish hair, and others cannot find their way in the evening. Name the "
             "deficiency disease in each case and the nutrient that is lacking.",
      4, "Apply", "17.3", "Challenging"),
     ("(b)", "Your class has been asked to help the village. Describe what you would tell the "
             "families to do, and explain why it would help.",
      4, "Create", "17.3", "Challenging"),
   ]),
]

# ------------------------------------------------------- MARKING SCHEME
MARKING = {
 1: [
   ("(a)", ["Carbohydrates", "Proteins", "Fats and oils (fatty acids)", "Vitamins",
            "Mineral salts", "Water", "Roughage or fibre"],
    "1 mark each for any FIVE correct classes (5 marks). Accept any five of the seven. Do NOT "
    "accept a named food such as 'rice' or 'beans' - the question asks for the CLASS of "
    "nutrient."),
   ("(b)", ["Carbohydrate - provides energy for work, play and warmth.",
            "Protein - builds the body and repairs worn-out tissues.",
            "Fat and oil - provides energy, keeps the body warm and helps the body absorb some "
            "vitamins.",
            "Vitamin - protects the body from disease and keeps parts such as the eyes and gums "
            "healthy.",
            "Mineral salt - builds hard parts such as bones and teeth, and helps body processes "
            "such as making blood.",
            "Water - carries substances round the body and helps to control body temperature.",
            "Roughage or fibre - helps the food to move through the gut and prevents "
            "constipation."],
    "1 mark for each class correctly matched to a correct use (3 marks). The class must be one "
    "of those named in (a) and the use must belong to THAT class; award no mark for a correct "
    "use attached to the wrong class."),
   ("(c)", ["A child's body is growing, so new tissue is being made all the time.",
            "Protein is the nutrient the body uses to build new tissue and to repair worn-out "
            "tissue.", "Without enough protein the child stops growing properly and becomes "
            "weak.", "A child that lacks protein over a long time may develop kwashiorkor."],
    "1 mark each for any TWO correct points (2 marks). The key idea is that protein BUILDS "
    "tissue and a growing child is making new tissue. Do NOT accept 'protein gives energy' on "
    "its own."),
 ],
 2: [
   ("(a)", ["(i) rice, maize, yam, cassava, plantain, gari, bread, or any starchy food",
            "(ii) fish, meat, eggs, beans, groundnuts, soya beans, milk, or any protein food",
            "(iii) growth, and the repair and replacement of worn-out body tissues",
            "(iv) palm oil, groundnut oil, coconut, shea butter, margarine, or any fatty food",
            "(v) provides energy, keeps the body warm, and helps the body absorb some vitamins",
            "(vi) liver, eggs, milk, red palm oil, carrots, mango, pawpaw, or dark green leafy "
            "vegetables"],
    "1 mark each for any SIX correct entries (6 marks). The blank number must be matched to the "
    "answer. For (i), (ii), (iv) and (vi) accept any correct Ghanaian food source of that "
    "nutrient. For (iii) the key word is GROWTH or REPAIR. For (v) accept energy, warmth or "
    "helping to absorb vitamins."),
   ("(b)", ["Iron - liver, beans, dark green leafy vegetables, fish, meat, eggs, cocoa.",
            "Calcium - milk, cheese, fish with soft bones, groundnuts, green leafy vegetables.",
            "Iodine - iodised salt, sea fish, seaweed.",
            "Phosphorus - milk, fish, eggs, meat, beans.",
            "Potassium - banana, orange, yam, cocoyam, beans."],
    "1 mark for each of TWO correct minerals with a correct food source (2 marks). Accept any "
    "mineral genuinely needed by the body; the source must actually contain that mineral."),
 ],
 3: [
   ("(a)", ["A deficiency disease is an illness caused by a lack of an essential nutrient in "
            "the diet.", "It is not caught from another person and it is not caused by germs.",
            "It happens when the body does not get enough of a nutrient over a long period.",
            "It can be prevented or cured by eating the missing nutrient."],
    "1 mark each for any THREE correct points (3 marks). The key word is LACK of a nutrient. "
    "Do NOT accept 'a disease caused by germs'."),
   ("(b)", ["Not eating enough food in general.",
            "Not eating enough of one particular nutrient, such as protein or iron.",
            "Eating the same few foods all the time instead of a varied diet.",
            "Poverty, so that the family cannot afford foods with the needed nutrients.",
            "Poor feeding habits, such as a child being given only one kind of food.",
            "Ignorance of what makes up a balanced diet.",
            "Illness that stops the body absorbing the nutrient even when it is eaten."],
    "1 mark each for any THREE correct causes (3 marks). Accept any sensible cause."),
   ("(c)", ["No single food contains all the classes of nutrient the body needs.",
            "So a person who eats only one kind of food gets plenty of one nutrient but misses "
            "the others.", "The missing nutrient is the one that causes the deficiency disease.",
            "Eating a variety of foods makes sure that all the nutrients are present.",
            "A child fed only on maize, for example, may get energy but miss protein and "
            "vitamins."],
    "1 mark each for any THREE correct points (3 marks). The key idea is that one food cannot "
    "supply every nutrient."),
 ],
 4: [
   ("(a)", ["SYMPTOMS are the signs that can be seen or felt in the patient, and that the "
            "doctor or nurse looks for.",
            "EFFECTS are what the disease does to the body and to the person's life.",
            "A symptom is what you notice, such as pale eyes or bleeding gums.",
            "An effect is the harm that follows, such as a child failing to grow or being too "
            "weak to walk to school.",
            "For anaemia: the symptom is paleness and tiredness; the effect is that the child "
            "cannot concentrate or play."],
    "1 mark each for any FOUR correct points (4 marks). At least ONE mark must come from "
    "explaining symptoms and at least ONE from explaining effects; award at most 3 marks if "
    "only one of the two is explained."),
   ("(b)", ["Teaching families to eat a balanced diet is better.",
            "A balanced diet gives all the nutrients, not only the ones in the tablet.",
            "The habit lasts for life, while the tablets stop when the supply stops.",
            "Local foods are cheaper and always available; tablets have to be bought and "
            "delivered.",
            "Tablets can help in an emergency, but they do not teach the family anything.",
            "Accept a pupil who argues for tablets only if they give a good reason, such as "
            "that the tablets work faster for a child who is already ill."],
    "1 mark for a clear position and 1 mark each for any THREE good reasons (4 marks). Credit "
    "either side of the argument, provided the reasons genuinely support the position taken. An "
    "answer with no reason scores at most 1."),
 ],
 5: [
   ("(a)", ["Night blindness - lack of vitamin A.",
            "Rickets - lack of vitamin D, together with calcium and phosphorus.",
            "Scurvy - lack of vitamin C."],
    "1 mark for each disease correctly matched to its missing nutrient (3 marks). The nutrient "
    "must be matched to the disease. For rickets accept vitamin D alone or vitamin D with "
    "calcium."),
   ("(b)", ["Night blindness - the child cannot see clearly in dim light or after dusk, and "
            "bumps into things.",
            "Rickets - the bones are soft and bent, giving bow legs, a bent spine or a "
            "knock-kneed look.",
            "Scurvy - the gums swell and bleed, teeth may loosen, and wounds heal slowly."],
    "1 mark for each correct symptom (3 marks). The symptom must be matched to the disease."),
   ("(c)", ["Eat foods containing vitamin D, such as fish, egg yolk, milk and fortified "
            "spreads.", "Eat foods containing calcium and phosphorus, such as milk, fish with "
            "soft bones, groundnuts and green leafy vegetables.",
            "Let the skin get some gentle morning sunlight, which helps the body make its own "
            "vitamin D.",
            "Give babies and young children the foods above from an early age, so the bones "
            "harden properly.",
            "Take a child with soft or bent bones to the clinic or hospital for treatment."],
    "1 mark each for any THREE correct points (3 marks). At least ONE point must mention "
    "vitamin D and at least ONE must mention calcium or sunlight; award at most 2 marks if only "
    "one of these is given."),
 ],
 6: [
   ("(a)", ["Kwashiorkor is caused by a lack of PROTEIN.",
            "The belly swells with fluid.", "The arms and legs become very thin.",
            "The hair becomes thin, dry and reddish or light in colour.",
            "The child stops growing, is miserable and loses interest in food.",
            "The skin may crack and peel, and sores heal slowly."],
    "1 mark for naming protein and 1 mark each for any TWO correct symptoms (3 marks). Award at "
    "most 2 marks if the nutrient is wrong but the symptoms are right."),
   ("(b)", ["Iron is needed to make haemoglobin, the red substance in the blood that carries "
            "oxygen.", "Without enough iron the body cannot make enough healthy red blood "
            "cells.", "So the blood carries less oxygen than the body needs.",
            "Without oxygen the cells cannot release energy from food, so the child has little "
            "energy.", "That is why the child tires quickly, feels weak and looks pale.",
            "The child is also likely to fall ill more often, because the body is run down."],
    "1 mark each for any THREE correct points (3 marks). The chain to look for is: lack of iron "
    "means less haemoglobin, less haemoglobin means less oxygen carried, and less oxygen means "
    "less energy. Award at most 1 mark for an answer that only says 'the blood is not enough'."),
   ("(c)", ["Liver", "Beans and other legumes", "Dark green leafy vegetables such as kontomire "
            "or alefu", "Fish", "Meat", "Eggs", "Groundnuts", "Fortified cereals or flour"],
    "1 mark each for any TWO correct foods (2 marks). Accept any food genuinely rich in iron. "
    "Do NOT accept milk - it is a good food but it is poor in iron."),
 ],
 7: [
   ("(a)", ["The children with swollen bellies, thin arms and legs and reddish hair have "
            "KWASHIORKOR.", "The nutrient they lack is PROTEIN.",
            "The children who cannot find their way in the evening have NIGHT BLINDNESS.",
            "The nutrient they lack is VITAMIN A."],
    "1 mark for each disease correctly named and 1 mark for each nutrient correctly matched "
    "(4 marks). The disease and the nutrient must go together. Accept the pair in either "
    "order."),
   ("(b)", ["Tell the families to add protein foods to the children's meals - beans, "
            "groundnuts, fish, eggs or soya.",
            "Tell them to add foods rich in vitamin A - red palm oil, eggs, liver, dark green "
            "leafy vegetables, mango and pawpaw.",
            "Explain that the children will then get the nutrients they are missing and will "
            "grow properly again.",
            "Show them how to mix the foods they already grow, rather than asking them to buy "
            "new ones.",
            "Advise them to take the worst-affected children to the clinic or health centre.",
            "Suggest a small demonstration meal or a talk at the next community meeting so the "
            "whole village hears the same message.",
            "Explain that the changes must be kept up, not done once, or the children will fall "
            "ill again."],
    "1 mark each for any FOUR correct points (4 marks). This is a design task: award method "
    "marks for any sensible answer. At least ONE point must be about protein and at least ONE "
    "about vitamin A; award at most 3 marks if only one of the two is covered. Saying WHAT to "
    "do and WHY it helps are both creditworthy."),
 ],
}


# --------------------------------------------- derive summary statistics
def topic_totals():
    m = {k: 0 for k in TOPIC}
    it = {k: 0 for k in TOPIC}
    for q in MCQ:
        m[q[3]] += 1
        it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk
            it[key] += 1
    return m, it


def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}
    b = {k: 0 for k in order}
    for q in MCQ:
        a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            b[cog] += mk
    return order, a, b


def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ:
        d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            d[diff] += mk
    return d
