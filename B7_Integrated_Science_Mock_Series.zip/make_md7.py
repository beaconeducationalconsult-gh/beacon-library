# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "/home/user")
from build_digest import *

L = []
def w(s=""): L.append(s)

w(f"# {SCHOOL}"); w()
w(f"## {SUBJECT}"); w()
w(f"### {EXAM}"); w()
w(f"**Class:** {CLASS}  ")
w(f"**Time:** {TIME}  ")
w(f"**Total Marks:** {MARKS}  ")
w(f"**Academic Year:** {YEAR}"); w()
w("---"); w()
w("### INSTRUCTIONS"); w()
for i, t in enumerate([
    "Write your name and class clearly in the spaces provided on your answer sheet.",
    "This paper has TWO sections: Section A and Section B.",
    "Answer ALL the questions in both sections.",
    "Section A has 40 multiple-choice questions. Each question carries 1 mark. Choose the best answer (A, B, C or D) and record it on the answer sheet provided.",
    "Section B has 7 theory questions totalling 60 marks. Write your answers clearly and neatly in your answer booklet. Draw and label diagrams or tables where you are asked to.",
    "Read every question carefully before you answer it.",
    "Do not use correction fluid. Cancel any mistake neatly with a single line.",
    "Hand in your answer sheet and your answer booklet at the end of the examination.",
], start=1):
    w(f"{i}. {t}")
w(); w("---"); w()

w("## SECTION A: OBJECTIVE TEST (40 marks)"); w()
w("*Answer ALL questions. Each question carries 1 mark. Choose the BEST answer and write its letter "
  "(A, B, C or D) against the question number on your answer sheet.*"); w()
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"**{i}. {q}**"); w()
    for j, o in enumerate(opts): w(f"{'ABCD'[j]}. {o}")
    w()
w("---"); w()

w("## SECTION B: THEORY (60 marks)"); w()
w("*Answer ALL questions. Write your answers in your answer booklet. The marks for each question are shown "
  "in brackets.*"); w()
for qb in SECTION_B:
    w(f"### Question {qb['num']}  [{qb['total']} marks]"); w()
    w(qb["stem"]); w()
    if qb.get("diagram"):
        w("```")
        for line in DIGESTIVE_SYSTEM: w(line)
        w("```")
        w("*Fig. 1: The human digestive system (not drawn to scale)*"); w()
    if qb.get("table") == "endproducts":
        w("| " + " | ".join(END_HEADERS) + " |")
        w("| " + " | ".join(["---"] * len(END_HEADERS)) + " |")
        for r in END_ROWS:
            w("| " + " | ".join(r) + " |")
        w()
        w("*Table 1: End products of digestion*"); w()
    if qb.get("table") == "foodtests":
        w("| " + " | ".join(TEST_HEADERS) + " |")
        w("| " + " | ".join(["---"] * len(TEST_HEADERS)) + " |")
        for r in TEST_ROWS:
            w("| " + " | ".join(r) + " |")
        w()
        w("*Table 2: Food tests*"); w()
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        w(f"**{lab}** {text}  **[{mk} mark{'s' if mk > 1 else ''}]**"); w()
w("---"); w()

w("## ANSWER KEY"); w()
w("### Section A - Objective Test"); w()
w("| Question | Answer | Curriculum Area (Topic) | Cognitive Level |")
w("| -------- | ------ | ----------------------- | --------------- |")
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"| {i} | {ans} | {TOPIC[tp]} | {cog} |")
counts = {L2: sum(1 for q in MCQ if q[2] == L2) for L2 in "ABCD"}
w()
w("Correct-answer distribution: " + ", ".join(f"{L2} = {counts[L2]}" for L2 in "ABCD") + " (40 items).")
w()
w("### Section B - Theory (summary answers; full detail in the Marking Scheme)"); w()
w("| Question | Expected Answer | Curriculum Area | Cognitive Level |")
w("| -------- | --------------- | --------------- | --------------- |")
sba = [
 ("1 (a)", "Food is any substance, solid or liquid, that a living thing takes in and that provides nutrients for growth, energy and health. Nutrients: carbohydrates, proteins, fats and oils, vitamins, mineral salts and water.", "7.1", "Understand"),
 ("1 (b)", "Any three of: to provide energy; to build the body and repair worn-out parts; to protect the body against disease; to keep the body warm; to supply water for body processes.", "7.1", "Understand"),
 ("1 (c)", "Yes, in part - it supplies sugar, which gives energy - but it is not a complete food, because it contains no protein, fat, vitamins or mineral salts.", "7.1", "Evaluate"),
 ("2 (a)", "The starved person looks thin with the ribs and bones showing, weak and tired, with dry pale skin and dull hair; a starved child may have a swollen belly. The well-fed person looks well covered with firm muscles, bright eyes and healthy skin, and is active and strong.", "7.2", "Analyse"),
 ("2 (b)", "Any three of: to give energy; to build and repair the body; to help the body grow; to keep the body healthy and protect it from disease; to keep the body warm.", "7.2", "Understand"),
 ("2 (c)", "Without enough food the body has no energy and cannot fight disease; without the right nutrients it cannot build new tissue, so the child grows slowly; lack of vitamins and mineral salts lowers protection against illness.", "7.2", "Analyse"),
 ("3 (a)", "1 = mouth; 2 = oesophagus (gullet); 3 = stomach; 4 = small intestine; 5 = large intestine.", "7.3", "Remember"),
 ("3 (b)", "Any two of: the liver - makes bile, which helps digest fats and oils; the pancreas - makes pancreatic juice, which helps digest starch, protein and fat; the salivary glands - make saliva, which begins the digestion of starch.", "7.3", "Understand"),
 ("3 (c)", "Any three of: the food is churned by the muscular walls; it is mixed with gastric juice; the digestion of protein begins; it becomes a thick semi-liquid mass; it is released a little at a time into the small intestine.", "7.3", "Understand"),
 ("4 (a)", "The teeth cut and chew the yam into small pieces; saliva mixes with it to moisten it and make it easy to swallow; the saliva begins to digest the starch into sugar; the tongue rolls it into a ball for swallowing.", "7.4", "Understand"),
 ("4 (b)", "The food is churned and squeezed by the muscular walls of the stomach; it is mixed with gastric juice; the digestion of the protein in the meat begins; it becomes a thick semi-liquid mass and is released a little at a time into the small intestine.", "7.4", "Understand"),
 ("4 (c)", "The meat would be digested more slowly, because large pieces give the juices less surface to act on, and some of it may pass through without being fully digested.", "7.4", "Apply"),
 ("5 (a)", "(i) simple sugars such as glucose; (ii) amino acids; (iii) fatty acids and glycerol.", "7.5", "Understand"),
 ("5 (b)", "Any protein food: egg, meat, fish, beans, groundnuts, milk, cheese, soya. Use: the amino acids are used to build the body - for growth and for repairing worn-out parts.", "7.5", "Apply"),
 ("5 (c)", "The molecules in starch, protein and fat are far too large to pass through the wall of the small intestine into the blood; digestion breaks them into small soluble molecules - glucose, amino acids, fatty acids and glycerol - which can pass through.", "7.5", "Analyse"),
 ("6 (a)", "The inner wall of the small intestine is covered with tiny finger-like villi; the small soluble molecules pass through the thin wall of the villi into the blood vessels inside them; the blood carries the food to the liver and round the body.", "7.6", "Understand"),
 ("6 (b)", "Any three of: it is long; its inner wall is folded and covered with thousands of villi, which give a very large surface area; its wall is only one cell thick; it has a rich blood supply that carries the food away quickly.", "7.6", "Analyse"),
 ("6 (c)", "The undigested part - mostly roughage or fibre - passes into the large intestine, where most of the remaining water is absorbed; the rest becomes faeces, which are stored in the rectum and pass out through the anus.", "7.6", "Understand"),
 ("7 (a)", "(i) a blue-black colour; (ii) Benedict's solution, heated in a water bath (Fehling's solution is also accepted); (iii) a violet (purple) colour; (iv) rub a little of the food on a piece of paper - the grease-spot test.", "7.7", "Understand"),
 ("7 (b)", "Crush each sample into a separate labelled tube or dish; add iodine to the gari - blue-black means starch is present; add Biuret solution to the beans - violet means protein is present; rub palm oil on paper - a translucent spot means fat is present; keep one untreated control; record results in a table. Safety: do not taste any sample, handle iodine and Biuret solution with care, heat only in a water bath, wash hands afterwards.", "7.7", "Create"),
]
for r in sba: w(f"| {r[0]} | {r[1]} | {r[2]} | {r[3]} |")
w(); w("---"); w()

w("## MARKING SCHEME - SECTION B (60 marks)"); w()
w("*General rules: (1) Accept any other correct and relevant answer. (2) Award marks for correct points, not "
  "for repeating the question. (3) For procedures, award method marks. (4) Do not deduct marks for spelling "
  "unless the meaning is changed. (5) Where a candidate gives more answers than are asked for, mark only the "
  "first ones up to the number required.*"); w()
for qb in SECTION_B:
    n = qb["num"]
    w(f"### Question {n} ({qb['total']} marks)"); w()
    for (lab, points, note) in MARKING[n]:
        mkv = [p_[2] for p_ in qb["parts"] if p_[0] == lab]
        head = f"**{lab}**"
        if mkv: head += f" [{mkv[0]} mark{'s' if mkv[0] > 1 else ''}]"
        w(head); w()
        for pt in points: w(f"- {pt}")
        w(f"  - *Marking note: {note}*"); w()
w("---"); w()

w("## CURRICULUM ASSESSMENT BLUEPRINT"); w()
w(f"**Strand:** {STRAND} | **Sub-strand:** {SUBSTRAND} | **Class:** {CLASS}"); w()
w(f"**Content Standard:** {CS} - {CS_TEXT}"); w()
w("> Source: NaCCA Science Common Core Programme Curriculum (B7/JHS1-B9/JHS3), September 2020, "
  "Strand 3: Systems, Sub-strand 1: The Human Body System, pp. 16-18. Indicators are quoted, not "
  "invented."); w()

w("### Section A"); w()
w("| Qn | Sub-strand | Content Standard | Indicator (NaCCA) - Indicator Text | Topic / Content | Cognitive Level | Marks |")
w("| -- | ---------- | ---------------- | ---------------------------------- | --------------- | --------------- | ----- |")
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"| A{i} | {SUBSTRAND} | {CS_BY_TOPIC[tp]} | {IND[tp]} - {IND_TEXT[tp]} | {TOPIC[tp]} | {cog} | 1 |")
w()
w("### Section B"); w()
w("| Qn | Sub-strand | Content Standard | Indicator (NaCCA) - Indicator Text | Topic / Content | Cognitive Level | Marks |")
w("| -- | ---------- | ---------------- | ---------------------------------- | --------------- | --------------- | ----- |")
for qb in SECTION_B:
    for (lab, text, mkv, cog, tp, diff) in qb["parts"]:
        key = tp if tp in TOPIC else tp.split(",")[0].strip()
        w(f"| B{qb['num']}{lab.strip('()')} | {SUBSTRAND} | {CS_BY_TOPIC[key]} | {IND[key]} - {IND_TEXT[key]} | {TOPIC[key]} | {cog} | {mkv} |")
w(); w("---"); w()

def topic_totals():
    m = {k: 0 for k in TOPIC}; it = {k: 0 for k in TOPIC}
    for q in MCQ: m[q[3]] += 1; it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk; it[key] += 1
    return m, it

def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}; b = {k: 0 for k in order}
    for q in MCQ: a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: b[cog] += mk
    return order, a, b

def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ: d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: d[diff] += mk
    return d

m, it = topic_totals(); diff_ = difficulty_totals(); order, ca, cb = cognitive_by_section()

w("### Summary 1 - Coverage by Curriculum Area (Topic)"); w()
w("| Topic / Content Area | No. of Items | Marks | % of Total Marks | Core Competencies |")
w("| -------------------- | ------------ | ----- | ---------------- | ----------------- |")
for k in TOPIC: w(f"| {TOPIC[k]} | {it[k]} | {m[k]} | {(m[k]/100)*100:.1f}% | {CC[k]} |")
w(f"| **TOTAL** | **{sum(it.values())}** | **{sum(m.values())}** | **100%** | - |")
w()
w("*CC = Communication and Collaboration; CP = Critical Thinking and Problem Solving; DL = Digital Literacy; "
  "CI = Creativity and Innovation.*"); w()
w("### Summary 2 - Cognitive-Level Distribution (Bloom's Taxonomy)"); w()
w("| Cognitive Level | Section A Marks | Section B Marks | Total Marks | % of Total |")
w("| --------------- | --------------- | --------------- | ----------- | ---------- |")
for lv in order:
    tot = ca[lv] + cb[lv]
    w(f"| {lv} | {ca[lv]} | {cb[lv]} | {tot} | {(tot/100)*100:.1f}% |")
w(f"| **TOTAL** | **{sum(ca.values())}** | **{sum(cb.values())}** | **{sum(ca.values())+sum(cb.values())}** | **100%** |")
w()
w("### Summary 3 - Difficulty Distribution"); w()
w("| Difficulty | Marks | % of Total Marks |")
w("| ---------- | ----- | ---------------- |")
for k, v in diff_.items(): w(f"| {k} | {v} | {(v/100)*100:.1f}% |")
w(f"| **TOTAL** | **{sum(diff_.values())}** | **100%** |")
w()
w("*Target in the master prompt: approximately 30% easy / 50% moderate / 20% challenging.*"); w()
w("### Summary 4 - Section Weighting"); w()
w("| Section | Question Type | Items | Marks | % of Total |")
w("| ------- | ------------- | ----- | ----- | ---------- |")
w("| A | Objective (multiple choice) | 40 | 40 | 40% |")
w("| B | Theory / constructed response | 20 | 60 | 60% |")
w("| **TOTAL** | - | **60** | **100** | **100%** |")
w(); w("---"); w()

w("## QUALITY-CONTROL SUMMARY")
w("")
w("| Check | Status |")
w("| --- | --- |")
for q_, a_ in [
 ("Every question within supplied curriculum scope",
  "Yes - topics 7.1-7.7 of Strand 3, Sub-Strand 1 (The Human Body System), mapped to indicators B7/JHS1.3.1.1.1, B7/JHS1.3.1.1.2 and B7/JHS1.3.1.1.3"),
 ("Appropriate for the class",
  "Yes - B7 level; no named enzymes, no pH chemistry and no villus histology, all of which sit outside the B7 indicator"),
 ("Genuinely BECE-style",
  "Yes - 40 four-option objectives plus structured theory with printed mark allocations, a labelled diagram and two completion tables"),
 ("Sufficient application and reasoning",
  "Yes - 31 of 100 marks (31%) at Apply level or above (Apply 11, Analyse 14, Evaluate 3, Create 3)"),
 ("Plausible MCQ distractors",
  "Yes - drawn from the same content family as the key: the wrong nutrient, the wrong end product, the wrong organ or stage, and the wrong reagent or result in the food tests"),
 ("Single best answer per MCQ",
  "Yes - reviewed item by item; special care with A5, where the stem asks specifically for the best source of starch"),
 ("Marks internally consistent",
  "Yes - Section A 40 x 1 = 40; Section B 8 + 9 + 10 + 9 + 8 + 9 + 7 = 60; sub-question marks match the marking scheme"),
 ("Total adds up correctly",
  "Yes - 40 + 60 = 100"),
 ("Answer key correct",
  "Yes - all 40 keys and all 20 Section B answers verified against the marking scheme"),
 ("Marking scheme matches questions",
  "Yes - expected answers plus marking notes covering partial credit, alternatives, common wrong answers and method marks; the diagram key, both completion tables and the investigation plan have explicit marking grids"),
 ("Free from unnecessary ambiguity",
  "Yes - open items are anchored with 'state three', 'name two' and the mark allocation; Question 5(a) and Question 7(a) number every blank (i) to (iv), and Question 7(b) spells out the three things the plan must contain"),
 ("Ghanaian contexts natural and accurate",
  "Yes - boiled yam, gari, plantain, cassava, beans, groundnuts, palm oil and palm soup, meat and fish, a school water bath, and the starved-versus-well-fed comparison from the curriculum's own exemplar"),
 ("No content beyond the curriculum",
  "No - Question 2 uses exemplars 2 and 3 of B7/JHS1.3.1.1.1; Question 3 uses exemplars 1 and 3 of B7/JHS1.3.1.1.2; Question 4 uses exemplar 2; Question 5 uses exemplar 2 of B7/JHS1.3.1.1.3; Question 6 uses exemplar 1; Question 7 uses exemplar 3"),
 ("Questions sufficiently varied",
  "Yes - definition, listing, judgement, comparison of appearance, diagram labelling, naming associated organs, describing each digestive stage, explaining surface area, completing two tables, explaining a mechanism, and designing an investigation"),
]:
    w("| " + q_ + " | " + a_ + " |")
w("")
w("### EXAMINER NOTES")
w("")
for n_ in [
 "Question 3 is the 'identify and draw the digestive system' exemplar. The diagram is drawn with text characters: redraw it with real boxes or paste in a hand-drawn figure - the numbering (1-5) is what the questions depend on. Key: 1 mouth, 2 oesophagus, 3 stomach, 4 small intestine, 5 large intestine.",
 "Question 3(b) is a common trip-up. The stomach and intestines are part of the alimentary canal, so they are NOT accepted here; the expected answers are the liver, the pancreas and the salivary glands.",
 "Question 7 is the practical food-test exemplar. If you can, run it before the mock: iodine on gari or bread, Biuret on beans or egg white, and the grease-spot test with palm oil. Pupils who have seen the colours answer far better.",
 "Safety for any practical follow-up: no tasting of unknown samples, iodine and Biuret solution are irritants, Benedict's solution must be heated in a water bath and never over a naked flame, and hands must be washed afterwards. The marking note withholds credit from a plan that tells pupils to taste an unknown sample.",
 "The paper deliberately does NOT name enzymes. B7 expects 'saliva begins the digestion of starch' and 'gastric juice begins the digestion of protein' - do not reward answers that go beyond this, and do not penalise pupils for not using the words amylase or pepsin.",
 "Topic 7.7 carries 12 of 100 marks, the lightest weighting, only because it is the last topic and much of it is practical. If you have a well-equipped laboratory and want a more practical paper, move marks from Question 6 to Question 7.",
 "The digestive-system diagram and both tables are laid out for A4 portrait. Check the page break before Question 3 and before Question 7 when you print.",
 "Edit the school name, academic year and examination title on page 1 before printing.",
 "This is an original, teacher-made mock. It is not a reproduction of any WAEC or NaCCA examination paper.",
]:
    w("- " + n_)
w()

open("/home/user/Basic7_Integrated_Science_Mock_Strand3_HumanBodyDigestion.md", "w", encoding="utf-8").write("\n".join(L))
print("md written", len("\n".join(L)), "chars")
