# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "/home/user")
from build_force import *

L = []
def w(s=""): L.append(s)

w(f"# {SCHOOL}"); w()
w(f"## {SUBJECT}"); w()
w(f"### {EXAM}"); w()
w(f"**Class:** {CLASS}  ")
w(f"**Time:** {TIME}  ")
w(f"**Total Marks:** {MARKS}  ")
w(f"**Academic Year:** {YEAR}"); w()
w("---"); w()
w("### INSTRUCTIONS"); w()
for i, t in enumerate([
    "Write your name and class clearly in the spaces provided on your answer sheet.",
    "This paper has TWO sections: Section A and Section B.",
    "Answer ALL the questions in both sections.",
    "Section A has 40 multiple-choice questions. Each question carries 1 mark. Choose the best answer (A, B, C or D) and record it on the answer sheet provided.",
    "Section B has 7 theory questions totalling 60 marks. Write your answers clearly and neatly in your answer booklet. Draw and label diagrams or tables where you are asked to.",
    "Read every question carefully before you answer it.",
    "Do not use correction fluid. Cancel any mistake neatly with a single line.",
    "Hand in your answer sheet and your answer booklet at the end of the examination.",
], start=1):
    w(f"{i}. {t}")
w(); w("---"); w()

w("## SECTION A: OBJECTIVE TEST (40 marks)"); w()
w("*Answer ALL questions. Each question carries 1 mark. Choose the BEST answer and write its letter "
  "(A, B, C or D) against the question number on your answer sheet.*"); w()
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"**{i}. {q}**"); w()
    for j, o in enumerate(opts): w(f"{'ABCD'[j]}. {o}")
    w()
w("---"); w()

w("## SECTION B: THEORY (60 marks)"); w()
w("*Answer ALL questions. Write your answers in your answer booklet. The marks for each question are shown "
  "in brackets.*"); w()
for qb in SECTION_B:
    w(f"### Question {qb['num']}  [{qb['total']} marks]"); w()
    w(qb["stem"]); w()
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        w(f"**{lab}** {text}  **[{mk} mark{'s' if mk > 1 else ''}]**"); w()
w("---"); w()

w("## ANSWER KEY"); w()
w("### Section A - Objective Test"); w()
w("| Question | Answer | Curriculum Area (Topic) | Cognitive Level |")
w("| -------- | ------ | ----------------------- | --------------- |")
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"| {i} | {ans} | {TOPIC[tp]} | {cog} |")
counts = {L2: sum(1 for q in MCQ if q[2] == L2) for L2 in "ABCD"}
w()
w("Correct-answer distribution: " + ", ".join(f"{L2} = {counts[L2]}" for L2 in "ABCD") + " (40 items).")
w()
w("### Section B - Theory (summary answers; full detail in the Marking Scheme)"); w()
w("| Question | Expected Answer | Curriculum Area | Cognitive Level |")
w("| -------- | --------------- | --------------- | --------------- |")
sba = [
 ("1 (a)", "A force is a push or a pull on an object; it makes an object start moving, stop, speed up, slow down, change direction or change shape. The SI unit is the newton (N).", "14.1", "Understand"),
 ("1 (b)", "Any three of: it can make a still object move; stop a moving object; speed it up or slow it down; change its direction; change its shape or size.", "14.1", "Understand"),
 ("1 (c)", "The goalkeeper's hands apply a force to the ball in the opposite direction to its motion; the force slows the ball and brings it to a stop, and squashes the ball and the gloves a little.", "14.1", "Apply"),
 ("2 (a)", "Balanced forces are equal in size and opposite in direction, so they cancel out and there is no overall force. Unbalanced forces are not equal and opposite, so there is an overall force in one direction.", "14.2", "Understand"),
 ("2 (b)", "Its motion does not change: if it was at rest it stays at rest, and if it was moving it keeps moving at the same speed in the same direction.", "14.2", "Understand"),
 ("2 (c)", "The box moves towards the boy pushing with 45 N. The forces are not balanced because 60 N is bigger than 45 N, so there is an overall force of 15 N towards the 45 N side.", "14.2", "Apply"),
 ("3 (a)", "Inertia is the tendency of a body to resist a change in its motion - a body at rest tends to stay at rest, and a moving body tends to keep moving at the same speed in the same direction.", "14.3", "Understand"),
 ("3 (b)", "The mass of the body - the more matter it contains, the more inertia it has.", "14.3", "Understand"),
 ("3 (c)", "No. The passenger was moving forward at the same speed as the tro-tro. When the tro-tro braked, a force slowed the vehicle but nothing slowed the passenger, so his own inertia kept him moving forward while the vehicle slowed underneath him.", "14.3", "Evaluate"),
 ("4 (a)", "A body continues in its state of rest, or of uniform motion in a straight line, unless an unbalanced force acts on it.", "14.4", "Remember"),
 ("4 (b)", "Inertia is the tendency to resist a change in motion, and Newton's First Law describes exactly that behaviour, so the law explains in words what inertia is.", "14.4", "Analyse"),
 ("4 (c)", "The ball keeps rolling at almost the same speed in a straight line for a long time, because there is very little friction on a smooth floor to act as the unbalanced force needed to stop it.", "14.4", "Apply"),
 ("5 (a)", "The passenger falls backwards, because the lower part of his body moves forward with the bus while the upper part tends to stay at rest. This shows Newton's First Law of Motion.", "14.5", "Understand"),
 ("5 (b)", "The passenger is moving forward with the car; when the car stops suddenly his inertia keeps him moving; the seat belt applies the unbalanced force that holds him back and stops him hitting the dashboard.", "14.5", "Apply"),
 ("5 (c)", "Any one correct application with an explanation - e.g. luggage sliding off a seat when a bus turns a corner, a ball rolling until it hits a block, shaking water off the hands, or pulling a tablecloth from under a plate.", "14.5", "Understand"),
 ("6 (a)", "A magnet is a material or object that attracts iron and steel. It attracts iron, steel, nickel and cobalt.", "14.6", "Understand"),
 ("6 (b)", "Any two of: a bar magnet; a horseshoe magnet; a ring or round magnet; a U-shaped magnet; a button magnet; a magnetic strip or fridge magnet.", "14.6", "Remember"),
 ("6 (c)", "Suspend each bar in turn from a thread; the one that always comes to rest pointing north-south is the magnet, because only a magnet has poles and lines up with the earth's field. Or dip each bar into iron pins; the one that picks up a cluster at its ends is the magnet. Or bring one end of bar A to the middle of bar B; if it attracts, A is the magnet.", "14.6", "Create"),
 ("7 (a)", "Attraction is when two magnets pull towards each other, and it happens between unlike poles (north and south). Repulsion is when two magnets push each other away, and it happens between like poles (north and north, or south and south).", "14.7", "Understand"),
 ("7 (b)", "The magnet turns and comes to rest pointing north-south, with the same end always pointing north. This is used in a magnetic compass to find direction.", "14.7", "Apply"),
 ("7 (c)", "Any four of: a magnetic compass; a catch on a fridge or cupboard door; holding notes on a magnetic board; picking up fallen steel pins, nails or screws; separating iron from a mixture; in a door bell, loudspeaker or electric motor; a magnetic bag fastener.", "14.8", "Remember"),
]
for r in sba: w(f"| {r[0]} | {r[1]} | {r[2]} | {r[3]} |")
w(); w("---"); w()

w("## MARKING SCHEME - SECTION B (60 marks)"); w()
w("*General rules: (1) Accept any other correct and relevant answer. (2) Award marks for correct points, not "
  "for repeating the question. (3) For procedures, award method marks. (4) Do not deduct marks for spelling "
  "unless the meaning is changed. (5) Where a candidate gives more answers than are asked for, mark only the "
  "first ones up to the number required.*"); w()
for qb in SECTION_B:
    n = qb["num"]
    w(f"### Question {n} ({qb['total']} marks)"); w()
    for (lab, points, note) in MARKING[n]:
        mkv = [p_[2] for p_ in qb["parts"] if p_[0] == lab]
        head = f"**{lab}**"
        if mkv: head += f" [{mkv[0]} mark{'s' if mkv[0] > 1 else ''}]"
        w(head); w()
        for pt in points: w(f"- {pt}")
        w(f"  - *Marking note: {note}*"); w()
w("---"); w()

w("## CURRICULUM ASSESSMENT BLUEPRINT"); w()
w(f"**Strand:** {STRAND} | **Sub-strand:** {SUBSTRAND} | **Class:** {CLASS}"); w()
w(f"**Content Standard:** {CS} - {CS_TEXT}"); w()
w("> Source: NaCCA Science Common Core Programme Curriculum (B7/JHS1-B9/JHS3), September 2020, "
  "Strand 4: Forces and Energy, Sub-strand 4: Force and Motion (topics 14.1-14.8), "
  "pp. 35-38. Indicators are quoted, not invented."); w()

w("### Section A"); w()
w("| Qn | Sub-strand | Content Standard | Indicator (NaCCA) - Indicator Text | Topic / Content | Cognitive Level | Marks |")
w("| -- | ---------- | ---------------- | ---------------------------------- | --------------- | --------------- | ----- |")
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"| A{i} | {SUBSTRAND} | {CS_BY_TOPIC[tp]} | {IND[tp]} - {IND_TEXT[tp]} | {TOPIC[tp]} | {cog} | 1 |")
w()
w("### Section B"); w()
w("| Qn | Sub-strand | Content Standard | Indicator (NaCCA) - Indicator Text | Topic / Content | Cognitive Level | Marks |")
w("| -- | ---------- | ---------------- | ---------------------------------- | --------------- | --------------- | ----- |")
for qb in SECTION_B:
    for (lab, text, mkv, cog, tp, diff) in qb["parts"]:
        key = tp if tp in TOPIC else tp.split(",")[0].strip()
        w(f"| B{qb['num']}{lab.strip('()')} | {SUBSTRAND} | {CS_BY_TOPIC[key]} | {IND[key]} - {IND_TEXT[key]} | {TOPIC[key]} | {cog} | {mkv} |")
w(); w("---"); w()

def topic_totals():
    m = {k: 0 for k in TOPIC}; it = {k: 0 for k in TOPIC}
    for q in MCQ: m[q[3]] += 1; it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk; it[key] += 1
    return m, it

def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}; b = {k: 0 for k in order}
    for q in MCQ: a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: b[cog] += mk
    return order, a, b

def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ: d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: d[diff] += mk
    return d

m, it = topic_totals(); diff_ = difficulty_totals(); order, ca, cb = cognitive_by_section()

w("### Summary 1 - Coverage by Curriculum Area (Topic)"); w()
w("| Topic / Content Area | No. of Items | Marks | % of Total Marks | Core Competencies |")
w("| -------------------- | ------------ | ----- | ---------------- | ----------------- |")
for k in TOPIC: w(f"| {TOPIC[k]} | {it[k]} | {m[k]} | {(m[k]/100)*100:.1f}% | {CC[k]} |")
w(f"| **TOTAL** | **{sum(it.values())}** | **{sum(m.values())}** | **100%** | - |")
w()
w("*CC = Communication and Collaboration; CP = Critical Thinking and Problem Solving; DL = Digital Literacy; "
  "CI = Creativity and Innovation.*"); w()
w("### Summary 2 - Cognitive-Level Distribution (Bloom's Taxonomy)"); w()
w("| Cognitive Level | Section A Marks | Section B Marks | Total Marks | % of Total |")
w("| --------------- | --------------- | --------------- | ----------- | ---------- |")
for lv in order:
    tot = ca[lv] + cb[lv]
    w(f"| {lv} | {ca[lv]} | {cb[lv]} | {tot} | {(tot/100)*100:.1f}% |")
w(f"| **TOTAL** | **{sum(ca.values())}** | **{sum(cb.values())}** | **{sum(ca.values())+sum(cb.values())}** | **100%** |")
w()
w("### Summary 3 - Difficulty Distribution"); w()
w("| Difficulty | Marks | % of Total Marks |")
w("| ---------- | ----- | ---------------- |")
for k, v in diff_.items(): w(f"| {k} | {v} | {(v/100)*100:.1f}% |")
w(f"| **TOTAL** | **{sum(diff_.values())}** | **100%** |")
w()
w("*Target in the master prompt: approximately 30% easy / 50% moderate / 20% challenging.*"); w()
w("### Summary 4 - Section Weighting"); w()
w("| Section | Question Type | Items | Marks | % of Total |")
w("| ------- | ------------- | ----- | ----- | ---------- |")
w("| A | Objective (multiple choice) | 40 | 40 | 40% |")
w("| B | Theory / constructed response | 21 | 60 | 60% |")
w("| **TOTAL** | - | **61** | **100** | **100%** |")
w(); w("---"); w()

w("## QUALITY-CONTROL SUMMARY")
w("")
w("| Check | Status |")
w("| --- | --- |")
for q_, a_ in [
 ("Every question within supplied curriculum scope",
  "Yes - all 61 items (40 objectives and 21 theory sub-questions) sit in topics 14.1-14.8 of Strand 4, Sub-Strand 4 (Force and Motion), under content standard B7/JHS1.4.4.1, mapped to indicators B7/JHS1.4.4.1.1 to B7/JHS1.4.4.1.4. Simple machines and efficiency are excluded; they form the companion paper on B7/JHS1.4.4.2"),
 ("Appropriate for the class",
  "Yes - B7 level; no Newton's Second or Third Law, no F = ma, no momentum, no friction coefficients and no magnetic field lines"),
 ("Genuinely BECE-style",
  "Yes - 40 four-option objectives plus structured theory with printed mark allocations; the tug-of-war, the tro-tro and the suspended bar magnet are all treated through explanation rather than calculation"),
 ("Sufficient application and reasoning",
  "Yes - 32 of 100 marks (32%) at Apply level or above (Apply 22, Analyse 3, Evaluate 3, Create 4)"),
 ("Plausible MCQ distractors",
  "Yes - another law of motion or another scientific law, a property that is not an effect of a force, a material that a magnet does not attract, the opposite pole behaviour, and a genuine object that simply has no magnet in it"),
 ("Single best answer per MCQ",
  "Yes - reviewed item by item; special care with A9 (the rope moves towards team A because their pull is larger), A26 (a steel clip is attracted but a plastic ruler is not) and A40 (weighing maize is not a use of magnets)"),
 ("Marks internally consistent",
  "Yes - Section A 40 x 1 = 40; Section B 8 + 9 + 8 + 8 + 9 + 8 + 10 = 60; sub-question marks match the marking scheme"),
 ("Total adds up correctly",
  "Yes - 40 + 60 = 100"),
 ("Answer key correct",
  "Yes - all 40 keys and all 21 Section B answers verified against the marking scheme; Question 2(c) checked (60 N against 45 N gives an overall force of 15 N towards the weaker side)"),
 ("Marking scheme matches questions",
  "Yes - expected answers plus marking notes covering partial credit, alternatives, common wrong answers and method marks; the magnet-identification test in Question 6(c) is marked on four separate points and the note lists three different valid tests"),
 ("Free from unnecessary ambiguity",
  "Yes - open items are anchored with 'state three' and 'name four' plus the mark allocation; Question 2(a) requires both balanced and unbalanced forces, Question 7(a) requires both attraction and repulsion, Question 5(a) requires both what happens and the name of the law, and Question 6(c) says the reason is marked too"),
 ("Ghanaian contexts natural and accurate",
  "Yes - a tro-tro on the Accra-Kumasi road, an inter-house tug-of-war at school, a goalkeeper, an empty plastic water bottle, a loaded cargo truck, a magnetic board in a classroom, a kitchen cupboard catch, and a bag of maize at the market"),
 ("No content beyond the curriculum",
  "No - every item sits inside topics 14.1-14.8; simple machines, levers, work and efficiency belong to the companion paper on B7/JHS1.4.4.2 and are excluded here"),
 ("Questions sufficiently varied",
  "Yes - defining a force and its unit, listing effects, explaining a goalkeeper's catch, distinguishing balanced from unbalanced forces, predicting the direction of motion from two unequal forces, defining inertia, judging a passenger's description, stating a law, linking the law to inertia, explaining seat belts, describing another application, planning a test to identify a magnet, explaining attraction and repulsion, describing a suspended magnet, and listing the uses of magnets"),
]:
    w("| " + q_ + " | " + a_ + " |")
w("")
w("### EXAMINER NOTES")
w("")
for n_ in [
 "Question 3(c) is the item to watch. Pupils routinely say the vehicle 'threw' them forward, as if something pushed them. It did not: the passenger was already moving forward at the same speed as the vehicle, and when the vehicle braked nothing braked the passenger, so his own inertia carried him on. Allow the two reason marks only for answers that make this point.",
 "Question 6(c) is the design task, and it is deliberately open. Three different tests are listed in the marking scheme - suspending the bar, dipping it into iron pins, and touching one end to the middle of the other bar - and all three earn full marks. Do not insist on the one you taught.",
 "Question 4(a) is a four-mark recall of Newton's First Law, and the note withholds a mark if the word UNBALANCED is missing. Balanced forces are already acting on every object at rest; it takes an unbalanced force to change the motion. Teach that word before the mock.",
 "The magnet and the mechanics halves of this paper are both under the same content standard, B7/JHS1.4.4.1, which is titled 'motion, Newton's first law of motion, magnetic force in relation to motion'. That is why magnets sit in the same paper as forces - it is the curriculum's own grouping, not mine.",
 "Topic weighting is 13 marks each for topics 14.1 to 14.6 and 11 each for 14.7 and 14.8. If you spent longer on magnets than on forces, move marks towards Questions 6 and 7.",
 "Two cheap practicals that raise marks sharply: (1) flick a card from under a coin on a glass, and (2) float a magnetised needle on a leaf in a bowl of water and watch it settle north-south. The first teaches Questions 3 and 5, the second teaches Question 7(b).",
 "The companion paper covers topics 14.9 to 14.11 - simple machines, the three classes of lever, and work input, work output and efficiency - under content standard B7/JHS1.4.4.2. Use the two papers together for a full end-of-term examination on this sub-strand, or separately as two class tests.",
 "Edit the school name, academic year and examination title on page 1 before printing.",
 "This is an original, teacher-made mock. It is not a reproduction of any WAEC or NaCCA examination paper.",
]:
    w("- " + n_)
w()

open("/home/user/Basic7_Integrated_Science_Mock_Strand4_ForceAndMotion1.md", "w", encoding="utf-8").write("\n".join(L))
print("md written", len("\n".join(L)), "chars")
