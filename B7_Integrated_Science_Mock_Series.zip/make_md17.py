# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "/home/user")
from build_waste import *

L = []
def w(s=""): L.append(s)

w(f"# {SCHOOL}"); w()
w(f"## {SUBJECT}"); w()
w(f"### {EXAM}"); w()
w(f"**Class:** {CLASS}  ")
w(f"**Time:** {TIME}  ")
w(f"**Total Marks:** {MARKS}  ")
w(f"**Academic Year:** {YEAR}"); w()
w("---"); w()
w("### INSTRUCTIONS"); w()
for i, t in enumerate([
    "Write your name and class clearly in the spaces provided on your answer sheet.",
    "This paper has TWO sections: Section A and Section B.",
    "Answer ALL the questions in both sections.",
    "Section A has 40 multiple-choice questions. Each question carries 1 mark. Choose the best answer (A, B, C or D) and record it on the answer sheet provided.",
    "Section B has 7 theory questions totalling 60 marks. Write your answers clearly and neatly in your answer booklet. Draw and label diagrams or tables where you are asked to.",
    "Read every question carefully before you answer it.",
    "Do not use correction fluid. Cancel any mistake neatly with a single line.",
    "Hand in your answer sheet and your answer booklet at the end of the examination.",
], start=1):
    w(f"{i}. {t}")
w(); w("---"); w()

w("## SECTION A: OBJECTIVE TEST (40 marks)"); w()
w("*Answer ALL questions. Each question carries 1 mark. Choose the BEST answer and write its letter "
  "(A, B, C or D) against the question number on your answer sheet.*"); w()
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"**{i}. {q}**"); w()
    for j, o in enumerate(opts): w(f"{'ABCD'[j]}. {o}")
    w()
w("---"); w()

w("## SECTION B: THEORY (60 marks)"); w()
w("*Answer ALL questions. Write your answers in your answer booklet. The marks for each question are shown "
  "in brackets.*"); w()
for qb in SECTION_B:
    w(f"### Question {qb['num']}  [{qb['total']} marks]"); w()
    w(qb["stem"]); w()
    if qb.get("diagram"):
        w("```")
        for line in PIT: w(line)
        w("```")
        w("*Fig. 1: A compost pit*"); w()
    if qb.get("table") == "waste":
        w("| " + " | ".join(WASTE_HEADERS) + " |")
        w("| " + " | ".join(["---"] * len(WASTE_HEADERS)) + " |")
        for r in WASTE_ROWS:
            w("| " + " | ".join(r) + " |")
        w()
        w("*Table 1: Common types of waste*"); w()
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        w(f"**{lab}** {text}  **[{mk} mark{'s' if mk > 1 else ''}]**"); w()
w("---"); w()

w("## ANSWER KEY"); w()
w("### Section A - Objective Test"); w()
w("| Question | Answer | Curriculum Area (Topic) | Cognitive Level |")
w("| -------- | ------ | ----------------------- | --------------- |")
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"| {i} | {ans} | {TOPIC[tp]} | {cog} |")
counts = {L2: sum(1 for q in MCQ if q[2] == L2) for L2 in "ABCD"}
w()
w("Correct-answer distribution: " + ", ".join(f"{L2} = {counts[L2]}" for L2 in "ABCD") + " (40 items).")
w()
w("### Section B - Theory (summary answers; full detail in the Marking Scheme)"); w()
w("| Question | Expected Answer | Curriculum Area | Cognitive Level |")
w("| -------- | --------------- | --------------- | --------------- |")
sba = [
 ("1 (a)", "Any four: solid waste; liquid waste; gaseous waste; biodegradable waste; non-biodegradable waste; household waste; agricultural waste; industrial waste; medical or hospital waste; e-waste; sewage.", "16.1", "Remember"),
 ("1 (b)", "Biodegradable waste can be broken down or rotted by bacteria and fungi, e.g. food remains and leaves. Non-biodegradable waste cannot be broken down by living organisms, e.g. plastic bags, glass and metals. Biodegradable waste rots away after a time; the other stays in the environment for a very long time.", "16.1", "Understand"),
 ("2 (a)", "(i) biodegradable, (ii) non-biodegradable, (iii) biodegradable, (iv) non-biodegradable, (v) non-biodegradable, (vi) biodegradable.", "16.1", "Understand"),
 ("2 (b)", "Any two sources with a matching type - e.g. the market: vegetable leaves and polythene bags; the farm: maize stalks and animal droppings; the school: used paper and food wrappers.", "16.1", "Apply"),
 ("3 (a)", "Any four: sort waste into different containers; put waste into covered bins and empty them regularly; compost biodegradable waste; reuse bottles, bags and containers; recycle paper, plastics, glass and metals; dispose of batteries and medicines separately and safely; do not litter; clean gutters and drains.", "16.2", "Understand"),
 ("3 (b)", "Waste in a gutter blocks the flow of water, so rain water cannot drain away and the streets flood. Standing dirty water breeds mosquitoes, the rotting waste smells and attracts flies and rats, and the overflow can carry waste into water people use.", "16.2", "Understand"),
 ("3 (c)", "Any two: buy only what the household needs; choose goods with little or recyclable wrapping; compost food remains; reuse bags, bottles and containers; repair clothes and furniture instead of replacing them.", "16.2", "Apply"),
 ("4 (a)", "REDUCE means producing less waste in the first place, e.g. buying only what is needed. REUSE means using an item again for the same or another purpose, e.g. an old margarine tin to store salt. RECYCLE means changing waste material into new useful products, e.g. melting old aluminium to make new pans.", "16.2", "Understand"),
 ("4 (b)", "Any two: recycling turns the material into something useful while burning destroys it; burning plastic gives off poisonous gases; burning causes air pollution while recycling does not; recycling saves raw materials and energy.", "16.2", "Evaluate"),
 ("5 (a)", "(i) the top layer - a covering of soil, dry grass or dry leaves. (ii) the middle layer - the organic waste being composted, such as food remains and green leaves. (iii) the bottom layer - coarse dry material such as stalks, husks and dry grass.", "16.3", "Understand"),
 ("5 (b)", "Bacteria and fungi in the soil feed on the waste and break it down into simple substances such as water, carbon dioxide and humus. The process needs moisture, warmth and air, so the heap is turned over from time to time. After some weeks it becomes a dark, crumbly material called compost.", "16.3", "Understand"),
 ("5 (c)", "Plastic is made of long chains of molecules that bacteria and fungi cannot digest, so the micro-organisms that rot food remains have no way of breaking plastic down. Plastic may break into small pieces but it does not rot into simple substances, so it stays in the soil for a very long time.", "16.3", "Analyse"),
 ("6 (a)", "Any three: blocked gutters cause flooding; rotting waste smells; waste attracts flies, rats and other pests; standing dirty water breeds mosquitoes that spread malaria; waste pollutes streams, rivers and soil; cholera, dysentery and typhoid can spread; burning pollutes the air; the environment becomes ugly.", "16.3", "Understand"),
 ("6 (b)", "Non-biodegradable waste such as plastic and glass does not rot, so it stays in the ground for many years. It can release harmful liquids that soak into the soil and poison it, and those liquids can reach a stream or borehole. The waste takes up space, rotting waste gives off methane, animals may dig it up, and rain may wash a shallow hole open.", "16.3", "Apply"),
 ("7 (a)", "Hold a class meeting to agree the aim and choose the area. Walk round the area and list what needs doing. Share out the work and collect the tools and refuse bags. Work in groups wearing gloves and boots, keeping clear of anything sharp. Sort the waste into what can be composted, recycled or dumped, carry it away and dispose of it properly, arrange for dustbins, then write and present the report.", "16.4", "Create"),
 ("7 (b)", "Any three: refuse bags or sacks; rakes; cutlasses; shovels or spades; wheelbarrows; gloves and boots; nose covers or face masks; a first-aid box; separate containers for sorting; water to drink.", "16.4", "Remember"),
 ("7 (c)", "Any three: the aim of the project; the area cleaned and when; who took part; the tools and materials used; the kinds and amounts of waste collected; what was done with the waste; problems met and what would be done differently; recommendations for keeping the area clean.", "16.4", "Understand"),
]
for r in sba: w(f"| {r[0]} | {r[1]} | {r[2]} | {r[3]} |")
w(); w("---"); w()

w("## MARKING SCHEME - SECTION B (60 marks)"); w()
w("*General rules: (1) Accept any other correct and relevant answer. (2) Award marks for correct points, not "
  "for repeating the question. (3) For procedures, award method marks. (4) Do not deduct marks for spelling "
  "unless the meaning is changed. (5) Where a candidate gives more answers than are asked for, mark only the "
  "first ones up to the number required.*"); w()
for qb in SECTION_B:
    n = qb["num"]
    w(f"### Question {n} ({qb['total']} marks)"); w()
    for (lab, points, note) in MARKING[n]:
        mkv = [p_[2] for p_ in qb["parts"] if p_[0] == lab]
        head = f"**{lab}**"
        if mkv: head += f" [{mkv[0]} mark{'s' if mkv[0] > 1 else ''}]"
        w(head); w()
        for pt in points: w(f"- {pt}")
        w(f"  - *Marking note: {note}*"); w()
w("---"); w()

w("## CURRICULUM ASSESSMENT BLUEPRINT"); w()
w(f"**Strand:** {STRAND} | **Sub-strand:** {SUBSTRAND} | **Class:** {CLASS}"); w()
w(f"**Content Standard:** {CS} - {CS_TEXT}"); w()
w("> Source: NaCCA Science Common Core Programme Curriculum (B7/JHS1-B9/JHS3), September 2020, "
  "Strand 5: Humans and the Environment, Sub-strand 1: Waste Management, p. 44. "
  "Indicators are quoted, not invented."); w()

w("### Section A"); w()
w("| Qn | Sub-strand | Content Standard | Indicator (NaCCA) - Indicator Text | Topic / Content | Cognitive Level | Marks |")
w("| -- | ---------- | ---------------- | ---------------------------------- | --------------- | --------------- | ----- |")
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"| A{i} | {SUBSTRAND} | {CS_BY_TOPIC[tp]} | {IND[tp]} - {IND_TEXT[tp]} | {TOPIC[tp]} | {cog} | 1 |")
w()
w("### Section B"); w()
w("| Qn | Sub-strand | Content Standard | Indicator (NaCCA) - Indicator Text | Topic / Content | Cognitive Level | Marks |")
w("| -- | ---------- | ---------------- | ---------------------------------- | --------------- | --------------- | ----- |")
for qb in SECTION_B:
    for (lab, text, mkv, cog, tp, diff) in qb["parts"]:
        key = tp if tp in TOPIC else tp.split(",")[0].strip()
        w(f"| B{qb['num']}{lab.strip('()')} | {SUBSTRAND} | {CS_BY_TOPIC[key]} | {IND[key]} - {IND_TEXT[key]} | {TOPIC[key]} | {cog} | {mkv} |")
w(); w("---"); w()

def topic_totals():
    m = {k: 0 for k in TOPIC}; it = {k: 0 for k in TOPIC}
    for q in MCQ: m[q[3]] += 1; it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk; it[key] += 1
    return m, it

def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}; b = {k: 0 for k in order}
    for q in MCQ: a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: b[cog] += mk
    return order, a, b

def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ: d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: d[diff] += mk
    return d

m, it = topic_totals(); diff_ = difficulty_totals(); order, ca, cb = cognitive_by_section()

w("### Summary 1 - Coverage by Curriculum Area (Topic)"); w()
w("| Topic / Content Area | No. of Items | Marks | % of Total Marks | Core Competencies |")
w("| -------------------- | ------------ | ----- | ---------------- | ----------------- |")
for k in TOPIC: w(f"| {TOPIC[k]} | {it[k]} | {m[k]} | {(m[k]/100)*100:.1f}% | {CC[k]} |")
w(f"| **TOTAL** | **{sum(it.values())}** | **{sum(m.values())}** | **100%** | - |")
w()
w("*CC = Communication and Collaboration; CP = Critical Thinking and Problem Solving; DL = Digital Literacy; "
  "CI = Creativity and Innovation.*"); w()
w("### Summary 2 - Cognitive-Level Distribution (Bloom's Taxonomy)"); w()
w("| Cognitive Level | Section A Marks | Section B Marks | Total Marks | % of Total |")
w("| --------------- | --------------- | --------------- | ----------- | ---------- |")
for lv in order:
    tot = ca[lv] + cb[lv]
    w(f"| {lv} | {ca[lv]} | {cb[lv]} | {tot} | {(tot/100)*100:.1f}% |")
w(f"| **TOTAL** | **{sum(ca.values())}** | **{sum(cb.values())}** | **{sum(ca.values())+sum(cb.values())}** | **100%** |")
w()
w("### Summary 3 - Difficulty Distribution"); w()
w("| Difficulty | Marks | % of Total Marks |")
w("| ---------- | ----- | ---------------- |")
for k, v in diff_.items(): w(f"| {k} | {v} | {(v/100)*100:.1f}% |")
w(f"| **TOTAL** | **{sum(diff_.values())}** | **100%** |")
w()
w("*Target in the master prompt: approximately 30% easy / 50% moderate / 20% challenging.*"); w()
w("### Summary 4 - Section Weighting"); w()
w("| Section | Question Type | Items | Marks | % of Total |")
w("| ------- | ------------- | ----- | ----- | ---------- |")
w("| A | Objective (multiple choice) | 40 | 40 | 40% |")
w("| B | Theory / constructed response | 17 | 60 | 60% |")
w("| **TOTAL** | - | **57** | **100** | **100%** |")
w(); w("---"); w()

w("## QUALITY-CONTROL SUMMARY")
w("")
w("| Check | Status |")
w("| --- | --- |")
for q_, a_ in [
 ("Every question within supplied curriculum scope",
  "Yes - all 57 items (40 objectives and 17 theory sub-questions) sit in topics 16.1-16.4 of Strand 5, Sub-Strand 1 (Waste Management), under content standard B7/JHS1.5.1.1, mapped to indicator B7/JHS1.5.1.1.1. All three exemplars are covered: carrying out a project, writing a report for presentation, and discussing how to manage types of waste with the science underlying it"),
 ("Appropriate for the class",
  "Yes - B7 level; no incineration technology, no landfill engineering, no waste-to-energy and no polymer chemistry beyond 'micro-organisms cannot digest it'"),
 ("Genuinely BECE-style",
  "Yes - 40 four-option objectives plus structured theory with printed mark allocations, a labelled diagram of a compost pit, a six-row classification table, several 'state' and 'name' items, and two open tasks requiring explanation, judgement and planning"),
 ("Sufficient application and reasoning",
  "Yes - 30 of 100 marks (30%) at Apply level or above (Apply 20, Analyse 4, Evaluate 2, Create 4)"),
 ("Plausible MCQ distractors",
  "Yes - another state or type of waste, a genuine term that is not the one asked for, a real activity that is not good practice, a real item that is not waste management practice, and a genuine safety measure reversed"),
 ("Single best answer per MCQ",
  "Yes - reviewed item by item and each option list was checked so that the declared key sits on the correct answer; a glass bottle and a polythene bag are both non-biodegradable in A6 so that only banana peels fits, recycling, burning and composting are all real terms in A15 but only segregation means sorting, and three of the four options in A40 are genuinely safe"),
 ("Marks internally consistent",
  "Yes - Section A 40 x 1 = 40; Section B 9 + 8 + 9 + 8 + 9 + 7 + 10 = 60; sub-question marks match the marking scheme"),
 ("Total adds up correctly",
  "Yes - 40 + 60 = 100"),
 ("Answer key correct",
  "Yes - all 40 keys and all 17 Section B answers verified against the marking scheme; the diagram key checked against the figure (covering on top, organic waste in the middle, coarse dry material at the bottom) and the table key checked row by row (paper and garden waste are biodegradable, while plastic, metal and glass are not)"),
 ("Marking scheme matches questions",
  "Yes - expected answers plus marking notes covering partial credit, alternatives, common wrong answers and method marks; Question 4(a) reserves one mark of each pair for the example, Question 5(a) still awards 2 marks if the top and bottom layers are reversed but the middle is right, and Question 7(a) caps the answer at 3 if it does no more than sweep the compound"),
 ("Free from unnecessary ambiguity",
  "Yes - open items are anchored with 'name four', 'state three' and 'state two' plus the mark allocation; Question 1(b) requires both the difference and one example of each, Question 4(b) requires a comparison of recycling with burning, Question 1(a) notes that a type without an example still scores but an example with no type does not, and Question 6(b) asks specifically about burying"),
 ("Ghanaian contexts natural and accurate",
  "Yes - maize stalks and cocoa husks, polythene bags and pure water sachets, kitchen food remains and vegetable peels, blocked gutters and rainy-season flooding, mosquitoes and malaria, cholera and dysentery, refuse dumped in a stream, a market, a borehole, and a school clean-up presented to the class"),
 ("No content beyond the curriculum",
  "No - every item sits inside topics 16.1-16.4; incineration technology, landfill engineering, waste-to-energy plants, sewage treatment works and polymer chemistry are not required anywhere in the paper"),
 ("Questions sufficiently varied",
  "Yes - defining waste, classifying solid, liquid and gaseous waste, distinguishing biodegradable from non-biodegradable, completing a six-row classification table, naming sources of waste, stating four good practices, explaining why gutters must stay clear, reducing waste at home, explaining reduce, reuse and recycle with examples, arguing recycling against burning, naming the layers of a compost pit, explaining decomposition, explaining why plastic does not rot, listing the problems of poor waste management, explaining why burying waste is unsatisfactory, planning a school clean-up project, listing what the project needs, and listing the contents of the report"),
]:
    w("| " + q_ + " | " + a_ + " |")
w("")
w("### EXAMINER NOTES")
w("")
for n_ in [
 "Question 5(a) is the item pupils are most likely to argue about, because a compost pit can be built in more than one order. The note accepts the standard answer - covering on top, waste in the middle, coarse material at the bottom - but still awards 2 marks to a pupil who reverses the top and bottom layers provided they identify the middle layer as the waste. The one answer that earns nothing is 'compost' for any of the three labels: compost is what the pit produces, not a layer in it.",
 "Question 7(a) is the design task and it is the one that carries the indicator's real demand - the curriculum asks pupils to USE what they have researched to carry out a project. The note caps the answer at 3 of 4 if it does no more than say the class will sweep the compound, and it looks for at least one point about planning and one about what happens to the waste afterwards. Safety earns a mark, so tell them to mention gloves and boots.",
 "Question 4(a) is marked twice over: one mark for the meaning of each of the three terms and one for its example. Pupils who know reduce, reuse and recycle perfectly but write no examples lose half the marks. Worth drilling before the mock.",
 "Questions 2(a) and 1(b) both turn on the biodegradable line, and the two that catch pupils out are paper and glass. Paper rots, so it is biodegradable; glass does not, so it is not. Several pupils assume that anything recycled must be non-biodegradable.",
 "Topic weighting is 28 marks for 16.1, 26 for 16.2, 27 for 16.3 and 19 for 16.4. If you spent longer on the community project than on types of waste, move marks towards Question 7.",
 "Two cheap practicals that raise marks sharply: (1) bury a banana peel, a piece of paper, a polythene bag and a nail in a box of soil, water it, and dig them up after three weeks; and (2) start a class compost pit behind the science block and use it all term. The first teaches Questions 1, 2 and 5, the second teaches Questions 3, 5 and 7.",
 "Question 7 is worth doing for real rather than only on paper. One afternoon of cleaning the school compound, followed by a short report presented to the class, satisfies the indicator directly and gives every pupil something concrete to write about in the mock.",
 "Edit the school name, academic year and examination title on page 1 before printing.",
 "This is an original, teacher-made mock. It is not a reproduction of any WAEC or NaCCA examination paper.",
]:
    w("- " + n_)
w()

open("/home/user/Basic7_Integrated_Science_Mock_Strand5_WasteManagement.md", "w", encoding="utf-8").write("\n".join(L))
print("md written", len("\n".join(L)), "chars")
