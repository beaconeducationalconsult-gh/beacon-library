# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "/home/user")
from build_solar import *

L = []
def w(s=""): L.append(s)

w(f"# {SCHOOL}"); w()
w(f"## {SUBJECT}"); w()
w(f"### {EXAM}"); w()
w(f"**Class:** {CLASS}  ")
w(f"**Time:** {TIME}  ")
w(f"**Total Marks:** {MARKS}  ")
w(f"**Academic Year:** {YEAR}"); w()
w("---"); w()
w("### INSTRUCTIONS"); w()
for i, t in enumerate([
    "Write your name and class clearly in the spaces provided on your answer sheet.",
    "This paper has TWO sections: Section A and Section B.",
    "Answer ALL the questions in both sections.",
    "Section A has 40 multiple-choice questions. Each question carries 1 mark. Choose the best answer (A, B, C or D) and record it on the answer sheet provided.",
    "Section B has 7 theory questions totalling 60 marks. Write your answers clearly and neatly in your answer booklet. Draw and label diagrams or tables where you are asked to.",
    "Read every question carefully before you answer it.",
    "Do not use correction fluid. Cancel any mistake neatly with a single line.",
    "Hand in your answer sheet and your answer booklet at the end of the examination.",
], start=1):
    w(f"{i}. {t}")
w(); w("---"); w()

w("## SECTION A: OBJECTIVE TEST (40 marks)"); w()
w("*Answer ALL questions. Each question carries 1 mark. Choose the BEST answer and write its letter "
  "(A, B, C or D) against the question number on your answer sheet.*"); w()
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"**{i}. {q}**"); w()
    for j, o in enumerate(opts): w(f"{'ABCD'[j]}. {o}")
    w()
w("---"); w()

w("## SECTION B: THEORY (60 marks)"); w()
w("*Answer ALL questions. Write your answers in your answer booklet. The marks for each question are shown "
  "in brackets.*"); w()
for qb in SECTION_B:
    w(f"### Question {qb['num']}  [{qb['total']} marks]"); w()
    w(qb["stem"]); w()
    if qb.get("diagram"):
        w("```")
        for line in INNER_PLANETS: w(line)
        w("```")
        w("*Fig. 1: The inner planets (not drawn to scale)*"); w()
    if qb.get("table") == "properties":
        w("| " + " | ".join(PROP_HEADERS) + " |")
        w("| " + " | ".join(["---"] * len(PROP_HEADERS)) + " |")
        for r in PROP_ROWS:
            w("| " + " | ".join(r) + " |")
        w()
        w("*Table 1: Properties of the inner planets*"); w()
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        w(f"**{lab}** {text}  **[{mk} mark{'s' if mk > 1 else ''}]**"); w()
w("---"); w()

w("## ANSWER KEY"); w()
w("### Section A - Objective Test"); w()
w("| Question | Answer | Curriculum Area (Topic) | Cognitive Level |")
w("| -------- | ------ | ----------------------- | --------------- |")
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"| {i} | {ans} | {TOPIC[tp]} | {cog} |")
counts = {L2: sum(1 for q in MCQ if q[2] == L2) for L2 in "ABCD"}
w()
w("Correct-answer distribution: " + ", ".join(f"{L2} = {counts[L2]}" for L2 in "ABCD") + " (40 items).")
w()
w("### Section B - Theory (summary answers; full detail in the Marking Scheme)"); w()
w("| Question | Expected Answer | Curriculum Area | Cognitive Level |")
w("| -------- | --------------- | --------------- | --------------- |")
sba = [
 ("1 (a)", "The Sun together with all the bodies that move around it: the eight planets and their moons, dwarf planets, asteroids, comets and meteoroids, all held by the Sun's gravity.", "8.1", "Understand"),
 ("1 (b)", "Mercury, Venus, Earth, Mars (in that order from the Sun).", "8.1", "Remember"),
 ("1 (c)", "It gives out the light and heat the planets receive, and its gravity holds everything in its path; without it there would be no solar system.", "8.1", "Understand"),
 ("2 (a)", "A galaxy is a very large group of stars, gas and dust held together by gravity. Our galaxy is the Milky Way.", "8.2", "Understand"),
 ("2 (b)", "The Milky Way is the spiral galaxy in which the Sun and the solar system are found; it contains many millions of stars and is only one of many galaxies.", "8.2", "Understand"),
 ("2 (c)", "The Sun is by far the nearest star to the Earth, so we get almost all our light and heat from it; the other stars are too far away to warm us, and the Sun's gravity keeps the Earth in its path.", "8.2", "Understand"),
 ("3 (a)", "1 = Mercury; 2 = Venus; 3 = Earth; 4 = Mars.", "8.3", "Remember"),
 ("3 (b)", "Any three of: they are small; they have a solid rocky surface (terrestrial); they are the four nearest the Sun and so are warmer; they have few moons or none; they have no rings.", "8.3", "Understand"),
 ("3 (c)", "Being an inner planet depends on how near the Sun a planet is, not on its size. Jupiter and Saturn are far from the Sun, so they belong to the OUTER planets (the gas giants).", "8.3", "Apply"),
 ("4 (a)", "(i) the smallest planet, nearest the Sun, shortest year (about 88 days); (ii) the hottest planet, about the same size as the Earth, thick atmosphere of carbon dioxide; (iii) 1; (iv) 2.", "8.4", "Understand"),
 ("4 (b)", "Smallest: Mercury. Largest: Earth.", "8.4", "Remember"),
 ("4 (c)", "Venus has a thick atmosphere of carbon dioxide which traps the Sun's heat and will not let it escape; Mercury has almost no atmosphere, so its heat escapes back into space.", "8.4", "Analyse"),
 ("5 (a)", "Mercury moves round the Sun along its own orbit; it is the nearest planet, so its path is the shortest and it moves fastest; it has the shortest year, about 88 Earth days.", "8.5", "Understand"),
 ("5 (b)", "Venus moves round the Sun along its own orbit, outside that of Mercury; it is the second planet from the Sun and takes about 225 Earth days to go once round it.", "8.5", "Understand"),
 ("5 (c)", "Mercury is nearer the Sun, so the Sun's pull on it is stronger and it moves faster; its path is also shorter. Venus is further away, so the pull is weaker and its path is longer.", "8.5", "Analyse"),
 ("6 (a)", "The path a planet follows as it moves around the Sun.", "8.6", "Understand"),
 ("6 (b)", "An oval path - a flattened circle, not a perfect circle - with two foci instead of one centre.", "8.6", "Understand"),
 ("6 (c)", "Because the Sun is off to one side of the ellipse, the planet is nearer the Sun at one part of the path and further away at another, so the distance changes during one orbit. The Sun lies at one focus of the ellipse, not at its centre.", "8.6", "Analyse"),
 ("7 (a)", "Decide what the model will show; gather materials such as balls of clay or paper, string, wire, cardboard and paint; make the Sun the biggest ball; make and label the eight planets in the right order from the Sun; hang or fix them on a frame; show each path as an ellipse.", "8.1", "Create"),
 ("7 (b)", "Any two of: a model shows the order and relative sizes in a way a drawing cannot; the class can handle it and walk round it; building it together makes pupils explain it to one another; it shows the shapes of the paths. One thing it must show: the planets in the correct order from the Sun (or the paths as ellipses, or the Sun at the centre).", "8.6", "Evaluate"),
]
for r in sba: w(f"| {r[0]} | {r[1]} | {r[2]} | {r[3]} |")
w(); w("---"); w()

w("## MARKING SCHEME - SECTION B (60 marks)"); w()
w("*General rules: (1) Accept any other correct and relevant answer. (2) Award marks for correct points, not "
  "for repeating the question. (3) For procedures, award method marks. (4) Do not deduct marks for spelling "
  "unless the meaning is changed. (5) Where a candidate gives more answers than are asked for, mark only the "
  "first ones up to the number required.*"); w()
for qb in SECTION_B:
    n = qb["num"]
    w(f"### Question {n} ({qb['total']} marks)"); w()
    for (lab, points, note) in MARKING[n]:
        mkv = [p_[2] for p_ in qb["parts"] if p_[0] == lab]
        head = f"**{lab}**"
        if mkv: head += f" [{mkv[0]} mark{'s' if mkv[0] > 1 else ''}]"
        w(head); w()
        for pt in points: w(f"- {pt}")
        w(f"  - *Marking note: {note}*"); w()
w("---"); w()

w("## CURRICULUM ASSESSMENT BLUEPRINT"); w()
w(f"**Strand:** {STRAND} | **Sub-strand:** {SUBSTRAND} | **Class:** {CLASS}"); w()
w(f"**Content Standard:** {CS} - {CS_TEXT}"); w()
w("> Source: NaCCA Science Common Core Programme Curriculum (B7/JHS1-B9/JHS3), September 2020, "
  "Strand 3: Systems, Sub-strand 2: The Solar System, pp. 19-20. Indicators are quoted, not "
  "invented."); w()

w("### Section A"); w()
w("| Qn | Sub-strand | Content Standard | Indicator (NaCCA) - Indicator Text | Topic / Content | Cognitive Level | Marks |")
w("| -- | ---------- | ---------------- | ---------------------------------- | --------------- | --------------- | ----- |")
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"| A{i} | {SUBSTRAND} | {CS_BY_TOPIC[tp]} | {IND[tp]} - {IND_TEXT[tp]} | {TOPIC[tp]} | {cog} | 1 |")
w()
w("### Section B"); w()
w("| Qn | Sub-strand | Content Standard | Indicator (NaCCA) - Indicator Text | Topic / Content | Cognitive Level | Marks |")
w("| -- | ---------- | ---------------- | ---------------------------------- | --------------- | --------------- | ----- |")
for qb in SECTION_B:
    for (lab, text, mkv, cog, tp, diff) in qb["parts"]:
        key = tp if tp in TOPIC else tp.split(",")[0].strip()
        w(f"| B{qb['num']}{lab.strip('()')} | {SUBSTRAND} | {CS_BY_TOPIC[key]} | {IND[key]} - {IND_TEXT[key]} | {TOPIC[key]} | {cog} | {mkv} |")
w(); w("---"); w()

def topic_totals():
    m = {k: 0 for k in TOPIC}; it = {k: 0 for k in TOPIC}
    for q in MCQ: m[q[3]] += 1; it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk; it[key] += 1
    return m, it

def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}; b = {k: 0 for k in order}
    for q in MCQ: a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: b[cog] += mk
    return order, a, b

def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ: d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: d[diff] += mk
    return d

m, it = topic_totals(); diff_ = difficulty_totals(); order, ca, cb = cognitive_by_section()

w("### Summary 1 - Coverage by Curriculum Area (Topic)"); w()
w("| Topic / Content Area | No. of Items | Marks | % of Total Marks | Core Competencies |")
w("| -------------------- | ------------ | ----- | ---------------- | ----------------- |")
for k in TOPIC: w(f"| {TOPIC[k]} | {it[k]} | {m[k]} | {(m[k]/100)*100:.1f}% | {CC[k]} |")
w(f"| **TOTAL** | **{sum(it.values())}** | **{sum(m.values())}** | **100%** | - |")
w()
w("*CC = Communication and Collaboration; CP = Critical Thinking and Problem Solving; DL = Digital Literacy; "
  "CI = Creativity and Innovation.*"); w()
w("### Summary 2 - Cognitive-Level Distribution (Bloom's Taxonomy)"); w()
w("| Cognitive Level | Section A Marks | Section B Marks | Total Marks | % of Total |")
w("| --------------- | --------------- | --------------- | ----------- | ---------- |")
for lv in order:
    tot = ca[lv] + cb[lv]
    w(f"| {lv} | {ca[lv]} | {cb[lv]} | {tot} | {(tot/100)*100:.1f}% |")
w(f"| **TOTAL** | **{sum(ca.values())}** | **{sum(cb.values())}** | **{sum(ca.values())+sum(cb.values())}** | **100%** |")
w()
w("### Summary 3 - Difficulty Distribution"); w()
w("| Difficulty | Marks | % of Total Marks |")
w("| ---------- | ----- | ---------------- |")
for k, v in diff_.items(): w(f"| {k} | {v} | {(v/100)*100:.1f}% |")
w(f"| **TOTAL** | **{sum(diff_.values())}** | **100%** |")
w()
w("*Target in the master prompt: approximately 30% easy / 50% moderate / 20% challenging.*"); w()
w("### Summary 4 - Section Weighting"); w()
w("| Section | Question Type | Items | Marks | % of Total |")
w("| ------- | ------------- | ----- | ----- | ---------- |")
w("| A | Objective (multiple choice) | 40 | 40 | 40% |")
w("| B | Theory / constructed response | 20 | 60 | 60% |")
w("| **TOTAL** | - | **60** | **100** | **100%** |")
w(); w("---"); w()

w("## QUALITY-CONTROL SUMMARY")
w("")
w("| Check | Status |")
w("| --- | --- |")
for q_, a_ in [
 ("Every question within supplied curriculum scope",
  "Yes - topics 8.1-8.6 of Strand 3, Sub-Strand 2 (The Solar System), mapped to indicators B7/JHS1.3.2.1.1 and B7/JHS1.3.2.1.2"),
 ("Appropriate for the class",
  "Yes - B7 level; no calculation of orbital periods, no distances in kilometres and no physics of gravity, all of which sit outside the B7 indicator"),
 ("Genuinely BECE-style",
  "Yes - 40 four-option objectives plus structured theory with printed mark allocations, a labelled diagram and a completion table"),
 ("Sufficient application and reasoning",
  "Yes - 29 of 100 marks (29%) at Apply level or above (Apply 9, Analyse 11, Evaluate 5, Create 4)"),
 ("Plausible MCQ distractors",
  "Yes - drawn from the same content family as the key: the outer planets, the wrong order from the Sun, the wrong property for a named planet, and the misconception that the nearest planet is the hottest"),
 ("Single best answer per MCQ",
  "Yes - reviewed item by item; special care with A24, where the keyed option correctly says Venus shines because it is bright, not because it gives out its own light"),
 ("Marks internally consistent",
  "Yes - Section A 40 x 1 = 40; Section B 8 + 9 + 10 + 8 + 9 + 9 + 7 = 60; sub-question marks match the marking scheme"),
 ("Total adds up correctly",
  "Yes - 40 + 60 = 100"),
 ("Answer key correct",
  "Yes - all 40 keys and all 20 Section B answers verified against the marking scheme"),
 ("Marking scheme matches questions",
  "Yes - expected answers plus marking notes covering partial credit, alternatives, common wrong answers and method marks; the diagram key, the completion table and the model-construction task have explicit marking grids"),
 ("Free from unnecessary ambiguity",
  "Yes - open items are anchored with 'state three', 'name two' and the mark allocation; Question 4(a) numbers every blank (i) to (iv), and Question 7(b) asks for two reasons plus one thing the model must show"),
 ("Ghanaian contexts natural and accurate",
  "Yes - materials a Ghanaian class can really find (clay, paper, string, wire, cardboard and paint), group work in class, watching the sky on a clear night away from the city lights, and the Sun as the source of the light and heat Ghana depends on"),
 ("No content beyond the curriculum",
  "No - Question 2 and Question 6 use the galaxy-and-Milky-Way and elliptical-path parts of exemplar 2; Question 7 uses exemplar 3, the model; Questions 4 and 5 use exemplars 1 and 2 of B7/JHS1.3.2.1.2, which name Mercury and Venus"),
 ("Questions sufficiently varied",
  "Yes - definition, ordering, diagram labelling, stating common properties, comparing inner with outer planets, completing a properties table, explaining a misconception, describing motion, explaining an elliptical path, and designing a model"),
]:
    w("| " + q_ + " | " + a_ + " |")
w("")
w("### EXAMINER NOTES")
w("")
for n_ in [
 "The two indicators name only Mercury and Venus specifically (B7/JHS1.3.2.1.2), so Questions 4 and 5 are built around those two planets. Earth and Mars are tested only as members of the inner four, which is what B7/JHS1.3.2.1.1 asks for.",
 "Question 3 is the 'identify the inner planets from a picture' exemplar. The diagram is drawn with text characters: redraw it with real circles or paste in a printed picture - the numbering (1-4) is what the questions depend on. Key: 1 Mercury, 2 Venus, 3 Earth, 4 Mars.",
 "Question 4(c) targets the most common misconception in this topic: that the planet nearest the Sun must be the hottest. The expected answer is the thick carbon-dioxide atmosphere of Venus that traps heat. Expect many pupils to give the wrong answer here.",
 "Question 7 is the 'design and construct a model' exemplar. Because it is open, award method marks generously: any sensible step earns credit. Look first for the correct order of the planets, the Sun at the centre, and materials a real class could find. If your class actually builds the model, accept what they did as evidence.",
 "Question 6(c) expects only that the Sun is off to one side of the ellipse and that the distance therefore changes. Do NOT expect the word 'focus' or any statement of Kepler's laws - that is beyond B7.",
 "Topic 8.1 carries 19 of 100 marks, the highest weighting, because defining the solar system and building the model are the opening and closing tasks of the indicator. If you want a flatter spread, move marks from Questions 1 and 7 to Questions 2 and 5.",
 "If you have printed pictures, a chart or a short video of the solar system, use them during revision: exemplar 1 of B7/JHS1.3.2.1.1 specifically asks pupils to identify the inner planets using pictures and videos.",
 "Edit the school name, academic year and examination title on page 1 before printing.",
 "This is an original, teacher-made mock. It is not a reproduction of any WAEC or NaCCA examination paper.",
]:
    w("- " + n_)
w()

open("/home/user/Basic7_Integrated_Science_Mock_Strand3_SolarSystem.md", "w", encoding="utf-8").write("\n".join(L))
print("md written", len("\n".join(L)), "chars")
