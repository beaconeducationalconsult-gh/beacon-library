# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "/home/user")
from build_exam import *  # data

from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.section import WD_ORIENT

doc = Document()

# page setup
sec = doc.sections[0]
sec.left_margin = Inches(0.7); sec.right_margin = Inches(0.7)
sec.top_margin = Inches(0.7); sec.bottom_margin = Inches(0.6)

st = doc.styles["Normal"]
st.font.name = "Calibri"
st.font.size = Pt(11)


def set_font(run, size=11, bold=False, italic=False, mono=False, color=None):
    run.font.size = Pt(size)
    run.bold = bold
    run.italic = italic
    run.font.name = "Consolas" if mono else "Calibri"
    if color:
        run.font.color.rgb = color
    return run


def para(text="", size=11, bold=False, italic=False, align=None, mono=False,
         space_before=0, space_after=4, color=None):
    p = doc.add_paragraph()
    if align == "c":
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    elif align == "j":
        p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p.paragraph_format.space_before = Pt(space_before)
    p.paragraph_format.space_after = Pt(space_after)
    if text:
        r = p.add_run(text)
        set_font(r, size, bold, italic, mono, color)
    return p


def rule():
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(6)
    p.paragraph_format.space_before = Pt(2)
    r = p.add_run("_" * 78)
    set_font(r, 9, color=RGBColor(0x99, 0x99, 0x99))


def add_table(headers, rows, widths=None, size=9, head_size=9, grid=True):
    t = doc.add_table(rows=1, cols=len(headers))
    t.style = "Table Grid" if grid else "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    hdr = t.rows[0].cells
    for i, h in enumerate(headers):
        hdr[i].text = ""
        p = hdr[i].paragraphs[0]
        r = p.add_run(str(h))
        set_font(r, head_size, bold=True)
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    for row in rows:
        cells = t.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = ""
            p = cells[i].paragraphs[0]
            p.paragraph_format.space_after = Pt(1)
            r = p.add_run(str(v))
            set_font(r, size)
    if widths:
        for r_ in t.rows:
            for i, w in enumerate(widths):
                r_.cells[i].width = Inches(w)
    return t


# ============================================================ TITLE BLOCK
para(SCHOOL, size=15, bold=True, align="c", space_after=2)
para(SUBJECT, size=13, bold=True, align="c", space_after=2)
para(EXAM, size=12, bold=True, align="c", space_after=2)
para(YEAR, size=10, italic=True, align="c", space_after=8)

info = doc.add_table(rows=1, cols=3)
info.style = "Table Grid"
info.alignment = WD_TABLE_ALIGNMENT.CENTER
vals = [f"Class: {CLASS}", f"Time: {TIME}", f"Total Marks: {MARKS}"]
for i, v in enumerate(vals):
    c = info.rows[0].cells[i]
    c.text = ""
    p = c.paragraphs[0]
    r = p.add_run(v)
    set_font(r, 10, bold=True)

para("", space_after=6)

# instructions
para("INSTRUCTIONS", size=11, bold=True, space_after=3)
for txt in [
    "1. Write your name and class clearly in the spaces provided on your answer sheet.",
    "2. This paper has TWO sections: Section A and Section B.",
    "3. Answer ALL the questions in both sections.",
    "4. Section A has 40 multiple-choice questions. Each question carries 1 mark. Choose the best answer "
    "(A, B, C or D) and record it on the answer sheet provided.",
    "5. Section B has 7 theory questions totalling 60 marks. Write your answers clearly and neatly in your "
    "answer booklet. Show all your working where necessary.",
    "6. Read every question carefully before you answer it.",
    "7. Do not use correction fluid. Cancel any mistake neatly with a single line.",
    "8. Hand in your answer sheet and your answer booklet at the end of the examination.",
]:
    para(txt, size=10.5, space_after=2)

rule()

# ============================================================== SECTION A
para("SECTION A - OBJECTIVE TEST (40 marks)", size=12, bold=True, align="c", space_after=2)
para("Answer ALL questions. Each question carries 1 mark. Choose the BEST answer and write its letter "
     "(A, B, C or D) against the question number on your answer sheet.",
     size=10, italic=True, align="c", space_after=8)

for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(1)
    p.paragraph_format.space_before = Pt(4)
    r = p.add_run(f"{i}. {q}")
    set_font(r, 10.5, bold=False)
    for j, o in enumerate(opts):
        letter = "ABCD"[j]
        p2 = doc.add_paragraph()
        p2.paragraph_format.left_indent = Inches(0.28)
        p2.paragraph_format.space_after = Pt(0)
        p2.paragraph_format.space_before = Pt(0)
        r2 = p2.add_run(f"{letter}. {o}")
        set_font(r2, 10.5)

doc.add_page_break()

# ============================================================== SECTION B
para("SECTION B - THEORY (60 marks)", size=12, bold=True, align="c", space_after=2)
para("Answer ALL questions. Write your answers in your answer booklet. The marks for each question are "
     "shown in brackets.", size=10, italic=True, align="c", space_after=8)

for qb in SECTION_B:
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(8)
    p.paragraph_format.space_after = Pt(2)
    r = p.add_run(f"Question {qb['num']}")
    set_font(r, 11, bold=True)
    r2 = p.add_run(f"  [{qb['total']} marks]")
    set_font(r2, 10, bold=True, italic=True)

    para(qb["stem"], size=10.5, space_after=4)

    if qb.get("diagram"):
        for ln in PARTICLES:
            pp = doc.add_paragraph()
            pp.paragraph_format.space_after = Pt(0)
            pp.alignment = WD_ALIGN_PARAGRAPH.CENTER
            set_font(pp.add_run(ln), 9, mono=True)
        para("Figure 1: How particles are arranged in the three states of matter",
             size=9, italic=True, align="c", space_after=6)
    if qb.get("table"):
        add_table(Q2_TABLE_HEAD, Q2_TABLE_ROWS, widths=[2.6, 1.3, 1.3, 1.3], size=10, head_size=10)
        para("", space_after=2)

    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Inches(0.25)
        p.paragraph_format.space_after = Pt(3)
        p.paragraph_format.space_before = Pt(2)
        r = p.add_run(f"{lab} {text}  ")
        set_font(r, 10.5)
        r2 = p.add_run(f"[{mk} mark{'s' if mk > 1 else ''}]")
        set_font(r2, 10, bold=True)

doc.add_page_break()

# ============================================================= ANSWER KEY
para("ANSWER KEY", size=13, bold=True, align="c", space_after=6)
para("SECTION A - OBJECTIVE TEST", size=11, bold=True, space_after=4)
counts = {Lx: sum(1 for q in MCQ if q[2] == Lx) for Lx in "ABCD"}
rows = [[i, ans, TOPIC[tp], cog] for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1)]
add_table(["Question", "Answer", "Curriculum Area (Topic)", "Cognitive Level"],
          rows, widths=[0.8, 0.7, 3.6, 1.5], size=9)
para("", space_after=4)
para("Correct-answer distribution: " + ", ".join(f"{Lx} = {counts[Lx]}" for Lx in "ABCD") + " (40 items).", size=9, italic=True)

para("", space_after=8)
para("SECTION B - THEORY (summary answers; see the Marking Scheme for full detail)",
     size=11, bold=True, space_after=4)
rows = [
 ["1 (a)", "P = solid; Q = liquid; R = gas", "1.1", "Understand"],
 ["1 (b)", "P", "1.2", "Remember"],
 ["1 (c)", "R - its particles are far apart, so there is much empty space to push them into.", "1.2", "Analyse"],
 ["1 (d)", "Evaporation - e.g. water drying from clothes hung on a line.", "1.1", "Understand"],
 ["2 (a)", "(i) No  (ii) No  (iii) No  (iv) Yes  (v) No", "1.2", "Understand"],
 ["2 (b)", "Any two of: both can flow; neither has a definite shape.", "1.2", "Understand"],
 ["3 (a)", "A balance (or lever balance) and a balloon, plus a pump.", "1.2", "Remember"],
 ["3 (b)", "Weigh the deflated balloon, inflate it, weigh it again and compare the readings.", "1.2", "Create"],
 ["3 (c)", "The inflated balloon is heavier; therefore air has mass.", "1.2", "Analyse"],
 ["3 (d)", "Gas particles from the plantain move freely and spread out (diffuse) in all directions.",
  "1.2", "Apply"],
 ["4 (a)", "Any three of: digestion; transport of substances; cooling the body; main part of blood.",
  "1.3", "Understand"],
 ["4 (b)", "Any two liquids with matching uses, e.g. kerosene - lighting a lamp.", "1.3", "Apply"],
 ["4 (c)", "The body loses water it cannot replace; the person becomes dehydrated, dizzy and weak.",
  "1.3", "Apply"],
 ["5 (a)", "Any three of: building; tools and furniture; food; utensils.", "1.4", "Understand"],
 ["5 (b)", "Any two solids with matching uses, e.g. cement blocks - building.", "1.4", "Apply"],
 ["5 (c)", "Metals conduct heat well; wood and plastic do not, and wood burns / plastic melts.",
  "1.4", "Evaluate"],
 ["6 (a)", "Any three of: conduct heat; conduct electricity; shiny; strong / malleable.", "1.5", "Understand"],
 ["6 (b)", "Any two of: poor conductors; dull; brittle; often gases at room temperature.", "1.5", "Understand"],
 ["6 (c)", "e.g. Metal - iron; Non-metal - sulphur; Noble gas - helium.", "1.5", "Remember"],
 ["6 (d)", "They do not react easily; helium is light for balloons; neon and argon glow in lamps.",
  "1.5", "Understand"],
 ["6 (e)", "Copper allows electricity to pass through it easily; sulphur does not.", "1.5", "Evaluate"],
 ["7 (a)", "Groups", "1.6", "Remember"],
 ["7 (b)", "Periods", "1.6", "Remember"],
 ["7 (c)", "In order of increasing atomic number.", "1.6", "Remember"],
 ["7 (d)", "Group 8 (also called Group 0).", "1.5", "Remember"],
 ["7 (e)", "Any three of: groups similar properties; orderly arrangement; predicts properties.",
  "1.6", "Understand"],
 ["7 (f)", "Disagree - the table also contains non-metals and noble gases.", "1.6", "Evaluate"],
]
add_table(["Question", "Expected Answer", "Curriculum Area", "Cognitive Level"],
          rows, widths=[0.8, 4.2, 1.2, 1.2], size=9)

doc.add_page_break()

# ========================================================== MARKING SCHEME
para("MARKING SCHEME - SECTION B (60 marks)", size=13, bold=True, align="c", space_after=4)
para("General rules: (1) Accept any other correct and relevant answer. (2) Award marks for correct points, "
     "not for repeating the question. (3) For calculations and procedures, award method marks. "
     "(4) Do not deduct marks for spelling unless the meaning is changed.",
     size=9.5, italic=True, space_after=8)

for qb in SECTION_B:
    n = qb["num"]
    para(f"Question {n}  ({qb['total']} marks)", size=11, bold=True, space_before=8, space_after=3)
    for (lab, points, note) in MARKING[n]:
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(2)
        r = p.add_run(f"{lab} ")
        set_font(r, 10.5, bold=True)
        mk = [p_[2] for p_ in qb["parts"] if p_[0] == lab]
        if mk:
            r2 = p.add_run(f"[{mk[0]} mark{'s' if mk[0] > 1 else ''}]")
            set_font(r2, 10, bold=True)
        for pt in points:
            pp = doc.add_paragraph()
            pp.paragraph_format.left_indent = Inches(0.35)
            pp.paragraph_format.space_after = Pt(1)
            rr = pp.add_run("- " + pt)
            set_font(rr, 10.5)
        pp = doc.add_paragraph()
        pp.paragraph_format.left_indent = Inches(0.35)
        pp.paragraph_format.space_after = Pt(6)
        rr = pp.add_run("Marking note: " + note)
        set_font(rr, 9.5, italic=True)

doc.add_page_break()

# ============================================== CURRICULUM BLUEPRINT
para("CURRICULUM ASSESSMENT BLUEPRINT", size=13, bold=True, align="c", space_after=3)
para(f"Strand: {STRAND}   |   Sub-strand: {SUBSTRAND}   |   Class: {CLASS}",
     size=10, italic=True, align="c", space_after=3)
para(f"Content Standards: B7/JHS1.1.1.1 - {CS_TEXT['B7/JHS1.1.1.1']};  "
     f"B7/JHS1.1.1.2 - {CS_TEXT['B7/JHS1.1.1.2']}",
     size=9, italic=True, align="c", space_after=3)
para("Source: NaCCA Science Common Core Programme Curriculum (B7/JHS1-B9/JHS3), September 2020, "
     "Strand 1: Diversity of Matter, Sub-strand 1: Materials, pp. 2-4. Indicators are quoted, not invented.",
     size=9, italic=True, space_after=8)

hdr = ["Qn", "Sub-strand", "Content Standard", "Indicator (NaCCA) - Indicator Text", "Topic / Content",
       "Cognitive Level", "Marks"]

rows = []
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    rows.append([f"A{i}", SUBSTRAND, CS[tp], f"{IND[tp]} - {IND_TEXT[tp]}", TOPIC[tp], cog, 1])
add_table(hdr, rows, widths=[0.35, 0.75, 0.75, 1.75, 1.4, 0.8, 0.35], size=7, head_size=7.5)

para("", space_after=8)
rows = []
for qb in SECTION_B:
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        key = tp if tp in TOPIC else tp.split(",")[0].strip()
        rows.append([f"B{qb['num']}{lab.strip('()')}", SUBSTRAND, CS[key],
                     f"{IND[key]} - {IND_TEXT[key]}", TOPIC[key], cog, mk])
add_table(hdr, rows, widths=[0.35, 0.75, 0.75, 1.75, 1.4, 0.8, 0.35], size=7, head_size=7.5)

doc.add_page_break()

# ---------------------------------------------------------- summaries
m, it = topic_totals()
diff = difficulty_totals()
order, ca, cb = cognitive_by_section()

para("SUMMARY 1 - COVERAGE BY CURRICULUM AREA (TOPIC)", size=12, bold=True, space_after=4)
rows = []
for k in TOPIC:
    rows.append([TOPIC[k], it[k], m[k], f"{(m[k] / 100) * 100:.1f}%", CC[k]])
rows.append(["TOTAL", sum(it.values()), sum(m.values()), "100%", "-"])
add_table(["Topic / Content Area", "No. of Items", "Marks", "% of Total Marks", "Core Competencies"],
          rows, widths=[2.7, 0.8, 0.6, 1.0, 1.1], size=8.5)
para("CC = Communication and Collaboration; CP = Critical Thinking and Problem Solving; "
     "DL = Digital Literacy; CI = Creativity and Innovation.", size=8.5, italic=True, space_after=2)

para("", space_after=8)
para("SUMMARY 2 - COGNITIVE-LEVEL DISTRIBUTION (Bloom's Taxonomy)", size=12, bold=True, space_after=4)
rows = []
for lv in order:
    tot = ca[lv] + cb[lv]
    rows.append([lv, ca[lv], cb[lv], tot, f"{(tot / 100) * 100:.1f}%"])
rows.append(["TOTAL", sum(ca.values()), sum(cb.values()), sum(ca.values()) + sum(cb.values()), "100%"])
add_table(["Cognitive Level", "Section A Marks", "Section B Marks", "Total Marks", "% of Total"],
          rows, widths=[1.6, 1.3, 1.3, 1.1, 1.1], size=9.5)

para("", space_after=8)
para("SUMMARY 3 - DIFFICULTY DISTRIBUTION", size=12, bold=True, space_after=4)
rows = [[k, v, f"{(v / 100) * 100:.1f}%"] for k, v in diff.items()]
rows.append(["TOTAL", sum(diff.values()), "100%"])
add_table(["Difficulty", "Marks", "% of Total Marks"], rows, widths=[2.0, 1.2, 1.5], size=9.5)
para("Target in the master prompt: approximately 30% easy / 50% moderate / 20% challenging.",
     size=9, italic=True, space_after=2)

para("", space_after=8)
para("SUMMARY 4 - SECTION WEIGHTING", size=12, bold=True, space_after=4)
add_table(["Section", "Question Type", "Items", "Marks", "% of Total"],
          [["A", "Objective (multiple choice)", 40, 40, "40%"],
           ["B", "Theory / constructed response", 27, 60, "60%"],
           ["TOTAL", "-", 67, 100, "100%"]],
          widths=[0.9, 2.4, 0.8, 0.8, 1.0], size=9.5)

doc.add_page_break()

# ================================================= QUALITY-CONTROL SUMMARY
para("QUALITY-CONTROL SUMMARY", size=13, bold=True, align="c", space_after=4)
para("This check was carried out against the 14-point validation list in the master prompt before the "
     "examination was finalised.", size=9.5, italic=True, space_after=8)

qc = [
 ("Does every question belong to the supplied curriculum scope?",
  "Yes. All 47 items trace to Strand 1 (Diversity of Matter), Sub-strand 1 (Materials), topics 1.1-1.6, and to "
  "the official B7 indicators B7/JHS1.1.1.1.1, .1.2, .1.3 and B7/JHS1.1.1.2.1. No content outside the six "
  "supplied topics was introduced."),
 ("Is the examination appropriate for the stated class?",
  "Yes. Language is pitched at Basic 7. Abstract ideas (particle arrangement, atomic number, Group 8) are "
  "introduced only at identification level, which matches the JHS 1 introduction to the periodic table."),
 ("Are the questions genuinely BECE-style?",
  "Yes: Section A is 30 four-option objectives worth 1 mark each, and Section B is structured theory with "
  "sub-questions carrying printed mark allocations - the standard BECE format."),
 ("Are there enough application and reasoning questions?",
  "Yes. 32 of 100 marks (32%) are at Apply level or above (Apply 16, Analyse 5, Evaluate 9, Create 2), "
  "including diagram interpretation, a practical design task, an application to dehydration, and two "
  "justification tasks."),
 ("Are the MCQ distractors plausible?",
  "Yes. Each distractor is drawn from the same content family as the key (e.g. other states of matter, "
  "other household liquids, other periodic-table groups) rather than being obviously absurd."),
 ("Is there only one best answer for each MCQ?",
  "Yes. Every item was reviewed for a single defensible key, including Q13 (water's body functions) and "
  "Q23 (oxygen as the breathing non-metal), where distractors were checked for partial truth."),
 ("Are the marks internally consistent?",
  "Yes. Section A = 40 items x 1 mark = 40. Section B = 8 + 7 + 7 + 8 + 8 + 12 + 10 = 60. "
  "Each Section B sub-question's marks match its marking-scheme allocation."),
 ("Does the total add up correctly?",
  "Yes: 40 + 60 = 100 marks, matching the stated total on the front page."),
 ("Are the answers in the answer key correct?",
  "Yes. All 40 objective keys and all 27 Section B answers were verified against the marking scheme."),
 ("Does the marking scheme match the questions?",
  "Yes. Every Section B sub-question has an expected-answer list and a marking note covering partial credit, "
  "alternative answers and method marks."),
 ("Are the questions free from unnecessary ambiguity?",
  'Yes. Vague wording was removed; open items are anchored with "state two", "give one use" and the mark '
  "allocation, so candidates know how much to write."),
 ("Are Ghanaian contexts used naturally and accurately?",
  "Yes: Accra, Wenchi, Suame Magazine, cooking gas (LPG), methylated spirit in clinics, cement blocks, "
  "harmattan-free and locally accurate food examples (yam, rice, maize), and cedi-era school contexts are "
  "used only where they fit the science."),
 ("Has any content outside the supplied curriculum been introduced?",
  "No. Questions on evaporation (A4) and blood (A16) sit inside topics 1.1 and 1.3 respectively. Chemical "
  "symbols were deliberately left out: although indicator B7/JHS1.1.1.2.1 exemplar 1 covers the symbols of the "
  "first 20 elements, the supplied topic list did not include them, so they were treated as out of scope."),
 ("Are the questions sufficiently varied?",
  "Yes. Item types include definition, identification, property comparison, diagram interpretation, "
  "table completion, practical design, application to a real situation, justification and "
  "classification."),
]
for i, (q, a) in enumerate(qc, start=1):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(2)
    r = p.add_run(f"{i}. {q}")
    set_font(r, 10.5, bold=True)
    p2 = doc.add_paragraph()
    p2.paragraph_format.left_indent = Inches(0.3)
    p2.paragraph_format.space_after = Pt(6)
    r2 = p2.add_run(a)
    set_font(r2, 10)

para("", space_after=8)
para("EXAMINER NOTES (for the teacher, not for candidates)", size=11, bold=True, space_after=4)
for n in [
 "Topic 1.2 carries 26 of 100 marks (26%). This is deliberate: it is the broadest of the six topics, "
 "and topic 1.1 carries 11%. If you want a flatter spread, shift marks from Questions 2 and 3 to "
 "Question 1.",
 "Question A27 (atomic number) and A24 (Group 8) are the two hardest objective items at this level. "
 "If your class has only just been introduced to the periodic table, replace them with two easier "
 "items on naming metals and non-metals.",
 "The Section B diagram is drawn with text characters so it can be edited or redrawn in Word. "
 "The diagram particles are drawn with small dot characters; enlarge or redraw them in Word if you prefer.",
 "Edit the school name, academic year and examination title on page 1 before printing.",
 "Indicator B7/JHS1.1.1.2.1 exemplar 1 expects learners to name and write the chemical symbols of the first "
 "20 elements. That was not in your supplied topic list, so it is not tested here. If you want it included, "
 "add a Section B table item asking for the symbols of elements 1-20.",
 "This is an original, teacher-made mock. It is not a reproduction of any WAEC or NaCCA examination paper.",
]:
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Inches(0.3)
    p.paragraph_format.space_after = Pt(3)
    r = p.add_run("- " + n)
    set_font(r, 10)

doc.save("/home/user/Basic7_Integrated_Science_Mock_Strand1_Materials.docx")
print("docx written")

# ---------------- quick console verification
print("Section A:", len(MCQ), "items")
print("Section B total:", sum(q["total"] for q in SECTION_B))
print("Topic marks:", m, "sum", sum(m.values()))
print("Difficulty:", diff, "sum", sum(diff.values()))
print("Cognitive A:", ca, "B:", cb)
print("Answer counts:", {L: sum(1 for q in MCQ if q[2] == L) for L in "ABCD"})
