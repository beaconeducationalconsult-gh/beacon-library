# -*- coding: utf-8 -*-
"""Basic 7 Integrated Science mock - Strand 4 Sub-strand 3: CONVERSION AND CONSERVATION OF ENERGY.
100 marks. Indicators sourced from the official NaCCA Science CCP curriculum (B7/JHS1-B9/JHS3,
Sept 2020), Strand 4: Forces and Energy, Sub-strand 3, printed pages 33-34."""

SCHOOL = "[SCHOOL NAME]"
SUBJECT = "INTEGRATED SCIENCE (SCIENCE)"
EXAM = "END-OF-TERM MOCK EXAMINATION"
CLASS = "Basic 7 (JHS 1)"
TIME = "2 hours (Suggested: Section A - 40 min; Section B - 80 min)"
MARKS = "100"
YEAR = "2025/2026 Academic Year"

STRAND = "Forces and Energy"
SUBSTRAND = "Conversion and Conservation of Energy"

TOPIC = {
    "13.1": "13.1 The Law of Conservation of Energy",
    "13.2": "13.2 Energy Conversion",
    "13.3": "13.3 Everyday Examples of Energy Conversion",
    "13.4": "13.4 Conserving Energy for Future Use",
}

CS = "B7/JHS1.4.3.1"
CS_BY_TOPIC = {k: "B7/JHS1.4.3.1" for k in ["13.1", "13.2", "13.3", "13.4"]}
CS_TEXT = ("Demonstrate an understanding of the principle of conservation and conversion of energy "
           "and their application in real life situations")

IND = {
    "13.1": "B7/JHS1.4.3.1.1 (Ex. 1)",
    "13.2": "B7/JHS1.4.3.1.1 (Ex. 2); B7/JHS1.4.3.1.2 (Ex. 1)",
    "13.3": "B7/JHS1.4.3.1.2 (Ex. 1)",
    "13.4": "B7/JHS1.4.3.1.3 (Ex. 1)",
}
IND_TEXT = {
    "13.1": "Explain the principle underlying conservation and conversion of energy. Ex. 1: Explain "
            "the law of conservation of energy by using diagram to show that in a closed system the "
            "value of chemical energy, for example in dry cell which changes into electrical, heat "
            "and light energy will remain the same.",
    "13.2": "Use exemplar 1 to explain energy conversion and its application to life; demonstrate "
            "the conversion of energy into useable forms. Ex. 1 of B7/JHS1.4.3.1.2: Illustrate "
            "everyday use of conversion of energy and show diagrammatically the conversion of "
            "energy to other forms.",
    "13.3": "Demonstrate the conversion of energy into useable forms. Ex. 1: Illustrate everyday "
            "use of conversion of energy and show diagrammatically the conversion of energy to "
            "other forms.",
    "13.4": "Know how energy could be conserved for future use in life. Ex. 1: Describe how energy "
            "is conserved and explain how it can be done for the benefit of humans and other life "
            "forms.",
}
CC = {"13.1": "DL, CI, CP", "13.2": "DL, CI, CP", "13.3": "CI", "13.4": "DL, CC, CP"}

# ---------------------------------------------------------------- SECTION A
# (question, [A,B,C,D], answer, topic, cognitive, difficulty)
MCQ = [
 ("The law of conservation of energy states that energy",
  ["is used up completely whenever work is done", "can be created by a powerful machine",
   "cannot be created or destroyed, but can be changed from one form into another",
   "disappears as soon as a machine is switched off"],
  "C", "13.1", "Remember", "Easy"),
 ("In a closed system, the total amount of energy",
  ["stays the same", "increases steadily", "falls to zero", "doubles every hour"],
  "A", "13.1", "Remember", "Easy"),
 ("Which statement about energy is correct?",
  ["energy is destroyed when a bulb is switched off",
   "a machine can make energy out of nothing",
   "the total amount of energy in the world is getting less every day",
   "energy can be changed from one form into another, but the total stays the same"],
  "D", "13.1", "Understand", "Easy"),
 ("A dry cell in a torch changes its chemical energy into",
  ["sound energy only", "electrical energy, which then becomes light and heat",
   "nuclear energy", "potential energy stored in the bulb"],
  "B", "13.1", "Understand", "Moderate"),
 ("In the law of conservation of energy, the word 'conservation' means that the total amount of "
  "energy is",
  ["kept the same, not that we save it up", "saved in a battery for later",
   "used more slowly than before", "shared out equally among people"],
  "A", "13.1", "Understand", "Moderate"),
 ("A machine is said to 'lose' energy. What this really means is that",
  ["the energy has gone out of the world", "the machine was badly made",
   "some of the energy has changed into a form that is not useful, such as heat and sound",
   "the energy has been stored inside the machine for ever"],
  "C", "13.1", "Understand", "Moderate"),
 ("A man says he has built a machine that gives out more energy than is put into it. The law of "
  "conservation of energy tells us that this is",
  ["possible, if the machine is big enough", "possible, but only at night",
   "possible, if the machine uses a dry cell", "impossible, because energy cannot be created"],
  "D", "13.1", "Understand", "Easy"),
 ("Which of these is the best statement of the law of conservation of energy?",
  ["energy should be saved for future use",
   "energy can neither be created nor destroyed; it can only be changed from one form into "
   "another",
   "energy is always lost whenever work is done", "energy is made in power stations"],
  "B", "13.1", "Remember", "Easy"),
 ("The total amount of energy before a change takes place and after it has taken place is",
  ["greater before the change", "greater after the change", "the same",
   "impossible to tell"],
  "C", "13.1", "Remember", "Easy"),
 ("A closed system is one in which",
  ["no energy enters or leaves the system", "all the machines are switched off",
   "no work is done at all", "the energy is stored in a battery"],
  "A", "13.1", "Remember", "Moderate"),
 ("A bulb is given 100 J of electrical energy. It gives out 20 J of light energy and the rest as "
  "heat. The amount of heat energy it gives out is",
  ["20 J", "80 J", "100 J", "120 J"], "B", "13.1", "Apply", "Challenging"),

 ("Energy conversion means",
  ["saving energy for the future", "making energy disappear",
   "storing energy inside a dry cell", "changing energy from one form into another"],
  "D", "13.2", "Remember", "Easy"),
 ("A torch changes chemical energy into light energy. The form of energy that comes in between is",
  ["heat energy", "sound energy", "electrical energy", "nuclear energy"],
  "C", "13.2", "Understand", "Moderate"),
 ("In an electric pressing iron, electrical energy is changed mainly into",
  ["heat energy", "sound energy", "light energy", "chemical energy"],
  "A", "13.2", "Remember", "Easy"),
 ("A radio changes electrical energy mainly into",
  ["heat energy", "sound energy", "chemical energy", "potential energy"],
  "B", "13.2", "Remember", "Easy"),
 ("In a car engine, the chemical energy in the fuel is changed into",
  ["light energy only", "electrical energy only", "chemical energy again",
   "kinetic energy, heat and sound"],
  "D", "13.2", "Understand", "Moderate"),
 ("A solar panel changes light energy from the sun into",
  ["electrical energy", "sound energy", "the chemical energy in petrol", "nuclear energy"],
  "A", "13.2", "Remember", "Easy"),
 ("When a pupil eats food and then runs in a race, the energy conversion in the body is mainly",
  ["heat into light", "electrical into sound", "chemical into kinetic and heat",
   "kinetic into chemical"],
  "C", "13.2", "Understand", "Moderate"),
 ("A rechargeable battery is being charged. During charging, electrical energy is changed into",
  ["light energy", "chemical energy", "sound energy", "nuclear energy"],
  "B", "13.2", "Understand", "Challenging"),
 ("The energy that is not useful in a conversion is usually changed into",
  ["light and sound", "electrical and chemical", "chemical and nuclear", "heat and sound"],
  "D", "13.2", "Remember", "Moderate"),

 ("A charcoal pot changes the chemical energy in the charcoal into",
  ["heat energy", "electrical energy", "light energy", "sound energy"],
  "A", "13.3", "Remember", "Easy"),
 ("Which of these is an everyday example of energy conversion?",
  ["a book lying on a table", "water standing in a bucket",
   "a maize mill changing electrical energy into movement energy",
   "a stone resting on the ground"],
  "C", "13.3", "Understand", "Moderate"),
 ("A school bell changes electrical energy into",
  ["heat energy", "sound energy", "chemical energy", "light energy"],
  "B", "13.3", "Remember", "Easy"),
 ("A boy pedals a bicycle. The main energy conversion taking place is",
  ["electrical into sound", "heat into light", "light into chemical",
   "the chemical energy in his food into kinetic energy"],
  "D", "13.3", "Understand", "Moderate"),
 ("A rechargeable lamp is plugged in to be charged. The energy conversion taking place is",
  ["chemical into electrical", "light into heat", "electrical into chemical",
   "kinetic into electrical"],
  "C", "13.3", "Apply", "Moderate"),
 ("When petrol burns in a car engine, the energy conversion is",
  ["chemical into heat and then into kinetic", "kinetic into chemical and then into heat",
   "electrical into light and then into sound", "heat into chemical and then into electrical"],
  "A", "13.3", "Understand", "Moderate"),
 ("At the Akosombo Dam, the potential energy of the stored water is changed into",
  ["nuclear energy and then into heat", "chemical energy and then into light",
   "sound energy and then into heat", "kinetic energy and then into electrical energy"],
  "D", "13.3", "Understand", "Moderate"),
 ("A television set changes electrical energy into",
  ["heat and chemical energy", "light and sound energy", "nuclear and heat energy",
   "chemical and kinetic energy"],
  "B", "13.3", "Remember", "Easy"),
 ("A windmill on a hill changes the kinetic energy of the wind into",
  ["electrical energy", "nuclear energy", "chemical energy", "sound energy"],
  "A", "13.3", "Apply", "Challenging"),

 ("One way in which energy can be conserved (saved) for future use is to",
  ["leave all the lights on at night", "keep the fridge door open",
   "switch off lights and fans when nobody is in the room", "use the largest bulb available"],
  "C", "13.4", "Understand", "Easy"),
 ("Which of these helps to conserve energy in the home?",
  ["leaving the television on all night", "ironing a few clothes over a very long time",
   "boiling more water in the kettle than is needed",
   "using energy-saving bulbs instead of ordinary ones"],
  "D", "13.4", "Understand", "Easy"),
 ("Energy is conserved for future use mainly because",
  ["energy is being destroyed every day",
   "the sources we use, such as fuel and electricity, are limited and cost money",
   "the law of conservation of energy says we must",
   "machines cannot change energy from one form to another"],
  "B", "13.4", "Understand", "Moderate"),
 ("Which of these does NOT help to conserve energy?",
  ["leaving the fridge door open while you decide what to eat",
   "switching off the pressing iron when you finish",
   "closing the door of a refrigerator quickly", "using a lid on a cooking pot"],
  "A", "13.4", "Understand", "Easy"),
 ("A family dries cocoa beans in the sun instead of using a dryer that runs on electricity. This "
  "conserves",
  ["sound energy", "chemical energy", "electrical energy", "nuclear energy"],
  "C", "13.4", "Apply", "Moderate"),
 ("A cook puts a lid on the pot while the soup is heating. This conserves energy because",
  ["the food becomes softer", "the pot becomes heavier", "more air gets into the soup",
   "less heat escapes, so less fuel is used"],
  "D", "13.4", "Apply", "Moderate"),
 ("Rechargeable batteries help to conserve energy because",
  ["they are cheaper than ordinary batteries to throw away",
   "they can be used again and again instead of being thrown away after one use",
   "they produce more energy than they are given", "they do not need any energy at all"],
  "B", "13.4", "Understand", "Moderate"),
 ("One way in which conserving energy benefits other life forms is that",
  ["fewer trees are cut down for fuel, so animals keep their habitat",
   "animals learn how to use electricity", "plants grow faster in the dark",
   "rivers dry up more quickly"],
  "A", "13.4", "Understand", "Moderate"),
 ("Conserving energy helps human beings mainly by",
  ["making energy disappear", "making machines produce more energy than they are given",
   "saving money and making the fuel we have last longer",
   "allowing us to use as much energy as we like"],
  "C", "13.4", "Understand", "Moderate"),
 ("A school switches off all the lights and fans during break. This is an example of",
  ["the law of conservation of energy", "energy conversion", "wasting energy",
   "conserving energy for future use"],
  "D", "13.4", "Apply", "Moderate"),
 ("We should conserve energy even though the law of conservation of energy says that energy cannot "
  "be destroyed, because",
  ["the law is not true",
   "useful forms of energy, such as fuel, get changed into forms we cannot easily use again",
   "energy is running out of the world", "machines destroy energy every day"],
  "B", "13.4", "Analyse", "Challenging"),
]

# --------------------------------------- SECTION B DIAGRAM (Q2) + TABLE (Q3)
TORCH = [
    "  DRY CELL            WIRES               BULB",
    "+----------+ ---> +------------+ ---> +----------+",
    "|   (i)    |      |    (ii)    |      |  (iii)   |",
    "|  ENERGY  |      |   ENERGY   |      |  ENERGY  |",
    "+----------+      +------------+      +----------+",
    "                                           |",
    "                                           v",
    "                                      +----------+",
    "                                      |   (iv)   |",
    "                                      |  ENERGY  |",
    "                                      +----------+",
]
TORCH_KEY = "(i) chemical energy, (ii) electrical energy, (iii) light energy, (iv) heat energy"

CVS_HEADERS = ["Device", "Energy put in", "Useful energy got out"]
CVS_ROWS = [
 ["A torch", "(i)", "light energy"],
 ["An electric pressing iron", "electrical energy", "(ii)"],
 ["A radio", "electrical energy", "(iii)"],
 ["A car engine", "(iv)", "kinetic (movement) energy"],
 ["A maize mill", "electrical energy", "(v)"],
 ["A solar panel", "(vi)", "electrical energy"],
]

# ---------------------------------------------------------------- SECTION B
SECTION_B = [
 dict(
   num=1, total=12, topic="13.1",
   stem="Your class has been learning about the law of conservation of energy.",
   parts=[
     ("(a)", "State the law of conservation of energy.", 3, "Understand", "13.1", "Easy"),
     ("(b)", "Explain what is meant by a closed system.", 2, "Understand", "13.1", "Moderate"),
     ("(c)", "Use the example of a dry cell in a closed system to explain the law of conservation "
             "of energy.", 4, "Apply", "13.1", "Moderate"),
     ("(d)", "A man says he has built a machine that gives out more energy than is put into it. "
             "What does the law of conservation of energy tell us about this claim? Give two "
             "reasons for your answer.", 3, "Evaluate", "13.1", "Challenging"),
   ]),
 dict(
   num=2, total=8, topic="13.2",
   stem="Fig. 1 shows the energy changes that take place in a torch. Study it and answer the "
        "questions that follow.",
   diagram=True,
   parts=[
     ("(a)", "Name the form of energy at each of the stages labelled (i), (ii), (iii) and (iv) in "
             "Fig. 1.", 4, "Understand", "13.2", "Moderate"),
     ("(b)", "Explain what is meant by energy conversion.", 2, "Remember", "13.2", "Easy"),
     ("(c)", "State what happens to the TOTAL amount of energy during these changes in the torch.",
      2, "Understand", "13.2", "Challenging"),
   ]),
 dict(
   num=3, total=8, topic="13.2",
   stem="Energy is changed into useable forms every day. Study the incomplete table below and "
        "answer the questions that follow.",
   table="conversion",
   parts=[
     ("(a)", "Copy and complete the table.", 6, "Understand", "13.2", "Moderate"),
     ("(b)", "Choose any one device from the table and name the form of energy that comes out of "
             "it but is NOT useful.", 2, "Apply", "13.2", "Moderate"),
   ]),
 dict(
   num=4, total=9, topic="13.3",
   stem="Many of the things your family uses at home work by changing energy from one form into "
        "another.",
   parts=[
     ("(a)", "Name three appliances used in the home and state the energy conversion that takes "
             "place in each one.", 3, "Apply", "13.3", "Moderate"),
     ("(b)", "Explain why the energy conversions that take place in the home are important to your "
             "family.", 3, "Understand", "13.3", "Easy"),
     ("(c)", "For each of the three appliances you named in (a), state the form of energy that is "
             "wasted rather than useful.", 3, "Understand", "13.3", "Moderate"),
   ]),
 dict(
   num=5, total=8, topic="13.3",
   stem="Your class is preparing a display about energy conversion for the school open day.",
   parts=[
     ("(a)", "Design a simple diagram your class could put on the wall to show the energy "
             "conversions that happen in a home. Describe what you would draw and the labels you "
             "would use.", 3, "Create", "13.3", "Challenging"),
     ("(b)", "Explain how a pupil's body gets the energy to ride a bicycle to school, naming the "
             "energy conversion involved.", 3, "Understand", "13.3", "Moderate"),
     ("(c)", "State two forms of energy that are wasted when the bicycle is ridden.",
      2, "Understand", "13.3", "Easy"),
   ]),
 dict(
   num=6, total=8, topic="13.4",
   stem="Energy can be conserved, or saved, so that there is enough for future use.",
   parts=[
     ("(a)", "State four ways in which energy can be conserved for future use in the home or at "
             "school.", 4, "Understand", "13.4", "Easy"),
     ("(b)", "Explain why it is important to conserve energy even though the law of conservation "
             "of energy says that energy cannot be destroyed.", 4, "Analyse", "13.4",
      "Challenging"),
   ]),
 dict(
   num=7, total=7, topic="13.4",
   stem="Conserving energy benefits people and the living things around them.",
   parts=[
     ("(a)", "Explain three ways in which conserving energy benefits human beings.",
      3, "Understand", "13.4", "Moderate"),
     ("(b)", "Explain how conserving energy benefits other life forms, giving two examples.",
      4, "Evaluate", "13.4", "Challenging"),
   ]),
]

# ------------------------------------------------------- MARKING SCHEME
MARKING = {
 1: [
   ("(a)", ["Energy cannot be created and it cannot be destroyed.",
            "Energy can only be changed from one form into another.",
            "The total amount of energy always stays the same."],
    "1 mark each for any THREE correct points (3 marks). The three ideas to look for are: cannot "
    "be created, cannot be destroyed, can be changed from one form to another. Award at most 2 "
    "marks if one of these is missing."),
   ("(b)", ["A closed system is one in which no energy enters and no energy leaves.",
            "All the energy stays inside the system; none escapes into the surroundings."],
    "1 mark each for any TWO correct points (2 marks). The key idea is that nothing crosses the "
    "boundary of the system."),
   ("(c)", ["The dry cell stores chemical energy.",
            "The chemical energy is changed into electrical energy in the wires.",
            "The electrical energy is then changed into light energy and heat energy in the bulb.",
            "No energy is lost - the total amount at the end is exactly the same as the chemical "
            "energy that was in the dry cell at the start.",
            "Some of the energy has simply changed into forms that are not useful, such as heat."],
    "1 mark each for any FOUR correct points (4 marks). The pupil must trace the chain chemical "
    "to electrical to light and heat AND say that the total stays the same; award at most 3 marks "
    "if the total is not mentioned."),
   ("(d)", ["The law tells us that the claim is impossible.",
            "Energy cannot be created, so a machine cannot give out more energy than it was "
            "given.",
            "The most the machine could do is change all the energy it was given into other "
            "forms.",
            "A machine that appears to do this is only releasing energy that was already stored "
            "in it."],
    "1 mark for saying the claim is impossible and 1 mark each for any TWO correct reasons "
    "(3 marks). Accept 'it cannot be done' or 'the machine would not work'. Do NOT accept 'the "
    "machine would work at night'."),
 ],
 2: [
   ("(a)", ["(i) chemical energy", "(ii) electrical energy", "(iii) light energy",
            "(iv) heat energy"],
    "1 mark each for all FOUR correct forms of energy (4 marks). The blank number must be matched "
    "to the answer. For (i) accept 'chemical energy in the dry cells'. For (iv) accept 'heat "
    "energy'. Do NOT accept 'electrical' for (iii)."),
   ("(b)", ["Energy conversion is the changing of energy from one form into another.",
            "It is when one form of energy becomes a different form of energy."],
    "1 mark each for any TWO correct points (2 marks). Accept any correct statement that energy "
    "CHANGES FORM. Do NOT accept 'saving energy' or 'storing energy' - that is conservation for "
    "future use, topic 13.4."),
   ("(c)", ["The total amount of energy stays the same throughout.",
            "No energy is lost or destroyed during the changes; it only changes form.",
            "The energy put in by the dry cell equals the light energy plus the heat energy "
            "given out."],
    "1 mark each for any TWO correct points (2 marks). The key words are 'the same' and 'not "
    "destroyed'. Award 1 mark only if the pupil says the energy 'reduces' or 'runs down'."),
 ],
 3: [
   ("(a)", ["(i) chemical energy (from the dry cells inside the torch)",
            "(ii) heat energy",
            "(iii) sound energy",
            "(iv) chemical energy (from the petrol or diesel)",
            "(v) kinetic energy, or movement energy",
            "(vi) solar energy, or light energy from the sun"],
    "1 mark each for any SIX correct entries (6 marks). The blank number must be matched to the "
    "answer. For (iv) accept 'chemical energy in the fuel'. For (v) accept 'movement energy'. "
    "For (vi) accept 'light energy from the sun'."),
   ("(b)", ["A torch - heat energy is given out as well as light, and the heat is not useful.",
            "A pressing iron - a little light and sound may be given out, but they are not "
            "useful.",
            "A radio - heat energy is given out by the set, and that is not useful.",
            "A car engine - heat and sound are given out, and they are not useful.",
            "A maize mill - heat and sound are given out, and they are not useful.",
            "A solar panel - some heat is given out, and that is not useful."],
    "1 mark for naming one device from the table and 1 mark for naming the form of energy from it "
    "that is NOT useful (2 marks). The device must be one that is actually in the table."),
 ],
 4: [
   ("(a)", ["A pressing iron - electrical energy into heat energy.",
            "A radio or a television set - electrical energy into sound (and light) energy.",
            "A bulb or a lamp - electrical energy into light (and heat) energy.",
            "A blender or a maize mill - electrical energy into kinetic (movement) energy.",
            "A charcoal pot - chemical energy into heat energy.",
            "A rechargeable lamp being charged - electrical energy into chemical energy.",
            "A fan - electrical energy into kinetic energy."],
    "1 mark each for all THREE appliances with the correct energy conversion (3 marks). Both the "
    "appliance AND the conversion must be given for each mark. Accept any sensible household "
    "appliance."),
   ("(b)", ["The conversions give the family light to see by at night.",
            "They give heat for cooking food and for ironing clothes.",
            "They give sound, so the family can listen to the radio or the television.",
            "They give movement, so a fan can cool the room or a blender can grind food.",
            "Without them the family would have to fetch firewood and cook over an open fire."],
    "1 mark each for any THREE correct points (3 marks). The answer should say what the "
    "conversion DOES for the family, not just name the conversion again."),
   ("(c)", ["A pressing iron - heat escapes into the room instead of staying in the iron.",
            "A radio - heat is given out by the set, and that is wasted.",
            "A bulb - heat energy is given out as well as light, and the heat is wasted.",
            "A fan - heat and sound are given out by the motor, and they are wasted.",
            "A charcoal pot - heat escapes into the air and light is given off but not used."],
    "1 mark each for the wasted form for EACH of the three appliances the pupil named in (a) "
    "(3 marks). The answer must match the appliances named in (a); if the pupil named different "
    "appliances here, mark what is written but do not award credit twice."),
 ],
 5: [
   ("(a)", ["A row of boxes joined by arrows, showing the chain: fuel or mains electricity, then "
            "the appliance, then the useful form of energy it gives out.",
            "One box for each energy form, labelled 'chemical', 'electrical', 'heat', 'light', "
            "'sound' or 'movement'.",
            "A drawing of a home in the middle with arrows leading to a bulb, a pressing iron, a "
            "radio and a charcoal pot.",
            "A caption under each arrow saying 'changes into'.",
            "A title such as 'Energy conversion in our homes'.",
            "Colour coding: one colour for the energy going in and another for the useful energy "
            "coming out."],
    "1 mark for a sensible overall design, 1 mark for the labels or captions, and 1 mark for "
    "showing at least two real conversions (3 marks). This is a design task: award method marks "
    "for any workable diagram that is clearly described."),
   ("(b)", ["The pupil eats food, and food stores chemical energy.",
            "During digestion the body releases the chemical energy from the food.",
            "In the muscles the chemical energy is changed into kinetic energy, which moves the "
            "legs.",
            "Some of the energy is changed into heat, which is why the pupil gets warm and "
            "sweats."],
    "1 mark each for any THREE correct points (3 marks). The chain to look for is: chemical "
    "energy in food, to kinetic energy in the muscles, with heat given off as well."),
   ("(c)", ["Heat energy, from the pupil's body and from friction in the moving parts.",
            "Sound energy, from the tyres on the road and from the chain."],
    "1 mark each for TWO correct forms of wasted energy (2 marks). Heat must be one of them. "
    "Accept 'heat from friction'."),
 ],
 6: [
   ("(a)", ["Switch off lights, fans and the television when nobody is in the room.",
            "Use energy-saving bulbs or LED bulbs instead of ordinary ones.",
            "Put a lid on the pot when cooking, so less heat escapes and less fuel is used.",
            "Do not boil more water in the kettle than is needed.",
            "Close the fridge door quickly and do not leave it open.",
            "Iron all the clothes at one time instead of heating the iron again and again.",
            "Dry clothes and food in the sun instead of using a dryer.",
            "Use a solar panel or a rechargeable battery where possible."],
    "1 mark each for any FOUR correct ways (4 marks). Accept any sensible way of saving energy "
    "in the home or at school."),
   ("(b)", ["The law says energy cannot be destroyed, but it does not say the energy stays in a "
            "form we can use.",
            "When fuel is burnt or electricity is used, the useful energy is changed into forms "
            "such as heat and sound that spread out and cannot easily be gathered up again.",
            "So the amount of energy that is easy to use - fuel, electricity - keeps going down, "
            "even though the total amount of energy stays the same.",
            "Conserving energy means slowing down the change of useful energy into forms we "
            "cannot use.",
            "It also saves money and makes the fuel we have last longer."],
    "1 mark each for any FOUR correct points (4 marks). The key idea is the difference between "
    "the TOTAL energy (which stays the same) and the USEFUL energy (which does not). Award at "
    "most 3 marks if the pupil does not make that distinction clear."),
 ],
 7: [
   ("(a)", ["It saves the family money, because less electricity and less fuel are bought.",
            "It makes the fuel and the electricity we have last longer, so they are there for "
            "the future.",
            "It means fewer power cuts and less pressure on the national grid.",
            "It reduces smoke and fumes in the home, so the family breathes cleaner air.",
            "The money saved can be used for other things the family needs, such as school "
            "books."],
    "1 mark each for any THREE correct points (3 marks). Accept any sensible benefit to human "
    "beings."),
   ("(b)", ["Fewer trees are cut down for firewood and charcoal, so forest animals keep their "
            "habitat and birds keep their nesting places.",
            "Less smoke and fewer gases go into the air, so plants and animals are not damaged "
            "by pollution.",
            "Rivers and streams are not dammed or polluted as much, so fish and other water life "
            "survive.",
            "Less fuel is burnt, so the climate is not warmed as quickly and animals are not "
            "forced to move.",
            "Fewer forests are cleared, so the plants that give out oxygen are left standing for "
            "all living things."],
    "1 mark each for any FOUR correct points (4 marks). At least TWO of the four must be clearly "
    "about OTHER LIFE FORMS (plants or animals), not about people; award at most 2 marks if all "
    "the points are about human beings."),
 ],
}


# --------------------------------------------- derive summary statistics
def topic_totals():
    m = {k: 0 for k in TOPIC}
    it = {k: 0 for k in TOPIC}
    for q in MCQ:
        m[q[3]] += 1
        it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk
            it[key] += 1
    return m, it


def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}
    b = {k: 0 for k in order}
    for q in MCQ:
        a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            b[cog] += mk
    return order, a, b


def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ:
        d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            d[diff] += mk
    return d
