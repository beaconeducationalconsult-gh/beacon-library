# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "/home/user")
from build_waste import *

from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT

doc = Document()
sec = doc.sections[0]
sec.left_margin = Inches(0.7); sec.right_margin = Inches(0.7)
sec.top_margin = Inches(0.7); sec.bottom_margin = Inches(0.6)

st = doc.styles["Normal"]; st.font.name = "Calibri"; st.font.size = Pt(11)


def set_font(run, size=11, bold=False, italic=False, mono=False, color=None):
    run.font.size = Pt(size); run.bold = bold; run.italic = italic
    run.font.name = "Consolas" if mono else "Calibri"
    if color: run.font.color.rgb = color
    return run


def para(text="", size=11, bold=False, italic=False, align=None, mono=False,
         space_before=0, space_after=4, color=None):
    p = doc.add_paragraph()
    if align == "c": p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    elif align == "j": p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p.paragraph_format.space_before = Pt(space_before)
    p.paragraph_format.space_after = Pt(space_after)
    if text: set_font(p.add_run(text), size, bold, italic, mono, color)
    return p


def rule():
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(6); p.paragraph_format.space_before = Pt(2)
    set_font(p.add_run("_" * 78), 9, color=RGBColor(0x99, 0x99, 0x99))


def add_table(headers, rows, widths=None, size=9, head_size=9):
    t = doc.add_table(rows=1, cols=len(headers)); t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, h in enumerate(headers):
        c = t.rows[0].cells[i]; c.text = ""
        p = c.paragraphs[0]; p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_font(p.add_run(str(h)), head_size, bold=True)
    for row in rows:
        cells = t.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = ""
            p = cells[i].paragraphs[0]; p.paragraph_format.space_after = Pt(1)
            set_font(p.add_run(str(v)), size)
    if widths:
        for r_ in t.rows:
            for i, w in enumerate(widths): r_.cells[i].width = Inches(w)
    return t


def draw_diagram(lines, caption):
    t = doc.add_table(rows=2, cols=1); t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = t.rows[0].cells[0]
    for k, line in enumerate(lines):
        p = cell.paragraphs[0] if k == 0 else cell.add_paragraph()
        p.paragraph_format.space_after = Pt(0); p.paragraph_format.space_before = Pt(0)
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_font(p.add_run(line), 10, mono=True)
    c2 = t.rows[1].cells[0].paragraphs[0]
    c2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_font(c2.add_run(caption), 9, italic=True)
    t.rows[0].cells[0].width = Inches(6.6)
    t.rows[1].cells[0].width = Inches(6.6)


# ============================================================= TITLE BLOCK
para(SCHOOL, size=15, bold=True, align="c", space_after=2)
para(SUBJECT, size=13, bold=True, align="c", space_after=2)
para(EXAM, size=12, bold=True, align="c", space_after=2)
para(YEAR, size=10, italic=True, align="c", space_after=8)

info = doc.add_table(rows=1, cols=3); info.style = "Table Grid"
info.alignment = WD_TABLE_ALIGNMENT.CENTER
for i, v in enumerate([f"Class: {CLASS}", f"Time: {TIME}", f"Total Marks: {MARKS}"]):
    c = info.rows[0].cells[i]; c.text = ""
    set_font(c.paragraphs[0].add_run(v), 10, bold=True)
para("", space_after=6)

para("INSTRUCTIONS", size=11, bold=True, space_after=3)
for txt in [
    "1. Write your name and class clearly in the spaces provided on your answer sheet.",
    "2. This paper has TWO sections: Section A and Section B.",
    "3. Answer ALL the questions in both sections.",
    "4. Section A has 40 multiple-choice questions. Each question carries 1 mark. Choose the best answer "
    "(A, B, C or D) and record it on the answer sheet provided.",
    "5. Section B has 7 theory questions totalling 60 marks. Write your answers clearly and neatly in your "
    "answer booklet. Draw and label diagrams or tables where you are asked to.",
    "6. Read every question carefully before you answer it.",
    "7. Do not use correction fluid. Cancel any mistake neatly with a single line.",
    "8. Hand in your answer sheet and your answer booklet at the end of the examination.",
]:
    para(txt, size=10.5, space_after=2)
rule()

# =============================================================== SECTION A
para("SECTION A - OBJECTIVE TEST (40 marks)", size=12, bold=True, align="c", space_after=2)
para("Answer ALL questions. Each question carries 1 mark. Choose the BEST answer and write its letter "
     "(A, B, C or D) against the question number on your answer sheet.",
     size=10, italic=True, align="c", space_after=8)

for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(1); p.paragraph_format.space_before = Pt(4)
    set_font(p.add_run(f"{i}. {q}"), 10.5)
    for j, o in enumerate(opts):
        p2 = doc.add_paragraph()
        p2.paragraph_format.left_indent = Inches(0.28)
        p2.paragraph_format.space_after = Pt(0); p2.paragraph_format.space_before = Pt(0)
        set_font(p2.add_run(f"{'ABCD'[j]}. {o}"), 10.5)

doc.add_page_break()

# =============================================================== SECTION B
para("SECTION B - THEORY (60 marks)", size=12, bold=True, align="c", space_after=2)
para("Answer ALL questions. Write your answers in your answer booklet. The marks for each question are "
     "shown in brackets.", size=10, italic=True, align="c", space_after=8)

for qb in SECTION_B:
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(8); p.paragraph_format.space_after = Pt(2)
    set_font(p.add_run(f"Question {qb['num']}"), 11, bold=True)
    set_font(p.add_run(f"  [{qb['total']} marks]"), 10, bold=True, italic=True)
    para(qb["stem"], size=10.5, space_after=4)
    if qb.get("diagram"):
        draw_diagram(PIT, "Fig. 1: A compost pit")
        para("", space_after=2)
    if qb.get("table") == "waste":
        add_table(WASTE_HEADERS, WASTE_ROWS, widths=[3.4, 2.6], size=8.5, head_size=8.5)
        para("Table 1: Common types of waste", size=9, italic=True, align="c",
             space_after=6)
        para("", space_after=2)
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Inches(0.25)
        p.paragraph_format.space_after = Pt(3); p.paragraph_format.space_before = Pt(2)
        set_font(p.add_run(f"{lab} {text}  "), 10.5)
        set_font(p.add_run(f"[{mk} mark{'s' if mk > 1 else ''}]"), 10, bold=True)

doc.add_page_break()

# ============================================================== ANSWER KEY
para("ANSWER KEY", size=13, bold=True, align="c", space_after=6)
para("SECTION A - OBJECTIVE TEST", size=11, bold=True, space_after=4)
rows = [[i, ans, TOPIC[tp], cog] for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1)]
add_table(["Question", "Answer", "Curriculum Area (Topic)", "Cognitive Level"],
          rows, widths=[0.8, 0.7, 3.6, 1.5], size=9)
counts = {L: sum(1 for q in MCQ if q[2] == L) for L in "ABCD"}
para("", space_after=4)
para("Correct-answer distribution: " + ", ".join(f"{L} = {counts[L]}" for L in "ABCD") + " (30 items).",
     size=9, italic=True)

para("", space_after=8)
para("SECTION B - THEORY (summary answers; see the Marking Scheme for full detail)",
     size=11, bold=True, space_after=4)
sba = [
 ("1 (a)", "Any four: solid waste; liquid waste; gaseous waste; biodegradable waste; non-biodegradable waste; household waste; agricultural waste; industrial waste; medical or hospital waste; e-waste; sewage.", "16.1", "Remember"),
 ("1 (b)", "Biodegradable waste can be broken down or rotted by bacteria and fungi, e.g. food remains and leaves. Non-biodegradable waste cannot be broken down by living organisms, e.g. plastic bags, glass and metals. Biodegradable waste rots away after a time; the other stays in the environment for a very long time.", "16.1", "Understand"),
 ("2 (a)", "(i) biodegradable, (ii) non-biodegradable, (iii) biodegradable, (iv) non-biodegradable, (v) non-biodegradable, (vi) biodegradable.", "16.1", "Understand"),
 ("2 (b)", "Any two sources with a matching type - e.g. the market: vegetable leaves and polythene bags; the farm: maize stalks and animal droppings; the school: used paper and food wrappers.", "16.1", "Apply"),
 ("3 (a)", "Any four: sort waste into different containers; put waste into covered bins and empty them regularly; compost biodegradable waste; reuse bottles, bags and containers; recycle paper, plastics, glass and metals; dispose of batteries and medicines separately and safely; do not litter; clean gutters and drains.", "16.2", "Understand"),
 ("3 (b)", "Waste in a gutter blocks the flow of water, so rain water cannot drain away and the streets flood. Standing dirty water breeds mosquitoes, the rotting waste smells and attracts flies and rats, and the overflow can carry waste into water people use.", "16.2", "Understand"),
 ("3 (c)", "Any two: buy only what the household needs; choose goods with little or recyclable wrapping; compost food remains; reuse bags, bottles and containers; repair clothes and furniture instead of replacing them.", "16.2", "Apply"),
 ("4 (a)", "REDUCE means producing less waste in the first place, e.g. buying only what is needed. REUSE means using an item again for the same or another purpose, e.g. an old margarine tin to store salt. RECYCLE means changing waste material into new useful products, e.g. melting old aluminium to make new pans.", "16.2", "Understand"),
 ("4 (b)", "Any two: recycling turns the material into something useful while burning destroys it; burning plastic gives off poisonous gases; burning causes air pollution while recycling does not; recycling saves raw materials and energy.", "16.2", "Evaluate"),
 ("5 (a)", "(i) the top layer - a covering of soil, dry grass or dry leaves. (ii) the middle layer - the organic waste being composted, such as food remains and green leaves. (iii) the bottom layer - coarse dry material such as stalks, husks and dry grass.", "16.3", "Understand"),
 ("5 (b)", "Bacteria and fungi in the soil feed on the waste and break it down into simple substances such as water, carbon dioxide and humus. The process needs moisture, warmth and air, so the heap is turned over from time to time. After some weeks it becomes a dark, crumbly material called compost.", "16.3", "Understand"),
 ("5 (c)", "Plastic is made of long chains of molecules that bacteria and fungi cannot digest, so the micro-organisms that rot food remains have no way of breaking plastic down. Plastic may break into small pieces but it does not rot into simple substances, so it stays in the soil for a very long time.", "16.3", "Analyse"),
 ("6 (a)", "Any three: blocked gutters cause flooding; rotting waste smells; waste attracts flies, rats and other pests; standing dirty water breeds mosquitoes that spread malaria; waste pollutes streams, rivers and soil; cholera, dysentery and typhoid can spread; burning pollutes the air; the environment becomes ugly.", "16.3", "Understand"),
 ("6 (b)", "Non-biodegradable waste such as plastic and glass does not rot, so it stays in the ground for many years. It can release harmful liquids that soak into the soil and poison it, and those liquids can reach a stream or borehole. The waste takes up space, rotting waste gives off methane, animals may dig it up, and rain may wash a shallow hole open.", "16.3", "Apply"),
 ("7 (a)", "Hold a class meeting to agree the aim and choose the area. Walk round the area and list what needs doing. Share out the work and collect the tools and refuse bags. Work in groups wearing gloves and boots, keeping clear of anything sharp. Sort the waste into what can be composted, recycled or dumped, carry it away and dispose of it properly, arrange for dustbins, then write and present the report.", "16.4", "Create"),
 ("7 (b)", "Any three: refuse bags or sacks; rakes; cutlasses; shovels or spades; wheelbarrows; gloves and boots; nose covers or face masks; a first-aid box; separate containers for sorting; water to drink.", "16.4", "Remember"),
 ("7 (c)", "Any three: the aim of the project; the area cleaned and when; who took part; the tools and materials used; the kinds and amounts of waste collected; what was done with the waste; problems met and what would be done differently; recommendations for keeping the area clean.", "16.4", "Understand"),
]
add_table(["Question", "Expected Answer", "Curriculum Area", "Cognitive Level"],
          [list(r) for r in sba], widths=[0.8, 4.2, 1.2, 1.2], size=9)

doc.add_page_break()

# =========================================================== MARKING SCHEME
para("MARKING SCHEME - SECTION B (60 marks)", size=13, bold=True, align="c", space_after=4)
para("General rules: (1) Accept any other correct and relevant answer. (2) Award marks for correct points, "
     "not for repeating the question. (3) For procedures, award method marks. (4) Do not deduct marks for "
     "spelling unless the meaning is changed. (5) Where a candidate gives more answers than are asked for, "
     "mark only the first ones up to the number required.",
     size=9.5, italic=True, space_after=8)

for qb in SECTION_B:
    n = qb["num"]
    para(f"Question {n}  ({qb['total']} marks)", size=11, bold=True, space_before=8, space_after=3)
    for (lab, points, note) in MARKING[n]:
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(2)
        set_font(p.add_run(f"{lab} "), 10.5, bold=True)
        mkv = [p_[2] for p_ in qb["parts"] if p_[0] == lab]
        if mkv: set_font(p.add_run(f"[{mkv[0]} mark{'s' if mkv[0] > 1 else ''}]"), 10, bold=True)
        for pt in points:
            pp = doc.add_paragraph()
            pp.paragraph_format.left_indent = Inches(0.35); pp.paragraph_format.space_after = Pt(1)
            set_font(pp.add_run("- " + pt), 10.5)
        pp = doc.add_paragraph()
        pp.paragraph_format.left_indent = Inches(0.35); pp.paragraph_format.space_after = Pt(6)
        set_font(pp.add_run("Marking note: " + note), 9.5, italic=True)

doc.add_page_break()

# ================================================================ BLUEPRINT
para("CURRICULUM ASSESSMENT BLUEPRINT", size=13, bold=True, align="c", space_after=3)
para(f"Strand: {STRAND}   |   Sub-strand: {SUBSTRAND}   |   Class: {CLASS}",
     size=10, italic=True, align="c", space_after=3)
para(f"Content Standard: {CS} - {CS_TEXT}", size=9, italic=True, align="c", space_after=3)
para("Source: NaCCA Science Common Core Programme Curriculum (B7/JHS1-B9/JHS3), September 2020, "
     "Strand 5: Humans and the Environment, Sub-strand 1: Waste Management, p. 44. "
     "Indicators are quoted, not invented.",
     size=9, italic=True, space_after=8)

hdr = ["Qn", "Sub-strand", "Content Standard", "Indicator (NaCCA) - Indicator Text", "Topic / Content",
       "Cognitive Level", "Marks"]

rows = [[f"A{i}", SUBSTRAND, CS_BY_TOPIC[tp], f"{IND[tp]} - {IND_TEXT[tp]}", TOPIC[tp], cog, 1]
        for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1)]
add_table(hdr, rows, widths=[0.35, 0.75, 0.75, 1.75, 1.4, 0.8, 0.35], size=7, head_size=7.5)

para("", space_after=8)
rows = []
for qb in SECTION_B:
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        key = tp if tp in TOPIC else tp.split(",")[0].strip()
        rows.append([f"B{qb['num']}{lab.strip('()')}", SUBSTRAND, CS_BY_TOPIC[key],
                     f"{IND[key]} - {IND_TEXT[key]}", TOPIC[key], cog, mk])
add_table(hdr, rows, widths=[0.35, 0.75, 0.75, 1.75, 1.4, 0.8, 0.35], size=7, head_size=7.5)

doc.add_page_break()

# ----------------------------------------------------------------- helpers
def topic_totals():
    m = {k: 0 for k in TOPIC}; it = {k: 0 for k in TOPIC}
    for q in MCQ:
        m[q[3]] += 1; it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk; it[key] += 1
    return m, it

def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}; b = {k: 0 for k in order}
    for q in MCQ: a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: b[cog] += mk
    return order, a, b

def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ: d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: d[diff] += mk
    return d

m, it = topic_totals(); diff = difficulty_totals(); order, ca, cb = cognitive_by_section()

para("SUMMARY 1 - COVERAGE BY CURRICULUM AREA (TOPIC)", size=12, bold=True, space_after=4)
rows = [[TOPIC[k], it[k], m[k], f"{(m[k]/100)*100:.1f}%", CC[k]] for k in TOPIC]
rows.append(["TOTAL", sum(it.values()), sum(m.values()), "100%", "-"])
add_table(["Topic / Content Area", "No. of Items", "Marks", "% of Total Marks", "Core Competencies"],
          rows, widths=[2.7, 0.8, 0.6, 1.0, 1.1], size=8.5)
para("CC = Communication and Collaboration; CP = Critical Thinking and Problem Solving; "
     "DL = Digital Literacy; CI = Creativity and Innovation.", size=8.5, italic=True, space_after=2)

para("", space_after=8)
para("SUMMARY 2 - COGNITIVE-LEVEL DISTRIBUTION (Bloom's Taxonomy)", size=12, bold=True, space_after=4)
rows = []
for lv in order:
    tot = ca[lv] + cb[lv]
    rows.append([lv, ca[lv], cb[lv], tot, f"{(tot/100)*100:.1f}%"])
rows.append(["TOTAL", sum(ca.values()), sum(cb.values()), sum(ca.values()) + sum(cb.values()), "100%"])
add_table(["Cognitive Level", "Section A Marks", "Section B Marks", "Total Marks", "% of Total"],
          rows, widths=[1.6, 1.3, 1.3, 1.1, 1.1], size=9.5)

para("", space_after=8)
para("SUMMARY 3 - DIFFICULTY DISTRIBUTION", size=12, bold=True, space_after=4)
rows = [[k, v, f"{(v/100)*100:.1f}%"] for k, v in diff.items()]
rows.append(["TOTAL", sum(diff.values()), "100%"])
add_table(["Difficulty", "Marks", "% of Total Marks"], rows, widths=[2.0, 1.2, 1.5], size=9.5)
para("Target in the master prompt: approximately 30% easy / 50% moderate / 20% challenging.",
     size=9, italic=True, space_after=2)

para("", space_after=8)
para("SUMMARY 4 - SECTION WEIGHTING", size=12, bold=True, space_after=4)
add_table(["Section", "Question Type", "Items", "Marks", "% of Total"],
          [["A", "Objective (multiple choice)", 40, 40, "40%"],
           ["B", "Theory / constructed response", 17, 60, "60%"],
           ["TOTAL", "-", 57, 100, "100%"]],
          widths=[0.9, 2.4, 0.8, 0.8, 1.0], size=9.5)

doc.add_page_break()

# ===================================================== QUALITY-CONTROL
para("QUALITY-CONTROL SUMMARY", size=13, bold=True, align="c", space_after=4)
para("Carried out against the 14-point validation list in the master prompt before the examination was "
     "finalised.", size=9.5, italic=True, space_after=8)

qc = [
 ("Does every question belong to the supplied curriculum scope?",
  "Yes. All 57 items - 40 objectives and 17 theory sub-questions - trace to Strand 5 (Humans "
  "and the Environment), Sub-Strand 1 (Waste Management), topics 16.1-16.4, and to the single "
  "official B7 indicator B7/JHS1.5.1.1.1 under content standard B7/JHS1.5.1.1. The three "
  "exemplars are each covered: carrying out a project, writing a report for presentation, and "
  "discussing how to manage types of waste with the science underlying it."),
 ("Is the examination appropriate for the stated class?",
  "Yes. The B7 curriculum asks learners to research good waste management practices, use them to "
  "carry out a clean-up project, report on the outcome, and discuss how to manage types of waste "
  "while explaining the science underlying it. Nothing beyond that is tested: no incineration "
  "technology, no landfill engineering, no waste-to-energy, and no chemistry of polymers beyond "
  "'micro-organisms cannot digest it'."),
 ("Are the questions genuinely BECE-style?",
  "Yes: Section A is 40 four-option objectives worth 1 mark each, and Section B is structured "
  "theory with sub-questions carrying printed mark allocations. There is a labelled diagram of a "
  "compost pit, a six-row classification table, several 'state' and 'name' items, and two open "
  "tasks that require explanation, judgement and planning."),
 ("Are there enough application and reasoning questions?",
  "Yes. 30 of 100 marks (30%) are at Apply level or above (Apply 20, Analyse 4, Evaluate 2, "
  "Create 4). Create appears in Question 7(a), where pupils must plan and carry out a school "
  "clean-up project from beginning to end; Analyse in Question 5(c), where they must explain why "
  "plastic does not rot as food remains do; and Evaluate in Question 4(b), where they must argue "
  "why recycling beats open burning."),
 ("Are the MCQ distractors plausible?",
  "Yes. Distractors are drawn from the same content family as the key: another state or type of "
  "waste (A2, A3, A4, A9, A10), a genuine term that is not the one asked for (A15, A19, A20), a "
  "real activity that is not good practice (A18), a real item that is not waste management "
  "practice (A36), and a genuine safety measure reversed (A40)."),
 ("Is there only one best answer for each MCQ?",
  "Yes. Every item was reviewed for a single defensible key, and each option list was checked so "
  "that the declared key sits on the correct answer. Special care was taken with A6, where a "
  "glass bottle and a polythene bag are both non-biodegradable so that only banana peels fits, "
  "with A15, where recycling, burning and composting are all real terms but only segregation "
  "means sorting, and with A40, where three of the four options are genuinely safe."),
 ("Are the marks internally consistent?",
  "Yes. Section A = 40 items x 1 mark = 40. Section B = 9 + 8 + 9 + 8 + 9 + 7 + 10 = 60. "
  "Each Section B sub-question's printed marks match its marking-scheme allocation, and every "
  "N-mark sub-question asks for N things."),
 ("Does the total add up correctly?",
  "Yes: 40 + 60 = 100 marks, matching the stated total on the front page."),
 ("Are the answers in the answer key correct?",
  "Yes. All 40 objective keys and all 17 Section B answers were verified against the marking "
  "scheme. The diagram key was checked against the figure: the top layer is the covering of soil "
  "or dry grass, the middle is the organic waste, and the bottom is coarse dry material. The "
  "table key was checked row by row: paper and garden waste are biodegradable, while plastic, "
  "metal and glass are not."),
 ("Does the marking scheme match the questions?",
  "Yes. Every Section B sub-question has an expected-answer list and a marking note covering "
  "partial credit, acceptable alternatives, common wrong answers and method marks. Question "
  "4(a) reserves one mark of each pair for the example, so a pupil who explains all three terms "
  "but gives no examples scores 3 of 6; Question 5(a) still awards 2 marks if a pupil reverses "
  "the top and bottom layers but identifies the middle correctly; and Question 7(a) caps the "
  "answer at 3 if it does no more than say the class will sweep the compound."),
 ("Are the questions free from unnecessary ambiguity?",
  "Yes. Open items are anchored with 'name four', 'state three', 'state two' and the mark "
  "allocation. Question 1(b) requires both the difference AND one example of each; Question "
  "4(b) requires a comparison of recycling with burning rather than mere praise of recycling; "
  "Question 1(a) notes that a type named without an example still scores, but an example with no "
  "type does not; and Question 6(b) asks specifically about burying, not about waste management "
  "in general."),
 ("Are Ghanaian contexts used naturally and accurately?",
  "Yes: maize stalks and cocoa husks, polythene bags and pure water sachets, food remains and "
  "vegetable peels from the kitchen, blocked gutters and flooding in the rainy season, mosquitoes "
  "and malaria, cholera and dysentery, refuse dumped in a stream, a market, a borehole, and a "
  "school clean-up exercise presented to the class."),
 ("Has any content outside the supplied curriculum been introduced?",
  "No. Every item sits inside topics 16.1-16.4. Incineration technology, landfill engineering, "
  "waste-to-energy plants, sewage treatment works and polymer chemistry are not required "
  "anywhere in the paper; methane is named once as a gas from rotting waste and is not tested "
  "beyond recognition."),
 ("Are the questions sufficiently varied?",
  "Yes. Item types include defining waste, classifying solid, liquid and gaseous waste, "
  "distinguishing biodegradable from non-biodegradable, completing a six-row classification "
  "table, naming sources of waste, stating four good practices, explaining why gutters must stay "
  "clear, reducing waste at home, explaining reduce, reuse and recycle with examples, arguing "
  "recycling against burning, naming the layers of a compost pit, explaining decomposition, "
  "explaining why plastic does not rot, listing the problems of poor waste management, "
  "explaining why burying waste is unsatisfactory, planning a school clean-up project, listing "
  "what the project needs, and listing the contents of the report."),
]
for i, (q, a) in enumerate(qc, start=1):
    p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(2)
    set_font(p.add_run(f"{i}. {q}"), 10.5, bold=True)
    p2 = doc.add_paragraph()
    p2.paragraph_format.left_indent = Inches(0.3); p2.paragraph_format.space_after = Pt(6)
    set_font(p2.add_run(a), 10)

para("", space_after=8)
para("EXAMINER NOTES (for the teacher, not for candidates)", size=11, bold=True, space_after=4)
for n in [
 "Question 5(a) is the item pupils are most likely to argue about, because a compost pit can be "
 "built in more than one order. The note accepts the standard answer - covering on top, waste in "
 "the middle, coarse material at the bottom - but still awards 2 marks to a pupil who reverses "
 "the top and bottom layers provided they identify the middle layer as the waste. The one answer "
 "that earns nothing is 'compost' for any of the three labels: compost is what the pit produces, "
 "not a layer in it.",
 "Question 7(a) is the design task and it is the one that carries the indicator's real demand - "
 "the curriculum asks pupils to USE what they have researched to carry out a project. The note "
 "caps the answer at 3 of 4 if it does no more than say the class will sweep the compound, and it "
 "looks for at least one point about planning and one about what happens to the waste "
 "afterwards. Safety earns a mark, so tell them to mention gloves and boots.",
 "Question 4(a) is marked twice over: one mark for the meaning of each of the three terms and one "
 "for its example. Pupils who know reduce, reuse and recycle perfectly but write no examples lose "
 "half the marks. Worth drilling before the mock.",
 "Questions 2(a) and 1(b) both turn on the biodegradable line, and the two that catch pupils out "
 "are paper and glass. Paper rots, so it is biodegradable; glass does not, so it is not. Several "
 "pupils assume that anything recycled must be non-biodegradable.",
 "Topic weighting is 28 marks for 16.1, 26 for 16.2, 27 for 16.3 and 19 for 16.4. If you spent "
 "longer on the community project than on types of waste, move marks towards Question 7.",
 "Two cheap practicals that raise marks sharply: (1) bury a banana peel, a piece of paper, a "
 "polythene bag and a nail in a box of soil, water it, and dig them up after three weeks; and "
 "(2) start a class compost pit behind the science block and use it all term. The first teaches "
 "Questions 1, 2 and 5, the second teaches Questions 3, 5 and 7.",
 "Question 7 is worth doing for real rather than only on paper. One afternoon of cleaning the "
 "school compound, followed by a short report presented to the class, satisfies the indicator "
 "directly and gives every pupil something concrete to write about in the mock.",
 "Edit the school name, academic year and examination title on page 1 before printing.",
 "This is an original, teacher-made mock. It is not a reproduction of any WAEC or NaCCA examination "
 "paper.",
]:
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Inches(0.3); p.paragraph_format.space_after = Pt(3)
    set_font(p.add_run("- " + n), 10)

doc.save("/home/user/Basic7_Integrated_Science_Mock_Strand5_WasteManagement.docx")
print("docx written")

print("Section A:", len(MCQ), "items")
print("Section B total:", sum(q["total"] for q in SECTION_B))
print("Topic marks:", m, "sum", sum(m.values()))
print("Difficulty:", diff, "sum", sum(diff.values()))
print("Cognitive A:", ca)
print("Cognitive B:", cb)
print("Answer counts:", counts)
print("Totals:", sum(m.values()), sum(diff.values()),
      sum(ca.values()) + sum(cb.values()))
