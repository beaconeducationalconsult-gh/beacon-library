# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "/home/user")
from build_tools import *

from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT

doc = Document()
sec = doc.sections[0]
sec.left_margin = Inches(0.7); sec.right_margin = Inches(0.7)
sec.top_margin = Inches(0.7); sec.bottom_margin = Inches(0.6)

st = doc.styles["Normal"]; st.font.name = "Calibri"; st.font.size = Pt(11)


def set_font(run, size=11, bold=False, italic=False, mono=False, color=None):
    run.font.size = Pt(size); run.bold = bold; run.italic = italic
    run.font.name = "Consolas" if mono else "Calibri"
    if color: run.font.color.rgb = color
    return run


def para(text="", size=11, bold=False, italic=False, align=None, mono=False,
         space_before=0, space_after=4, color=None):
    p = doc.add_paragraph()
    if align == "c": p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    elif align == "j": p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p.paragraph_format.space_before = Pt(space_before)
    p.paragraph_format.space_after = Pt(space_after)
    if text: set_font(p.add_run(text), size, bold, italic, mono, color)
    return p


def rule():
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(6); p.paragraph_format.space_before = Pt(2)
    set_font(p.add_run("_" * 78), 9, color=RGBColor(0x99, 0x99, 0x99))


def add_table(headers, rows, widths=None, size=9, head_size=9):
    t = doc.add_table(rows=1, cols=len(headers)); t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, h in enumerate(headers):
        c = t.rows[0].cells[i]; c.text = ""
        p = c.paragraphs[0]; p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_font(p.add_run(str(h)), head_size, bold=True)
    for row in rows:
        cells = t.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = ""
            p = cells[i].paragraphs[0]; p.paragraph_format.space_after = Pt(1)
            set_font(p.add_run(str(v)), size)
    if widths:
        for r_ in t.rows:
            for i, w in enumerate(widths): r_.cells[i].width = Inches(w)
    return t


def draw_diagram(lines, caption):
    t = doc.add_table(rows=2, cols=1); t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = t.rows[0].cells[0]
    for k, line in enumerate(lines):
        p = cell.paragraphs[0] if k == 0 else cell.add_paragraph()
        p.paragraph_format.space_after = Pt(0); p.paragraph_format.space_before = Pt(0)
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_font(p.add_run(line), 10, mono=True)
    c2 = t.rows[1].cells[0].paragraphs[0]
    c2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_font(c2.add_run(caption), 9, italic=True)
    t.rows[0].cells[0].width = Inches(6.6)
    t.rows[1].cells[0].width = Inches(6.6)


# ============================================================= TITLE BLOCK
para(SCHOOL, size=15, bold=True, align="c", space_after=2)
para(SUBJECT, size=13, bold=True, align="c", space_after=2)
para(EXAM, size=12, bold=True, align="c", space_after=2)
para(YEAR, size=10, italic=True, align="c", space_after=8)

info = doc.add_table(rows=1, cols=3); info.style = "Table Grid"
info.alignment = WD_TABLE_ALIGNMENT.CENTER
for i, v in enumerate([f"Class: {CLASS}", f"Time: {TIME}", f"Total Marks: {MARKS}"]):
    c = info.rows[0].cells[i]; c.text = ""
    set_font(c.paragraphs[0].add_run(v), 10, bold=True)
para("", space_after=6)

para("INSTRUCTIONS", size=11, bold=True, space_after=3)
for txt in [
    "1. Write your name and class clearly in the spaces provided on your answer sheet.",
    "2. This paper has TWO sections: Section A and Section B.",
    "3. Answer ALL the questions in both sections.",
    "4. Section A has 40 multiple-choice questions. Each question carries 1 mark. Choose the best answer "
    "(A, B, C or D) and record it on the answer sheet provided.",
    "5. Section B has 7 theory questions totalling 60 marks. Write your answers clearly and neatly in your "
    "answer booklet. Draw and label diagrams or tables where you are asked to.",
    "6. Read every question carefully before you answer it.",
    "7. Do not use correction fluid. Cancel any mistake neatly with a single line.",
    "8. Hand in your answer sheet and your answer booklet at the end of the examination.",
]:
    para(txt, size=10.5, space_after=2)
rule()

# =============================================================== SECTION A
para("SECTION A - OBJECTIVE TEST (40 marks)", size=12, bold=True, align="c", space_after=2)
para("Answer ALL questions. Each question carries 1 mark. Choose the BEST answer and write its letter "
     "(A, B, C or D) against the question number on your answer sheet.",
     size=10, italic=True, align="c", space_after=8)

for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(1); p.paragraph_format.space_before = Pt(4)
    set_font(p.add_run(f"{i}. {q}"), 10.5)
    for j, o in enumerate(opts):
        p2 = doc.add_paragraph()
        p2.paragraph_format.left_indent = Inches(0.28)
        p2.paragraph_format.space_after = Pt(0); p2.paragraph_format.space_before = Pt(0)
        set_font(p2.add_run(f"{'ABCD'[j]}. {o}"), 10.5)

doc.add_page_break()

# =============================================================== SECTION B
para("SECTION B - THEORY (60 marks)", size=12, bold=True, align="c", space_after=2)
para("Answer ALL questions. Write your answers in your answer booklet. The marks for each question are "
     "shown in brackets.", size=10, italic=True, align="c", space_after=8)

for qb in SECTION_B:
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(8); p.paragraph_format.space_after = Pt(2)
    set_font(p.add_run(f"Question {qb['num']}"), 11, bold=True)
    set_font(p.add_run(f"  [{qb['total']} marks]"), 10, bold=True, italic=True)
    para(qb["stem"], size=10.5, space_after=4)
    if qb.get("diagram"):
        draw_diagram(HOE, "Fig. 1: A hoe")
        para("", space_after=2)
    if qb.get("table") == "tools":
        add_table(TOOL_HEADERS, TOOL_ROWS, widths=[1.8, 4.2], size=8.5, head_size=8.5)
        para("Table 1: Common farm tools and their uses", size=9, italic=True, align="c",
             space_after=6)
        para("", space_after=2)
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Inches(0.25)
        p.paragraph_format.space_after = Pt(3); p.paragraph_format.space_before = Pt(2)
        set_font(p.add_run(f"{lab} {text}  "), 10.5)
        set_font(p.add_run(f"[{mk} mark{'s' if mk > 1 else ''}]"), 10, bold=True)

doc.add_page_break()

# ============================================================== ANSWER KEY
para("ANSWER KEY", size=13, bold=True, align="c", space_after=6)
para("SECTION A - OBJECTIVE TEST", size=11, bold=True, space_after=4)
rows = [[i, ans, TOPIC[tp], cog] for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1)]
add_table(["Question", "Answer", "Curriculum Area (Topic)", "Cognitive Level"],
          rows, widths=[0.8, 0.7, 3.6, 1.5], size=9)
counts = {L: sum(1 for q in MCQ if q[2] == L) for L in "ABCD"}
para("", space_after=4)
para("Correct-answer distribution: " + ", ".join(f"{L} = {counts[L]}" for L in "ABCD") + " (30 items).",
     size=9, italic=True)

para("", space_after=8)
para("SECTION B - THEORY (summary answers; see the Marking Scheme for full detail)",
     size=11, bold=True, space_after=4)
sba = [
 ("1 (a)", "(i) handle, (ii) blade, (iii) cutting edge.", "15.1", "Understand"),
 ("1 (b)", "Any four other tools: a cutlass; a hoe; a rake; a spade or shovel; a garden fork; a trowel; a watering can; a wheelbarrow; a knapsack sprayer; a sickle; an axe; a dibber; a head pan; a mattock; a pair of secateurs.", "15.1", "Remember"),
 ("1 (c)", "A watering can - used to water young plants and seedlings. A knapsack sprayer - used to apply chemicals such as pesticides and weedicides. A wheelbarrow - used to carry soil, manure, harvested produce or other loads.", "15.1", "Understand"),
 ("2 (a)", "(i) cutting and clearing bushes, weeding, or cutting grass. (ii) digging, turning and loosening the soil, and making mounds. (iii) harvesting rice, guinea corn or grass by cutting the stems. (iv) carrying soil, manure or harvested produce. (v) gathering leaves, grass and rubbish together, and levelling the soil. (vi) watering young plants and seedlings.", "15.1", "Understand"),
 ("2 (b)", "Any two animal-farm tools with a correct use each - e.g. a feeding trough holds feed for the animals; a spray pump is used to dip or spray animals against ticks and lice.", "15.1", "Apply"),
 ("3 (a)", "Handling is the way a tool is carried, used and kept while work is going on. It covers how the tool is picked up, carried to the farm, used and put down, and it means using the tool only for the job it was made for.", "15.2", "Understand"),
 ("3 (b)", "Maintenance is looking after a tool so that it stays in good working order. It includes cleaning, drying, sharpening, oiling and repairing the tool, and it is done after use and during storage so that the tool lasts longer.", "15.2", "Understand"),
 ("3 (c)", "Any three: proper handling prevents accidents and injuries; well-maintained tools last longer, so they do not have to be replaced often; the tools work better and faster, so more work is done; good maintenance saves money on repairs and replacements; clean, sharp tools do a better job.", "15.2", "Understand"),
 ("4 (a)", "Any three: the metal part rusts and becomes weak and blunt; the wooden handle rots or cracks and may break; the tool becomes blunt and does its work badly; it has to be repaired or replaced often, which costs money; a neglected tool can cause accidents; moving parts seize up or the handle works loose.", "15.2", "Understand"),
 ("4 (b)", "Rust makes the blade weak, so it may bend or break, and blunt, so it does not cut into the soil easily. A blunt blade needs much more force, so the farmer tires quickly, and the extra force makes the hoe more likely to slip and cause an injury. Less work is done in the day.", "15.2", "Apply"),
 ("4 (c)", "Look after good tools, because they cost more at first but last for many years and so are cheaper in the long run, because there are fewer repairs and replacements, and because sharp tools do the work better and faster.", "15.2", "Evaluate"),
 ("5 (a)", "Any four: always cut away from the body; carry tools with the blade or sharp edge pointing downwards; use each tool only for the job it was made for; put an unused tool down safely away from the working area; wear boots and gloves; never leave tools lying on a path; repair or report a damaged tool before using it; children should use tools only under adult supervision; read the label before using any chemical and wash afterwards.", "15.3", "Understand"),
 ("5 (b)", "A blunt cutlass does not bite in easily, so the farmer has to use much more force. The extra force makes the blade harder to control, so it is more likely to slip, and when it slips it can cut the leg, hand or foot. A sharp cutlass cuts with a light, controlled stroke and goes where the farmer wants it to go.", "15.3", "Analyse"),
 ("5 (c)", "Any two: wash the hands, face and any exposed skin with soap and clean water; wash or change the clothing worn while spraying; clean the sprayer and put it away safely; do not eat or drink before washing; report any feeling of sickness or dizziness at once.", "15.3", "Understand"),
 ("6 (a)", "A cutlass - always cut away from the body, and carry it with the blade pointing downwards. A hoe - keep the blade pointing down when carrying it, and do not swing it near another person. A knapsack sprayer - read the label, wear a nose cover and gloves, and do not spray against the wind. A wheelbarrow - do not overload it, and keep the load balanced so that it does not tip over.", "15.3", "Apply"),
 ("6 (b)", "Wash or wipe off all the soil and moisture from the blade, dry the hoe thoroughly, sharpen the blade if it is blunt, and oil or grease the metal part lightly to keep rust away. Hang it up or stand it in a dry, covered store rather than leaving it on the ground, and check the handle and tighten or replace it if it is loose or cracked.", "15.3", "Apply"),
 ("7 (a)", "Any three: farmers clean, dry and oil shared tools after use; tools are kept in a dry, locked community store; the community sets rules about who may use the tools and how they are cared for; farmers meet to repair or replace damaged tools together; pupils and farmers assemble tools from the community and practise using and maintaining them; a visit is made to a community farm to observe and report.", "15.4", "Understand"),
 ("7 (b)", "Ask permission from the farm owner and agree a date and time. Decide beforehand what the class is looking for and prepare a short checklist. Move round the farm in a group watching how each tool is carried, used and put down, and look at how the tools are cleaned, dried, sharpened and stored. Ask the farmer or workers about the rules they follow, and write down or draw each tool seen with a note of its condition. Keep clear of the working area so that the class does not cause an accident.", "15.4", "Create"),
 ("7 (c)", "Any two: the names of the tools seen; what each tool is used for; how each tool was handled; how each tool was maintained; the condition the tools were found in and anything that needed repair.", "15.4", "Remember"),
]
add_table(["Question", "Expected Answer", "Curriculum Area", "Cognitive Level"],
          [list(r) for r in sba], widths=[0.8, 4.2, 1.2, 1.2], size=9)

doc.add_page_break()

# =========================================================== MARKING SCHEME
para("MARKING SCHEME - SECTION B (60 marks)", size=13, bold=True, align="c", space_after=4)
para("General rules: (1) Accept any other correct and relevant answer. (2) Award marks for correct points, "
     "not for repeating the question. (3) For procedures, award method marks. (4) Do not deduct marks for "
     "spelling unless the meaning is changed. (5) Where a candidate gives more answers than are asked for, "
     "mark only the first ones up to the number required.",
     size=9.5, italic=True, space_after=8)

for qb in SECTION_B:
    n = qb["num"]
    para(f"Question {n}  ({qb['total']} marks)", size=11, bold=True, space_before=8, space_after=3)
    for (lab, points, note) in MARKING[n]:
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(2)
        set_font(p.add_run(f"{lab} "), 10.5, bold=True)
        mkv = [p_[2] for p_ in qb["parts"] if p_[0] == lab]
        if mkv: set_font(p.add_run(f"[{mkv[0]} mark{'s' if mkv[0] > 1 else ''}]"), 10, bold=True)
        for pt in points:
            pp = doc.add_paragraph()
            pp.paragraph_format.left_indent = Inches(0.35); pp.paragraph_format.space_after = Pt(1)
            set_font(pp.add_run("- " + pt), 10.5)
        pp = doc.add_paragraph()
        pp.paragraph_format.left_indent = Inches(0.35); pp.paragraph_format.space_after = Pt(6)
        set_font(pp.add_run("Marking note: " + note), 9.5, italic=True)

doc.add_page_break()

# ================================================================ BLUEPRINT
para("CURRICULUM ASSESSMENT BLUEPRINT", size=13, bold=True, align="c", space_after=3)
para(f"Strand: {STRAND}   |   Sub-strand: {SUBSTRAND}   |   Class: {CLASS}",
     size=10, italic=True, align="c", space_after=3)
para(f"Content Standard: {CS} - {CS_TEXT}", size=9, italic=True, align="c", space_after=3)
para("Source: NaCCA Science Common Core Programme Curriculum (B7/JHS1-B9/JHS3), September 2020, "
     "Strand 4: Forces and Energy, Sub-strand 5: Agricultural Tools, pp. 41-43. "
     "Indicators are quoted, not invented.",
     size=9, italic=True, space_after=8)

hdr = ["Qn", "Sub-strand", "Content Standard", "Indicator (NaCCA) - Indicator Text", "Topic / Content",
       "Cognitive Level", "Marks"]

rows = [[f"A{i}", SUBSTRAND, CS_BY_TOPIC[tp], f"{IND[tp]} - {IND_TEXT[tp]}", TOPIC[tp], cog, 1]
        for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1)]
add_table(hdr, rows, widths=[0.35, 0.75, 0.75, 1.75, 1.4, 0.8, 0.35], size=7, head_size=7.5)

para("", space_after=8)
rows = []
for qb in SECTION_B:
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        key = tp if tp in TOPIC else tp.split(",")[0].strip()
        rows.append([f"B{qb['num']}{lab.strip('()')}", SUBSTRAND, CS_BY_TOPIC[key],
                     f"{IND[key]} - {IND_TEXT[key]}", TOPIC[key], cog, mk])
add_table(hdr, rows, widths=[0.35, 0.75, 0.75, 1.75, 1.4, 0.8, 0.35], size=7, head_size=7.5)

doc.add_page_break()

# ----------------------------------------------------------------- helpers
def topic_totals():
    m = {k: 0 for k in TOPIC}; it = {k: 0 for k in TOPIC}
    for q in MCQ:
        m[q[3]] += 1; it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk; it[key] += 1
    return m, it

def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}; b = {k: 0 for k in order}
    for q in MCQ: a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: b[cog] += mk
    return order, a, b

def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ: d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: d[diff] += mk
    return d

m, it = topic_totals(); diff = difficulty_totals(); order, ca, cb = cognitive_by_section()

para("SUMMARY 1 - COVERAGE BY CURRICULUM AREA (TOPIC)", size=12, bold=True, space_after=4)
rows = [[TOPIC[k], it[k], m[k], f"{(m[k]/100)*100:.1f}%", CC[k]] for k in TOPIC]
rows.append(["TOTAL", sum(it.values()), sum(m.values()), "100%", "-"])
add_table(["Topic / Content Area", "No. of Items", "Marks", "% of Total Marks", "Core Competencies"],
          rows, widths=[2.7, 0.8, 0.6, 1.0, 1.1], size=8.5)
para("CC = Communication and Collaboration; CP = Critical Thinking and Problem Solving; "
     "DL = Digital Literacy; CI = Creativity and Innovation.", size=8.5, italic=True, space_after=2)

para("", space_after=8)
para("SUMMARY 2 - COGNITIVE-LEVEL DISTRIBUTION (Bloom's Taxonomy)", size=12, bold=True, space_after=4)
rows = []
for lv in order:
    tot = ca[lv] + cb[lv]
    rows.append([lv, ca[lv], cb[lv], tot, f"{(tot/100)*100:.1f}%"])
rows.append(["TOTAL", sum(ca.values()), sum(cb.values()), sum(ca.values()) + sum(cb.values()), "100%"])
add_table(["Cognitive Level", "Section A Marks", "Section B Marks", "Total Marks", "% of Total"],
          rows, widths=[1.6, 1.3, 1.3, 1.1, 1.1], size=9.5)

para("", space_after=8)
para("SUMMARY 3 - DIFFICULTY DISTRIBUTION", size=12, bold=True, space_after=4)
rows = [[k, v, f"{(v/100)*100:.1f}%"] for k, v in diff.items()]
rows.append(["TOTAL", sum(diff.values()), "100%"])
add_table(["Difficulty", "Marks", "% of Total Marks"], rows, widths=[2.0, 1.2, 1.5], size=9.5)
para("Target in the master prompt: approximately 30% easy / 50% moderate / 20% challenging.",
     size=9, italic=True, space_after=2)

para("", space_after=8)
para("SUMMARY 4 - SECTION WEIGHTING", size=12, bold=True, space_after=4)
add_table(["Section", "Question Type", "Items", "Marks", "% of Total"],
          [["A", "Objective (multiple choice)", 40, 40, "40%"],
           ["B", "Theory / constructed response", 19, 60, "60%"],
           ["TOTAL", "-", 59, 100, "100%"]],
          widths=[0.9, 2.4, 0.8, 0.8, 1.0], size=9.5)

doc.add_page_break()

# ===================================================== QUALITY-CONTROL
para("QUALITY-CONTROL SUMMARY", size=13, bold=True, align="c", space_after=4)
para("Carried out against the 14-point validation list in the master prompt before the examination was "
     "finalised.", size=9.5, italic=True, space_after=8)

qc = [
 ("Does every question belong to the supplied curriculum scope?",
  "Yes. All 59 items - 40 objectives and 19 theory sub-questions - trace to Strand 4 (Forces and "
  "Energy), Sub-Strand 5 (Agricultural Tools), topics 15.1-15.4, and to the two official B7 "
  "indicators under content standard B7/JHS1.4.5.1 (B7/JHS1.4.5.1.1 and B7/JHS1.4.5.1.2). Only "
  "basic and simple hand tools are tested; tractors, combine harvesters and ploughs appear only "
  "as distractors, because the curriculum asks for simple or basic farm tools."),
 ("Is the examination appropriate for the stated class?",
  "Yes. The B7 curriculum requires learners to list simple or basic farm tools with examples from "
  "both crop and animal farms, to discuss the meaning and importance of handling and "
  "maintenance, to list and match the basic rules with specific tools and describe how handling "
  "and maintenance are done, and to apply all of this in the community by observing, "
  "reporting, assembling tools and practising. Nothing beyond that is tested."),
 ("Are the questions genuinely BECE-style?",
  "Yes: Section A is 40 four-option objectives worth 1 mark each, and Section B is structured "
  "theory with sub-questions carrying printed mark allocations. There is a labelled diagram, a "
  "completion table, several 'state' and 'name' items, and two open tasks that require "
  "explanation and planning."),
 ("Are there enough application and reasoning questions?",
  "Yes. 32 of 100 marks (32%) are at Apply level or above (Apply 22, Analyse 4, Evaluate 2, "
  "Create 4). Create appears in Question 7(b), where pupils must plan a farm visit and say what "
  "they would record; Analyse in Question 5(b), where they must explain why a blunt cutlass is "
  "the more dangerous one; and Evaluate in Question 4(c), where they must choose between cheap "
  "tools and well-kept ones and justify the choice."),
 ("Are the MCQ distractors plausible?",
  "Yes. Distractors are drawn from the same content family as the key: another farm tool used "
  "for a different job (A3, A4, A9, A11), a machine rather than a simple tool (A1), a plausible "
  "but wrong way of caring for a tool (A36, A39), the opposite and unsafe practice (A21, A23, "
  "A26), and a real activity that is simply not the right answer (A33, A40)."),
 ("Is there only one best answer for each MCQ?",
  "Yes. Every item was reviewed for a single defensible key, and each option list was checked so "
  "that the declared key sits on the correct answer. Special care was taken with A1, where a "
  "plough is named alongside the tractor and the harvester so that only the hoe is a simple "
  "tool, with A19, where a wooden handle left in the rain rots rather than grows, and with A23, "
  "where the blade must point downwards and not merely forwards."),
 ("Are the marks internally consistent?",
  "Yes. Section A = 40 items x 1 mark = 40. Section B = 10 + 8 + 9 + 8 + 9 + 7 + 9 = 60. "
  "Each Section B sub-question's printed marks match its marking-scheme allocation, and every "
  "N-mark sub-question asks for N things."),
 ("Does the total add up correctly?",
  "Yes: 40 + 60 = 100 marks, matching the stated total on the front page."),
 ("Are the answers in the answer key correct?",
  "Yes. All 40 objective keys and all 19 Section B answers were verified against the marking "
  "scheme. The diagram key was checked against the figure: the long shaft is the handle, the "
  "flat box below it is the blade, and the arrow below points to the cutting edge."),
 ("Does the marking scheme match the questions?",
  "Yes. Every Section B sub-question has an expected-answer list and a marking note covering "
  "partial credit, acceptable alternatives, common wrong answers and method marks. Question "
  "4(b) insists that one mark come from the difficulty and one from the danger; Question 6(a) "
  "withholds the mark when a correct rule is attached to the wrong tool; and Question 7(b) "
  "requires at least one point about preparing for the visit and one about what would be "
  "recorded."),
 ("Are the questions free from unnecessary ambiguity?",
  "Yes. Open items are anchored with 'name four', 'state three', 'state two' and the mark "
  "allocation. Question 1(b) says 'four OTHER basic tools' so that pupils do not repeat the hoe "
  "in Fig. 1; Question 5(a) asks for rules for handling, and the note excludes maintenance "
  "answers; and Question 7(b) says 'describe what you would do to prepare AND what you would "
  "observe and record' so that both halves are expected."),
 ("Are Ghanaian contexts used naturally and accurately?",
  "Yes: a hoe, cutlass, head pan and wheelbarrow on a Ghanaian farm; rice and guinea corn "
  "harvested with a sickle; knapsack sprayers used for pesticides and weedicides; a community "
  "farm visit; a shared community tool store; and a class report presented after the visit."),
 ("Has any content outside the supplied curriculum been introduced?",
  "No. Every item sits inside topics 15.1-15.4. Farm machinery, tractor maintenance, irrigation "
  "and agro-chemical manufacture are not required anywhere in the paper; machines are named only "
  "as distractors in A1."),
 ("Are the questions sufficiently varied?",
  "Yes. Item types include naming the labelled parts of a hoe, listing other tools, matching "
  "three tools to their uses, completing a six-row tool table, naming animal-farm tools, "
  "explaining the meaning of handling and of maintenance, stating why they matter, describing "
  "what neglect does, explaining why a rusty hoe is dangerous, arguing a choice between cheap "
  "and good tools, stating four safety rules, explaining why blunt is dangerous, giving the "
  "steps after spraying, matching a rule to each of four tools, describing end-of-day care for a "
  "hoe, describing community maintenance, planning a farm visit, and listing the contents of a "
  "report."),
]
for i, (q, a) in enumerate(qc, start=1):
    p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(2)
    set_font(p.add_run(f"{i}. {q}"), 10.5, bold=True)
    p2 = doc.add_paragraph()
    p2.paragraph_format.left_indent = Inches(0.3); p2.paragraph_format.space_after = Pt(6)
    set_font(p2.add_run(a), 10)

para("", space_after=8)
para("EXAMINER NOTES (for the teacher, not for candidates)", size=11, bold=True, space_after=4)
for n in [
 "Question 5(b) is the discriminator, and it is the one most pupils get backwards. They assume a "
 "sharp cutlass is the dangerous one. It is not: a blunt blade will not bite, so the farmer "
 "forces it, loses control, and the blade slips onto a leg or a hand. The note withholds marks "
 "from an answer that only says 'it can cut you' - the reasoning is what earns them.",
 "Question 7(b) is the design task, and it is marked on two halves. Pupils must say something "
 "about PREPARING for the visit and something about what they would OBSERVE AND RECORD. An "
 "answer that covers only one half is capped at 3 of the 4 marks. Do not insist on a particular "
 "farm - the school farm, a nearby cocoa or maize farm, or a community animal farm all work.",
 "Question 1(b) asks for four tools OTHER than the one in Fig. 1. Several pupils will write "
 "'hoe' because it is the first tool they think of, and that mark is withheld. Worth saying out "
 "loud before the mock.",
 "Question 6(a) is marked on the match, not on the rules alone. A pupil who lists four correct "
 "safety rules but attaches them to the wrong tools scores nothing. Tell them to write the tool "
 "and the rule together in one sentence.",
 "The two indicators under this content standard are 'explain the basic rules' (B7/JHS1.4.5.1.1) "
 "and 'apply the handling and maintenance in their community' (B7/JHS1.4.5.1.2). That is why "
 "the paper moves from naming tools, through meanings and rules, to a community visit and a "
 "report - the curriculum's own sequence, not mine.",
 "Topic weighting is 30 marks for 15.1, 25 for 15.2, 27 for 15.3 and 18 for 15.4. Tools and "
 "safety carry the most. If you spent longer on community work, move marks towards Question 7.",
 "Two cheap practicals that raise marks sharply: (1) bring a hoe, a cutlass and a rake to class "
 "and let pupils name the parts and pass them round safely, and (2) leave two nails, one oiled "
 "and one wet, overnight and look at them the next morning. The first teaches Questions 1 and 6, "
 "the second teaches Questions 3 and 4.",
 "If you can arrange it, the farm visit in Question 7(b) is worth doing for real. A single "
 "afternoon at a nearby farm fixes the whole sub-strand better than any number of notes, and it "
 "gives pupils something concrete to write about.",
 "Edit the school name, academic year and examination title on page 1 before printing.",
 "This is an original, teacher-made mock. It is not a reproduction of any WAEC or NaCCA examination "
 "paper.",
]:
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Inches(0.3); p.paragraph_format.space_after = Pt(3)
    set_font(p.add_run("- " + n), 10)

doc.save("/home/user/Basic7_Integrated_Science_Mock_Strand4_AgriculturalTools.docx")
print("docx written")

print("Section A:", len(MCQ), "items")
print("Section B total:", sum(q["total"] for q in SECTION_B))
print("Topic marks:", m, "sum", sum(m.values()))
print("Difficulty:", diff, "sum", sum(diff.values()))
print("Cognitive A:", ca)
print("Cognitive B:", cb)
print("Answer counts:", counts)
print("Totals:", sum(m.values()), sum(diff.values()),
      sum(ca.values()) + sum(cb.values()))
