# -*- coding: utf-8 -*-
"""Basic 7 Integrated Science mock - Strand 2 Sub-strand 3: CROP PRODUCTION. 100 marks.
Indicators sourced from the official NaCCA Science CCP curriculum (B7/JHS1-B9/JHS3, Sept 2020),
Strand 2: Cycles, Sub-strand 3: Crop Production, printed page 11."""

SCHOOL = "[SCHOOL NAME]"
SUBJECT = "INTEGRATED SCIENCE (SCIENCE)"
EXAM = "END-OF-TERM MOCK EXAMINATION"
CLASS = "Basic 7 (JHS 1)"
TIME = "2 hours (Suggested: Section A - 40 min; Section B - 80 min)"
MARKS = "100"
YEAR = "2025/2026 Academic Year"

STRAND = "Cycles"
SUBSTRAND = "Crop Production"

TOPIC = {
    "5.1": "5.1 What are Plant Nutrients?",
    "5.2": "5.2 Organic and Inorganic Nutrient Sources",
    "5.3": "5.3 Differences Between Organic and Inorganic Fertilizers",
    "5.4": "5.4 Physical Characteristics of Plant Nutrients",
    "5.5": "5.5 How Plant Nutrients Are Applied in the Field",
    "5.6": "5.6 Practical Application in the School Garden",
}

CS = "B7/JHS1.2.3.1"
CS_TEXT = "Demonstrate understanding of the different plant nutrients (organic, and inorganic fertilizers) " \
          "and their application in school farming (school gardening)"

IND = {
    "5.1": "B7/JHS1.2.3.1.1",
    "5.2": "B7/JHS1.2.3.1.1",
    "5.3": "B7/JHS1.2.3.1.1 (Ex. 1, 2)",
    "5.4": "B7/JHS1.2.3.1.2 (Ex. 1)",
    "5.5": "B7/JHS1.2.3.1.2 (Ex. 2)",
    "5.6": "B7/JHS1.2.3.1.2 (Ex. 3)",
}
IND_TEXT = {
    "5.1": "Observe and list all plant nutrient sources available in a community, and say what a plant "
           "nutrient is and why crops need it.",
    "5.2": "Observe and list all plant nutrient sources available in a community and categorise them into "
           "organic and inorganic nutrient sources.",
    "5.3": "Create a table to explain the differences between organic and inorganic plant nutrients; compare "
           "the volumes of organic and inorganic nutrient source required by different plants.",
    "5.4": "Identify each plant nutrient source and explain how its physical structure and appearance affect "
           "its application.",
    "5.5": "Describe in groups how each type of nutrient source may be applied to plants in the field "
           "(e.g. school garden).",
    "5.6": "Demonstrate practical application of each type of nutrient source to plants in the field "
           "(e.g. school garden).",
}
CC = {
    "5.1": "CC, CP", "5.2": "CC, CP", "5.3": "CC, CP",
    "5.4": "DL, CC, CI", "5.5": "DL, CC, CI", "5.6": "DL, CC, CI",
}

# ---------------------------------------------------------------- SECTION A
# (question, [A,B,C,D], answer, topic, cognitive, difficulty)
MCQ = [
 ("A plant nutrient is",
  ["any liquid poured on the soil", "any substance added to the soil to kill pests",
   "any substance that a plant takes in and uses for its growth and development", "water only"],
  "C", "5.1", "Remember", "Easy"),
 ("The three nutrient elements most often supplied to crops in fertilizers are",
  ["nitrogen, phosphorus and potassium", "calcium, iron and zinc",
   "sodium, chlorine and sulphur", "carbon, hydrogen and oxygen"],
  "A", "5.1", "Remember", "Easy"),
 ("A maize crop has pale yellow-green leaves and is not growing well. The nutrient most likely to be "
  "short is",
  ["phosphorus", "potassium", "calcium", "nitrogen"],
  "D", "5.1", "Understand", "Moderate"),
 ("Which nutrient helps a young pepper plant to develop a strong root system, flowers and fruits?",
  ["nitrogen", "phosphorus", "potassium", "magnesium"],
  "B", "5.1", "Understand", "Moderate"),
 ("A pupil fills a bucket with clean sand, plants maize in it and waters the maize every day. After three "
  "weeks the plants are thin and yellow. The best explanation is that",
  ["the plants did not get enough water", "the bucket became too warm in the sun",
   "clean sand contains almost no plant nutrients", "the maize seeds were too old"],
  "C", "5.1", "Understand", "Moderate"),
 ("A farmer grows maize on the same land every year. The main reason she has to replace the nutrients in "
  "the soil is that",
  ["each harvest carries nutrients away in the grain, leaves and stalks, so the soil becomes poorer",
   "the soil becomes too hard for the roots to push through",
   "the rain washes the seeds out of the ground",
   "the maize cannot be sold if the soil is not treated"],
  "A", "5.1", "Understand", "Easy"),
 ("Which of the following is an organic nutrient source?",
  ["urea", "NPK 15-15-15", "sulphate of ammonia", "compost"],
  "D", "5.2", "Remember", "Easy"),
 ("Which of the following is an inorganic nutrient source?",
  ["poultry manure", "sulphate of ammonia", "cow dung", "cocoa husk"],
  "B", "5.2", "Remember", "Easy"),
 ("Which of the following is NOT an organic nutrient source?",
  ["poultry manure", "compost", "NPK 15-15-15", "wood ash"],
  "C", "5.2", "Remember", "Easy"),
 ("A nutrient source is grouped as organic mainly because it",
  ["comes from the remains of living things such as plants and animals",
   "is bought from an agro-chemical shop", "dissolves quickly in water", "is made in a factory"],
  "A", "5.2", "Understand", "Moderate"),
 ("Which organic nutrient source is made by heaping plant and animal waste together and letting it rot?",
  ["green manure", "wood ash", "crop residue", "compost"],
  "D", "5.2", "Remember", "Easy"),
 ("Inorganic fertilizers are also called",
  ["green fertilizers", "mineral or chemical fertilizers", "humus fertilizers", "farmyard fertilizers"],
  "B", "5.2", "Remember", "Easy"),
 ("Which pair contains ONLY organic nutrient sources?",
  ["urea and compost", "NPK and wood ash", "poultry manure and cocoa husk",
   "sulphate of ammonia and cow dung"],
  "C", "5.2", "Understand", "Moderate"),
 ("Compared with an equal mass of compost, a bag of NPK fertilizer",
  ["contains a higher concentration of nutrients", "is cheaper for each kilogram of nutrient supplied",
   "improves the soil structure much more", "releases its nutrients more slowly"],
  "A", "5.3", "Understand", "Moderate"),
 ("A farmer uses a much larger volume of poultry manure than of NPK on the same crop. The main reason is "
  "that the manure",
  ["is heavier to carry", "smells stronger", "is harder to find",
   "contains far less of each nutrient in every kilogram"],
  "D", "5.3", "Understand", "Moderate"),
 ("Which of these is an advantage of an organic nutrient source over an inorganic one?",
  ["it is easier to carry to the farm", "it improves the soil structure and helps the soil hold water",
   "it feeds the crop at once", "its nutrient content is printed on the bag"],
  "B", "5.3", "Understand", "Moderate"),
 ("Which of these is an advantage of an inorganic fertilizer over an organic one?",
  ["it adds humus to the soil", "it is always free",
   "it is concentrated, so a small amount is easy to carry and to measure",
   "it can never harm the crop"],
  "C", "5.3", "Understand", "Moderate"),
 ("Organic nutrients become available to the crop slowly because",
  ["soil organisms must first break the material down before the roots can take up the nutrients",
   "the rain washes them away slowly", "the roots cannot reach them in the soil",
   "they are always stored in a bag"],
  "A", "5.3", "Understand", "Challenging"),
 ("A farmer who uses only inorganic fertilizer for many years without adding any organic matter may find "
  "that the soil",
  ["becomes too soft for the plants", "makes the crops grow too quickly",
   "becomes too wet for the roots", "loses its humus, becomes hard and holds less water"],
  "D", "5.3", "Understand", "Challenging"),
 ("Which statement about cost is most often true on a small Ghanaian farm?",
  ["inorganic fertilizer is always free",
   "organic manure is cheap and bulky, while inorganic fertilizer is costly but concentrated",
   "both types always cost the same", "compost is the most expensive nutrient source of all"],
  "B", "5.3", "Understand", "Moderate"),
 ("An inorganic fertilizer such as NPK is usually seen as",
  ["a dark, crumbly, moist mass", "a thick liquid sold in bottles",
   "dry granules or crystals packed in a bag", "large wet lumps that smell of decay"],
  "C", "5.4", "Remember", "Easy"),
 ("Well-rotted compost is usually",
  ["dark brown or black, crumbly and smelling of decay", "white crystals with a sharp smell",
   "a fine blue powder", "a clear liquid"],
  "A", "5.4", "Remember", "Easy"),
 ("Which physical property makes it easy to measure an inorganic fertilizer accurately in the field?",
  ["it is coloured", "it is heavy", "it smells strongly",
   "it is dry and flows freely as granules or powder"],
  "D", "5.4", "Understand", "Moderate"),
 ("The figures 15-15-15 printed on a bag of NPK refer to",
  ["the price of the bag in cedis",
   "the percentage of nitrogen, phosphorus and potassium in the fertilizer",
   "the number of bags the farmer should buy", "the mass of the bag in kilograms"],
  "B", "5.4", "Understand", "Moderate"),
 ("Because most inorganic fertilizers dissolve readily in water, they",
  ["can only be sprayed on the leaves", "cannot be used on sandy soil",
   "can be washed away by heavy rain if they are left uncovered on the surface",
   "must be applied only at night"],
  "C", "5.4", "Apply", "Challenging"),
 ("A bag of fertilizer has been stored in a damp room and has formed hard lumps. The best way to deal "
  "with it before application is to",
  ["break up the lumps and crush them so that the fertilizer can be spread evenly",
   "throw the lumps away and use only the powder", "add more water until the lumps dissolve",
   "apply the lumps whole beside each plant"],
  "A", "5.4", "Apply", "Moderate"),
 ("Because compost is bulky and coarse, it is best",
  ["dissolved in water and sprayed on the leaves", "placed in a small ring round each seed",
   "given to the crop as a liquid feed",
   "spread over the whole bed and mixed lightly into the soil"],
  "D", "5.4", "Understand", "Moderate"),
 ("The most common way of applying NPK fertilizer to maize on a small farm is to",
  ["scatter it on the leaves",
   "place it in a ring or band a few centimetres from the plant and cover it with soil",
   "pour it on the growing point of the plant", "mix it with the seed in the planting hole"],
  "B", "5.5", "Understand", "Moderate"),
 ("Fertilizer is placed a few centimetres away from the stem of a young plant instead of being heaped "
  "against it because",
  ["it can draw water out of the young tissues and burn the plant",
   "the roots of a young plant cannot reach it", "birds will come and eat it",
   "the wind will blow it away"],
  "A", "5.5", "Understand", "Challenging"),
 ("Broadcasting a nutrient source means",
  ["spraying a solution of it on the leaves", "putting it in a hole beside each plant",
   "mixing it with the water used for irrigation",
   "scattering it evenly over the whole surface of the field"],
  "D", "5.5", "Remember", "Easy"),
 ("The best time to apply fertilizer to a growing crop is",
  ["at midday when the sun is hottest", "just before a heavy storm is expected",
   "when the soil is moist, for example just after rain", "during the harmattan when the soil is dry"],
  "C", "5.5", "Apply", "Moderate"),
 ("Compost or well-rotted poultry manure is usually applied to a bed",
  ["after the crop has been harvested", "before planting, and mixed lightly into the topsoil",
   "only on the day the crop starts to flower", "on the morning of the harvest"],
  "B", "5.5", "Understand", "Moderate"),
 ("Splitting a nitrogen fertilizer into two or three smaller doses during the season is better than "
  "applying it all at once because",
  ["less of it is washed away or lost before the crop can use it",
   "small amounts of fertilizer are always cheaper", "the crop will grow twice as fast",
   "it keeps the soil cool"],
  "A", "5.5", "Analyse", "Challenging"),
 ("Side-dressing (top-dressing) is",
  ["spraying a solution of the nutrient on the leaves",
   "applying fertilizer along the rows beside a growing crop",
   "scattering it over the field before ploughing", "treating the seed before it is planted"],
  "B", "5.5", "Remember", "Easy"),
 ("Before applying any nutrient in the school garden, the most useful first step is to",
  ["buy the most expensive fertilizer available", "water the whole garden thoroughly",
   "harvest the crop that is already growing",
   "measure the beds and work out how much each bed will receive"],
  "D", "5.6", "Understand", "Moderate"),
 ("A pupil is about to apply NPK fertilizer in the school garden. The most important safety measure is to",
  ["wear a raincoat", "wear gloves and wash the hands with soap afterwards",
   "wear dark sunglasses", "work alone so that nobody is distracted"],
  "B", "5.6", "Understand", "Easy"),
 ("Which of these should NOT be done when applying fertilizer in the school garden?",
  ["wearing gloves while handling it", "covering the fertilizer with soil after placing it",
   "applying it just before a heavy storm is expected",
   "writing down the date and the amount applied"],
  "C", "5.6", "Apply", "Moderate"),
 ("To find out whether the nutrient the class applied has worked, the class should",
  ["measure and record plant height and leaf colour at regular intervals and compare treated beds with "
   "untreated beds", "ask the oldest pupil in the class what she thinks",
   "count the number of empty bags left over", "weigh the bags before and after"],
  "A", "5.6", "Apply", "Moderate"),
 ("A class wants to compare the volume of compost and the volume of NPK needed by the same crop. The "
  "fairest way to do this is to",
  ["use a different crop in each of the two beds", "water one bed more often than the other",
   "keep the compost bed in the shade and the NPK bed in the sun",
   "use two similar beds with the same crop, the same spacing and the same watering, and change only the "
   "type of nutrient"],
  "D", "5.6", "Analyse", "Challenging"),
 ("After the class has worked poultry manure into the school garden beds, the best next step is to",
  ["leave the beds untouched for one month", "spray the leaves with water only",
   "water the beds lightly and record the date and the amount applied",
   "dig the manure out again the next day"],
  "C", "5.6", "Apply", "Moderate"),
]

# ------------------------------------------------------- SECTION B TABLE (Q3)
COMPARE_HEADERS = ["Feature", "Organic nutrient source", "Inorganic nutrient source"]
COMPARE_ROWS = [
 ["Where it comes from",
  "The remains of plants and animals, e.g. manure, compost, crop residue",
  "(i)"],
 ["Amount of nutrient in 1 kg", "(ii)",
  "High, and the amount is printed on the bag"],
 ["How quickly it feeds the crop", "(iii)",
  "Fast, because it dissolves readily in soil water"],
 ["Effect on soil structure",
  "Improves it: adds humus and helps the soil hold water", "(iv)"],
 ["Volume needed for the same crop", "(v)", "Small"],
 ["Danger if too much is applied", "(vi)",
  "Can scorch or burn the plant"],
]
COMPARE_CAPTION = "Table 1: Differences between organic and inorganic plant nutrients"

# ---------------------------------------------------------------- SECTION B
SECTION_B = [
 dict(
   num=1, total=8, topic="5.1",
   stem="Crops grown on the same piece of land year after year often become weak and give poor harvests.",
   parts=[
     ("(a)", "What is meant by a plant nutrient?", 2, "Understand", "5.1", "Easy"),
     ("(b)", "State three things that plant nutrients help a crop plant to do.",
      3, "Understand", "5.1", "Moderate"),
     ("(c)", "Explain why a farmer who harvests maize from the same land every year must keep adding "
             "nutrients to the soil.", 3, "Analyse", "5.1", "Challenging"),
   ]),
 dict(
   num=2, total=9, topic="5.2",
   stem="A Basic 7 class was asked to observe and list the plant nutrient sources available in their "
        "community and to group them into organic and inorganic sources.",
   parts=[
     ("(a)", "Name three organic nutrient sources the class is likely to find.",
      3, "Remember", "5.2", "Easy"),
     ("(b)", "Name three inorganic nutrient sources the class may find.",
      3, "Remember", "5.2", "Easy"),
     ("(c)", "Explain how the class would decide whether a nutrient source is organic or inorganic.",
      3, "Understand", "5.2", "Moderate"),
   ]),
 dict(
   num=3, total=10, topic="5.3",
   stem="The class was asked to create a table to explain the differences between organic and inorganic "
        "plant nutrients. Study the incomplete table below and answer the questions that follow.",
   table="compare",
   parts=[
     ("(a)", "Copy and complete the table.", 6, "Understand", "5.3", "Moderate"),
     ("(b)", "A farmer is told that she can feed her maize with three bags of poultry manure or with half "
             "a bag of NPK 15-15-15. Explain why such a small amount of NPK is enough.",
      2, "Apply", "5.3", "Challenging"),
     ("(c)", "A second farmer has hard, sandy soil. Which type of nutrient source would you advise her to "
             "use? Give a reason for your answer.", 2, "Evaluate", "5.3", "Moderate"),
   ]),
 dict(
   num=4, total=9, topic="5.4",
   stem="The physical characteristics of a nutrient source affect the way it is applied in the field.",
   parts=[
     ("(a)", "State three physical characteristics of an inorganic fertilizer such as NPK.",
      3, "Remember", "5.4", "Easy"),
     ("(b)", "State three physical characteristics of compost or well-rotted poultry manure.",
      3, "Remember", "5.4", "Easy"),
     ("(c)", "Explain how the physical form of each type affects the way it is applied to a crop.",
      3, "Apply", "5.4", "Moderate"),
   ]),
 dict(
   num=5, total=9, topic="5.5",
   stem="A farmer has just bought a bag of NPK 15-15-15 and she also has a heap of well-rotted compost.",
   parts=[
     ("(a)", "Describe how she should apply the NPK to her maize.", 3, "Understand", "5.5", "Moderate"),
     ("(b)", "Describe how she should apply the compost.", 3, "Understand", "5.5", "Moderate"),
     ("(c)", "Explain why the fertilizer is placed a few centimetres from the plant and covered with soil, "
             "instead of being heaped against the stem.", 3, "Understand", "5.5", "Challenging"),
   ]),
 dict(
   num=6, total=10, topic="5.6",
   stem="Your class has been asked to apply compost to a bed of garden eggs in the school garden.",
   parts=[
     ("(a)", "List three tools or materials the class will need.", 3, "Remember", "5.6", "Easy"),
     ("(b)", "Describe the steps the class should follow to apply the compost properly.",
      3, "Apply", "5.6", "Moderate"),
     ("(c)", "Design a simple record sheet the class could keep to find out whether the compost made a "
             "difference to the crop.", 4, "Create", "5.6", "Challenging"),
   ]),
 dict(
   num=7, total=5, topic="5.6",
   stem="The class also wants to compare the volume of compost and the volume of NPK 15-15-15 needed by "
        "the same crop in the school garden.",
   parts=[
     ("(a)", "Describe how the class should set up this comparison so that the result is fair.",
      3, "Create", "5.6", "Challenging"),
     ("(b)", "State two observations the class should record to help them decide which nutrient source "
             "gave the better result.", 2, "Evaluate", "5.6", "Moderate"),
   ]),
]

# ------------------------------------------------------- MARKING SCHEME
MARKING = {
 1: [
   ("(a)", ["A plant nutrient is any substance that a plant takes in and uses for its growth and "
            "development.",
            "It is a substance that feeds the plant and helps it to grow, produce leaves, flowers, "
            "fruits and seeds.",
            "It is the 'food' of the plant, taken mainly from the soil, air and water."],
    "1 mark each for any TWO correct points (2 marks). Award 1 mark for 'something the plant needs to "
    "grow' if it is not developed further. Do NOT accept 'fertilizer' on its own - a fertilizer is a "
    "source of nutrients, not the nutrient itself."),
   ("(b)", ["To grow tall and produce more leaves and stems.",
            "To produce a good root system.",
            "To produce flowers, fruits and seeds (a good yield).",
            "To stay healthy and resist disease and drought.",
            "To give a dark green leaf colour (nitrogen builds the green colouring)."],
    "1 mark each for any THREE correct points (3 marks). Accept 'to grow well' once. Do NOT award three "
    "marks for the same point worded three times."),
   ("(c)", ["Every harvest carries nutrients away from the land in the grain, leaves and stalks that are "
            "removed.",
            "Cropping year after year therefore takes more nutrients out of the soil than are put back.",
            "Rain also washes some nutrients deeper into the soil or off the land altogether.",
            "So the store of nutrients in the soil becomes smaller and the crop becomes weak and the "
            "yield falls, unless the farmer replaces them.",
            "Adding fertilizer or manure puts back what the crop has taken out."],
    "1 mark each for any THREE correct points (3 marks). The key idea is that the harvest removes "
    "nutrients, so they must be replaced. Award 1 mark for 'so that the soil does not become poor'."),
 ],
 2: [
   ("(a)", ["Poultry manure", "Cow dung", "Goat or sheep droppings", "Compost", "Green manure",
            "Crop residue (e.g. maize stalks, cocoa husks)", "Kitchen refuse", "Wood ash",
            "Fish waste from the market", "Decayed leaves"],
    "1 mark each for any THREE correct organic sources (3 marks). Accept any locally available organic "
    "material. Do NOT accept a named fertilizer such as NPK or urea."),
   ("(b)", ["NPK 15-15-15", "Urea", "Sulphate of ammonia", "Muriate of potash",
            "Single superphosphate"],
    "1 mark each for any THREE correct inorganic sources (3 marks). Accept the correct Ghanaian trade "
    "name of any manufactured mineral fertilizer."),
   ("(c)", ["Ask where the material comes from: if it is the remains of plants or animals it is organic, "
            "if it is manufactured or mined it is inorganic.",
            "Organic sources are bulky, dark and smell of decay; inorganic ones are usually dry, clean "
            "granules or crystals.",
            "Organic sources rot and can be broken down further; inorganic ones mostly dissolve in water "
            "instead of rotting.",
            "If the nutrient content is printed on a bag and it was made in a factory, it is inorganic."],
    "1 mark each for any THREE correct points (3 marks). The key idea is the ORIGIN of the material. "
    "Accept a clear test based on origin alone."),
 ],
 3: [
   ("(a)", ["(i) It is manufactured from mineral deposits or made in a factory from chemicals.",
            "(ii) Low, and it varies from heap to heap.",
            "(iii) Slow, because soil organisms must first break it down (rot it) before the roots can "
            "take the nutrients up.",
            "(iv) Little or no humus is added; used alone for a long time it can make the soil hard and "
            "less able to hold water.",
            "(v) Large.",
            "(vi) Very low; it releases its nutrients slowly and rarely burns the plant."],
    "1 mark each for all SIX blanks correctly filled (6 marks). The blank number must be matched to the "
    "correct answer. Accept any clear equivalent wording, e.g. 'small' for (ii) and 'big/much' for (v)."),
   ("(b)", ["NPK is concentrated: each kilogram contains far more of the nutrient than a kilogram of "
            "manure does.",
            "So a small volume of NPK supplies as much nutrient as a very large volume of poultry "
            "manure.",
            "The figures printed on the bag (15-15-15) show how much nutrient it contains."],
    "1 mark each for any TWO correct points (2 marks). Accept 'NPK is stronger' if it is explained. "
    "Do NOT award both marks for 'NPK is better' on its own."),
   ("(c)", ["Organic nutrient source (compost or manure).",
            "Because it adds humus, which binds sandy particles together and helps the soil hold water.",
            "It also feeds the soil organisms and improves the soil structure year after year.",
            "An inorganic fertilizer would feed the crop but would do little to improve the soil itself."],
    "1 mark for choosing the ORGANIC source and 1 mark for a correct reason (2 marks). The reason must "
    "say something about improving the soil, not only about feeding the plant. Accept inorganic ONLY if "
    "the pupil explains a crop-nutrition reason and admits the soil problem is not solved."),
 ],
 4: [
   ("(a)", ["It is dry.", "It is in the form of granules, crystals or powder.",
            "The particles are small and fairly uniform in size.",
            "It is often coloured (white, grey, pink or blue).",
            "It is packed and sold in labelled bags.",
            "It has little or no smell of decay.",
            "It dissolves readily in water.",
            "It is heavy for its size."],
    "1 mark each for any THREE correct characteristics (3 marks). Accept 'it is bagged' or 'it looks "
    "like salt or sugar'."),
   ("(b)", ["It is dark brown or black.", "It is crumbly or powdery when it is well rotted.",
            "It is moist or damp.", "It smells of decay (like rotting leaves or manure).",
            "It is bulky: a little of it takes up a lot of space for its mass.",
            "It contains visible pieces of straw, husks, leaves or fibre.",
            "The particles are of many different sizes.", "It is light for its size."],
    "1 mark each for any THREE correct characteristics (3 marks). Accept 'it looks like dark soil'."),
   ("(c)", ["Because NPK is dry and flows freely, it can be measured out with a tin or a cup and placed "
            "in a ring or band beside each plant.",
            "Because it dissolves quickly, it must be covered with soil and the soil kept moist, "
            "otherwise rain washes it away before the roots reach it.",
            "Because it is concentrated, a small measured amount is enough, and too much in one place "
            "will burn the plant.",
            "Because compost is bulky and coarse, it is spread over the whole bed and mixed into the "
            "topsoil rather than measured into small rings.",
            "Because compost is coarse and holds water, it can also be spread on the surface as a mulch.",
            "A dusty powdery fertilizer must not be applied on a windy day, because the wind will blow "
            "it away."],
    "1 mark each for any THREE correct points (3 marks). The answer must say something about BOTH the "
    "inorganic form and the organic form to earn full marks; award at most 2 marks if only one type is "
    "dealt with."),
 ],
 5: [
   ("(a)", ["Wait until the soil is moist, for example just after rain, or water the plot first.",
            "Measure out the amount needed for the number of plants.",
            "Place it in a ring or a band about 5-10 cm from the base of each maize plant.",
            "Cover it with a thin layer of soil so that the rain does not wash it away.",
            "Apply it in two or three smaller doses (split application) during the growing season "
            "instead of all at once."],
    "1 mark each for any THREE correct points (3 marks). The key ideas are: moist soil, measured "
    "amount, placed beside the plant, and covered with soil."),
   ("(b)", ["Spread the compost evenly over the whole bed or plot.",
            "Work it lightly into the topsoil with a hoe or a rake.",
            "Do this before planting, or round the base of established plants without touching the stem.",
            "Water the plot afterwards so that the nutrients begin to move into the soil.",
            "Use a generous layer, because compost is bulky and contains less nutrient per kilogram."],
    "1 mark each for any THREE correct points (3 marks). Accept spreading it as a mulch round the plants."),
   ("(c)", ["Fertilizer placed against the stem can draw water out of the young tissues and burn or kill "
            "the plant.",
            "Placing it a few centimetres away puts the nutrient where the feeding roots are, which "
            "spread sideways from the plant.",
            "Covering it with soil stops it from being washed away by rain or blown away by the wind.",
            "Covering also keeps the nutrient from being lost to the air before the roots can take it up.",
            "A ring is better than a heap, because the nutrient is spread where the roots can reach it."],
    "1 mark each for any THREE correct points (3 marks). One mark must come from an explanation of the "
    "burning/scorching risk; award at most 2 marks if the answer only deals with the roots."),
 ],
 6: [
   ("(a)", ["A hoe or a hand fork", "A rake", "A bucket or a basin to carry the compost",
            "A measuring tin, cup or small bucket", "A watering can with water",
            "String and pegs to mark out the bed", "Gloves", "A nose mask", "Boots or old shoes",
            "A notebook and pencil for recording"],
    "1 mark each for any THREE correct tools or materials (3 marks). Accept any sensible item a pupil "
    "would really use in a school garden."),
   ("(b)", ["Clear the bed of weeds and loosen the topsoil.",
            "Mark out the bed and the planting positions with string and pegs.",
            "Measure out the compost with a tin or a bucket so that every part of the bed gets the same "
            "amount.",
            "Spread the compost evenly over the surface of the bed.",
            "Work it lightly into the topsoil with a hoe or a rake, without damaging the roots of "
            "nearby plants.",
            "Plant or water in the seedlings and water the bed well afterwards.",
            "Record the date, the amount used and what was observed."],
    "1 mark each for any THREE correct steps in a sensible order (3 marks). Award method marks: a "
    "sensible sequence that would work in a real school garden earns credit even if the wording is "
    "simple."),
   ("(c)", ["A column for the date of each observation.",
            "A column naming the bed or plot (e.g. Bed A with compost, Bed B without compost).",
            "A column recording what was applied and how much.",
            "A column for plant height, measured with a ruler or a stick at regular intervals.",
            "A column for the number of leaves, or for leaf colour and general vigour.",
            "A column for the yield: the number or the mass of the garden eggs harvested.",
            "A column for any other observation, such as pests, wilting or rainfall.",
            "A second bed with no compost, so that the class has something to compare with.",
            "Space to write the pupil's name or group and any comments."],
    "1 mark each for any FOUR sensible features of the record sheet (4 marks). This is a design task: "
    "award method marks generously for any feature that would help the class decide whether the compost "
    "made a difference. A comparison bed, a measurement taken over time, and a record of what was "
    "applied are the three features to look for first."),
 ],
 7: [
   ("(a)", ["Mark out two (or more) beds of the same size, in the same place and with the same soil.",
            "Plant the same crop, of the same variety, at the same spacing, on the same day.",
            "Give every bed the same water, the same weeding and the same care.",
            "Change only ONE thing: the type of nutrient source (compost in one bed, NPK in the other).",
            "Keep one bed with no nutrient at all as a control, so the class can see the difference.",
            "Work out the amount of each nutrient source beforehand by measuring, and write it down.",
            "Repeat the comparison, or use more than one bed of each type, so that one unlucky bed does "
            "not spoil the result."],
    "1 mark each for any THREE correct points (3 marks). The key idea is a FAIR TEST: only the type of "
    "nutrient is changed and everything else is kept the same. Award at least 1 mark if the pupil states "
    "this principle even if the practical detail is thin."),
   ("(b)", ["The height of the plants in each bed, measured at the same time.",
            "The colour of the leaves (dark green or pale yellow-green).",
            "The number of leaves, or how big the stems are.",
            "How quickly the plants flower or start to fruit.",
            "The number or the mass of the crop harvested from each bed.",
            "How much water each bed needed."],
    "1 mark each for any TWO sensible observations (2 marks). Accept any observation that can be "
    "compared between the beds. Do NOT award a mark for 'which one is better' without saying what was "
    "observed."),
 ],
}


# --------------------------------------------- derive summary statistics
def topic_totals():
    m = {k: 0 for k in TOPIC}
    it = {k: 0 for k in TOPIC}
    for q in MCQ:
        m[q[3]] += 1
        it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk
            it[key] += 1
    return m, it


def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}
    b = {k: 0 for k in order}
    for q in MCQ:
        a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            b[cog] += mk
    return order, a, b


def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ:
        d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            d[diff] += mk
    return d
