# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "/home/user")
from build_climate import *

from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT

doc = Document()
sec = doc.sections[0]
sec.left_margin = Inches(0.7); sec.right_margin = Inches(0.7)
sec.top_margin = Inches(0.7); sec.bottom_margin = Inches(0.6)

st = doc.styles["Normal"]; st.font.name = "Calibri"; st.font.size = Pt(11)


def set_font(run, size=11, bold=False, italic=False, mono=False, color=None):
    run.font.size = Pt(size); run.bold = bold; run.italic = italic
    run.font.name = "Consolas" if mono else "Calibri"
    if color: run.font.color.rgb = color
    return run


def para(text="", size=11, bold=False, italic=False, align=None, mono=False,
         space_before=0, space_after=4, color=None):
    p = doc.add_paragraph()
    if align == "c": p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    elif align == "j": p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p.paragraph_format.space_before = Pt(space_before)
    p.paragraph_format.space_after = Pt(space_after)
    if text: set_font(p.add_run(text), size, bold, italic, mono, color)
    return p


def rule():
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(6); p.paragraph_format.space_before = Pt(2)
    set_font(p.add_run("_" * 78), 9, color=RGBColor(0x99, 0x99, 0x99))


def add_table(headers, rows, widths=None, size=9, head_size=9):
    t = doc.add_table(rows=1, cols=len(headers)); t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, h in enumerate(headers):
        c = t.rows[0].cells[i]; c.text = ""
        p = c.paragraphs[0]; p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_font(p.add_run(str(h)), head_size, bold=True)
    for row in rows:
        cells = t.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = ""
            p = cells[i].paragraphs[0]; p.paragraph_format.space_after = Pt(1)
            set_font(p.add_run(str(v)), size)
    if widths:
        for r_ in t.rows:
            for i, w in enumerate(widths): r_.cells[i].width = Inches(w)
    return t


def draw_diagram(lines, caption):
    t = doc.add_table(rows=2, cols=1); t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = t.rows[0].cells[0]
    for k, line in enumerate(lines):
        p = cell.paragraphs[0] if k == 0 else cell.add_paragraph()
        p.paragraph_format.space_after = Pt(0); p.paragraph_format.space_before = Pt(0)
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_font(p.add_run(line), 10, mono=True)
    c2 = t.rows[1].cells[0].paragraphs[0]
    c2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_font(c2.add_run(caption), 9, italic=True)
    t.rows[0].cells[0].width = Inches(6.6)
    t.rows[1].cells[0].width = Inches(6.6)


# ============================================================= TITLE BLOCK
para(SCHOOL, size=15, bold=True, align="c", space_after=2)
para(SUBJECT, size=13, bold=True, align="c", space_after=2)
para(EXAM, size=12, bold=True, align="c", space_after=2)
para(YEAR, size=10, italic=True, align="c", space_after=8)

info = doc.add_table(rows=1, cols=3); info.style = "Table Grid"
info.alignment = WD_TABLE_ALIGNMENT.CENTER
for i, v in enumerate([f"Class: {CLASS}", f"Time: {TIME}", f"Total Marks: {MARKS}"]):
    c = info.rows[0].cells[i]; c.text = ""
    set_font(c.paragraphs[0].add_run(v), 10, bold=True)
para("", space_after=6)

para("INSTRUCTIONS", size=11, bold=True, space_after=3)
for txt in [
    "1. Write your name and class clearly in the spaces provided on your answer sheet.",
    "2. This paper has TWO sections: Section A and Section B.",
    "3. Answer ALL the questions in both sections.",
    "4. Section A has 40 multiple-choice questions. Each question carries 1 mark. Choose the best answer "
    "(A, B, C or D) and record it on the answer sheet provided.",
    "5. Section B has 7 theory questions totalling 60 marks. Write your answers clearly and neatly in your "
    "answer booklet. Draw and label diagrams or tables where you are asked to.",
    "6. Read every question carefully before you answer it.",
    "7. Do not use correction fluid. Cancel any mistake neatly with a single line.",
    "8. Hand in your answer sheet and your answer booklet at the end of the examination.",
]:
    para(txt, size=10.5, space_after=2)
rule()

# =============================================================== SECTION A
para("SECTION A - OBJECTIVE TEST (40 marks)", size=12, bold=True, align="c", space_after=2)
para("Answer ALL questions. Each question carries 1 mark. Choose the BEST answer and write its letter "
     "(A, B, C or D) against the question number on your answer sheet.",
     size=10, italic=True, align="c", space_after=8)

for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(1); p.paragraph_format.space_before = Pt(4)
    set_font(p.add_run(f"{i}. {q}"), 10.5)
    for j, o in enumerate(opts):
        p2 = doc.add_paragraph()
        p2.paragraph_format.left_indent = Inches(0.28)
        p2.paragraph_format.space_after = Pt(0); p2.paragraph_format.space_before = Pt(0)
        set_font(p2.add_run(f"{'ABCD'[j]}. {o}"), 10.5)

doc.add_page_break()

# =============================================================== SECTION B
para("SECTION B - THEORY (60 marks)", size=12, bold=True, align="c", space_after=2)
para("Answer ALL questions. Write your answers in your answer booklet. The marks for each question are "
     "shown in brackets.", size=10, italic=True, align="c", space_after=8)

for qb in SECTION_B:
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(8); p.paragraph_format.space_after = Pt(2)
    set_font(p.add_run(f"Question {qb['num']}"), 11, bold=True)
    set_font(p.add_run(f"  [{qb['total']} marks]"), 10, bold=True, italic=True)
    para(qb["stem"], size=10.5, space_after=4)
    if qb.get("table") == "green":
        add_table(GREEN_HEADERS, GREEN_ROWS, widths=[1.9, 1.5, 2.6], size=8.5, head_size=8.5)
        para("Table 1: Human activities that add greenhouse gases to the air", size=9,
             italic=True, align="c", space_after=6)
        para("", space_after=2)
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Inches(0.25)
        p.paragraph_format.space_after = Pt(3); p.paragraph_format.space_before = Pt(2)
        set_font(p.add_run(f"{lab} {text}  "), 10.5)
        set_font(p.add_run(f"[{mk} mark{'s' if mk > 1 else ''}]"), 10, bold=True)

doc.add_page_break()

# ============================================================== ANSWER KEY
para("ANSWER KEY", size=13, bold=True, align="c", space_after=6)
para("SECTION A - OBJECTIVE TEST", size=11, bold=True, space_after=4)
rows = [[i, ans, TOPIC[tp], cog] for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1)]
add_table(["Question", "Answer", "Curriculum Area (Topic)", "Cognitive Level"],
          rows, widths=[0.8, 0.7, 3.6, 1.5], size=9)
counts = {L: sum(1 for q in MCQ if q[2] == L) for L in "ABCD"}
para("", space_after=4)
para("Correct-answer distribution: " + ", ".join(f"{L} = {counts[L]}" for L in "ABCD") + " (40 items).",
     size=9, italic=True)

para("", space_after=8)
para("SECTION B - THEORY (summary answers; see the Marking Scheme for full detail)",
     size=11, bold=True, space_after=4)
sba = [
 ("1 (a)", "Any four: the sun or solar energy; the wind; moving water or water behind a dam; biogas from animal dung and food waste; crops and crop waste grown again each season; the heat inside the earth.", "19.1", "Remember"),
 ("1 (b)", "A renewable source is one that is replaced naturally as fast as people use it, so it never runs out. It is also a source that can go on being used without spoiling the air, the land or the climate for people in the future.", "19.1", "Understand"),
 ("1 (c)", "Any two: fewer trees are cut down, so the woodland around the village is saved; the goat waste is used instead of being left to rot; the gas burns without smoke, so the kitchen and the family's lungs stay cleaner; the slurry left over is a good manure for the farm; the family spends less on charcoal or firewood; the gas is free once the digester is built.", "19.1", "Understand"),
 ("2 (a)", "Any two: it is made from trees, and trees take many years to grow back; making it destroys the forest around the village; the wood is being used faster than it can be replaced; burning it gives out smoke and carbon dioxide.", "19.1", "Understand"),
 ("2 (b)", "Any three: the sun, using a solar cooker or solar panels; biogas from the goat pen and the kitchen waste; LPG; an improved cookstove, which cuts the wood used very sharply; wind or water power if the village has them.", "19.1", "Understand"),
 ("2 (c)", "Accept any one real difficulty, explained. The digester or the cooker costs money to buy or build. A biogas digester needs dung and water every day, and a family with no animals has none. A solar cooker works only when the sun is out, so it cannot cook the evening meal or work in the rainy season. LPG cylinders must be refilled, and the dealer may be far away. Nobody in the family may know how to look after the new equipment.", "19.1", "Apply"),
 ("3 (a)", "Any two: carbon dioxide, methane, nitrous oxide, water vapour.", "19.2", "Remember"),
 ("3 (b)", "Heat from the sun reaches the earth and warms the ground. The warm ground gives the heat back out again as infrared radiation. Greenhouse gases in the air let the sun's heat pass down but they absorb much of the heat going back up, and send some of it back towards the ground instead of letting it escape into space. So the heat is held near the surface, and the air near the ground stays warmer than it would otherwise be.", "19.2", "Understand"),
 ("3 (c)", "HELPFUL: without any greenhouse gases the earth would be far too cold for living things, so the natural greenhouse effect keeps the planet warm enough to live on. HARMFUL: people are now adding far more of these gases - by burning fuel, cutting down the forest and keeping cattle - so too much heat is being trapped and the earth is warming too fast. That extra warming brings floods at the coast, unreliable rain, crop failure and hunger.", "19.2", "Understand"),
 ("4 (i)", "Carbon dioxide.", "19.2", "Understand"),
 ("4 (ii)", "Cutting down and burning the forest. Also accept bush burning, or clearing land for farming by burning.", "19.2", "Understand"),
 ("4 (iii)", "Methane.", "19.2", "Understand"),
 ("4 (iv)", "Walk, ride a bicycle, use a tro-tro, or share transport instead of driving alone. Also accept: use the generator less, keep the engine serviced, or switch to solar power instead of a generator.", "19.2", "Understand"),
 ("5 (a)", "Any three: fit solar panels on the roof; use a solar water heater; cook with an improved cookstove or LPG instead of firewood; install a biogas digester for the dining-hall waste; use LED bulbs instead of filament bulbs; use a wind pump to draw water; switch off lights, fans and computers when they are not needed; insulate the roof; plant trees round the compound for shade.", "19.3", "Remember"),
 ("5 (b)", "Accept any two correctly explained. Solar panels: materials in the panel take in light energy from the sun and change it straight into electrical energy, with nothing burnt and no smoke. Improved cookstove: a wall round the fire keeps the heat in and sends it up to the pot, and the controlled air lets the wood burn more completely. LED bulb: it gives out light without first getting hot, so far less electricity is wasted as heat. Biogas digester: bacteria rot the waste without air and give off methane, which burns as a fuel.", "19.3", "Understand"),
 ("5 (c)", "Accept any sensible check: read the electricity meter before and after and compare the bills; count how many bags of firewood the kitchen buys each term and compare with last term; keep a daily record of how long the lights are on; check that the LED bulbs are still working after a term.", "19.3", "Apply"),
 ("6 (a)", "A solar dryer is a closed box or cabinet, often with a clear cover, that lets the sun's heat in and keeps it there, so the air inside gets hotter than the air outside and the water in the fish evaporates faster. Because the fish is inside a covered box, it is protected from dust, flies and sudden rain, so much less of it is spoiled. The fish dries evenly and more quickly, keeps its quality, and so fetches a better price at the market.", "19.3", "Apply"),
 ("6 (b)", "The whole community benefits, not only she does. Less fish is spoiled, so more food reaches the market and families nearby have fish to buy; good dried fish travels further, so it can be sold in other towns and brings money into the town; because the fish keeps, it can be eaten in the lean season when the catch is poor; and less spoiled fish is thrown away, so there is less waste and fewer flies breeding near the market.", "19.3", "Evaluate"),
 ("7 (a)", "Any three: what the clinic actually needs the energy for - light at night, a refrigerator for vaccines, or power for a small machine; how much sunshine, wind or flowing water the village has; what materials can be found nearby and what must be bought; how much money is available; whether anyone in the village can repair the equipment; where the project would be safe from damage and theft.", "19.4", "Understand"),
 ("7 (b)", "Accept any sensible project. For example, a solar system for the clinic: mount solar panels on the clinic roof facing the sun where no tree shades them; fix a frame, a charge controller, a battery and wiring; connect LED lamps inside and a small refrigerator for vaccines; test each lamp and the refrigerator; label the switches. MATERIALS: solar panels, a battery, a charge controller, cable, switches, LED lamps, a frame and fixings. STEPS: survey the roof, collect the parts, fit the frame, mount the panels, wire the controller and battery, run the cable inside, fit the lamps, test, and hand over with instructions.", "19.4", "Create"),
 ("7 (c)", "KNOWING IT WORKS: check that the clinic has light at night and that the refrigerator keeps vaccines cold; read a meter or keep a daily record for a few weeks; compare the clinic's bills or its kerosene use with what it was before. KEEPING IT RUNNING: name a person at the clinic and one pupil or teacher to check it; clean the panels; keep a few spare parts and the number of someone who can repair it; fix a card of instructions near the switch; show the next class how it works.", "19.4", "Apply"),
]
add_table(["Question", "Expected Answer", "Curriculum Area", "Cognitive Level"],
          [list(r) for r in sba], widths=[0.8, 4.2, 1.2, 1.2], size=9)

doc.add_page_break()

# =========================================================== MARKING SCHEME
para("MARKING SCHEME - SECTION B (60 marks)", size=13, bold=True, align="c", space_after=4)
para("General rules: (1) Accept any other correct and relevant answer. (2) Award marks for correct points, "
     "not for repeating the question. (3) For procedures, award method marks. (4) Do not deduct marks for "
     "spelling unless the meaning is changed. (5) Where a candidate gives more answers than are asked for, "
     "mark only the first ones up to the number required.",
     size=9.5, italic=True, space_after=8)

for qb in SECTION_B:
    n = qb["num"]
    para(f"Question {n}  ({qb['total']} marks)", size=11, bold=True, space_before=8, space_after=3)
    for (lab, points, note) in MARKING[n]:
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(2)
        set_font(p.add_run(f"{lab} "), 10.5, bold=True)
        mkv = [p_[2] for p_ in qb["parts"] if p_[0] == lab]
        if mkv: set_font(p.add_run(f"[{mkv[0]} mark{'s' if mkv[0] > 1 else ''}]"), 10, bold=True)
        for pt in points:
            pp = doc.add_paragraph()
            pp.paragraph_format.left_indent = Inches(0.35); pp.paragraph_format.space_after = Pt(1)
            set_font(pp.add_run("- " + pt), 10.5)
        pp = doc.add_paragraph()
        pp.paragraph_format.left_indent = Inches(0.35); pp.paragraph_format.space_after = Pt(6)
        set_font(pp.add_run("Marking note: " + note), 9.5, italic=True)

doc.add_page_break()

# ================================================================ BLUEPRINT
para("CURRICULUM ASSESSMENT BLUEPRINT", size=13, bold=True, align="c", space_after=3)
para(f"Strand: {STRAND}   |   Sub-strand: {SUBSTRAND}   |   Class: {CLASS}",
     size=10, italic=True, align="c", space_after=3)
para(f"Content Standard: {CS} - {CS_TEXT}", size=9, italic=True, align="c", space_after=3)
para("Source: NaCCA Science Common Core Programme Curriculum (B7/JHS1-B9/JHS3), September 2020, "
     "Strand 5: Humans and the Environment, Sub-strand 4: Climate Change and Green "
     "Economy (topics 19.1-19.4), p. 48. Indicators are quoted, not invented.",
     size=9, italic=True, space_after=8)

hdr = ["Qn", "Sub-strand", "Content Standard", "Indicator (NaCCA) - Indicator Text", "Topic / Content",
       "Cognitive Level", "Marks"]

rows = [[f"A{i}", SUBSTRAND, CS_BY_TOPIC[tp], f"{IND[tp]} - {IND_TEXT[tp]}", TOPIC[tp], cog, 1]
        for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1)]
add_table(hdr, rows, widths=[0.35, 0.75, 0.75, 1.75, 1.4, 0.8, 0.35], size=7, head_size=7.5)

para("", space_after=8)
rows = []
for qb in SECTION_B:
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        key = tp if tp in TOPIC else tp.split(",")[0].strip()
        rows.append([f"B{qb['num']}{lab.strip('()')}", SUBSTRAND, CS_BY_TOPIC[key],
                     f"{IND[key]} - {IND_TEXT[key]}", TOPIC[key], cog, mk])
add_table(hdr, rows, widths=[0.35, 0.75, 0.75, 1.75, 1.4, 0.8, 0.35], size=7, head_size=7.5)

doc.add_page_break()

# ----------------------------------------------------------------- helpers
def topic_totals():
    m = {k: 0 for k in TOPIC}; it = {k: 0 for k in TOPIC}
    for q in MCQ:
        m[q[3]] += 1; it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk; it[key] += 1
    return m, it

def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}; b = {k: 0 for k in order}
    for q in MCQ: a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: b[cog] += mk
    return order, a, b

def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ: d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: d[diff] += mk
    return d

m, it = topic_totals(); diff = difficulty_totals(); order, ca, cb = cognitive_by_section()

para("SUMMARY 1 - COVERAGE BY CURRICULUM AREA (TOPIC)", size=12, bold=True, space_after=4)
rows = [[TOPIC[k], it[k], m[k], f"{(m[k]/100)*100:.1f}%", CC[k]] for k in TOPIC]
rows.append(["TOTAL", sum(it.values()), sum(m.values()), "100%", "-"])
add_table(["Topic / Content Area", "No. of Items", "Marks", "% of Total Marks", "Core Competencies"],
          rows, widths=[2.7, 0.8, 0.6, 1.0, 1.1], size=8.5)
para("CC = Communication and Collaboration; CP = Critical Thinking and Problem Solving; "
     "DL = Digital Literacy; CI = Creativity and Innovation.", size=8.5, italic=True, space_after=2)

para("", space_after=8)
para("SUMMARY 2 - COGNITIVE-LEVEL DISTRIBUTION (Bloom's Taxonomy)", size=12, bold=True, space_after=4)
rows = []
for lv in order:
    tot = ca[lv] + cb[lv]
    rows.append([lv, ca[lv], cb[lv], tot, f"{(tot/100)*100:.1f}%"])
rows.append(["TOTAL", sum(ca.values()), sum(cb.values()), sum(ca.values()) + sum(cb.values()), "100%"])
add_table(["Cognitive Level", "Section A Marks", "Section B Marks", "Total Marks", "% of Total"],
          rows, widths=[1.6, 1.3, 1.3, 1.1, 1.1], size=9.5)

para("", space_after=8)
para("SUMMARY 3 - DIFFICULTY DISTRIBUTION", size=12, bold=True, space_after=4)
rows = [[k, v, f"{(v/100)*100:.1f}%"] for k, v in diff.items()]
rows.append(["TOTAL", sum(diff.values()), "100%"])
add_table(["Difficulty", "Marks", "% of Total Marks"], rows, widths=[2.0, 1.2, 1.5], size=9.5)
para("Target in the master prompt: approximately 30% easy / 50% moderate / 20% challenging.",
     size=9, italic=True, space_after=2)

para("", space_after=8)
para("SUMMARY 4 - SECTION WEIGHTING", size=12, bold=True, space_after=4)
add_table(["Section", "Question Type", "Items", "Marks", "% of Total"],
          [["A", "Objective (multiple choice)", 40, 40, "40%"],
           ["B", "Theory / constructed response", 21, 60, "60%"],
           ["TOTAL", "-", 61, 100, "100%"]],
          widths=[0.9, 2.4, 0.8, 0.8, 1.0], size=9.5)

doc.add_page_break()

# ===================================================== QUALITY-CONTROL
para("QUALITY-CONTROL SUMMARY", size=13, bold=True, align="c", space_after=4)
para("Carried out against the 14-point validation list in the master prompt before the examination was "
     "finalised.", size=9.5, italic=True, space_after=8)

qc = [
 ("Does every question belong to the supplied curriculum scope?",
  "Yes. All 61 items - 40 objectives and 21 theory sub-questions - trace to Strand 5 (Humans "
  "and the Environment), Sub-Strand 4 (Climate Change and Green Economy), topics 19.1-19.4, "
  "and to the single official B7 indicator B7/JHS1.5.4.1.1 under content standard "
  "B7/JHS1.5.4.1. The three exemplars map to the topics: describing sustainable energy "
  "choices and scientific ideas, analysing the greenhouse effect and how to minimise it, and "
  "designing a local energy project."),
 ("Is the examination appropriate for the stated class?",
  "Yes. The B7 curriculum requires learners to search for information on ways sustainable "
  "energy choices and scientific ideas are used to protect the environment; to describe how "
  "people use them; to analyse greenhouse effects and show how they can be minimised; and to "
  "design a project showing how energy can be locally sustained through scientific processes. "
  "Nothing beyond that is tested."),
 ("Are the questions genuinely BECE-style?",
  "Yes: Section A is 40 four-option objectives worth 1 mark each, and Section B is structured "
  "theory with sub-questions carrying printed mark allocations. There is a three-column "
  "completion table, several 'name', 'state' and 'explain' items, and open tasks that require "
  "application, analysis, evaluation and design."),
 ("Are there enough application and reasoning questions?",
  "Yes. 34 of 100 marks (34%) are at Apply level or above (Apply 22, Analyse 4, Evaluate 5, "
  "Create 3). Create appears in Question 7(b), where pupils must design a clinic energy "
  "project; Analyse in Questions 8, 17 and 19 of Section A and in Question 3(c); and Evaluate "
  "in Question 6(b), where they must judge whether a whole community benefits from a solar "
  "dryer or only the fishmonger."),
 ("Are the MCQ distractors plausible?",
  "Yes. Distractors are drawn from the same content family as the key: a real source of energy "
  "that is not renewable (A2, A5, A9), a real gas in the air that is not a greenhouse gas "
  "(A11), a real description that explains the wrong thing (A3, A6, A38), a genuine activity "
  "that would not help (A18), and a real project step that is not the first one (A31) or not "
  "the best one (A39)."),
 ("Is there only one best answer for each MCQ?",
  "Yes. Every item was reviewed for a single defensible key, and each option list was checked "
  "so that the declared key sits on the correct answer. Special care was taken with A15, where "
  "three options are things that happen when a forest is cleared but only one explains the "
  "rise in carbon dioxide; with A25, where three are true of drying cassava but only one "
  "follows from using a solar dryer; and with A39, where three are things a group might really "
  "do but only one shows the project works."),
 ("Are the marks internally consistent?",
  "Yes. Section A = 40 items x 1 mark = 40. Section B = 9 + 8 + 9 + 8 + 9 + 8 + 9 = 60. "
  "Each Section B sub-question's printed marks match its marking-scheme allocation, and every "
  "N-mark sub-question asks for N things."),
 ("Does the total add up correctly?",
  "Yes: 40 + 60 = 100 marks, matching the stated total on the front page."),
 ("Are the answers in the answer key correct?",
  "Yes. All 40 objective keys and all 21 Section B answers were verified against the marking "
  "scheme. The science was checked item by item: biogas is made when waste rots WITHOUT air, "
  "rotting waste and cattle give out methane rather than carbon dioxide, a dark surface takes "
  "in heat rather than reflecting it, and a solar dryer uses the sun's heat directly while a solar panel changes light into electricity."),
 ("Does the marking scheme match the questions?",
  "Yes. Every Section B sub-question has an expected-answer list and a marking note covering "
  "partial credit, acceptable alternatives, common wrong answers and method marks. Question "
  "3(c) gives at most 1 to a pupil who says only that the greenhouse effect is bad; Question "
  "4(iii) does not accept carbon dioxide where the clue points to methane; Question 5(c) gives "
  "0 for 'we will see if it works' with no measurement; Question 6(b) gives 1 for a position "
  "but no more unless the benefit to others is argued; and Question 7(b) gives 0 for any "
  "project that burns charcoal, firewood or diesel."),
 ("Are the questions free from unnecessary ambiguity?",
  "Yes. Open items are anchored with 'name four', 'state two', 'name three', 'give two' and "
  "'explain one' plus the mark allocation. Question 1(a) asks for sources that will not run "
  "out and the note excludes bare 'electricity'; Question 5(b) must be answered on the choices "
  "named in 5(a); Question 2(c) asks for a difficulty the family would really face; and "
  "Question 7(b) requires the project, the materials and the steps, not just a name."),
 ("Are Ghanaian contexts used naturally and accurately?",
  "Yes: a village where one family cooks with firewood and another with gas from a goat pen, "
  "charcoal and the forest around the village, tro-tros and shared transport, a lakeside "
  "fishmonger drying fish on the ground, cassava dried for market, guinea-fowl and goat "
  "keeping, bush burning to clear farmland, flooding at a coastal town, a tro-tro, a clinic "
  "with a vaccine refrigerator, and the lean season when the catch is poor."),
 ("Has any content outside the supplied curriculum been introduced?",
  "No. Every item sits inside topics 19.1-19.4. No detailed chemistry of combustion or "
  "photosynthesis is required, no calculations are set, and no climate policy beyond what a "
  "Basic 7 pupil can observe is tested. The greenhouse effect is treated at the level of 'gases "
  "trap heat', which is what the indicator asks for."),
 ("Are the questions sufficiently varied?",
  "Yes. Item types include naming sources that will not run out, explaining renewability, "
  "giving reasons to switch to biogas, explaining why charcoal is not sustainable, naming "
  "alternatives, explaining a real difficulty of switching, naming greenhouse gases, "
  "explaining how they warm the earth, explaining why the effect is both helpful and harmful, "
  "completing a four-blank greenhouse-gas table, naming school energy choices, explaining the "
  "science behind two of them, planning a check that measures a saving, explaining how a solar "
  "dryer helps a fishmonger, evaluating who benefits from it, deciding what to find out before "
  "designing, and designing, testing and maintaining a clinic energy project."),
]
for i, (q, a) in enumerate(qc, start=1):
    p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(2)
    set_font(p.add_run(f"{i}. {q}"), 10.5, bold=True)
    p2 = doc.add_paragraph()
    p2.paragraph_format.left_indent = Inches(0.3); p2.paragraph_format.space_after = Pt(6)
    set_font(p2.add_run(a), 10)

para("", space_after=8)
para("EXAMINER NOTES (for the teacher, not for candidates)", size=11, bold=True, space_after=4)
for n in [
 "Question 3(c) is the most important item on this paper, because it is where pupils show "
 "whether they have understood the idea at all. Most will have learned that carbon dioxide is "
 "'bad' and will say the greenhouse effect is harmful, which earns 1 of 3. The full answer is "
 "that the effect keeps the earth warm enough to live on and the problem is the EXTRA gas we "
 "are adding. Teach both halves every time.",
 "Question 4(iii) is the blank that catches pupils out. Rotting waste and cattle give out "
 "METHANE, not carbon dioxide, and the table gives them the clue in the 'activity' column. The "
 "note does not accept carbon dioxide there. Drill the two gases separately: burning fuel and "
 "clearing forest give carbon dioxide; rotting waste and cattle give methane.",
 "Question 1(b) and Question 2(a) both press the same point from different sides - what makes "
 "a source renewable, and why charcoal is not one. Pupils will answer 'charcoal is expensive' "
 "or 'charcoal makes smoke', which the note does not accept, because the question is about the "
 "source running out. Push them to 'trees take years to grow back'.",
 "Question 6(b) is deliberately open. The strongest answers say the whole community benefits - "
 "more food reaches the market, less is wasted, fish can be eaten in the lean season, money "
 "comes into the town - while adding that the fishmonger herself gains most directly. A pupil "
 "who argues that only she benefits earns 1 for the position but no more unless the argument "
 "is genuinely developed.",
 "Question 7 is the design task from Exemplar 3, and pupils find it easy to NAME a project and "
 "hard to list materials and give the steps in order. The note caps them at 1 of 3 if the "
 "materials and steps are missing, and gives 0 for anything that burns charcoal, firewood or "
 "diesel - which is a common answer and worth warning them about before the examination.",
 "Question 5(c) asks pupils to CHECK that a change has saved energy, and the mark is on the "
 "comparison - a meter reading or a firewood count before and after. 'We will see if it works' "
 "earns 0. This is the same skill Question 7(c) needs, so the two reinforce each other.",
 "Topic weighting is 27 marks each for 19.1, 19.2 and 19.3, and 19 marks for 19.4. The design "
 "task carries the least in Section B, where it appears only once. If you spent longer on the "
 "project work, move marks towards Question 7.",
 "Three cheap activities that raise marks sharply: (1) put two thermometers in the sun, one "
 "under a clear bowl and one in the open, and read them after ten minutes, which makes the "
 "greenhouse effect visible; (2) leave two equal slices of fish or cassava out, one covered "
 "and one open to the flies and dust, which teaches Question 6; and (3) have each group cost "
 "out one clinic energy project on a single page, which teaches Question 7.",
 "This sub-strand has one content standard and one indicator, so it is a single paper and not "
 "split. The companion papers cover Sub-strand 2 (Human Health) in two parts, Sub-strand 3 "
 "(Science and Industry), and Sub-strand 5 (Understanding the Environment).",
 "This version is a full rebuild. Every question is new, and none is repeated from the earlier "
 "version of this paper, so you can use either as a mock and the other as a second sitting "
 "without pupils seeing the same items twice.",
 "Edit the school name, academic year and examination title on page 1 before printing.",
 "This is an original, teacher-made mock. It is not a reproduction of any WAEC or NaCCA examination "
 "paper.",
]:
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Inches(0.3); p.paragraph_format.space_after = Pt(3)
    set_font(p.add_run("- " + n), 10)

doc.save("/home/user/Basic7_Integrated_Science_Mock_Strand5_ClimateChange.docx")
print("docx written")

print("Section A:", len(MCQ), "items")
print("Section B total:", sum(q["total"] for q in SECTION_B))
print("Topic marks:", m, "sum", sum(m.values()))
print("Difficulty:", diff, "sum", sum(diff.values()))
print("Cognitive A:", ca)
print("Cognitive B:", cb)
print("Answer counts:", counts)
print("Totals:", sum(m.values()), sum(diff.values()),
      sum(ca.values()) + sum(cb.values()))
