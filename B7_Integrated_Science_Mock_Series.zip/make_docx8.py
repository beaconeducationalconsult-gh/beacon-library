# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "/home/user")
from build_solar import *

from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT

doc = Document()
sec = doc.sections[0]
sec.left_margin = Inches(0.7); sec.right_margin = Inches(0.7)
sec.top_margin = Inches(0.7); sec.bottom_margin = Inches(0.6)

st = doc.styles["Normal"]; st.font.name = "Calibri"; st.font.size = Pt(11)


def set_font(run, size=11, bold=False, italic=False, mono=False, color=None):
    run.font.size = Pt(size); run.bold = bold; run.italic = italic
    run.font.name = "Consolas" if mono else "Calibri"
    if color: run.font.color.rgb = color
    return run


def para(text="", size=11, bold=False, italic=False, align=None, mono=False,
         space_before=0, space_after=4, color=None):
    p = doc.add_paragraph()
    if align == "c": p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    elif align == "j": p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p.paragraph_format.space_before = Pt(space_before)
    p.paragraph_format.space_after = Pt(space_after)
    if text: set_font(p.add_run(text), size, bold, italic, mono, color)
    return p


def rule():
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(6); p.paragraph_format.space_before = Pt(2)
    set_font(p.add_run("_" * 78), 9, color=RGBColor(0x99, 0x99, 0x99))


def add_table(headers, rows, widths=None, size=9, head_size=9):
    t = doc.add_table(rows=1, cols=len(headers)); t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, h in enumerate(headers):
        c = t.rows[0].cells[i]; c.text = ""
        p = c.paragraphs[0]; p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_font(p.add_run(str(h)), head_size, bold=True)
    for row in rows:
        cells = t.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = ""
            p = cells[i].paragraphs[0]; p.paragraph_format.space_after = Pt(1)
            set_font(p.add_run(str(v)), size)
    if widths:
        for r_ in t.rows:
            for i, w in enumerate(widths): r_.cells[i].width = Inches(w)
    return t


def draw_diagram(lines, caption):
    t = doc.add_table(rows=2, cols=1); t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = t.rows[0].cells[0]
    for k, line in enumerate(lines):
        p = cell.paragraphs[0] if k == 0 else cell.add_paragraph()
        p.paragraph_format.space_after = Pt(0); p.paragraph_format.space_before = Pt(0)
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_font(p.add_run(line), 10, mono=True)
    c2 = t.rows[1].cells[0].paragraphs[0]
    c2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_font(c2.add_run(caption), 9, italic=True)
    t.rows[0].cells[0].width = Inches(6.6)
    t.rows[1].cells[0].width = Inches(6.6)


# ============================================================= TITLE BLOCK
para(SCHOOL, size=15, bold=True, align="c", space_after=2)
para(SUBJECT, size=13, bold=True, align="c", space_after=2)
para(EXAM, size=12, bold=True, align="c", space_after=2)
para(YEAR, size=10, italic=True, align="c", space_after=8)

info = doc.add_table(rows=1, cols=3); info.style = "Table Grid"
info.alignment = WD_TABLE_ALIGNMENT.CENTER
for i, v in enumerate([f"Class: {CLASS}", f"Time: {TIME}", f"Total Marks: {MARKS}"]):
    c = info.rows[0].cells[i]; c.text = ""
    set_font(c.paragraphs[0].add_run(v), 10, bold=True)
para("", space_after=6)

para("INSTRUCTIONS", size=11, bold=True, space_after=3)
for txt in [
    "1. Write your name and class clearly in the spaces provided on your answer sheet.",
    "2. This paper has TWO sections: Section A and Section B.",
    "3. Answer ALL the questions in both sections.",
    "4. Section A has 40 multiple-choice questions. Each question carries 1 mark. Choose the best answer "
    "(A, B, C or D) and record it on the answer sheet provided.",
    "5. Section B has 7 theory questions totalling 60 marks. Write your answers clearly and neatly in your "
    "answer booklet. Draw and label diagrams or tables where you are asked to.",
    "6. Read every question carefully before you answer it.",
    "7. Do not use correction fluid. Cancel any mistake neatly with a single line.",
    "8. Hand in your answer sheet and your answer booklet at the end of the examination.",
]:
    para(txt, size=10.5, space_after=2)
rule()

# =============================================================== SECTION A
para("SECTION A - OBJECTIVE TEST (40 marks)", size=12, bold=True, align="c", space_after=2)
para("Answer ALL questions. Each question carries 1 mark. Choose the BEST answer and write its letter "
     "(A, B, C or D) against the question number on your answer sheet.",
     size=10, italic=True, align="c", space_after=8)

for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(1); p.paragraph_format.space_before = Pt(4)
    set_font(p.add_run(f"{i}. {q}"), 10.5)
    for j, o in enumerate(opts):
        p2 = doc.add_paragraph()
        p2.paragraph_format.left_indent = Inches(0.28)
        p2.paragraph_format.space_after = Pt(0); p2.paragraph_format.space_before = Pt(0)
        set_font(p2.add_run(f"{'ABCD'[j]}. {o}"), 10.5)

doc.add_page_break()

# =============================================================== SECTION B
para("SECTION B - THEORY (60 marks)", size=12, bold=True, align="c", space_after=2)
para("Answer ALL questions. Write your answers in your answer booklet. The marks for each question are "
     "shown in brackets.", size=10, italic=True, align="c", space_after=8)

for qb in SECTION_B:
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(8); p.paragraph_format.space_after = Pt(2)
    set_font(p.add_run(f"Question {qb['num']}"), 11, bold=True)
    set_font(p.add_run(f"  [{qb['total']} marks]"), 10, bold=True, italic=True)
    para(qb["stem"], size=10.5, space_after=4)
    if qb.get("diagram"):
        draw_diagram(INNER_PLANETS, "Fig. 1: The inner planets (not drawn to scale)")
        para("", space_after=2)
    if qb.get("table") == "properties":
        add_table(PROP_HEADERS, PROP_ROWS, widths=[1.5, 1.5, 3.0], size=9, head_size=9)
        para("Table 1: Properties of the inner planets", size=9, italic=True, align="c",
             space_after=6)
        para("", space_after=2)
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Inches(0.25)
        p.paragraph_format.space_after = Pt(3); p.paragraph_format.space_before = Pt(2)
        set_font(p.add_run(f"{lab} {text}  "), 10.5)
        set_font(p.add_run(f"[{mk} mark{'s' if mk > 1 else ''}]"), 10, bold=True)

doc.add_page_break()

# ============================================================== ANSWER KEY
para("ANSWER KEY", size=13, bold=True, align="c", space_after=6)
para("SECTION A - OBJECTIVE TEST", size=11, bold=True, space_after=4)
rows = [[i, ans, TOPIC[tp], cog] for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1)]
add_table(["Question", "Answer", "Curriculum Area (Topic)", "Cognitive Level"],
          rows, widths=[0.8, 0.7, 3.6, 1.5], size=9)
counts = {L: sum(1 for q in MCQ if q[2] == L) for L in "ABCD"}
para("", space_after=4)
para("Correct-answer distribution: " + ", ".join(f"{L} = {counts[L]}" for L in "ABCD") + " (30 items).",
     size=9, italic=True)

para("", space_after=8)
para("SECTION B - THEORY (summary answers; see the Marking Scheme for full detail)",
     size=11, bold=True, space_after=4)
sba = [
 ("1 (a)", "The Sun together with all the bodies that move around it: the eight planets and their "
  "moons, dwarf planets, asteroids, comets and meteoroids, all held by the Sun's gravity.", "8.1",
  "Understand"),
 ("1 (b)", "Mercury, Venus, Earth, Mars (in that order from the Sun).", "8.1", "Remember"),
 ("1 (c)", "It gives out the light and heat the planets receive, and its gravity holds everything in "
  "its path; without it there would be no solar system.", "8.1", "Understand"),
 ("2 (a)", "A galaxy is a very large group of stars, gas and dust held together by gravity. Our "
  "galaxy is the Milky Way.", "8.2", "Understand"),
 ("2 (b)", "The Milky Way is the spiral galaxy in which the Sun and the solar system are found; it "
  "contains many millions of stars and is only one of many galaxies.", "8.2", "Understand"),
 ("2 (c)", "The Sun is by far the nearest star to the Earth, so we get almost all our light and heat "
  "from it; the other stars are too far away to warm us, and the Sun's gravity keeps the Earth in "
  "its path.", "8.2", "Understand"),
 ("3 (a)", "1 = Mercury; 2 = Venus; 3 = Earth; 4 = Mars.", "8.3", "Remember"),
 ("3 (b)", "Any three of: they are small; they have a solid rocky surface (terrestrial); they are the "
  "four nearest the Sun and so are warmer; they have few moons or none; they have no rings.", "8.3",
  "Understand"),
 ("3 (c)", "Being an inner planet depends on how near the Sun a planet is, not on its size. Jupiter "
  "and Saturn are far from the Sun, so they belong to the OUTER planets (the gas giants).", "8.3",
  "Apply"),
 ("4 (a)", "(i) the smallest planet, nearest the Sun, shortest year (about 88 days); (ii) the hottest "
  "planet, about the same size as the Earth, thick atmosphere of carbon dioxide; (iii) 1; (iv) 2.",
  "8.4", "Understand"),
 ("4 (b)", "Smallest: Mercury. Largest: Earth.", "8.4", "Remember"),
 ("4 (c)", "Venus has a thick atmosphere of carbon dioxide which traps the Sun's heat and will not "
  "let it escape; Mercury has almost no atmosphere, so its heat escapes back into space.", "8.4",
  "Analyse"),
 ("5 (a)", "Mercury moves round the Sun along its own orbit; it is the nearest planet, so its path is "
  "the shortest and it moves fastest; it has the shortest year, about 88 Earth days.", "8.5",
  "Understand"),
 ("5 (b)", "Venus moves round the Sun along its own orbit, outside that of Mercury; it is the second "
  "planet from the Sun and takes about 225 Earth days to go once round it.", "8.5", "Understand"),
 ("5 (c)", "Mercury is nearer the Sun, so the Sun's pull on it is stronger and it moves faster; its "
  "path is also shorter. Venus is further away, so the pull is weaker and its path is longer.", "8.5",
  "Analyse"),
 ("6 (a)", "The path a planet follows as it moves around the Sun.", "8.6", "Understand"),
 ("6 (b)", "An oval path - a flattened circle, not a perfect circle - with two foci instead of one "
  "centre.", "8.6", "Understand"),
 ("6 (c)", "Because the Sun is off to one side of the ellipse, the planet is nearer the Sun at one "
  "part of the path and further away at another, so the distance changes during one orbit. The Sun "
  "lies at one focus of the ellipse, not at its centre.", "8.6", "Analyse"),
 ("7 (a)", "Decide what the model will show; gather materials such as balls of clay or paper, string, "
  "wire, cardboard and paint; make the Sun the biggest ball; make and label the eight planets in the "
  "right order from the Sun; hang or fix them on a frame; show each path as an ellipse.", "8.1",
  "Create"),
 ("7 (b)", "Any two of: a model shows the order and relative sizes in a way a drawing cannot; the "
  "class can handle it and walk round it; building it together makes pupils explain it to one "
  "another; it shows the shapes of the paths. One thing it must show: the planets in the correct "
  "order from the Sun (or the paths as ellipses, or the Sun at the centre).", "8.6", "Evaluate"),
]
add_table(["Question", "Expected Answer", "Curriculum Area", "Cognitive Level"],
          [list(r) for r in sba], widths=[0.8, 4.2, 1.2, 1.2], size=9)

doc.add_page_break()

# =========================================================== MARKING SCHEME
para("MARKING SCHEME - SECTION B (60 marks)", size=13, bold=True, align="c", space_after=4)
para("General rules: (1) Accept any other correct and relevant answer. (2) Award marks for correct points, "
     "not for repeating the question. (3) For procedures, award method marks. (4) Do not deduct marks for "
     "spelling unless the meaning is changed. (5) Where a candidate gives more answers than are asked for, "
     "mark only the first ones up to the number required.",
     size=9.5, italic=True, space_after=8)

for qb in SECTION_B:
    n = qb["num"]
    para(f"Question {n}  ({qb['total']} marks)", size=11, bold=True, space_before=8, space_after=3)
    for (lab, points, note) in MARKING[n]:
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(2)
        set_font(p.add_run(f"{lab} "), 10.5, bold=True)
        mkv = [p_[2] for p_ in qb["parts"] if p_[0] == lab]
        if mkv: set_font(p.add_run(f"[{mkv[0]} mark{'s' if mkv[0] > 1 else ''}]"), 10, bold=True)
        for pt in points:
            pp = doc.add_paragraph()
            pp.paragraph_format.left_indent = Inches(0.35); pp.paragraph_format.space_after = Pt(1)
            set_font(pp.add_run("- " + pt), 10.5)
        pp = doc.add_paragraph()
        pp.paragraph_format.left_indent = Inches(0.35); pp.paragraph_format.space_after = Pt(6)
        set_font(pp.add_run("Marking note: " + note), 9.5, italic=True)

doc.add_page_break()

# ================================================================ BLUEPRINT
para("CURRICULUM ASSESSMENT BLUEPRINT", size=13, bold=True, align="c", space_after=3)
para(f"Strand: {STRAND}   |   Sub-strand: {SUBSTRAND}   |   Class: {CLASS}",
     size=10, italic=True, align="c", space_after=3)
para(f"Content Standard: {CS} - {CS_TEXT}", size=9, italic=True, align="c", space_after=3)
para("Source: NaCCA Science Common Core Programme Curriculum (B7/JHS1-B9/JHS3), September 2020, "
     "Strand 3: Systems, Sub-strand 2: The Solar System, pp. 19-20. Indicators are quoted, not "
     "invented.",
     size=9, italic=True, space_after=8)

hdr = ["Qn", "Sub-strand", "Content Standard", "Indicator (NaCCA) - Indicator Text", "Topic / Content",
       "Cognitive Level", "Marks"]

rows = [[f"A{i}", SUBSTRAND, CS_BY_TOPIC[tp], f"{IND[tp]} - {IND_TEXT[tp]}", TOPIC[tp], cog, 1]
        for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1)]
add_table(hdr, rows, widths=[0.35, 0.75, 0.75, 1.75, 1.4, 0.8, 0.35], size=7, head_size=7.5)

para("", space_after=8)
rows = []
for qb in SECTION_B:
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        key = tp if tp in TOPIC else tp.split(",")[0].strip()
        rows.append([f"B{qb['num']}{lab.strip('()')}", SUBSTRAND, CS_BY_TOPIC[key],
                     f"{IND[key]} - {IND_TEXT[key]}", TOPIC[key], cog, mk])
add_table(hdr, rows, widths=[0.35, 0.75, 0.75, 1.75, 1.4, 0.8, 0.35], size=7, head_size=7.5)

doc.add_page_break()

# ----------------------------------------------------------------- helpers
def topic_totals():
    m = {k: 0 for k in TOPIC}; it = {k: 0 for k in TOPIC}
    for q in MCQ:
        m[q[3]] += 1; it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk; it[key] += 1
    return m, it

def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}; b = {k: 0 for k in order}
    for q in MCQ: a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: b[cog] += mk
    return order, a, b

def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ: d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: d[diff] += mk
    return d

m, it = topic_totals(); diff = difficulty_totals(); order, ca, cb = cognitive_by_section()

para("SUMMARY 1 - COVERAGE BY CURRICULUM AREA (TOPIC)", size=12, bold=True, space_after=4)
rows = [[TOPIC[k], it[k], m[k], f"{(m[k]/100)*100:.1f}%", CC[k]] for k in TOPIC]
rows.append(["TOTAL", sum(it.values()), sum(m.values()), "100%", "-"])
add_table(["Topic / Content Area", "No. of Items", "Marks", "% of Total Marks", "Core Competencies"],
          rows, widths=[2.7, 0.8, 0.6, 1.0, 1.1], size=8.5)
para("CC = Communication and Collaboration; CP = Critical Thinking and Problem Solving; "
     "DL = Digital Literacy; CI = Creativity and Innovation.", size=8.5, italic=True, space_after=2)

para("", space_after=8)
para("SUMMARY 2 - COGNITIVE-LEVEL DISTRIBUTION (Bloom's Taxonomy)", size=12, bold=True, space_after=4)
rows = []
for lv in order:
    tot = ca[lv] + cb[lv]
    rows.append([lv, ca[lv], cb[lv], tot, f"{(tot/100)*100:.1f}%"])
rows.append(["TOTAL", sum(ca.values()), sum(cb.values()), sum(ca.values()) + sum(cb.values()), "100%"])
add_table(["Cognitive Level", "Section A Marks", "Section B Marks", "Total Marks", "% of Total"],
          rows, widths=[1.6, 1.3, 1.3, 1.1, 1.1], size=9.5)

para("", space_after=8)
para("SUMMARY 3 - DIFFICULTY DISTRIBUTION", size=12, bold=True, space_after=4)
rows = [[k, v, f"{(v/100)*100:.1f}%"] for k, v in diff.items()]
rows.append(["TOTAL", sum(diff.values()), "100%"])
add_table(["Difficulty", "Marks", "% of Total Marks"], rows, widths=[2.0, 1.2, 1.5], size=9.5)
para("Target in the master prompt: approximately 30% easy / 50% moderate / 20% challenging.",
     size=9, italic=True, space_after=2)

para("", space_after=8)
para("SUMMARY 4 - SECTION WEIGHTING", size=12, bold=True, space_after=4)
add_table(["Section", "Question Type", "Items", "Marks", "% of Total"],
          [["A", "Objective (multiple choice)", 40, 40, "40%"],
           ["B", "Theory / constructed response", 20, 60, "60%"],
           ["TOTAL", "-", 60, 100, "100%"]],
          widths=[0.9, 2.4, 0.8, 0.8, 1.0], size=9.5)

doc.add_page_break()

# ===================================================== QUALITY-CONTROL
para("QUALITY-CONTROL SUMMARY", size=13, bold=True, align="c", space_after=4)
para("Carried out against the 14-point validation list in the master prompt before the examination was "
     "finalised.", size=9.5, italic=True, space_after=8)

qc = [
 ("Does every question belong to the supplied curriculum scope?",
  "Yes. All 46 items trace to Strand 3 (Systems), Sub-Strand 2 (The Solar System), topics 8.1-8.6, "
  "and to the two official B7 indicators (B7/JHS1.3.2.1.1 and B7/JHS1.3.2.1.2). Kepler's laws, "
  "orbital mechanics, star life cycles, telescopes and space travel appear only as distractors, "
  "never as things pupils must answer on."),
 ("Is the examination appropriate for the stated class?",
  "Yes. The B7 curriculum requires learners to identify and describe the inner planets, describe the "
  "galaxy and the Milky Way, describe the elliptical shape of the planets' paths, outline the "
  "properties peculiar to Mercury and Venus, describe their movement around the Sun, and design and "
  "construct a model. No calculation of orbital periods, no distances in kilometres and no physics of "
  "gravity are tested, as these fall outside the B7 indicator."),
 ("Are the questions genuinely BECE-style?",
  "Yes: Section A is 40 four-option objectives worth 1 mark each, and Section B is structured theory "
  "with sub-questions carrying printed mark allocations. A labelled diagram and a completion table "
  "are included, matching the BECE science convention and the indicator's own exemplars, which ask "
  "pupils to identify the inner planets from pictures and to construct a model."),
 ("Are there enough application and reasoning questions?",
  "Yes. 29 of 100 marks (29%) are at Apply level or above (Apply 9, Analyse 11, Evaluate 5, Create 4). "
  "Create appears through the model-construction task in Question 7(a), which is exemplar 3 of "
  "B7/JHS1.3.2.1.1."),
 ("Are the MCQ distractors plausible?",
  "Yes. Distractors are drawn from the same content family as the key: the outer planets (A14, A16), "
  "the wrong order from the Sun (A6), the wrong property for a named planet (A23, A28), and the "
  "common misconception that the nearest planet is the hottest (A22, A23)."),
 ("Is there only one best answer for each MCQ?",
  "Yes. Every item was reviewed for a single defensible key. Special care was taken with A24, where "
  "'gives out its own light' is the property of a star, so the keyed option correctly says Venus "
  "shines because it is bright, not because it is a star."),
 ("Are the marks internally consistent?",
  "Yes. Section A = 40 items x 1 mark = 40. Section B = 8 + 9 + 10 + 8 + 9 + 9 + 7 = 60. "
  "Each Section B sub-question's printed marks match its marking-scheme allocation."),
 ("Does the total add up correctly?",
  "Yes: 40 + 60 = 100 marks, matching the stated total on the front page."),
 ("Are the answers in the answer key correct?",
  "Yes. All 40 objective keys and all 20 Section B answers were verified against the marking scheme."),
 ("Does the marking scheme match the questions?",
  "Yes. Every Section B sub-question has an expected-answer list and a marking note covering partial "
  "credit, acceptable alternatives, common wrong answers and method marks. The diagram key (1-4), the "
  "completion table and the model-construction task have explicit marking grids so they can be marked "
  "consistently across a class."),
 ("Are the questions free from unnecessary ambiguity?",
  "Yes. Open items are anchored with 'state three', 'name two' and the mark allocation. Question 4(a) "
  "numbers every blank, (i) to (iv), so there is no doubt which answer belongs where, and Question "
  "7(b) spells out exactly what is wanted: two reasons plus one thing the model must show."),
 ("Are Ghanaian contexts used naturally and accurately?",
  "Yes: materials a Ghanaian class can actually find - clay, paper, string, wire, cardboard and "
  "paint; group work in class; watching the sky on a clear night away from the city lights; and the "
  "Sun as the source of the light and heat Ghana depends on. Question 7 is set as a real class "
  "project, as the indicator requires."),
 ("Has any content outside the supplied curriculum been introduced?",
  "No. Every item sits inside topics 8.1-8.6. Question 2 is built on the galaxy-and-Milky-Way part of "
  "exemplar 2; Question 6 on the elliptical-path part of the same exemplar; Question 7 on exemplar 3, "
  "the model; Questions 4 and 5 on exemplars 1 and 2 of B7/JHS1.3.2.1.2, which name Mercury and "
  "Venus specifically."),
 ("Are the questions sufficiently varied?",
  "Yes. Item types include definition, ordering, diagram labelling, stating common properties, "
  "comparing inner with outer planets, completing a properties table, explaining a misconception, "
  "describing motion, explaining an elliptical path, and designing and constructing a model."),
]
for i, (q, a) in enumerate(qc, start=1):
    p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(2)
    set_font(p.add_run(f"{i}. {q}"), 10.5, bold=True)
    p2 = doc.add_paragraph()
    p2.paragraph_format.left_indent = Inches(0.3); p2.paragraph_format.space_after = Pt(6)
    set_font(p2.add_run(a), 10)

para("", space_after=8)
para("EXAMINER NOTES (for the teacher, not for candidates)", size=11, bold=True, space_after=4)
for n in [
 "The two indicators name only Mercury and Venus specifically (B7/JHS1.3.2.1.2), so Questions 4 and 5 "
 "are built around those two planets. Earth and Mars are tested only as members of the inner four, "
 "which is what B7/JHS1.3.2.1.1 asks for.",
 "Question 3 is the 'identify the inner planets from a picture' exemplar. The diagram is drawn with "
 "text characters inside a Word table: redraw it with real circles or paste in a printed picture - "
 "the numbering (1-4) is what the questions depend on. Key: 1 Mercury, 2 Venus, 3 Earth, 4 Mars.",
 "Question 4(c) targets the most common misconception in this topic: that the planet nearest the Sun "
 "must be the hottest. The expected answer is the thick carbon-dioxide atmosphere of Venus that traps "
 "heat. Expect many pupils to give the wrong answer here.",
 "Question 7 is the 'design and construct a model' exemplar. Because it is open, award method marks "
 "generously: any sensible step earns credit. Look first for the correct order of the planets, the "
 "Sun at the centre, and materials a real class could find. If your class actually builds the model, "
 "accept what they did as evidence.",
 "Question 6(c) expects only that the Sun is off to one side of the ellipse and that the distance "
 "therefore changes. Do NOT expect the word 'focus' or any statement of Kepler's laws - that is "
 "beyond B7.",
 "Topic 8.1 carries 19 of 100 marks, the highest weighting, because defining the solar system and "
 "building the model are the opening and closing tasks of the indicator. If you want a flatter "
 "spread, move marks from Questions 1 and 7 to Questions 2 and 5.",
 "If you have printed pictures, a chart or a short video of the solar system, use them during "
 "revision: exemplar 1 of B7/JHS1.3.2.1.1 specifically asks pupils to identify the inner planets "
 "using pictures and videos.",
 "Edit the school name, academic year and examination title on page 1 before printing.",
 "This is an original, teacher-made mock. It is not a reproduction of any WAEC or NaCCA examination "
 "paper.",
]:
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Inches(0.3); p.paragraph_format.space_after = Pt(3)
    set_font(p.add_run("- " + n), 10)

doc.save("/home/user/Basic7_Integrated_Science_Mock_Strand3_SolarSystem.docx")
print("docx written")

print("Section A:", len(MCQ), "items")
print("Section B total:", sum(q["total"] for q in SECTION_B))
print("Topic marks:", m, "sum", sum(m.values()))
print("Difficulty:", diff, "sum", sum(diff.values()))
print("Cognitive A:", ca)
print("Cognitive B:", cb)
print("Answer counts:", counts)
print("Totals:", sum(m.values()), sum(diff.values()),
      sum(ca.values()) + sum(cb.values()))
