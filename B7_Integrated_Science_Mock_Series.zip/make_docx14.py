# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "/home/user")
from build_force import *

from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT

doc = Document()
sec = doc.sections[0]
sec.left_margin = Inches(0.7); sec.right_margin = Inches(0.7)
sec.top_margin = Inches(0.7); sec.bottom_margin = Inches(0.6)

st = doc.styles["Normal"]; st.font.name = "Calibri"; st.font.size = Pt(11)


def set_font(run, size=11, bold=False, italic=False, mono=False, color=None):
    run.font.size = Pt(size); run.bold = bold; run.italic = italic
    run.font.name = "Consolas" if mono else "Calibri"
    if color: run.font.color.rgb = color
    return run


def para(text="", size=11, bold=False, italic=False, align=None, mono=False,
         space_before=0, space_after=4, color=None):
    p = doc.add_paragraph()
    if align == "c": p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    elif align == "j": p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p.paragraph_format.space_before = Pt(space_before)
    p.paragraph_format.space_after = Pt(space_after)
    if text: set_font(p.add_run(text), size, bold, italic, mono, color)
    return p


def rule():
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(6); p.paragraph_format.space_before = Pt(2)
    set_font(p.add_run("_" * 78), 9, color=RGBColor(0x99, 0x99, 0x99))


def add_table(headers, rows, widths=None, size=9, head_size=9):
    t = doc.add_table(rows=1, cols=len(headers)); t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, h in enumerate(headers):
        c = t.rows[0].cells[i]; c.text = ""
        p = c.paragraphs[0]; p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_font(p.add_run(str(h)), head_size, bold=True)
    for row in rows:
        cells = t.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = ""
            p = cells[i].paragraphs[0]; p.paragraph_format.space_after = Pt(1)
            set_font(p.add_run(str(v)), size)
    if widths:
        for r_ in t.rows:
            for i, w in enumerate(widths): r_.cells[i].width = Inches(w)
    return t


def draw_diagram(lines, caption):
    t = doc.add_table(rows=2, cols=1); t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = t.rows[0].cells[0]
    for k, line in enumerate(lines):
        p = cell.paragraphs[0] if k == 0 else cell.add_paragraph()
        p.paragraph_format.space_after = Pt(0); p.paragraph_format.space_before = Pt(0)
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_font(p.add_run(line), 10, mono=True)
    c2 = t.rows[1].cells[0].paragraphs[0]
    c2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_font(c2.add_run(caption), 9, italic=True)
    t.rows[0].cells[0].width = Inches(6.6)
    t.rows[1].cells[0].width = Inches(6.6)


# ============================================================= TITLE BLOCK
para(SCHOOL, size=15, bold=True, align="c", space_after=2)
para(SUBJECT, size=13, bold=True, align="c", space_after=2)
para(EXAM, size=12, bold=True, align="c", space_after=2)
para(YEAR, size=10, italic=True, align="c", space_after=8)

info = doc.add_table(rows=1, cols=3); info.style = "Table Grid"
info.alignment = WD_TABLE_ALIGNMENT.CENTER
for i, v in enumerate([f"Class: {CLASS}", f"Time: {TIME}", f"Total Marks: {MARKS}"]):
    c = info.rows[0].cells[i]; c.text = ""
    set_font(c.paragraphs[0].add_run(v), 10, bold=True)
para("", space_after=6)

para("INSTRUCTIONS", size=11, bold=True, space_after=3)
for txt in [
    "1. Write your name and class clearly in the spaces provided on your answer sheet.",
    "2. This paper has TWO sections: Section A and Section B.",
    "3. Answer ALL the questions in both sections.",
    "4. Section A has 40 multiple-choice questions. Each question carries 1 mark. Choose the best answer "
    "(A, B, C or D) and record it on the answer sheet provided.",
    "5. Section B has 7 theory questions totalling 60 marks. Write your answers clearly and neatly in your "
    "answer booklet. Draw and label diagrams or tables where you are asked to.",
    "6. Read every question carefully before you answer it.",
    "7. Do not use correction fluid. Cancel any mistake neatly with a single line.",
    "8. Hand in your answer sheet and your answer booklet at the end of the examination.",
]:
    para(txt, size=10.5, space_after=2)
rule()

# =============================================================== SECTION A
para("SECTION A - OBJECTIVE TEST (40 marks)", size=12, bold=True, align="c", space_after=2)
para("Answer ALL questions. Each question carries 1 mark. Choose the BEST answer and write its letter "
     "(A, B, C or D) against the question number on your answer sheet.",
     size=10, italic=True, align="c", space_after=8)

for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(1); p.paragraph_format.space_before = Pt(4)
    set_font(p.add_run(f"{i}. {q}"), 10.5)
    for j, o in enumerate(opts):
        p2 = doc.add_paragraph()
        p2.paragraph_format.left_indent = Inches(0.28)
        p2.paragraph_format.space_after = Pt(0); p2.paragraph_format.space_before = Pt(0)
        set_font(p2.add_run(f"{'ABCD'[j]}. {o}"), 10.5)

doc.add_page_break()

# =============================================================== SECTION B
para("SECTION B - THEORY (60 marks)", size=12, bold=True, align="c", space_after=2)
para("Answer ALL questions. Write your answers in your answer booklet. The marks for each question are "
     "shown in brackets.", size=10, italic=True, align="c", space_after=8)

for qb in SECTION_B:
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(8); p.paragraph_format.space_after = Pt(2)
    set_font(p.add_run(f"Question {qb['num']}"), 11, bold=True)
    set_font(p.add_run(f"  [{qb['total']} marks]"), 10, bold=True, italic=True)
    para(qb["stem"], size=10.5, space_after=4)
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Inches(0.25)
        p.paragraph_format.space_after = Pt(3); p.paragraph_format.space_before = Pt(2)
        set_font(p.add_run(f"{lab} {text}  "), 10.5)
        set_font(p.add_run(f"[{mk} mark{'s' if mk > 1 else ''}]"), 10, bold=True)

doc.add_page_break()

# ============================================================== ANSWER KEY
para("ANSWER KEY", size=13, bold=True, align="c", space_after=6)
para("SECTION A - OBJECTIVE TEST", size=11, bold=True, space_after=4)
rows = [[i, ans, TOPIC[tp], cog] for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1)]
add_table(["Question", "Answer", "Curriculum Area (Topic)", "Cognitive Level"],
          rows, widths=[0.8, 0.7, 3.6, 1.5], size=9)
counts = {L: sum(1 for q in MCQ if q[2] == L) for L in "ABCD"}
para("", space_after=4)
para("Correct-answer distribution: " + ", ".join(f"{L} = {counts[L]}" for L in "ABCD") + " (30 items).",
     size=9, italic=True)

para("", space_after=8)
para("SECTION B - THEORY (summary answers; see the Marking Scheme for full detail)",
     size=11, bold=True, space_after=4)
sba = [
 ("1 (a)", "A force is a push or a pull on an object; it makes an object start moving, stop, speed up, slow down, change direction or change shape. The SI unit is the newton (N).", "14.1", "Understand"),
 ("1 (b)", "Any three of: it can make a still object move; stop a moving object; speed it up or slow it down; change its direction; change its shape or size.", "14.1", "Understand"),
 ("1 (c)", "The goalkeeper's hands apply a force to the ball in the opposite direction to its motion; the force slows the ball and brings it to a stop, and squashes the ball and the gloves a little.", "14.1", "Apply"),
 ("2 (a)", "Balanced forces are equal in size and opposite in direction, so they cancel out and there is no overall force. Unbalanced forces are not equal and opposite, so there is an overall force in one direction.", "14.2", "Understand"),
 ("2 (b)", "Its motion does not change: if it was at rest it stays at rest, and if it was moving it keeps moving at the same speed in the same direction.", "14.2", "Understand"),
 ("2 (c)", "The box moves towards the boy pushing with 45 N. The forces are not balanced because 60 N is bigger than 45 N, so there is an overall force of 15 N towards the 45 N side.", "14.2", "Apply"),
 ("3 (a)", "Inertia is the tendency of a body to resist a change in its motion - a body at rest tends to stay at rest, and a moving body tends to keep moving at the same speed in the same direction.", "14.3", "Understand"),
 ("3 (b)", "The mass of the body - the more matter it contains, the more inertia it has.", "14.3", "Understand"),
 ("3 (c)", "No. The passenger was moving forward at the same speed as the tro-tro. When the tro-tro braked, a force slowed the vehicle but nothing slowed the passenger, so his own inertia kept him moving forward while the vehicle slowed underneath him.", "14.3", "Evaluate"),
 ("4 (a)", "A body continues in its state of rest, or of uniform motion in a straight line, unless an unbalanced force acts on it.", "14.4", "Remember"),
 ("4 (b)", "Inertia is the tendency to resist a change in motion, and Newton's First Law describes exactly that behaviour, so the law explains in words what inertia is.", "14.4", "Analyse"),
 ("4 (c)", "The ball keeps rolling at almost the same speed in a straight line for a long time, because there is very little friction on a smooth floor to act as the unbalanced force needed to stop it.", "14.4", "Apply"),
 ("5 (a)", "The passenger falls backwards, because the lower part of his body moves forward with the bus while the upper part tends to stay at rest. This shows Newton's First Law of Motion.", "14.5", "Understand"),
 ("5 (b)", "The passenger is moving forward with the car; when the car stops suddenly his inertia keeps him moving; the seat belt applies the unbalanced force that holds him back and stops him hitting the dashboard.", "14.5", "Apply"),
 ("5 (c)", "Any one correct application with an explanation - e.g. luggage sliding off a seat when a bus turns a corner, a ball rolling until it hits a block, shaking water off the hands, or pulling a tablecloth from under a plate.", "14.5", "Understand"),
 ("6 (a)", "A magnet is a material or object that attracts iron and steel. It attracts iron, steel, nickel and cobalt.", "14.6", "Understand"),
 ("6 (b)", "Any two of: a bar magnet; a horseshoe magnet; a ring or round magnet; a U-shaped magnet; a button magnet; a magnetic strip or fridge magnet.", "14.6", "Remember"),
 ("6 (c)", "Suspend each bar in turn from a thread; the one that always comes to rest pointing north-south is the magnet, because only a magnet has poles and lines up with the earth's field. Or dip each bar into iron pins; the one that picks up a cluster at its ends is the magnet. Or bring one end of bar A to the middle of bar B; if it attracts, A is the magnet.", "14.6", "Create"),
 ("7 (a)", "Attraction is when two magnets pull towards each other, and it happens between unlike poles (north and south). Repulsion is when two magnets push each other away, and it happens between like poles (north and north, or south and south).", "14.7", "Understand"),
 ("7 (b)", "The magnet turns and comes to rest pointing north-south, with the same end always pointing north. This is used in a magnetic compass to find direction.", "14.7", "Apply"),
 ("7 (c)", "Any four of: a magnetic compass; a catch on a fridge or cupboard door; holding notes on a magnetic board; picking up fallen steel pins, nails or screws; separating iron from a mixture; in a door bell, loudspeaker or electric motor; a magnetic bag fastener.", "14.8", "Remember"),
]
add_table(["Question", "Expected Answer", "Curriculum Area", "Cognitive Level"],
          [list(r) for r in sba], widths=[0.8, 4.2, 1.2, 1.2], size=9)

doc.add_page_break()

# =========================================================== MARKING SCHEME
para("MARKING SCHEME - SECTION B (60 marks)", size=13, bold=True, align="c", space_after=4)
para("General rules: (1) Accept any other correct and relevant answer. (2) Award marks for correct points, "
     "not for repeating the question. (3) For procedures, award method marks. (4) Do not deduct marks for "
     "spelling unless the meaning is changed. (5) Where a candidate gives more answers than are asked for, "
     "mark only the first ones up to the number required.",
     size=9.5, italic=True, space_after=8)

for qb in SECTION_B:
    n = qb["num"]
    para(f"Question {n}  ({qb['total']} marks)", size=11, bold=True, space_before=8, space_after=3)
    for (lab, points, note) in MARKING[n]:
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(2)
        set_font(p.add_run(f"{lab} "), 10.5, bold=True)
        mkv = [p_[2] for p_ in qb["parts"] if p_[0] == lab]
        if mkv: set_font(p.add_run(f"[{mkv[0]} mark{'s' if mkv[0] > 1 else ''}]"), 10, bold=True)
        for pt in points:
            pp = doc.add_paragraph()
            pp.paragraph_format.left_indent = Inches(0.35); pp.paragraph_format.space_after = Pt(1)
            set_font(pp.add_run("- " + pt), 10.5)
        pp = doc.add_paragraph()
        pp.paragraph_format.left_indent = Inches(0.35); pp.paragraph_format.space_after = Pt(6)
        set_font(pp.add_run("Marking note: " + note), 9.5, italic=True)

doc.add_page_break()

# ================================================================ BLUEPRINT
para("CURRICULUM ASSESSMENT BLUEPRINT", size=13, bold=True, align="c", space_after=3)
para(f"Strand: {STRAND}   |   Sub-strand: {SUBSTRAND}   |   Class: {CLASS}",
     size=10, italic=True, align="c", space_after=3)
para(f"Content Standard: {CS} - {CS_TEXT}", size=9, italic=True, align="c", space_after=3)
para("Source: NaCCA Science Common Core Programme Curriculum (B7/JHS1-B9/JHS3), September 2020, "
     "Strand 4: Forces and Energy, Sub-strand 4: Force and Motion (topics 14.1-14.8), "
     "pp. 35-38. Indicators are quoted, not invented.",
     size=9, italic=True, space_after=8)

hdr = ["Qn", "Sub-strand", "Content Standard", "Indicator (NaCCA) - Indicator Text", "Topic / Content",
       "Cognitive Level", "Marks"]

rows = [[f"A{i}", SUBSTRAND, CS_BY_TOPIC[tp], f"{IND[tp]} - {IND_TEXT[tp]}", TOPIC[tp], cog, 1]
        for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1)]
add_table(hdr, rows, widths=[0.35, 0.75, 0.75, 1.75, 1.4, 0.8, 0.35], size=7, head_size=7.5)

para("", space_after=8)
rows = []
for qb in SECTION_B:
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        key = tp if tp in TOPIC else tp.split(",")[0].strip()
        rows.append([f"B{qb['num']}{lab.strip('()')}", SUBSTRAND, CS_BY_TOPIC[key],
                     f"{IND[key]} - {IND_TEXT[key]}", TOPIC[key], cog, mk])
add_table(hdr, rows, widths=[0.35, 0.75, 0.75, 1.75, 1.4, 0.8, 0.35], size=7, head_size=7.5)

doc.add_page_break()

# ----------------------------------------------------------------- helpers
def topic_totals():
    m = {k: 0 for k in TOPIC}; it = {k: 0 for k in TOPIC}
    for q in MCQ:
        m[q[3]] += 1; it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk; it[key] += 1
    return m, it

def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}; b = {k: 0 for k in order}
    for q in MCQ: a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: b[cog] += mk
    return order, a, b

def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ: d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: d[diff] += mk
    return d

m, it = topic_totals(); diff = difficulty_totals(); order, ca, cb = cognitive_by_section()

para("SUMMARY 1 - COVERAGE BY CURRICULUM AREA (TOPIC)", size=12, bold=True, space_after=4)
rows = [[TOPIC[k], it[k], m[k], f"{(m[k]/100)*100:.1f}%", CC[k]] for k in TOPIC]
rows.append(["TOTAL", sum(it.values()), sum(m.values()), "100%", "-"])
add_table(["Topic / Content Area", "No. of Items", "Marks", "% of Total Marks", "Core Competencies"],
          rows, widths=[2.7, 0.8, 0.6, 1.0, 1.1], size=8.5)
para("CC = Communication and Collaboration; CP = Critical Thinking and Problem Solving; "
     "DL = Digital Literacy; CI = Creativity and Innovation.", size=8.5, italic=True, space_after=2)

para("", space_after=8)
para("SUMMARY 2 - COGNITIVE-LEVEL DISTRIBUTION (Bloom's Taxonomy)", size=12, bold=True, space_after=4)
rows = []
for lv in order:
    tot = ca[lv] + cb[lv]
    rows.append([lv, ca[lv], cb[lv], tot, f"{(tot/100)*100:.1f}%"])
rows.append(["TOTAL", sum(ca.values()), sum(cb.values()), sum(ca.values()) + sum(cb.values()), "100%"])
add_table(["Cognitive Level", "Section A Marks", "Section B Marks", "Total Marks", "% of Total"],
          rows, widths=[1.6, 1.3, 1.3, 1.1, 1.1], size=9.5)

para("", space_after=8)
para("SUMMARY 3 - DIFFICULTY DISTRIBUTION", size=12, bold=True, space_after=4)
rows = [[k, v, f"{(v/100)*100:.1f}%"] for k, v in diff.items()]
rows.append(["TOTAL", sum(diff.values()), "100%"])
add_table(["Difficulty", "Marks", "% of Total Marks"], rows, widths=[2.0, 1.2, 1.5], size=9.5)
para("Target in the master prompt: approximately 30% easy / 50% moderate / 20% challenging.",
     size=9, italic=True, space_after=2)

para("", space_after=8)
para("SUMMARY 4 - SECTION WEIGHTING", size=12, bold=True, space_after=4)
add_table(["Section", "Question Type", "Items", "Marks", "% of Total"],
          [["A", "Objective (multiple choice)", 40, 40, "40%"],
           ["B", "Theory / constructed response", 21, 60, "60%"],
           ["TOTAL", "-", 61, 100, "100%"]],
          widths=[0.9, 2.4, 0.8, 0.8, 1.0], size=9.5)

doc.add_page_break()

# ===================================================== QUALITY-CONTROL
para("QUALITY-CONTROL SUMMARY", size=13, bold=True, align="c", space_after=4)
para("Carried out against the 14-point validation list in the master prompt before the examination was "
     "finalised.", size=9.5, italic=True, space_after=8)

qc = [
 ("Does every question belong to the supplied curriculum scope?",
  "Yes. All 61 items - 40 objectives and 21 theory sub-questions - trace to Strand 4 (Forces and "
  "Energy), Sub-Strand 4 (Force and Motion), topics 14.1-14.8, and to the four official B7 "
  "indicators under content standard B7/JHS1.4.4.1 (B7/JHS1.4.4.1.1 to B7/JHS1.4.4.1.4). Simple "
  "machines, levers, work input and output, and efficiency are deliberately excluded - they form "
  "the companion paper on B7/JHS1.4.4.2. Friction is named only as the force that stops a ball; "
  "no friction calculation is required."),
 ("Is the examination appropriate for the stated class?",
  "Yes. The B7 curriculum requires learners to explain inertia as a tendency to resist motion, "
  "demonstrate how unbalanced forces cause motion, state and explain Newton's First Law, examine "
  "its applications in life (the exemplar names a ball on a smooth surface and the use of seat "
  "belts), and demonstrate the behaviour and uses of magnets - what they are, their types, "
  "attraction, repulsion, N-S orientation and everyday uses. Newton's Second and Third Laws, "
  "F = ma and momentum are nowhere tested."),
 ("Are the questions genuinely BECE-style?",
  "Yes: Section A is 40 four-option objectives worth 1 mark each, and Section B is structured "
  "theory with sub-questions carrying printed mark allocations. The tug-of-war, the tro-tro and "
  "the suspended bar magnet are all dealt with through explanation and description rather than "
  "calculation, which is the B7 treatment."),
 ("Are there enough application and reasoning questions?",
  "Yes. 32 of 100 marks (32%) are at Apply level or above (Apply 22, Analyse 3, Evaluate 3, "
  "Create 4). Create appears in Question 6(c), where pupils must plan a test to identify a "
  "magnet, and Evaluate in Question 3(c), where they must judge the everyday claim that a "
  "vehicle 'threw' a passenger forward."),
 ("Are the MCQ distractors plausible?",
  "Yes. Distractors are drawn from the same content family as the key: another law of motion or "
  "another scientific law (A19, A21), a property that is not an effect of a force (A3, A4), a "
  "material that a magnet does not attract (A26, A28), the opposite pole behaviour (A29, A30, "
  "A33), and a genuine object that simply has no magnet in it (A37, A40)."),
 ("Is there only one best answer for each MCQ?",
  "Yes. Every item was reviewed for a single defensible key. Special care was taken with A9, "
  "where the rope moves towards team A because their pull is larger, with A26, where a steel "
  "paper clip IS attracted but a plastic ruler is not, and with A40, where a compass, a door "
  "catch and picking up pins are all real uses but weighing maize is not."),
 ("Are the marks internally consistent?",
  "Yes. Section A = 40 items x 1 mark = 40. Section B = 8 + 9 + 8 + 8 + 9 + 8 + 10 = 60. "
  "Each Section B sub-question's printed marks match its marking-scheme allocation, and every "
  "N-mark sub-question asks for N things."),
 ("Does the total add up correctly?",
  "Yes: 40 + 60 = 100 marks, matching the stated total on the front page."),
 ("Are the answers in the answer key correct?",
  "Yes. All 40 objective keys and all 21 Section B answers were verified against the marking "
  "scheme. Question 2(c) was checked: 60 N against 45 N gives an overall force of 15 N towards "
  "the weaker side."),
 ("Does the marking scheme match the questions?",
  "Yes. Every Section B sub-question has an expected-answer list and a marking note covering "
  "partial credit, acceptable alternatives, common wrong answers and method marks. The "
  "magnet-identification test in Question 6(c) is marked on four separate points - the test, the "
  "observation, the conclusion and the reason - and the note lists three different valid tests "
  "so that no pupil is penalised for choosing a different one."),
 ("Are the questions free from unnecessary ambiguity?",
  "Yes. Open items are anchored with 'state three', 'name four' and the mark allocation. "
  "Question 2(a) requires BOTH balanced and unbalanced forces to be described, Question 7(a) "
  "requires both attraction and repulsion, and Question 5(a) requires both what happens and the "
  "name of the law. Question 6(c) says 'plan a test ... and explain why your test works', so "
  "pupils know the reason is marked too."),
 ("Are Ghanaian contexts used naturally and accurately?",
  "Yes: a tro-tro on the Accra-Kumasi road, an inter-house tug-of-war at school, a goalkeeper, "
  "an empty plastic water bottle, a loaded cargo truck, a magnetic board in a classroom, a "
  "kitchen cupboard catch, and a bag of maize at the market."),
 ("Has any content outside the supplied curriculum been introduced?",
  "No. Every item sits inside topics 14.1-14.8. Simple machines, levers, work and efficiency "
  "belong to the companion paper on B7/JHS1.4.4.2 and are excluded here. Newton's Second and "
  "Third Laws, F = ma, momentum, friction coefficients and magnetic field lines are not "
  "required anywhere in the paper."),
 ("Are the questions sufficiently varied?",
  "Yes. Item types include defining a force and its unit, listing effects, explaining a "
  "goalkeeper's catch, distinguishing balanced from unbalanced forces, predicting the direction "
  "of motion from two unequal forces, defining inertia, judging a passenger's description, "
  "stating a law, linking the law to inertia, explaining seat belts, describing another "
  "application, planning a test to identify a magnet, explaining attraction and repulsion, "
  "describing a suspended magnet, and listing the uses of magnets."),
]
for i, (q, a) in enumerate(qc, start=1):
    p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(2)
    set_font(p.add_run(f"{i}. {q}"), 10.5, bold=True)
    p2 = doc.add_paragraph()
    p2.paragraph_format.left_indent = Inches(0.3); p2.paragraph_format.space_after = Pt(6)
    set_font(p2.add_run(a), 10)

para("", space_after=8)
para("EXAMINER NOTES (for the teacher, not for candidates)", size=11, bold=True, space_after=4)
for n in [
 "Question 3(c) is the item to watch. Pupils routinely say the vehicle 'threw' them forward, as "
 "if something pushed them. It did not: the passenger was already moving forward at the same "
 "speed as the vehicle, and when the vehicle braked nothing braked the passenger, so his own "
 "inertia carried him on. Allow the two reason marks only for answers that make this point.",
 "Question 6(c) is the design task, and it is deliberately open. Three different tests are listed "
 "in the marking scheme - suspending the bar, dipping it into iron pins, and touching one end to "
 "the middle of the other bar - and all three earn full marks. Do not insist on the one you "
 "taught.",
 "Question 4(a) is a four-mark recall of Newton's First Law, and the note withholds a mark if the "
 "word UNBALANCED is missing. Balanced forces are already acting on every object at rest; it "
 "takes an unbalanced force to change the motion. Teach that word before the mock.",
 "The magnet and the mechanics halves of this paper are both under the same content standard, "
 "B7/JHS1.4.4.1, which is titled 'motion, Newton's first law of motion, magnetic force in "
 "relation to motion'. That is why magnets sit in the same paper as forces - it is the "
 "curriculum's own grouping, not mine.",
 "Topic weighting is 13 marks each for topics 14.1 to 14.6 and 11 each for 14.7 and 14.8. If you "
 "spent longer on magnets than on forces, move marks towards Questions 6 and 7.",
 "Two cheap practicals that raise marks sharply: (1) flick a card from under a coin on a glass, "
 "and (2) float a magnetised needle on a leaf in a bowl of water and watch it settle north-south. "
 "The first teaches Questions 3 and 5, the second teaches Question 7(b).",
 "The companion paper covers topics 14.9 to 14.11 - simple machines, the three classes of lever, "
 "and work input, work output and efficiency - under content standard B7/JHS1.4.4.2. Use the two "
 "papers together for a full end-of-term examination on this sub-strand, or separately as two "
 "class tests.",
 "Edit the school name, academic year and examination title on page 1 before printing.",
 "This is an original, teacher-made mock. It is not a reproduction of any WAEC or NaCCA examination "
 "paper.",
]:
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Inches(0.3); p.paragraph_format.space_after = Pt(3)
    set_font(p.add_run("- " + n), 10)

doc.save("/home/user/Basic7_Integrated_Science_Mock_Strand4_ForceAndMotion1.docx")
print("docx written")

print("Section A:", len(MCQ), "items")
print("Section B total:", sum(q["total"] for q in SECTION_B))
print("Topic marks:", m, "sum", sum(m.values()))
print("Difficulty:", diff, "sum", sum(diff.values()))
print("Cognitive A:", ca)
print("Cognitive B:", cb)
print("Answer counts:", counts)
print("Totals:", sum(m.values()), sum(diff.values()),
      sum(ca.values()) + sum(cb.values()))
