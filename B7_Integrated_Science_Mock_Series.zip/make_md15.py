# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "/home/user")
from build_machines import *

L = []
def w(s=""): L.append(s)

w(f"# {SCHOOL}"); w()
w(f"## {SUBJECT}"); w()
w(f"### {EXAM}"); w()
w(f"**Class:** {CLASS}  ")
w(f"**Time:** {TIME}  ")
w(f"**Total Marks:** {MARKS}  ")
w(f"**Academic Year:** {YEAR}"); w()
w("---"); w()
w("### INSTRUCTIONS"); w()
for i, t in enumerate([
    "Write your name and class clearly in the spaces provided on your answer sheet.",
    "This paper has TWO sections: Section A and Section B.",
    "Answer ALL the questions in both sections.",
    "Section A has 40 multiple-choice questions. Each question carries 1 mark. Choose the best answer (A, B, C or D) and record it on the answer sheet provided.",
    "Section B has 7 theory questions totalling 60 marks. Write your answers clearly and neatly in your answer booklet. Draw and label diagrams or tables where you are asked to.",
    "Read every question carefully before you answer it.",
    "Do not use correction fluid. Cancel any mistake neatly with a single line.",
    "Hand in your answer sheet and your answer booklet at the end of the examination.",
], start=1):
    w(f"{i}. {t}")
w(); w("---"); w()

w("## SECTION A: OBJECTIVE TEST (40 marks)"); w()
w("*Answer ALL questions. Each question carries 1 mark. Choose the BEST answer and write its letter "
  "(A, B, C or D) against the question number on your answer sheet.*"); w()
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"**{i}. {q}**"); w()
    for j, o in enumerate(opts): w(f"{'ABCD'[j]}. {o}")
    w()
w("---"); w()

w("## SECTION B: THEORY (60 marks)"); w()
w("*Answer ALL questions. Write your answers in your answer booklet. The marks for each question are shown "
  "in brackets.*"); w()
for qb in SECTION_B:
    w(f"### Question {qb['num']}  [{qb['total']} marks]"); w()
    w(qb["stem"]); w()
    if qb.get("diagram"):
        w("```")
        for line in LEVER: w(line)
        w("```")
        w("*Fig. 1: A lever*"); w()
    if qb.get("table") == "machines":
        w("| " + " | ".join(SM_HEADERS) + " |")
        w("| " + " | ".join(["---"] * len(SM_HEADERS)) + " |")
        for r in SM_ROWS:
            w("| " + " | ".join(r) + " |")
        w()
        w("*Table 1: Common simple machines*"); w()
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        w(f"**{lab}** {text}  **[{mk} mark{'s' if mk > 1 else ''}]**"); w()
w("---"); w()

w("## ANSWER KEY"); w()
w("### Section A - Objective Test"); w()
w("| Question | Answer | Curriculum Area (Topic) | Cognitive Level |")
w("| -------- | ------ | ----------------------- | --------------- |")
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"| {i} | {ans} | {TOPIC[tp]} | {cog} |")
counts = {L2: sum(1 for q in MCQ if q[2] == L2) for L2 in "ABCD"}
w()
w("Correct-answer distribution: " + ", ".join(f"{L2} = {counts[L2]}" for L2 in "ABCD") + " (40 items).")
w()
w("### Section B - Theory (summary answers; full detail in the Marking Scheme)"); w()
w("| Question | Expected Answer | Curriculum Area | Cognitive Level |")
w("| -------- | --------------- | --------------- | --------------- |")
sba = [
 ("1 (a)", "A simple machine is a device that makes work easier. It lets a small effort move a large load, or it changes the size or the direction of the force applied. It has few or no moving parts.", "14.9", "Understand"),
 ("1 (b)", "Any four of: a lever; a pulley; an inclined plane; a wheel and axle; a screw; a wedge.", "14.9", "Remember"),
 ("1 (c)", "Simple machines make work easier, so a smaller effort can move a bigger load. They let a force be applied in a more convenient direction, and they save time and energy.", "14.9", "Understand"),
 ("2 (a)", "(i) a crowbar lifting a stone, a see-saw, the handle of a hand pump, a bottle opener. (ii) a sloping surface or slope used to raise a load. (iii) raising a bucket from a well, raising a flag up a pole, lifting a load on a building site. (iv) a large wheel joined to a smaller rod (the axle) so that the two turn together. (v) holding two pieces of wood together, a corkscrew, a car jack. (vi) a piece of metal or wood that is thick at one end and thin at the other.", "14.9", "Understand"),
 ("2 (b)", "Any one machine from the table with a correct job - e.g. a lever: a crowbar is used to lift a heavy stone or to pull out a nail.", "14.9", "Apply"),
 ("3 (a)", "(i) effort, (ii) fulcrum, (iii) load.", "14.10", "Understand"),
 ("3 (b)", "A lever is a bar or a rigid rod that turns about a fixed point. The fixed point is called the fulcrum, and an effort applied at one point moves a load at another.", "14.10", "Understand"),
 ("3 (c)", "In a first-class lever the fulcrum is BETWEEN the effort and the load. One end is pushed down as the effort while the other end goes up and lifts the load. Example: a see-saw, a pair of scissors, a claw hammer pulling out a nail, the handle of a hand pump.", "14.10", "Understand"),
 ("4 (a)", "A second-class lever is one in which the LOAD lies between the fulcrum and the effort, so that the effort and the load are on the same side of the fulcrum. Example: a wheelbarrow, a nutcracker, a bottle opener.", "14.10", "Understand"),
 ("4 (b)", "A third-class lever is one in which the EFFORT lies between the fulcrum and the load, so that the effort is the nearer of the two to the fulcrum. Example: a pair of sugar tongs, a broom being used to sweep, a fishing rod, the human forearm.", "14.10", "Understand"),
 ("4 (c)", "Find the fulcrum first, then see which of the other two lies in the middle. Fulcrum in the middle means first class, e.g. a see-saw. Load in the middle means second class, e.g. a wheelbarrow. Effort in the middle means third class, e.g. a pair of sugar tongs.", "14.10", "Analyse"),
 ("5 (a)", "A claw hammer pulling a nail out of wood - FIRST class. A wheelbarrow - SECOND class. A broom being used to sweep - THIRD class. A nutcracker - SECOND class.", "14.10", "Apply"),
 ("5 (b)", "Any two: a claw hammer - the long handle means a small effort gives a large pulling force on the nail; a wheelbarrow - the load sits between the wheel and the handles, so a small lift moves a heavy load; a broom - a small movement of the upper hand sweeps a large area; a nutcracker - the effort is further from the hinge than the nut, so a small squeeze gives a large crushing force.", "14.10", "Understand"),
 ("5 (c)", "Use a lever such as a crowbar or a spanner on a bolt. Try it first with a short handle and then with a long one, pushing at the very end each time and comparing the effort needed. Keep the load and the position of the fulcrum the same, so that only the length of the handle changes. The class would find that the longer handle needs a much smaller effort.", "14.10", "Create"),
 ("6 (a)", "Work input is the work done ON a machine, that is, the work put into it. Work output is the useful work done BY the machine, that is, the work that comes out of it. Both are measured in joules (J).", "14.11", "Understand"),
 ("6 (b)", "50 J did not come out as useful work (200 J in minus 150 J out). It was used to overcome friction in the moving parts and was changed into heat, and some into sound, which spread out into the surroundings. The energy was not destroyed, only changed into forms that are not useful.", "14.11", "Apply"),
 ("6 (c)", "Some of the work put in is always used to overcome friction in the moving parts, and some is used to lift the moving parts of the machine itself. That energy is changed into heat and sound, which are not useful, so the useful work out is always less than the work put in.", "14.11", "Understand"),
 ("7 (a)", "Efficiency is the ratio of work output to work input, given as a percentage. Efficiency = (work output / work input) x 100%. It measures how much of the work put into a machine comes out as useful work.", "14.11", "Understand"),
 ("7 (b)", "Efficiency = (work output / work input) x 100% = (300 / 400) x 100% = 0.75 x 100% = 75%.", "14.11", "Apply"),
 ("7 (c)", "The 75 per cent machine, because it turns more of the work put into it into useful work and wastes less energy as heat and sound, so it will cost less to run. Accept the 40 per cent machine only if the pupil gives a good reason, such as that it is the only one the school can afford or repair.", "14.11", "Evaluate"),
]
for r in sba: w(f"| {r[0]} | {r[1]} | {r[2]} | {r[3]} |")
w(); w("---"); w()

w("## MARKING SCHEME - SECTION B (60 marks)"); w()
w("*General rules: (1) Accept any other correct and relevant answer. (2) Award marks for correct points, not "
  "for repeating the question. (3) For procedures, award method marks. (4) Do not deduct marks for spelling "
  "unless the meaning is changed. (5) Where a candidate gives more answers than are asked for, mark only the "
  "first ones up to the number required.*"); w()
for qb in SECTION_B:
    n = qb["num"]
    w(f"### Question {n} ({qb['total']} marks)"); w()
    for (lab, points, note) in MARKING[n]:
        mkv = [p_[2] for p_ in qb["parts"] if p_[0] == lab]
        head = f"**{lab}**"
        if mkv: head += f" [{mkv[0]} mark{'s' if mkv[0] > 1 else ''}]"
        w(head); w()
        for pt in points: w(f"- {pt}")
        w(f"  - *Marking note: {note}*"); w()
w("---"); w()

w("## CURRICULUM ASSESSMENT BLUEPRINT"); w()
w(f"**Strand:** {STRAND} | **Sub-strand:** {SUBSTRAND} | **Class:** {CLASS}"); w()
w(f"**Content Standard:** {CS} - {CS_TEXT}"); w()
w("> Source: NaCCA Science Common Core Programme Curriculum (B7/JHS1-B9/JHS3), September 2020, "
  "Strand 4: Forces and Energy, Sub-strand 4: Force and Motion (topics 14.9-14.11), "
  "pp. 38-40. Indicators are quoted, not invented."); w()

w("### Section A"); w()
w("| Qn | Sub-strand | Content Standard | Indicator (NaCCA) - Indicator Text | Topic / Content | Cognitive Level | Marks |")
w("| -- | ---------- | ---------------- | ---------------------------------- | --------------- | --------------- | ----- |")
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"| A{i} | {SUBSTRAND} | {CS_BY_TOPIC[tp]} | {IND[tp]} - {IND_TEXT[tp]} | {TOPIC[tp]} | {cog} | 1 |")
w()
w("### Section B"); w()
w("| Qn | Sub-strand | Content Standard | Indicator (NaCCA) - Indicator Text | Topic / Content | Cognitive Level | Marks |")
w("| -- | ---------- | ---------------- | ---------------------------------- | --------------- | --------------- | ----- |")
for qb in SECTION_B:
    for (lab, text, mkv, cog, tp, diff) in qb["parts"]:
        key = tp if tp in TOPIC else tp.split(",")[0].strip()
        w(f"| B{qb['num']}{lab.strip('()')} | {SUBSTRAND} | {CS_BY_TOPIC[key]} | {IND[key]} - {IND_TEXT[key]} | {TOPIC[key]} | {cog} | {mkv} |")
w(); w("---"); w()

def topic_totals():
    m = {k: 0 for k in TOPIC}; it = {k: 0 for k in TOPIC}
    for q in MCQ: m[q[3]] += 1; it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk; it[key] += 1
    return m, it

def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}; b = {k: 0 for k in order}
    for q in MCQ: a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: b[cog] += mk
    return order, a, b

def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ: d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: d[diff] += mk
    return d

m, it = topic_totals(); diff_ = difficulty_totals(); order, ca, cb = cognitive_by_section()

w("### Summary 1 - Coverage by Curriculum Area (Topic)"); w()
w("| Topic / Content Area | No. of Items | Marks | % of Total Marks | Core Competencies |")
w("| -------------------- | ------------ | ----- | ---------------- | ----------------- |")
for k in TOPIC: w(f"| {TOPIC[k]} | {it[k]} | {m[k]} | {(m[k]/100)*100:.1f}% | {CC[k]} |")
w(f"| **TOTAL** | **{sum(it.values())}** | **{sum(m.values())}** | **100%** | - |")
w()
w("*CC = Communication and Collaboration; CP = Critical Thinking and Problem Solving; DL = Digital Literacy; "
  "CI = Creativity and Innovation.*"); w()
w("### Summary 2 - Cognitive-Level Distribution (Bloom's Taxonomy)"); w()
w("| Cognitive Level | Section A Marks | Section B Marks | Total Marks | % of Total |")
w("| --------------- | --------------- | --------------- | ----------- | ---------- |")
for lv in order:
    tot = ca[lv] + cb[lv]
    w(f"| {lv} | {ca[lv]} | {cb[lv]} | {tot} | {(tot/100)*100:.1f}% |")
w(f"| **TOTAL** | **{sum(ca.values())}** | **{sum(cb.values())}** | **{sum(ca.values())+sum(cb.values())}** | **100%** |")
w()
w("### Summary 3 - Difficulty Distribution"); w()
w("| Difficulty | Marks | % of Total Marks |")
w("| ---------- | ----- | ---------------- |")
for k, v in diff_.items(): w(f"| {k} | {v} | {(v/100)*100:.1f}% |")
w(f"| **TOTAL** | **{sum(diff_.values())}** | **100%** |")
w()
w("*Target in the master prompt: approximately 30% easy / 50% moderate / 20% challenging.*"); w()
w("### Summary 4 - Section Weighting"); w()
w("| Section | Question Type | Items | Marks | % of Total |")
w("| ------- | ------------- | ----- | ----- | ---------- |")
w("| A | Objective (multiple choice) | 40 | 40 | 40% |")
w("| B | Theory / constructed response | 20 | 60 | 60% |")
w("| **TOTAL** | - | **60** | **100** | **100%** |")
w(); w("---"); w()

w("## QUALITY-CONTROL SUMMARY")
w("")
w("| Check | Status |")
w("| --- | --- |")
for q_, a_ in [
 ("Every question within supplied curriculum scope",
  "Yes - all 60 items (40 objectives and 20 theory sub-questions) sit in topics 14.9-14.11 of Strand 4, Sub-Strand 4 (Force and Motion), under content standard B7/JHS1.4.4.2, mapped to indicators B7/JHS1.4.4.2.1 to B7/JHS1.4.4.2.3. Force, motion, inertia, Newton's First Law and magnets are excluded; they form the companion paper on B7/JHS1.4.4.1"),
 ("Appropriate for the class",
  "Yes - B7 level; no mechanical advantage, no velocity ratio, no pulley-system force calculations, and no joule derived from force x distance"),
 ("Genuinely BECE-style",
  "Yes - 40 four-option objectives plus structured theory with printed mark allocations; the only arithmetic is the efficiency percentage in Question 7(b) and the subtraction in Question 6(b), both explicitly required by the curriculum"),
 ("Sufficient application and reasoning",
  "Yes - 33 of 100 marks (33%) at Apply level or above (Apply 25, Analyse 4, Evaluate 2, Create 2)"),
 ("Plausible MCQ distractors",
  "Yes - another simple machine, another part of a lever, the wrong class of lever, the inverted efficiency formula, and a genuine way of caring for a machine that does not improve its efficiency"),
 ("Single best answer per MCQ",
  "Yes - reviewed item by item and the option order was rebuilt so that each declared key sits on the correct answer; 'pivot pin' was replaced by 'the bar' in A17 because a pivot is another name for a fulcrum, A12 says 'winding handle' so that only the wheel-and-axle answer fits, and A40 asks for the energy wasted (100 J) and not the useful work (400 J)"),
 ("Marks internally consistent",
  "Yes - Section A 40 x 1 = 40; Section B 9 + 8 + 9 + 9 + 8 + 9 + 8 = 60; sub-question marks match the marking scheme"),
 ("Total adds up correctly",
  "Yes - 40 + 60 = 100"),
 ("Answer key correct",
  "Yes - all 40 keys and all 20 Section B answers verified against the marking scheme; Question 7(b) checked (300 / 400 = 0.75, so 75 per cent) and Question 6(b) checked (200 J in minus 150 J out leaves 50 J wasted)"),
 ("Marking scheme matches questions",
  "Yes - expected answers plus marking notes covering partial credit, alternatives, common wrong answers and method marks; the efficiency calculation in Question 7(b) is marked on three separate points and the note allows the substitution and answer marks even when the formula is not written"),
 ("Free from unnecessary ambiguity",
  "Yes - open items are anchored with 'name four' and 'state two' plus the mark allocation; Question 6(a) requires both work input and work output and the unit, Question 4(a) and 4(b) each require a definition and an example, Question 5(a) requires the class and the tool to be matched, and Question 5(c) says 'your class could carry out' so pupils know a fair test is expected"),
 ("Ghanaian contexts natural and accurate",
  "Yes - a drum of palm oil rolled up a ramp into a lorry, a cutlass splitting a coconut, the winding handle of a well, a see-saw in a playground, a flag raised at school, a building site in town, a bicycle chain, and a school choosing between two machines"),
 ("No content beyond the curriculum",
  "No - every item sits inside topics 14.9-14.11; force, motion, inertia, Newton's First Law and magnets belong to the companion paper on B7/JHS1.4.4.1 and are excluded here"),
 ("Questions sufficiently varied",
  "Yes - defining a simple machine, listing examples, completing a six-row table of machines, describing a job for one machine, naming labelled parts on a lever diagram, defining a lever, placing the fulcrum in a first-class lever, defining and exemplifying the second and third classes, explaining how to classify a lever, giving the class of four everyday tools, explaining how two levers make work easier, planning a fair demonstration, defining work input and output with the unit, accounting for missing energy, explaining why output is always less than input, defining efficiency, calculating efficiency, and choosing between two machines"),
]:
    w("| " + q_ + " | " + a_ + " |")
w("")
w("### EXAMINER NOTES")
w("")
for n_ in [
 "Question 5(a) is the discriminator. Nearly every pupil gets the claw hammer and the wheelbarrow right; the broom and the nutcracker sort the top from the rest. A broom is third class because the lower hand is the effort, the upper hand is the fulcrum and the load is at the far end - so the effort sits between the other two. Teach that one twice.",
 "Question 5(c) is the design task and it is marked on a fair test, not on a brilliant idea. The note awards 1 mark for the set-up and 1 mark for what the class would find, and it explicitly looks for the idea that only the length of the handle changes. Do not insist on the crowbar - a spanner on a bolt, or a door pushed near the hinge and then at the handle, works just as well.",
 "Question 7(b) is the only real calculation, and the note splits it three ways: formula, substitution and answer. Give the method marks generously. A pupil who writes 300 / 400 and then mis-handles the percentage has understood the idea and should not lose everything.",
 "Question 4(c) is the hardest item on the paper. The reliable route is to find the fulcrum first, then ask which of the other two lies in the middle. Pupils who try to memorise three separate definitions without that rule usually mix up the second and third classes.",
 "Topic weighting is 32 marks for 14.9, 36 for 14.10 and 32 for 14.11. Levers carry the most because the curriculum asks for naming, classifying AND demonstrating all three classes. If you spent longer on machines than on efficiency, move marks towards Questions 1 and 2.",
 "Two cheap practicals that raise marks sharply: (1) push a door open first near the hinge and then at the handle, and (2) lift a stone with a short crowbar and then with a long one. The first teaches Questions 3 to 5, the second teaches Question 5(c).",
 "The companion paper covers topics 14.1 to 14.8 - force, balanced and unbalanced forces, inertia, Newton's First Law and its applications, and the types, behaviour and uses of magnets - under content standard B7/JHS1.4.4.1. Use the two papers together for a full end-of-term examination on this sub-strand, or separately as two class tests.",
 "Edit the school name, academic year and examination title on page 1 before printing.",
 "This is an original, teacher-made mock. It is not a reproduction of any WAEC or NaCCA examination paper.",
]:
    w("- " + n_)
w()

open("/home/user/Basic7_Integrated_Science_Mock_Strand4_ForceAndMotion2.md", "w", encoding="utf-8").write("\n".join(L))
print("md written", len("\n".join(L)), "chars")
