# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "/home/user")
from build_career import *

from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT

doc = Document()
sec = doc.sections[0]
sec.left_margin = Inches(0.7); sec.right_margin = Inches(0.7)
sec.top_margin = Inches(0.7); sec.bottom_margin = Inches(0.6)

st = doc.styles["Normal"]; st.font.name = "Calibri"; st.font.size = Pt(11)


def set_font(run, size=11, bold=False, italic=False, mono=False, color=None):
    run.font.size = Pt(size); run.bold = bold; run.italic = italic
    run.font.name = "Consolas" if mono else "Calibri"
    if color: run.font.color.rgb = color
    return run


def para(text="", size=11, bold=False, italic=False, align=None, mono=False,
         space_before=0, space_after=4, color=None):
    p = doc.add_paragraph()
    if align == "c": p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    elif align == "j": p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p.paragraph_format.space_before = Pt(space_before)
    p.paragraph_format.space_after = Pt(space_after)
    if text: set_font(p.add_run(text), size, bold, italic, mono, color)
    return p


def rule():
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(6); p.paragraph_format.space_before = Pt(2)
    set_font(p.add_run("_" * 78), 9, color=RGBColor(0x99, 0x99, 0x99))


def add_table(headers, rows, widths=None, size=9, head_size=9):
    t = doc.add_table(rows=1, cols=len(headers)); t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, h in enumerate(headers):
        c = t.rows[0].cells[i]; c.text = ""
        p = c.paragraphs[0]; p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_font(p.add_run(str(h)), head_size, bold=True)
    for row in rows:
        cells = t.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = ""
            p = cells[i].paragraphs[0]; p.paragraph_format.space_after = Pt(1)
            set_font(p.add_run(str(v)), size)
    if widths:
        for r_ in t.rows:
            for i, w in enumerate(widths): r_.cells[i].width = Inches(w)
    return t


def draw_diagram(lines, caption):
    t = doc.add_table(rows=2, cols=1); t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = t.rows[0].cells[0]
    for k, line in enumerate(lines):
        p = cell.paragraphs[0] if k == 0 else cell.add_paragraph()
        p.paragraph_format.space_after = Pt(0); p.paragraph_format.space_before = Pt(0)
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_font(p.add_run(line), 10, mono=True)
    c2 = t.rows[1].cells[0].paragraphs[0]
    c2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_font(c2.add_run(caption), 9, italic=True)
    t.rows[0].cells[0].width = Inches(6.6)
    t.rows[1].cells[0].width = Inches(6.6)


# ============================================================= TITLE BLOCK
para(SCHOOL, size=15, bold=True, align="c", space_after=2)
para(SUBJECT, size=13, bold=True, align="c", space_after=2)
para(EXAM, size=12, bold=True, align="c", space_after=2)
para(YEAR, size=10, italic=True, align="c", space_after=8)

info = doc.add_table(rows=1, cols=3); info.style = "Table Grid"
info.alignment = WD_TABLE_ALIGNMENT.CENTER
for i, v in enumerate([f"Class: {CLASS}", f"Time: {TIME}", f"Total Marks: {MARKS}"]):
    c = info.rows[0].cells[i]; c.text = ""
    set_font(c.paragraphs[0].add_run(v), 10, bold=True)
para("", space_after=6)

para("INSTRUCTIONS", size=11, bold=True, space_after=3)
for txt in [
    "1. Write your name and class clearly in the spaces provided on your answer sheet.",
    "2. This paper has TWO sections: Section A and Section B.",
    "3. Answer ALL the questions in both sections.",
    "4. Section A has 40 multiple-choice questions. Each question carries 1 mark. Choose the best answer "
    "(A, B, C or D) and record it on the answer sheet provided.",
    "5. Section B has 7 theory questions totalling 60 marks. Write your answers clearly and neatly in your "
    "answer booklet. Draw and label diagrams or tables where you are asked to.",
    "6. Read every question carefully before you answer it.",
    "7. Do not use correction fluid. Cancel any mistake neatly with a single line.",
    "8. Hand in your answer sheet and your answer booklet at the end of the examination.",
]:
    para(txt, size=10.5, space_after=2)
rule()

# =============================================================== SECTION A
para("SECTION A - OBJECTIVE TEST (40 marks)", size=12, bold=True, align="c", space_after=2)
para("Answer ALL questions. Each question carries 1 mark. Choose the BEST answer and write its letter "
     "(A, B, C or D) against the question number on your answer sheet.",
     size=10, italic=True, align="c", space_after=8)

for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(1); p.paragraph_format.space_before = Pt(4)
    set_font(p.add_run(f"{i}. {q}"), 10.5)
    for j, o in enumerate(opts):
        p2 = doc.add_paragraph()
        p2.paragraph_format.left_indent = Inches(0.28)
        p2.paragraph_format.space_after = Pt(0); p2.paragraph_format.space_before = Pt(0)
        set_font(p2.add_run(f"{'ABCD'[j]}. {o}"), 10.5)

doc.add_page_break()

# =============================================================== SECTION B
para("SECTION B - THEORY (60 marks)", size=12, bold=True, align="c", space_after=2)
para("Answer ALL questions. Write your answers in your answer booklet. The marks for each question are "
     "shown in brackets.", size=10, italic=True, align="c", space_after=8)

for qb in SECTION_B:
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(8); p.paragraph_format.space_after = Pt(2)
    set_font(p.add_run(f"Question {qb['num']}"), 11, bold=True)
    set_font(p.add_run(f"  [{qb['total']} marks]"), 10, bold=True, italic=True)
    para(qb["stem"], size=10.5, space_after=4)
    if qb.get("table") == "scientist":
        add_table(SCIENTIST_HEADERS, SCIENTIST_ROWS, widths=[1.6, 1.7, 2.7], size=8.5,
                  head_size=8.5)
        para("Table 1: Some Ghanaian scientists and science educators and their work",
             size=9, italic=True, align="c", space_after=6)
        para("", space_after=2)
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Inches(0.25)
        p.paragraph_format.space_after = Pt(3); p.paragraph_format.space_before = Pt(2)
        set_font(p.add_run(f"{lab} {text}  "), 10.5)
        set_font(p.add_run(f"[{mk} mark{'s' if mk > 1 else ''}]"), 10, bold=True)

doc.add_page_break()

# ============================================================== ANSWER KEY
para("ANSWER KEY", size=13, bold=True, align="c", space_after=6)
para("SECTION A - OBJECTIVE TEST", size=11, bold=True, space_after=4)
rows = [[i, ans, TOPIC[tp], cog] for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1)]
add_table(["Question", "Answer", "Curriculum Area (Topic)", "Cognitive Level"],
          rows, widths=[0.8, 0.7, 3.6, 1.5], size=9)
counts = {L: sum(1 for q in MCQ if q[2] == L) for L in "ABCD"}
para("", space_after=4)
para("Correct-answer distribution: " + ", ".join(f"{L} = {counts[L]}" for L in "ABCD") + " (40 items).",
     size=9, italic=True)

para("", space_after=8)
para("SECTION B - THEORY (summary answers; see the Marking Scheme for full detail)",
     size=11, bold=True, space_after=4)
sba = [
 ("1 (a)", "Any three careers in science that are not medicine: agricultural scientist or food technologist, engineer, geologist, meteorologist, environmental health officer, science teacher, laboratory technician, veterinary doctor, computer or ICT specialist, soil scientist, water quality officer, solar technician, medical researcher.", "18.1", "Remember"),
 ("1 (b)", "Accept a correct description of the work for any two of the careers named in (a), for example: a soil scientist takes samples of the soil, tests them and tells the farmer what crop to plant and what fertiliser to use; an environmental health officer inspects houses, drains and water sources and advises the community on how to stop disease spreading; a solar technician fixes panels on a roof, wires them up and returns to clean and check them.", "18.1", "Understand"),
 ("1 (c)", "A veterinary doctor keeps farm animals healthy, so families keep the milk, meat and eggs they depend on and do not lose the animals that plough their fields. Healthy animals also mean more food in the market and a better income for the farmer. Some animal diseases can pass to people, so treating the animals protects the people who live with them.", "18.1", "Understand"),
 ("2 (a)", "Accept any two sensible careers with a reason that fits Adjoa: agricultural scientist or soil scientist - she wants to help her community grow more food and likes working outdoors; agricultural engineer - the work is outdoors and uses mathematics; environmental scientist - she likes the outdoors and wants to help her community; mathematics or science teacher - she is good at mathematics and could pass it on.", "18.1", "Apply"),
 ("2 (b)", "Any two: work hard at mathematics and science and pass them well; ask her science teacher about the careers and what subjects they need; read books and look for information about science; join the science club or enter a science competition; go on to a university or a training college that teaches the subject.", "18.1", "Understand"),
 ("2 (c)", "Any two: scientists solve the country's own problems in food, health, water and energy; a country that trains its own scientists does not have to buy every solution from abroad; science and technology create jobs and income; the problems Ghana faces - floods, crop failure, disease - need people who understand them.", "18.1", "Understand"),
 ("3 (a)", "A science educator is someone who teaches science and works to improve the way it is taught - training science teachers and designing what is taught and how, rather than doing research in a laboratory themselves.", "18.2", "Understand"),
 ("3 (b)", "Accept any two correctly named Ghanaian science educators. Prof. Jophus Anamuah-Mensah - a science educator who has worked to improve science teaching in Ghana, led a university and helped shape education policy. Prof. Theophilus Ossei-Anto and Prof. Christian Anthony-Krueger - science educators at the University of Cape Coast who train science teachers. Also accept Prof. Ewurama Addy, who worked to popularise science and directed the Science Education Programme for Africa.", "18.2", "Understand"),
 ("3 (c)", "Any three: teachers produce the next generation of scientists, so without them there would be no scientists at all; a researcher may discover something, but teachers make sure the discovery is understood and used; a country needs many good teachers but only a few researchers, so teachers reach far more people; teachers find and encourage the pupils who will become the scientists of the future; good teaching makes sure a discovery does not stay locked inside one laboratory.", "18.2", "Understand"),
 ("4 (i)", "Mathematical physics. Also accept physics.", "18.2", "Understand"),
 ("4 (ii)", "She reduces post-harvest losses and adds value to Ghanaian foods, so less of the harvest is wasted after it is picked. Also accept: her work on fortified sweetpotato products helps to reduce vitamin A deficiency.", "18.2", "Understand"),
 ("4 (iii)", "Prof. Ewurama Addy. Also accept Marian Ewurama Addy, or Prof. Addy.", "18.2", "Understand"),
 ("4 (iv)", "Science education. Also accept science education, or the training of science teachers.", "18.2", "Understand"),
 ("5 (a)", "Any two: scientific knowledge belongs to the whole world, so we use discoveries made in other countries every day; the medicines, machines and crops developed abroad are used in Ghana; their stories show pupils what patience, curiosity and hard work can achieve; learning about them gives pupils ideas they can apply to Ghana's own problems.", "18.3", "Understand"),
 ("5 (b)", "Accept any one correctly matched. Albert Einstein - physics; the theory of relativity and E = mc squared. Alexander Fleming - medicine and microbiology; the discovery of penicillin. Charles Darwin - biology and natural history; the theory of evolution by natural selection. Stephen Hawking - physics and cosmology; his work on black holes. Marie Curie - physics and chemistry; radioactivity. Isaac Newton - physics and mathematics; gravity and the laws of motion. Louis Pasteur - microbiology; showing that germs cause disease and developing vaccines.", "18.3", "Understand"),
 ("5 (c)", "Accept any accurate account of how the work named in (b) still matters. Fleming's penicillin began the age of antibiotics, and antibiotics are still the treatment for bacterial infections in every Ghanaian hospital today. Pasteur's idea that germs cause disease is why water is treated, wounds are cleaned and children are vaccinated. Einstein's work on energy and matter underlies the physics used in medical scanners, satellites and the generation of electricity.", "18.3", "Analyse"),
 ("6 (a)", "Any two: scientists publish their results so others can build on them; problems such as disease, climate and food do not stop at borders; a discovery made in one country can save lives in another; sharing saves each country from repeating work already done; journals, conferences and the internet let results travel quickly.", "18.3", "Understand"),
 ("6 (b)", "Either position, with reasons. For training our own scientists: they understand Ghana's own problems; the knowledge stays in the country and trains the next generation; it is cheaper in the long run; a country that cannot make or repair anything is always dependent. For buying from abroad: it is quicker; some technology already exists and is expensive to develop. A strong answer says Ghana needs both - to buy what exists and to train the people who will maintain, repair and adapt it.", "18.3", "Evaluate"),
 ("7 (a)", "Any three: electric light lets children read after dark; a refrigerator keeps food and fish from spoiling; a mobile phone lets families keep in touch and lets traders check prices; mobile money lets people pay without carrying cash; a borehole gives clean water close to home; a grinding mill saves hours of pounding; gas or electric cookers have replaced some firewood.", "18.4", "Understand"),
 ("7 (b)", "HOME: a page listing the technologies used at home, each with a picture and a note of what the family did before. SCHOOL: a page on computers, a projector, calculators, the science laboratory, treated water or a borehole, and what they have changed about lessons. COMMUNITY: a page on solar panels, a borehole, a mobile money agent, a grinding mill, a clinic or a tractor, with a note on who uses each one. Plus a title page, a contents list and a short conclusion.", "18.4", "Create"),
 ("7 (c)", "CHECKING: ask a parent, a teacher or an older person whether what you wrote is true; compare what you found with a book or a trusted website; check an internet fact against a second source; ask someone who uses the technology, such as the miller or the nurse. PRESENTING: pin the pages on the wall and walk the class round them; give a short talk to another class; demonstrate one of the technologies; show the album to parents on an open day; act out before and after.", "18.4", "Apply"),
]
add_table(["Question", "Expected Answer", "Curriculum Area", "Cognitive Level"],
          [list(r) for r in sba], widths=[0.8, 4.2, 1.2, 1.2], size=9)

doc.add_page_break()

# =========================================================== MARKING SCHEME
para("MARKING SCHEME - SECTION B (60 marks)", size=13, bold=True, align="c", space_after=4)
para("General rules: (1) Accept any other correct and relevant answer. (2) Award marks for correct points, "
     "not for repeating the question. (3) For procedures, award method marks. (4) Do not deduct marks for "
     "spelling unless the meaning is changed. (5) Where a candidate gives more answers than are asked for, "
     "mark only the first ones up to the number required.",
     size=9.5, italic=True, space_after=8)

for qb in SECTION_B:
    n = qb["num"]
    para(f"Question {n}  ({qb['total']} marks)", size=11, bold=True, space_before=8, space_after=3)
    for (lab, points, note) in MARKING[n]:
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(2)
        set_font(p.add_run(f"{lab} "), 10.5, bold=True)
        mkv = [p_[2] for p_ in qb["parts"] if p_[0] == lab]
        if mkv: set_font(p.add_run(f"[{mkv[0]} mark{'s' if mkv[0] > 1 else ''}]"), 10, bold=True)
        for pt in points:
            pp = doc.add_paragraph()
            pp.paragraph_format.left_indent = Inches(0.35); pp.paragraph_format.space_after = Pt(1)
            set_font(pp.add_run("- " + pt), 10.5)
        pp = doc.add_paragraph()
        pp.paragraph_format.left_indent = Inches(0.35); pp.paragraph_format.space_after = Pt(6)
        set_font(pp.add_run("Marking note: " + note), 9.5, italic=True)

doc.add_page_break()

# ================================================================ BLUEPRINT
para("CURRICULUM ASSESSMENT BLUEPRINT", size=13, bold=True, align="c", space_after=3)
para(f"Strand: {STRAND}   |   Sub-strand: {SUBSTRAND}   |   Class: {CLASS}",
     size=10, italic=True, align="c", space_after=3)
para(f"Content Standard: {CS} - {CS_TEXT}", size=9, italic=True, align="c", space_after=3)
para("Source: NaCCA Science Common Core Programme Curriculum (B7/JHS1-B9/JHS3), September 2020, "
     "Strand 5: Humans and the Environment, Sub-strand 3: Science and Industry "
     "(topics 18.1-18.4), p. 47. Indicators are quoted, not invented.",
     size=9, italic=True, space_after=8)

hdr = ["Qn", "Sub-strand", "Content Standard", "Indicator (NaCCA) - Indicator Text", "Topic / Content",
       "Cognitive Level", "Marks"]

rows = [[f"A{i}", SUBSTRAND, CS_BY_TOPIC[tp], f"{IND[tp]} - {IND_TEXT[tp]}", TOPIC[tp], cog, 1]
        for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1)]
add_table(hdr, rows, widths=[0.35, 0.75, 0.75, 1.75, 1.4, 0.8, 0.35], size=7, head_size=7.5)

para("", space_after=8)
rows = []
for qb in SECTION_B:
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        key = tp if tp in TOPIC else tp.split(",")[0].strip()
        rows.append([f"B{qb['num']}{lab.strip('()')}", SUBSTRAND, CS_BY_TOPIC[key],
                     f"{IND[key]} - {IND_TEXT[key]}", TOPIC[key], cog, mk])
add_table(hdr, rows, widths=[0.35, 0.75, 0.75, 1.75, 1.4, 0.8, 0.35], size=7, head_size=7.5)

doc.add_page_break()

# ----------------------------------------------------------------- helpers
def topic_totals():
    m = {k: 0 for k in TOPIC}; it = {k: 0 for k in TOPIC}
    for q in MCQ:
        m[q[3]] += 1; it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk; it[key] += 1
    return m, it

def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}; b = {k: 0 for k in order}
    for q in MCQ: a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: b[cog] += mk
    return order, a, b

def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ: d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: d[diff] += mk
    return d

m, it = topic_totals(); diff = difficulty_totals(); order, ca, cb = cognitive_by_section()

para("SUMMARY 1 - COVERAGE BY CURRICULUM AREA (TOPIC)", size=12, bold=True, space_after=4)
rows = [[TOPIC[k], it[k], m[k], f"{(m[k]/100)*100:.1f}%", CC[k]] for k in TOPIC]
rows.append(["TOTAL", sum(it.values()), sum(m.values()), "100%", "-"])
add_table(["Topic / Content Area", "No. of Items", "Marks", "% of Total Marks", "Core Competencies"],
          rows, widths=[2.7, 0.8, 0.6, 1.0, 1.1], size=8.5)
para("CC = Communication and Collaboration; CP = Critical Thinking and Problem Solving; "
     "DL = Digital Literacy; CI = Creativity and Innovation.", size=8.5, italic=True, space_after=2)

para("", space_after=8)
para("SUMMARY 2 - COGNITIVE-LEVEL DISTRIBUTION (Bloom's Taxonomy)", size=12, bold=True, space_after=4)
rows = []
for lv in order:
    tot = ca[lv] + cb[lv]
    rows.append([lv, ca[lv], cb[lv], tot, f"{(tot/100)*100:.1f}%"])
rows.append(["TOTAL", sum(ca.values()), sum(cb.values()), sum(ca.values()) + sum(cb.values()), "100%"])
add_table(["Cognitive Level", "Section A Marks", "Section B Marks", "Total Marks", "% of Total"],
          rows, widths=[1.6, 1.3, 1.3, 1.1, 1.1], size=9.5)

para("", space_after=8)
para("SUMMARY 3 - DIFFICULTY DISTRIBUTION", size=12, bold=True, space_after=4)
rows = [[k, v, f"{(v/100)*100:.1f}%"] for k, v in diff.items()]
rows.append(["TOTAL", sum(diff.values()), "100%"])
add_table(["Difficulty", "Marks", "% of Total Marks"], rows, widths=[2.0, 1.2, 1.5], size=9.5)
para("Target in the master prompt: approximately 30% easy / 50% moderate / 20% challenging.",
     size=9, italic=True, space_after=2)

para("", space_after=8)
para("SUMMARY 4 - SECTION WEIGHTING", size=12, bold=True, space_after=4)
add_table(["Section", "Question Type", "Items", "Marks", "% of Total"],
          [["A", "Objective (multiple choice)", 40, 40, "40%"],
           ["B", "Theory / constructed response", 21, 60, "60%"],
           ["TOTAL", "-", 61, 100, "100%"]],
          widths=[0.9, 2.4, 0.8, 0.8, 1.0], size=9.5)

doc.add_page_break()

# ===================================================== QUALITY-CONTROL
para("QUALITY-CONTROL SUMMARY", size=13, bold=True, align="c", space_after=4)
para("Carried out against the 14-point validation list in the master prompt before the examination was "
     "finalised.", size=9.5, italic=True, space_after=8)

qc = [
 ("Does every question belong to the supplied curriculum scope?",
  "Yes. All 61 items - 40 objectives and 21 theory sub-questions - trace to Strand 5 (Humans "
  "and the Environment), Sub-Strand 3 (Science and Industry), topics 18.1-18.4, and to the "
  "single official B7 indicator B7/JHS1.5.3.1.1 under content standard B7/JHS1.5.3.1. Every "
  "Ghanaian scientist named is one the curriculum itself names in Exemplar 1."),
 ("Is the examination appropriate for the stated class?",
  "Yes. The B7 curriculum requires learners to discover and explain how careers in science "
  "can improve human conditions and to relate those careers to the work of great national and "
  "international scientists and science educators; to describe careers and relate them to "
  "national scientists through Exemplar 1 and to international scientists through "
  "presentations in Exemplar 2; to research and build a portfolio on the impact of science, "
  "technology and innovation in homes, schools, communities and the universe; and to identify "
  "the science and technology careers Ghana must focus on and give reasons. The four "
  "exemplars map to the four topics in order."),
 ("Are the questions genuinely BECE-style?",
  "Yes: Section A is 40 four-option objectives worth 1 mark each, and Section B is structured "
  "theory with sub-questions carrying printed mark allocations. There is a three-column "
  "completion table, several 'name' and 'state' items, and open tasks that require "
  "explanation, analysis, evaluation and design."),
 ("Are there enough application and reasoning questions?",
  "Yes. 38 of 100 marks (38%) are at Apply level or above (Apply 25, Analyse 4, Evaluate 5, "
  "Create 4). Create appears in Question 7(b), where pupils must design the portfolio; "
  "Analyse in Question 5(c), where they must trace a discovery through to the present day, and "
  "in Question 4(i)-(iv); and Evaluate in Question 6(b), where they must weigh training "
  "Ghanaian scientists against buying technology from abroad."),
 ("Are the MCQ distractors plausible?",
  "Yes. Distractors are drawn from the same content family as the key: a real job that is not "
  "based on science (A9, A39), a real university that is not the one the scientist worked at "
  "(A12, A14), a real scientist whose work belongs to a different field (A22, A23, A26, A27, "
  "A28, A30), and a real but weaker way of judging or doing something (A37, A40)."),
 ("Is there only one best answer for each MCQ?",
  "Yes. Every item was reviewed for a single defensible key, and each option list was checked "
  "so that the declared key sits on the correct answer. Special care was taken with A21, where "
  "three of the pairs are real Ghanaian scientists but only Anamuah-Mensah and Ossei-Anto "
  "share a field; with A30, where the work of three of the four scientists does reach a "
  "hospital but only Fleming's is used there every day; and with A40, where three of the "
  "options are things a group might really do but only one actually tests the oven."),
 ("Are the marks internally consistent?",
  "Yes. Section A = 40 items x 1 mark = 40. Section B = 9 + 8 + 9 + 8 + 9 + 6 + 11 = 60. "
  "Each Section B sub-question's printed marks match its marking-scheme allocation, and every "
  "N-mark sub-question asks for N things."),
 ("Does the total add up correctly?",
  "Yes: 40 + 60 = 100 marks, matching the stated total on the front page."),
 ("Are the answers in the answer key correct?",
  "Yes. All 40 objective keys and all 21 Section B answers were verified against the marking "
  "scheme. The facts about each named Ghanaian scientist were checked against published "
  "sources: Prof. Oduro at KNUST and her work on post-harvest losses and vitamin A, Prof. "
  "Allotey as the first Ghanaian full professor of mathematics and his work in computing "
  "education, and Prof. Addy at the University of Ghana as the first Ghanaian woman to reach "
  "a full professorship in natural science."),
 ("Does the marking scheme match the questions?",
  "Yes. Every Section B sub-question has an expected-answer list and a marking note covering "
  "partial credit, acceptable alternatives, common wrong answers and method marks. Question "
  "1(a) withholds the mark for any medical career, because the question excludes medicine; "
  "Question 1(c) gives 0 for 'he treats animals' with no link to people; Question 3(b) does "
  "not accept a research scientist where a science educator is asked for; Question 4(i) caps "
  "the answer at 1 for 'mathematics' alone; and Question 7(b) caps it at 1 if only one or two "
  "of home, school and community are covered."),
 ("Are the questions free from unnecessary ambiguity?",
  "Yes. Open items are anchored with 'name three', 'state two', 'give two', 'give three' and "
  "'suggest two' plus the mark allocation. Question 1(b) must be answered on the careers "
  "named in 1(a); Question 2(a) says the reason must fit what the stem tells us about Adjoa; "
  "Question 5(c) asks about the scientist named in 5(b); and Question 7(c) asks for two ways "
  "of checking AND two ways of presenting."),
 ("Are Ghanaian contexts used naturally and accurately?",
  "Yes: KNUST in Kumasi, the University of Ghana at Legon, UEW in Winneba and UCC in Cape "
  "Coast, the University of Cape Coast science educators, fishmongers and grinding mills, "
  "maize sold at market prices checked on a mobile phone, mobile money agents, boreholes and "
  "hand pumps, a village far from the national grid, kerosene lanterns, and charcoal and "
  "firewood as the comparison for a solar oven."),
 ("Has any content outside the supplied curriculum been introduced?",
  "No. Every item sits inside topics 18.1-18.4. Marie Curie, Isaac Newton, Louis Pasteur and "
  "Jane Goodall are offered only as accepted alternatives in the marking scheme, since the "
  "curriculum's own list ends with 'etc.', and no question depends on knowing them. No "
  "detailed chemistry, physics or biology is required; the demand is on careers, people and "
  "impact, which is what the content standard asks for."),
 ("Are the questions sufficiently varied?",
  "Yes. Item types include naming non-medical careers, describing what two of them do, "
  "explaining a veterinary doctor's benefit to people, matching careers to a pupil's "
  "interests, planning how to prepare for a science career, defining a science educator, "
  "naming Ghanaian science educators and their work, arguing why teachers matter, completing "
  "a four-blank table, justifying the study of international scientists, describing a "
  "contribution, tracing it to the present day, explaining why knowledge is shared, weighing "
  "local training against imported technology, listing changes in homes and communities, "
  "designing a portfolio, and planning how to check and present it."),
]
for i, (q, a) in enumerate(qc, start=1):
    p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(2)
    set_font(p.add_run(f"{i}. {q}"), 10.5, bold=True)
    p2 = doc.add_paragraph()
    p2.paragraph_format.left_indent = Inches(0.3); p2.paragraph_format.space_after = Pt(6)
    set_font(p2.add_run(a), 10)

para("", space_after=8)
para("EXAMINER NOTES (for the teacher, not for candidates)", size=11, bold=True, space_after=4)
for n in [
 "The curriculum names 'Paul Ratnei' among the international scientists in Exemplar 2. That "
 "name could not be found in any reference source and is very likely a typographical error in "
 "the curriculum document. No question here tests a contribution by him; he is accepted as a "
 "name in Question 5(b) and nowhere else, and the note says no contribution can be credited. "
 "If you know who was intended, teach the right name and accept it.",
 "Question 3 is the one that is easiest to mark wrongly. It asks for SCIENCE EDUCATORS, not "
 "research scientists, so Prof. Allotey and Prof. Oduro do not fit here even though they are "
 "the names pupils remember best. The science educators are Prof. Anamuah-Mensah, Prof. "
 "Ossei-Anto and Prof. Anthony-Krueger. Keep Question 3 and Question 4 apart when you teach "
 "them.",
 "Question 4(i) is the paper's most reliable discriminator. Prof. Allotey is MATHEMATICAL "
 "PHYSICS, not mathematics - the Allotey Formalism came from his work on soft X-ray "
 "spectroscopy, and he was the first Ghanaian full professor of mathematics but a physicist "
 "by research. The note gives 2 marks for mathematical physics and only 1 for 'physics' or "
 "'mathematics' alone.",
 "Question 1(c) looks easy and is not. Pupils write 'a veterinary doctor treats animals' and "
 "earn 0, because the question asks how that improves HUMAN life. The two marks are for the "
 "link - food, income, ploughing, or protection from diseases that pass from animals to "
 "people. Teach the link, not the job.",
 "Question 6(b) is deliberately open, and the strongest answers say Ghana needs BOTH - to buy "
 "technology that already exists and to train Ghanaians who can run it, repair it and "
 "eventually make their own. Credit any position that is argued, and do not mark down a pupil "
 "who disagrees with you.",
 "Question 5(c) is the Analyse item and it is harder than it looks. Pupils tend to repeat the "
 "contribution from 5(b) instead of tracing it to today. The note caps them at 1 for that. "
 "Push them to a concrete present-day example - antibiotics in a Ghanaian hospital, clean "
 "water and vaccination from Pasteur's germ theory.",
 "Topic weighting is 28 marks for 18.1, 27 for 18.2, 24 for 18.3 and 21 for 18.4. If you "
 "spent longer on science, technology and innovation than on careers, move marks towards "
 "Question 7.",
 "Three cheap activities that raise marks sharply: (1) give each group one Ghanaian scientist "
 "to research for ten minutes and let them present to the class, which teaches Questions 3 "
 "and 4 and satisfies the 'presentations' in the exemplars; (2) hand out a page of job "
 "advertisements cut from a newspaper and ask pupils which ones need science and why, which "
 "teaches Question 1; and (3) walk round the school listing every piece of technology and "
 "asking what people did before it existed, which teaches Question 7(a).",
 "This sub-strand has one content standard and one indicator, so it is a single paper and not "
 "split. The companion papers cover Sub-strand 2 (Human Health) in two parts and Sub-strands "
 "4 and 5 in one paper each.",
 "This version is a full rebuild. Every question is new, and none is repeated from the "
 "earlier version of this paper, so you can use either as a mock and the other as a "
 "second sitting without pupils seeing the same items twice.",
 "Edit the school name, academic year and examination title on page 1 before printing.",
 "This is an original, teacher-made mock. It is not a reproduction of any WAEC or NaCCA examination "
 "paper.",
]:
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Inches(0.3); p.paragraph_format.space_after = Pt(3)
    set_font(p.add_run("- " + n), 10)

doc.save("/home/user/Basic7_Integrated_Science_Mock_Strand5_ScienceAndIndustry.docx")
print("docx written")

print("Section A:", len(MCQ), "items")
print("Section B total:", sum(q["total"] for q in SECTION_B))
print("Topic marks:", m, "sum", sum(m.values()))
print("Difficulty:", diff, "sum", sum(diff.values()))
print("Cognitive A:", ca)
print("Cognitive B:", cb)
print("Answer counts:", counts)
print("Totals:", sum(m.values()), sum(diff.values()),
      sum(ca.values()) + sum(cb.values()))
