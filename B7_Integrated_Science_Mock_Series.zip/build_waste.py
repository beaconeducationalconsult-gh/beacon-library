# -*- coding: utf-8 -*-
"""Basic 7 Integrated Science mock - Strand 5 Sub-strand 1: WASTE MANAGEMENT.
Covers topics 16.1 to 16.4 (types of waste; good waste management practices; the science behind
waste management; and community waste management projects). 100 marks.
Indicators sourced from the official NaCCA Science CCP curriculum (B7/JHS1-B9/JHS3, Sept 2020),
Strand 5: Humans and the Environment, Sub-strand 1: Waste Management, printed page 44.
Content standard: B7/JHS1.5.1.1."""

SCHOOL = "[SCHOOL NAME]"
SUBJECT = "INTEGRATED SCIENCE (SCIENCE)"
EXAM = "END-OF-TERM MOCK EXAMINATION"
CLASS = "Basic 7 (JHS 1)"
TIME = "2 hours (Suggested: Section A - 40 min; Section B - 80 min)"
MARKS = "100"
YEAR = "2025/2026 Academic Year"

STRAND = "Humans and the Environment"
SUBSTRAND = "Waste Management"

TOPIC = {
    "16.1": "16.1 Types of Waste in the Environment",
    "16.2": "16.2 Good Waste Management Practices",
    "16.3": "16.3 The Science Behind Waste Management",
    "16.4": "16.4 Community Waste Management Projects",
}

CS = "B7/JHS1.5.1.1"
CS_BY_TOPIC = {k: "B7/JHS1.5.1.1" for k in ["16.1", "16.2", "16.3", "16.4"]}
CS_TEXT = ("Exhibit knowledge and skill of scientific basis for management practices of types of "
           "waste in the environment")

IND = {
    "16.1": "B7/JHS1.5.1.1.1 (Ex. 3)",
    "16.2": "B7/JHS1.5.1.1.1 (Ex. 1, 3)",
    "16.3": "B7/JHS1.5.1.1.1 (Ex. 3)",
    "16.4": "B7/JHS1.5.1.1.1 (Ex. 1, 2)",
}
IND_TEXT = {
    "16.1": "Apply information from research on good management practices of waste to make the "
            "environment clean. Ex. 3: Discuss how to manage types of waste and explain the "
            "science underlying it.",
    "16.2": "Apply information from research on good management practices of waste to make the "
            "environment clean. Ex. 1, 3: Research for information on good waste management "
            "practices; discuss how to manage types of waste and explain the science underlying "
            "it.",
    "16.3": "Apply information from research on good management practices of waste to make the "
            "environment clean. Ex. 3: Discuss how to manage types of waste and explain the "
            "science underlying it.",
    "16.4": "Apply information from research on good management practices of waste to make the "
            "environment clean. Ex. 1, 2: Research for information on good waste management "
            "practices and use it to carry out a project to make the environment clean; write a "
            "report for presentation on the outcome of the project carried out in Exemplar 1.",
}
CC = {"16.1": "CP, CC, DL, CI", "16.2": "CP, CC, DL, CI",
      "16.3": "CP, CC, DL, CI", "16.4": "CP, CC, DL, CI"}

# ---------------------------------------------------------------- SECTION A
# (question, [A,B,C,D], answer, topic, cognitive, difficulty)
MCQ = [
 ("Waste can best be described as",
  ["any material that is useful to man", "any material bought from the market",
   "any material that is no longer useful and is thrown away", "any liquid found in the environment"],
  "C", "16.1", "Remember", "Easy"),
 ("Which of the following is solid waste?",
  ["broken plastic bottles", "smoke from a fire", "noise from a loudspeaker",
   "water from a tap"],
  "A", "16.1", "Remember", "Easy"),
 ("Liquid waste includes",
  ["old newspapers", "coconut husks", "broken glass", "dirty water from the bathroom"],
  "D", "16.1", "Understand", "Moderate"),
 ("Gaseous waste includes",
  ["food remains", "smoke from burning refuse", "plastic bags", "empty tins"],
  "B", "16.1", "Remember", "Easy"),
 ("Biodegradable waste is waste that",
  ["can be broken down by bacteria and fungi", "cannot be broken down", "is made of plastic",
   "comes from a factory"],
  "A", "16.1", "Understand", "Moderate"),
 ("Which of these is biodegradable?",
  ["a glass bottle", "a polythene bag", "banana peels", "an iron nail"],
  "C", "16.1", "Apply", "Moderate"),
 ("Which of these is non-biodegradable?",
  ["grass cuttings", "maize husks", "orange peels", "a plastic bottle"],
  "D", "16.1", "Apply", "Easy"),
 ("E-waste is",
  ["waste from the farm", "waste from old electrical and electronic equipment",
   "waste from the kitchen", "waste from the hospital only"],
  "B", "16.1", "Understand", "Moderate"),
 ("Agricultural waste includes",
  ["old car tyres", "broken radios", "maize stalks and cocoa husks", "used batteries"],
  "C", "16.1", "Apply", "Moderate"),
 ("Hospital or medical waste includes",
  ["used syringes and needles", "coconut shells", "old clothes", "food remains"],
  "A", "16.1", "Remember", "Easy"),
 ("Sewage is best described as",
  ["rain water from the roof", "waste water and human waste from homes and toilets",
   "water used to irrigate a farm", "drinking water from a borehole"],
  "B", "16.1", "Understand", "Challenging"),

 ("Good waste management means",
  ["throwing all waste into the gutter", "burning every kind of waste",
   "leaving waste to pile up", "collecting, treating and disposing of waste safely"],
  "D", "16.2", "Understand", "Moderate"),
 ("The best way to deal with food remains from the kitchen is to",
  ["compost them", "throw them into the drain", "burn them in the open",
   "bury them under the house"],
  "A", "16.2", "Apply", "Moderate"),
 ("Waste bins in the community should be",
  ["left open", "covered and emptied regularly", "placed in the middle of the road",
   "filled with water"],
  "B", "16.2", "Understand", "Easy"),
 ("Sorting waste into different containers before disposal is called",
  ["recycling", "burning", "separation or segregation of waste", "composting"],
  "C", "16.2", "Remember", "Challenging"),
 ("One good waste management practice at home is to",
  ["buy more than is needed", "throw everything into one bin", "burn plastic at home",
   "keep separate containers for different kinds of waste"],
  "D", "16.2", "Apply", "Moderate"),
 ("Littering means",
  ["throwing waste on the ground in a public place", "putting waste into a bin",
   "composting food remains", "recycling plastic"],
  "A", "16.2", "Remember", "Easy"),
 ("Which of these is NOT a good waste management practice?",
  ["composting", "dumping refuse in a stream", "recycling", "segregating waste"],
  "B", "16.2", "Understand", "Easy"),
 ("Reusing a material means",
  ["throwing it away", "burning it", "using it again for the same or another purpose",
   "burying it"],
  "C", "16.2", "Understand", "Easy"),
 ("Recycling means",
  ["throwing waste into the sea", "storing waste at home", "burning waste in the open",
   "changing waste material into new useful products"],
  "D", "16.2", "Understand", "Moderate"),

 ("Biodegradable waste is broken down mainly by",
  ["sunlight", "the wind", "bacteria and fungi", "rain water"],
  "C", "16.3", "Remember", "Easy"),
 ("During the decomposition of waste, the waste is changed into",
  ["simple substances such as water, carbon dioxide and humus", "plastic", "glass", "iron"],
  "A", "16.3", "Understand", "Moderate"),
 ("Compost is",
  ["fresh food remains", "a kind of plastic", "burnt rubbish",
   "the dark, crumbly material formed when organic waste rots"],
  "D", "16.3", "Understand", "Easy"),
 ("A compost heap works best when it is",
  ["dry and open to the sun", "moist, warm and turned over from time to time",
   "sealed in a plastic bag", "soaked in chemicals"],
  "B", "16.3", "Understand", "Moderate"),
 ("Plastic waste does not rot in the soil because",
  ["it is too heavy", "it is too colourful", "micro-organisms cannot break it down",
   "it is buried too deep"],
  "C", "16.3", "Understand", "Moderate"),
 ("Burning plastic in the open is harmful because it",
  ["gives off poisonous gases", "makes the plastic heavier", "makes the plastic rot faster",
   "turns the plastic into compost"],
  "A", "16.3", "Apply", "Moderate"),
 ("When waste blocks a gutter, the likely result is",
  ["cleaner streets", "more rain", "faster decomposition", "flooding when it rains"],
  "D", "16.3", "Apply", "Easy"),
 ("Rotting waste attracts",
  ["bees and butterflies", "earthworms only", "houseflies, rats and other pests", "fish"],
  "C", "16.3", "Understand", "Easy"),
 ("One gas often given off by rotting waste is",
  ["oxygen", "methane", "nitrogen", "hydrogen"],
  "B", "16.3", "Remember", "Moderate"),
 ("Burying non-biodegradable waste in the ground is a poor method because",
  ["the waste stays there for a very long time and may pollute the soil",
   "it makes the soil rich at once", "it disappears in a few days",
   "it turns into compost immediately"],
  "A", "16.3", "Apply", "Moderate"),
 ("Cholera and dysentery can spread when",
  ["people eat too much fruit", "people sleep early", "people exercise",
   "drinking water is contaminated by human waste"],
  "D", "16.3", "Apply", "Challenging"),

 ("A community clean-up exercise is",
  ["a meeting to discuss farming",
   "an activity in which people come together to clean their environment", "a market day",
   "a funeral ceremony"],
  "B", "16.4", "Understand", "Easy"),
 ("Before a clean-up project starts, the group should",
  ["wait for the rain", "buy food", "plan the work and decide who does what", "dig a trench"],
  "C", "16.4", "Understand", "Moderate"),
 ("Tools needed for a clean-up exercise include",
  ["rakes, cutlasses, shovels and refuse bags", "hoes and watering cans only",
   "sprayers and pesticides", "machetes and guns"],
  "A", "16.4", "Remember", "Easy"),
 ("Used syringes and blades found during a clean-up should be",
  ["picked up with bare hands", "kicked into the bush", "left for children to collect",
   "handled with care and put into a proper sharp-proof container"],
  "D", "16.4", "Apply", "Moderate"),
 ("A report on a clean-up project should include",
  ["the names of the market women", "what was done, who took part and the outcome",
   "the price of food", "the weather for the whole year"],
  "B", "16.4", "Apply", "Moderate"),
 ("The main aim of a school environmental project is to",
  ["make the surroundings clean and teach good habits", "punish pupils",
   "raise money for the school", "close the school early"],
  "A", "16.4", "Understand", "Easy"),
 ("A clean-up exercise should end with the collected waste",
  ["left in a heap", "covered with soil", "carried away and disposed of properly",
   "burnt on the spot"],
  "C", "16.4", "Understand", "Moderate"),
 ("One lasting way to keep the environment clean after a project is to",
  ["clean only once a year", "mount dustbins and empty them regularly", "ban all markets",
   "close the roads"],
  "B", "16.4", "Apply", "Moderate"),
 ("Which of these would make a clean-up project unsafe?",
  ["wearing gloves", "working in groups", "carrying refuse bags",
   "picking up broken glass and blades with bare hands"],
  "D", "16.4", "Analyse", "Challenging"),
]

# ------------------------------------------------ SECTION B DIAGRAM + TABLE
PIT = [
    "      +-------------------------------------+",
    "      |  /\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\  | <-- (i)",
    "      +-------------------------------------+",
    "      |                                     |",
    "      |   ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~   | <-- (ii)",
    "      |   ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~   |",
    "      +-------------------------------------+",
    "      |                                     |",
    "      |   : : : : : : : : : : : : : : : :   | <-- (iii)",
    "      |   : : : : : : : : : : : : : : : :   |",
    "      +-------------------------------------+",
    "      ///////////////////////////////////////",
    "                   the ground"
]
PIT_KEY = "(i) top covering of soil or dry grass, (ii) the organic waste, (iii) bottom layer of coarse dry material"

WASTE_HEADERS = ["Type of waste", "Biodegradable or non-biodegradable"]
WASTE_ROWS = [
 ["Kitchen waste (food remains, vegetable peels)", "(i)"],
 ["Plastic waste (polythene bags, plastic bottles)", "(ii)"],
 ["Paper waste (old exercise books, newspapers)", "(iii)"],
 ["Metal waste (empty tins, scrap iron)", "(iv)"],
 ["Glass waste (broken bottles)", "(v)"],
 ["Garden waste (dry leaves, maize husks)", "(vi)"],
]

# ---------------------------------------------------------------- SECTION B
SECTION_B = [
 dict(
   num=1, total=9, topic="16.1",
   stem="Waste is found everywhere in the environment - in homes, in schools, in markets and on "
        "farms.",
   parts=[
     ("(a)", "Name four types of waste found in the environment.", 4, "Remember", "16.1", "Easy"),
     ("(b)", "Explain the difference between biodegradable waste and non-biodegradable waste, "
             "giving one example of each.", 5, "Understand", "16.1", "Moderate"),
   ]),
 dict(
   num=2, total=8, topic="16.1",
   stem="The table below shows some common types of waste. Study it and answer the questions "
        "that follow.",
   table="waste",
   parts=[
     ("(a)", "Copy and complete the table.", 6, "Understand", "16.1", "Challenging"),
     ("(b)", "Name two sources of waste in your community and state one type of waste from each.",
      2, "Apply", "16.1", "Easy"),
   ]),
 dict(
   num=3, total=9, topic="16.2",
   stem="Good waste management keeps the environment clean and protects the health of the people "
        "living in it.",
   parts=[
     ("(a)", "State four good waste management practices.", 4, "Understand", "16.2", "Moderate"),
     ("(b)", "Explain why waste should not be thrown into gutters and drains.",
      3, "Understand", "16.2", "Moderate"),
     ("(c)", "State two things a household can do to reduce the amount of waste it produces.",
      2, "Apply", "16.2", "Easy"),
   ]),
 dict(
   num=4, total=8, topic="16.2",
   stem="Three words are used again and again whenever waste is discussed: reduce, reuse and "
        "recycle.",
   parts=[
     ("(a)", "Explain what is meant by each of the following, and give one example of each: "
             "reduce; reuse; recycle.", 6, "Understand", "16.2", "Challenging"),
     ("(b)", "State two reasons why recycling is better than burning waste in the open.",
      2, "Evaluate", "16.2", "Moderate"),
   ]),
 dict(
   num=5, total=9, topic="16.3",
   stem="Fig. 1 shows how organic waste can be turned into compost. Study it and answer the "
        "questions that follow.",
   diagram=True,
   parts=[
     ("(a)", "Name the parts labelled (i), (ii) and (iii) in Fig. 1.",
      3, "Understand", "16.3", "Moderate"),
     ("(b)", "Explain how the waste in the pit is broken down.", 3, "Understand", "16.3",
      "Moderate"),
     ("(c)", "Explain why plastic waste does not rot the way food remains do.",
      3, "Analyse", "16.3", "Moderate"),
   ]),
 dict(
   num=6, total=7, topic="16.3",
   stem="When waste is not managed well, it causes problems for people and for the environment.",
   parts=[
     ("(a)", "State three problems caused by poor waste management.",
      3, "Understand", "16.3", "Moderate"),
     ("(b)", "Explain why burying waste in a hole in the ground is not always a good way of "
             "getting rid of it.", 4, "Apply", "16.3", "Moderate"),
   ]),
 dict(
   num=7, total=10, topic="16.4",
   stem="Your class has decided to carry out a project to make the school environment clean.",
   parts=[
     ("(a)", "Describe how you would plan and carry out the project, from the beginning to the "
             "end.", 4, "Create", "16.4", "Challenging"),
     ("(b)", "State three things your class would need for the project.",
      3, "Remember", "16.4", "Easy"),
     ("(c)", "After the project, your class must write a report for presentation. State three "
             "things the report should contain.", 3, "Understand", "16.4", "Easy"),
   ]),
]

# ------------------------------------------------------- MARKING SCHEME
MARKING = {
 1: [
   ("(a)", ["Solid waste, e.g. plastic bottles, tins, paper and food remains.",
            "Liquid waste, e.g. dirty water from the bathroom and from washing.",
            "Gaseous waste, e.g. smoke from burning refuse and fumes from vehicles.",
            "Biodegradable waste, e.g. food remains, leaves and crop residues.",
            "Non-biodegradable waste, e.g. plastics, glass and metals.",
            "Household or domestic waste, e.g. rubbish from the home.",
            "Agricultural waste, e.g. maize stalks, cocoa husks and animal droppings.",
            "Industrial waste, e.g. waste from factories and workshops.",
            "Medical or hospital waste, e.g. used syringes, needles and dressings.",
            "E-waste, e.g. broken radios, phones, batteries and old computers.",
            "Sewage, e.g. waste water and human waste from toilets and drains."],
    "1 mark each for any FOUR correct types of waste (4 marks). A type named without an example "
    "still earns the mark, but a named example with no type does not. Do NOT accept two examples "
    "of the same type counted twice."),
   ("(b)", ["Biodegradable waste is waste that can be broken down or rotted by bacteria and "
            "fungi, e.g. food remains, leaves, grass cuttings.",
            "Non-biodegradable waste is waste that cannot be broken down by living organisms, "
            "e.g. plastic bags, glass, metals.",
            "Biodegradable waste rots and disappears after a time; non-biodegradable waste stays "
            "in the environment for a very long time.",
            "Biodegradable waste can be composted into manure; non-biodegradable waste has to be "
            "recycled or dumped."],
    "1 mark each for any FIVE correct points (5 marks). One mark is reserved for a correct "
    "example of biodegradable waste and one for a correct example of non-biodegradable waste; "
    "award at most 4 marks if either example is missing or wrong."),
 ],
 2: [
   ("(a)", ["(i) biodegradable", "(ii) non-biodegradable", "(iii) biodegradable",
            "(iv) non-biodegradable", "(v) non-biodegradable", "(vi) biodegradable"],
    "1 mark each for any SIX correct entries (6 marks). The blank number must be matched to the "
    "answer. Paper and garden waste are biodegradable; plastic, metal and glass are not."),
   ("(b)", ["The home or household - food remains, polythene bags, dirty water.",
            "The market - vegetable leaves, broken crates, polythene bags.",
            "The school - used paper, broken furniture, food wrappers.",
            "The farm - maize stalks, cocoa husks, animal droppings.",
            "The hospital or clinic - used syringes, dressings, medicine containers.",
            "The workshop or factory - scrap metal, used oil, off-cuts."],
    "1 mark for each of TWO correct sources with a matching type of waste (2 marks). Accept any "
    "genuine source in the community; the waste named must actually come from that source."),
 ],
 3: [
   ("(a)", ["Sort or segregate waste into different containers at the point of disposal.",
            "Put waste into covered bins and empty the bins regularly.",
            "Compost biodegradable waste such as food remains and garden waste.",
            "Reuse materials such as bottles, bags and containers instead of throwing them away.",
            "Recycle materials such as paper, plastics, glass and metals.",
            "Dispose of hazardous waste such as batteries and medicines separately and safely.",
            "Do not litter: put waste into a bin and not on the ground.",
            "Clean gutters and drains so that water can flow freely."],
    "1 mark each for any FOUR correct practices (4 marks). The practice must be something that is "
    "DONE, not merely a reason for doing it; 'it keeps the environment clean' on its own earns "
    "nothing."),
   ("(b)", ["Waste in a gutter blocks the flow of water, so rain water cannot drain away.",
            "Blocked gutters overflow and cause flooding in the streets and in homes.",
            "Standing dirty water becomes a breeding place for mosquitoes, which spread malaria.",
            "The rotting waste smells and attracts houseflies, rats and other pests.",
            "Blocked drains can burst and carry waste into water people use for drinking and "
            "cooking."],
    "1 mark each for any THREE correct points (3 marks). The key chain is: waste blocks the "
    "drain, water cannot flow, and the result is flooding and disease."),
   ("(c)", ["Buy only what the household needs, so that less is thrown away.",
            "Buy goods with little or no wrapping, or with wrapping that can be recycled.",
            "Compost food remains instead of putting them out with the rubbish.",
            "Reuse bags, bottles and containers instead of buying new ones each time.",
            "Repair items such as clothes and furniture rather than replacing them."],
    "1 mark each for any TWO correct points (2 marks). The key idea is producing LESS waste in "
    "the first place, not disposing of it better."),
 ],
 4: [
   ("(a)", ["REDUCE means producing less waste in the first place, e.g. buying only what is "
            "needed.",
            "REUSE means using an item again for the same or a different purpose instead of "
            "throwing it away, e.g. using an old margarine tin to store salt.",
            "RECYCLE means collecting waste material and changing it into new useful products, "
            "e.g. melting old aluminium to make new pans.",
            "Reduce comes first, then reuse, then recycle: it is better not to create the waste "
            "at all.",
            "Each of the three keeps material out of the dump and saves resources."],
    "1 mark each for any SIX correct points (6 marks). Two marks are available for each of the "
    "three terms - one for the meaning and one for the example - so a pupil who explains all "
    "three correctly but gives no examples scores 3."),
   ("(b)", ["Recycling turns the material into something useful; burning destroys it.",
            "Burning plastic and other waste gives off poisonous gases that harm people.",
            "Burning adds smoke and ash to the air and causes air pollution; recycling does not.",
            "Recycling saves raw materials and energy; burning wastes both.",
            "Recycling keeps the environment clean; open burning leaves a dirty, smelly heap."],
    "1 mark each for any TWO correct points (2 marks). Accept the answer only if it compares "
    "recycling with burning, not merely praising recycling."),
 ],
 5: [
   ("(a)", ["(i) the top layer - a covering of soil, dry grass or dry leaves",
            "(ii) the middle layer - the organic waste being composted, such as food remains "
            "and green leaves",
            "(iii) the bottom layer - coarse dry material such as stalks, husks and dry grass"],
    "1 mark each for all THREE correct labels (3 marks). Accept any answer that correctly "
    "identifies the MIDDLE layer as the waste being composted and the TOP layer as a covering; "
    "if a pupil reverses the top and bottom layers but gets the middle right, award 2 marks. Do "
    "NOT accept 'compost' for any of the three - compost is what the pit PRODUCES."),
   ("(b)", ["Bacteria and fungi in the soil feed on the waste and break it down.",
            "The waste is changed into simple substances such as water, carbon dioxide and "
            "humus.",
            "The process is called decomposition, and it needs moisture, warmth and air to go "
            "well.",
            "The heap is turned over from time to time to let air in and to mix the materials.",
            "After some weeks the waste becomes a dark, crumbly material called compost."],
    "1 mark each for any THREE correct points (3 marks). The two ideas to look for are "
    "MICRO-ORGANISMS doing the breaking down and the conditions (moist, warm, air) that let them "
    "work."),
   ("(c)", ["Plastic is made of long chains of molecules that bacteria and fungi cannot digest.",
            "The micro-organisms that rot food remains have no way of breaking plastic down.",
            "So plastic stays in the soil for a very long time instead of rotting away.",
            "Food remains are made of the same kind of material as living things, so "
            "micro-organisms can feed on them easily.",
            "Plastic may break into small pieces, but it does not rot into simple substances."],
    "1 mark each for any THREE correct points (3 marks). The key idea is that there are no "
    "micro-organisms that can digest plastic. Do NOT accept 'plastic is too strong' or 'plastic "
    "is too hard'."),
 ],
 6: [
   ("(a)", ["Blocked gutters and drains cause flooding when it rains.",
            "Rotting waste smells and makes the environment unpleasant.",
            "Waste attracts houseflies, rats and other pests that spread disease.",
            "Standing dirty water breeds mosquitoes, which spread malaria.",
            "Waste can pollute streams, rivers and the soil, and poison drinking water.",
            "Diseases such as cholera, dysentery and typhoid can spread.",
            "Burning waste pollutes the air and can cause fires to spread.",
            "The environment becomes ugly and spoils the beauty of the community."],
    "1 mark each for any THREE correct points (3 marks). Accept any sensible problem caused by "
    "poor waste management."),
   ("(b)", ["Non-biodegradable waste such as plastic and glass does not rot, so it stays in the "
            "ground for many years.",
            "The waste can release harmful liquids that soak into the soil and pollute it.",
            "That liquid can reach a stream or a borehole and poison the water people drink.",
            "The buried waste takes up space and the land cannot be used for building or "
            "farming.",
            "Rotting waste underground gives off gases such as methane, which can be dangerous.",
            "Animals may dig the waste up and scatter it around again.",
            "A shallow hole may be washed open by rain, exposing the waste."],
    "1 mark each for any FOUR correct points (4 marks). The key ideas are that the waste does "
    "not disappear, and that it can poison the soil and the water."),
 ],
 7: [
   ("(a)", ["Hold a class meeting to agree on the aim and to choose the area to be cleaned.",
            "Walk round the area first and list what needs to be done.",
            "Share out the work: who collects, who carries, who sorts, who records.",
            "Collect the tools and the refuse bags the class will need.",
            "Work in groups, wearing gloves and boots, and keep clear of anything sharp or "
            "dangerous.",
            "Sort the waste collected into what can be composted, what can be recycled and what "
            "must be dumped.",
            "Carry the waste away and dispose of it properly - do not leave it in a new heap.",
            "Mount or arrange for dustbins so that the area stays clean afterwards.",
            "Write the report and present it to the class or to the school."],
    "1 mark each for any FOUR correct points (4 marks). This is a design task: award method "
    "marks for any sensible plan. Look for at least ONE point about planning or preparing and at "
    "least ONE point about what happens to the waste afterwards; award at most 3 marks if the "
    "answer stops at 'we will sweep the compound'. Safety earns a mark."),
   ("(b)", ["Refuse bags or sacks", "Rakes", "Cutlasses", "Shovels or spades", "Wheelbarrows",
            "Gloves and boots", "Nose covers or face masks", "A first-aid box",
            "Separate containers or bins for sorting the waste", "Water to drink"],
    "1 mark each for any THREE correct items (3 marks). Accept any sensible item the class would "
    "genuinely need."),
   ("(c)", ["The aim of the project, or what the class set out to do.",
            "The area that was cleaned and when the work was done.",
            "The names or number of the people who took part.",
            "The tools and materials that were used.",
            "The kinds and amounts of waste that were collected.",
            "What was done with the waste afterwards.",
            "Any problems met and what the class would do differently next time.",
            "What the class recommends so that the area stays clean."],
    "1 mark each for any THREE correct points (3 marks). Accept any three sensible contents of a "
    "project report."),
 ],
}


# --------------------------------------------- derive summary statistics
def topic_totals():
    m = {k: 0 for k in TOPIC}
    it = {k: 0 for k in TOPIC}
    for q in MCQ:
        m[q[3]] += 1
        it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk
            it[key] += 1
    return m, it


def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}
    b = {k: 0 for k in order}
    for q in MCQ:
        a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            b[cog] += mk
    return order, a, b


def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ:
        d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            d[diff] += mk
    return d
