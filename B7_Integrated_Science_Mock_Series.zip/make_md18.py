# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "/home/user")
from build_health import *

L = []
def w(s=""): L.append(s)

w(f"# {SCHOOL}"); w()
w(f"## {SUBJECT}"); w()
w(f"### {EXAM}"); w()
w(f"**Class:** {CLASS}  ")
w(f"**Time:** {TIME}  ")
w(f"**Total Marks:** {MARKS}  ")
w(f"**Academic Year:** {YEAR}"); w()
w("---"); w()
w("### INSTRUCTIONS"); w()
for i, t in enumerate([
    "Write your name and class clearly in the spaces provided on your answer sheet.",
    "This paper has TWO sections: Section A and Section B.",
    "Answer ALL the questions in both sections.",
    "Section A has 40 multiple-choice questions. Each question carries 1 mark. Choose the best answer (A, B, C or D) and record it on the answer sheet provided.",
    "Section B has 7 theory questions totalling 60 marks. Write your answers clearly and neatly in your answer booklet. Draw and label diagrams or tables where you are asked to.",
    "Read every question carefully before you answer it.",
    "Do not use correction fluid. Cancel any mistake neatly with a single line.",
    "Hand in your answer sheet and your answer booklet at the end of the examination.",
], start=1):
    w(f"{i}. {t}")
w(); w("---"); w()

w("## SECTION A: OBJECTIVE TEST (40 marks)"); w()
w("*Answer ALL questions. Each question carries 1 mark. Choose the BEST answer and write its letter "
  "(A, B, C or D) against the question number on your answer sheet.*"); w()
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"**{i}. {q}**"); w()
    for j, o in enumerate(opts): w(f"{'ABCD'[j]}. {o}")
    w()
w("---"); w()

w("## SECTION B: THEORY (60 marks)"); w()
w("*Answer ALL questions. Write your answers in your answer booklet. The marks for each question are shown "
  "in brackets.*"); w()
for qb in SECTION_B:
    w(f"### Question {qb['num']}  [{qb['total']} marks]"); w()
    w(qb["stem"]); w()
    if qb.get("table") == "nutrient":
        w("| " + " | ".join(NUTRIENT_HEADERS) + " |")
        w("| " + " | ".join(["---"] * len(NUTRIENT_HEADERS)) + " |")
        for r in NUTRIENT_ROWS:
            w("| " + " | ".join(r) + " |")
        w()
        w("*Table 1: Food nutrients and their work in the body*"); w()
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        w(f"**{lab}** {text}  **[{mk} mark{'s' if mk > 1 else ''}]**"); w()
w("---"); w()

w("## ANSWER KEY"); w()
w("### Section A - Objective Test"); w()
w("| Question | Answer | Curriculum Area (Topic) | Cognitive Level |")
w("| -------- | ------ | ----------------------- | --------------- |")
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"| {i} | {ans} | {TOPIC[tp]} | {cog} |")
counts = {L2: sum(1 for q in MCQ if q[2] == L2) for L2 in "ABCD"}
w()
w("Correct-answer distribution: " + ", ".join(f"{L2} = {counts[L2]}" for L2 in "ABCD") + " (40 items).")
w()
w("### Section B - Theory (summary answers; full detail in the Marking Scheme)"); w()
w("| Question | Expected Answer | Curriculum Area | Cognitive Level |")
w("| -------- | --------------- | --------------- | --------------- |")
sba = [
 ("1 (a)", "Carbohydrates; proteins; fats and oils (fatty acids); vitamins; mineral salts; water; roughage or fibre.", "17.1", "Remember"),
 ("1 (b)", "Any three matched correctly: carbohydrate - provides energy for work, play and warmth; protein - builds the body and repairs worn-out tissues; fat and oil - provides energy, keeps the body warm, helps absorb some vitamins; vitamin - protects the body and keeps parts such as the eyes and gums healthy; mineral salt - builds bones and teeth and helps make blood; water - carries substances round the body; roughage - keeps food moving through the gut.", "17.1", "Understand"),
 ("1 (c)", "A growing child is making new tissue all the time, and protein is the nutrient the body uses to build and repair tissue. Without enough protein the child stops growing properly, becomes weak, and may develop kwashiorkor.", "17.1", "Understand"),
 ("2 (a)", "(i) rice, maize, yam, cassava, plantain, gari or bread. (ii) fish, meat, eggs, beans, groundnuts, soya beans or milk. (iii) growth, and the repair and replacement of worn-out body tissues. (iv) palm oil, groundnut oil, coconut, shea butter or margarine. (v) provides energy, keeps the body warm and helps the body absorb some vitamins. (vi) liver, eggs, milk, red palm oil, carrots, mango, pawpaw or dark green leafy vegetables.", "17.1", "Understand"),
 ("2 (b)", "Any two with a correct source: iron - liver, beans, dark green leafy vegetables, fish, meat, eggs; calcium - milk, fish with soft bones, groundnuts, green leafy vegetables; iodine - iodised salt, sea fish; phosphorus - milk, fish, eggs, meat, beans.", "17.1", "Apply"),
 ("3 (a)", "A deficiency disease is an illness caused by a lack of an essential nutrient in the diet. It is not caught from another person and it is not caused by germs; it happens when the body does not get enough of a nutrient over a long period, and it can be prevented or cured by eating the missing nutrient.", "17.2", "Understand"),
 ("3 (b)", "Any three: not eating enough food in general; not eating enough of one particular nutrient; eating the same few foods all the time; poverty, so the family cannot afford the needed foods; poor feeding habits; ignorance of what makes a balanced diet; illness that stops the body absorbing the nutrient.", "17.2", "Understand"),
 ("3 (c)", "No single food contains all the classes of nutrient the body needs, so a person who eats only one kind of food gets plenty of one nutrient but misses the others. The missing nutrient is the one that causes the deficiency disease, so eating a variety of foods makes sure that all the nutrients are present.", "17.2", "Understand"),
 ("4 (a)", "SYMPTOMS are the signs that can be seen or felt in the patient and that the doctor or nurse looks for, such as pale eyes or bleeding gums. EFFECTS are what the disease does to the body and to the person's life, such as a child failing to grow or being too weak to walk to school.", "17.2", "Understand"),
 ("4 (b)", "Teaching families to eat a balanced diet is better, because a balanced diet gives all the nutrients and not only the ones in the tablet, because the habit lasts for life while tablets stop when the supply stops, and because local foods are cheaper and always available. Tablets help in an emergency but teach the family nothing.", "17.2", "Evaluate"),
 ("5 (a)", "Night blindness - lack of vitamin A. Rickets - lack of vitamin D, together with calcium and phosphorus. Scurvy - lack of vitamin C.", "17.3", "Understand"),
 ("5 (b)", "Night blindness - the child cannot see clearly in dim light or after dusk and bumps into things. Rickets - the bones are soft and bent, giving bow legs or a bent spine. Scurvy - the gums swell and bleed, teeth may loosen, and wounds heal slowly.", "17.3", "Remember"),
 ("5 (c)", "Eat foods containing vitamin D such as fish, egg yolk and milk, and foods containing calcium and phosphorus such as milk, fish with soft bones, groundnuts and green leafy vegetables. Let the skin get some gentle morning sunlight, which helps the body make its own vitamin D, and take a child with soft or bent bones to the clinic.", "17.3", "Apply"),
 ("6 (a)", "Kwashiorkor is caused by a lack of PROTEIN. The belly swells with fluid, the arms and legs become very thin, the hair becomes dry and reddish, and the child stops growing and loses interest in food.", "17.3", "Understand"),
 ("6 (b)", "Iron is needed to make haemoglobin, the red substance in the blood that carries oxygen. Without enough iron the body cannot make enough healthy red blood cells, so the blood carries less oxygen. Without oxygen the cells cannot release energy from food, so the child has little energy, tires quickly, feels weak and looks pale.", "17.3", "Analyse"),
 ("6 (c)", "Any two: liver; beans and other legumes; dark green leafy vegetables such as kontomire or alefu; fish; meat; eggs; groundnuts; fortified cereals or flour.", "17.3", "Remember"),
 ("7 (a)", "The children with swollen bellies, thin arms and legs and reddish hair have KWASHIORKOR, caused by a lack of PROTEIN. The children who cannot find their way in the evening have NIGHT BLINDNESS, caused by a lack of VITAMIN A.", "17.3", "Apply"),
 ("7 (b)", "Tell the families to add protein foods such as beans, groundnuts, fish, eggs or soya to the children's meals, and foods rich in vitamin A such as red palm oil, eggs, liver, dark green leafy vegetables, mango and pawpaw. Show them how to mix the foods they already grow, explain that the children will then get the nutrients they are missing and will grow properly again, advise them to take the worst-affected children to the clinic, and suggest a demonstration meal at the next community meeting.", "17.3", "Create"),
]
for r in sba: w(f"| {r[0]} | {r[1]} | {r[2]} | {r[3]} |")
w(); w("---"); w()

w("## MARKING SCHEME - SECTION B (60 marks)"); w()
w("*General rules: (1) Accept any other correct and relevant answer. (2) Award marks for correct points, not "
  "for repeating the question. (3) For procedures, award method marks. (4) Do not deduct marks for spelling "
  "unless the meaning is changed. (5) Where a candidate gives more answers than are asked for, mark only the "
  "first ones up to the number required.*"); w()
for qb in SECTION_B:
    n = qb["num"]
    w(f"### Question {n} ({qb['total']} marks)"); w()
    for (lab, points, note) in MARKING[n]:
        mkv = [p_[2] for p_ in qb["parts"] if p_[0] == lab]
        head = f"**{lab}**"
        if mkv: head += f" [{mkv[0]} mark{'s' if mkv[0] > 1 else ''}]"
        w(head); w()
        for pt in points: w(f"- {pt}")
        w(f"  - *Marking note: {note}*"); w()
w("---"); w()

w("## CURRICULUM ASSESSMENT BLUEPRINT"); w()
w(f"**Strand:** {STRAND} | **Sub-strand:** {SUBSTRAND} | **Class:** {CLASS}"); w()
w(f"**Content Standard:** {CS} - {CS_TEXT}"); w()
w("> Source: NaCCA Science Common Core Programme Curriculum (B7/JHS1-B9/JHS3), September 2020, "
  "Strand 5: Humans and the Environment, Sub-strand 2: Human Health "
  "(topics 17.1-17.3), p. 45. Indicators are quoted, not invented."); w()

w("### Section A"); w()
w("| Qn | Sub-strand | Content Standard | Indicator (NaCCA) - Indicator Text | Topic / Content | Cognitive Level | Marks |")
w("| -- | ---------- | ---------------- | ---------------------------------- | --------------- | --------------- | ----- |")
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"| A{i} | {SUBSTRAND} | {CS_BY_TOPIC[tp]} | {IND[tp]} - {IND_TEXT[tp]} | {TOPIC[tp]} | {cog} | 1 |")
w()
w("### Section B"); w()
w("| Qn | Sub-strand | Content Standard | Indicator (NaCCA) - Indicator Text | Topic / Content | Cognitive Level | Marks |")
w("| -- | ---------- | ---------------- | ---------------------------------- | --------------- | --------------- | ----- |")
for qb in SECTION_B:
    for (lab, text, mkv, cog, tp, diff) in qb["parts"]:
        key = tp if tp in TOPIC else tp.split(",")[0].strip()
        w(f"| B{qb['num']}{lab.strip('()')} | {SUBSTRAND} | {CS_BY_TOPIC[key]} | {IND[key]} - {IND_TEXT[key]} | {TOPIC[key]} | {cog} | {mkv} |")
w(); w("---"); w()

def topic_totals():
    m = {k: 0 for k in TOPIC}; it = {k: 0 for k in TOPIC}
    for q in MCQ: m[q[3]] += 1; it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk; it[key] += 1
    return m, it

def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}; b = {k: 0 for k in order}
    for q in MCQ: a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: b[cog] += mk
    return order, a, b

def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ: d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: d[diff] += mk
    return d

m, it = topic_totals(); diff_ = difficulty_totals(); order, ca, cb = cognitive_by_section()

w("### Summary 1 - Coverage by Curriculum Area (Topic)"); w()
w("| Topic / Content Area | No. of Items | Marks | % of Total Marks | Core Competencies |")
w("| -------------------- | ------------ | ----- | ---------------- | ----------------- |")
for k in TOPIC: w(f"| {TOPIC[k]} | {it[k]} | {m[k]} | {(m[k]/100)*100:.1f}% | {CC[k]} |")
w(f"| **TOTAL** | **{sum(it.values())}** | **{sum(m.values())}** | **100%** | - |")
w()
w("*CC = Communication and Collaboration; CP = Critical Thinking and Problem Solving; DL = Digital Literacy; "
  "CI = Creativity and Innovation.*"); w()
w("### Summary 2 - Cognitive-Level Distribution (Bloom's Taxonomy)"); w()
w("| Cognitive Level | Section A Marks | Section B Marks | Total Marks | % of Total |")
w("| --------------- | --------------- | --------------- | ----------- | ---------- |")
for lv in order:
    tot = ca[lv] + cb[lv]
    w(f"| {lv} | {ca[lv]} | {cb[lv]} | {tot} | {(tot/100)*100:.1f}% |")
w(f"| **TOTAL** | **{sum(ca.values())}** | **{sum(cb.values())}** | **{sum(ca.values())+sum(cb.values())}** | **100%** |")
w()
w("### Summary 3 - Difficulty Distribution"); w()
w("| Difficulty | Marks | % of Total Marks |")
w("| ---------- | ----- | ---------------- |")
for k, v in diff_.items(): w(f"| {k} | {v} | {(v/100)*100:.1f}% |")
w(f"| **TOTAL** | **{sum(diff_.values())}** | **100%** |")
w()
w("*Target in the master prompt: approximately 30% easy / 50% moderate / 20% challenging.*"); w()
w("### Summary 4 - Section Weighting"); w()
w("| Section | Question Type | Items | Marks | % of Total |")
w("| ------- | ------------- | ----- | ----- | ---------- |")
w("| A | Objective (multiple choice) | 40 | 40 | 40% |")
w("| B | Theory / constructed response | 18 | 60 | 60% |")
w("| **TOTAL** | - | **58** | **100** | **100%** |")
w(); w("---"); w()

w("## QUALITY-CONTROL SUMMARY")
w("")
w("| Check | Status |")
w("| --- | --- |")
for q_, a_ in [
 ("Every question within supplied curriculum scope",
  "Yes - all 58 items (40 objectives and 18 theory sub-questions) sit in topics 17.1-17.3 of Strand 5, Sub-Strand 2 (Human Health), under content standard B7/JHS1.5.2.1, mapped to indicator B7/JHS1.5.2.1.1. Only deficiency diseases are tested; viral diseases, COVID-19, Ebola, H1N1 and management roles belong to the companion paper on B7/JHS1.5.2.2"),
 ("Appropriate for the class",
  "Yes - B7 level; no viral diseases, no COVID-19, no Ebola or H1N1, no pandemics and no vaccination"),
 ("Genuinely BECE-style",
  "Yes - 40 four-option objectives plus structured theory with printed mark allocations, a three-column completion table, several 'state' and 'name' items, and open tasks requiring explanation, judgement and planning"),
 ("Sufficient application and reasoning",
  "Yes - 33 of 100 marks (33%) at Apply level or above (Apply 21, Analyse 4, Evaluate 4, Create 4)"),
 ("Plausible MCQ distractors",
  "Yes - the function of a different nutrient, a different deficiency disease, a real nutrient that does not cause the disease named, a real cause that is not the one asked for, and a genuine activity that is simply not a cause"),
 ("Single best answer per MCQ",
  "Yes - reviewed item by item and each option list was checked so that the declared key sits on the correct answer; the word 'only' rules out 'build teeth and bones' in A5, scurvy, kwashiorkor and night blindness are all vitamin or protein deficiencies in A22 so that only iron-deficiency anaemia is a mineral deficiency, and vitamin D is given together with calcium in A24 so the answer is complete"),
 ("Marks internally consistent",
  "Yes - Section A 40 x 1 = 40; Section B 10 + 8 + 9 + 8 + 9 + 8 + 8 = 60; sub-question marks match the marking scheme"),
 ("Total adds up correctly",
  "Yes - 40 + 60 = 100"),
 ("Answer key correct",
  "Yes - all 40 keys and all 18 Section B answers verified against the marking scheme; the table key checked row by row (carbohydrate from rice and cassava, protein from beans and fish for growth and repair, fat from palm oil for energy and warmth, vitamin A from red palm oil and liver for healthy eyes)"),
 ("Marking scheme matches questions",
  "Yes - expected answers plus marking notes covering partial credit, alternatives, common wrong answers and method marks; Question 1(b) withholds the mark when a correct use is attached to the wrong class, Question 4(a) insists one mark come from symptoms and one from effects, Question 5(c) requires vitamin D and also calcium or sunlight, and Question 7(b) requires advice on protein and on vitamin A"),
 ("Free from unnecessary ambiguity",
  "Yes - open items are anchored with 'name the five', 'state three' and 'state two' plus the mark allocation; Question 1(a) notes that a named food is not a class of nutrient, Question 1(b) says 'choose three of the classes you named in (a)', Question 7(a) describes two groups of children so the diseases are distinguishable, and Question 4(b) asks for two reasons so a bare opinion is not enough"),
 ("Ghanaian contexts natural and accurate",
  "Yes - rice, maize, yam, cassava, plantain, gari and bread; palm oil, groundnut oil, coconut and shea butter; beans, groundnuts, soya, kontomire and alefu; red palm oil, mango and pawpaw; fish with soft bones, liver and eggs; iodised salt; a village visit with a community meeting; and the clinic or health centre"),
 ("No content beyond the curriculum",
  "No - every item sits inside topics 17.1-17.3; viral diseases, COVID-19, Ebola, H1N1, pandemics, vaccination and management roles are not required anywhere in the paper. Goitre appears once as a further example of a mineral deficiency"),
 ("Questions sufficiently varied",
  "Yes - naming the classes of nutrient, matching a class to its use, explaining why a growing child needs protein, completing a six-blank table of nutrients, naming mineral sources, defining a deficiency disease, listing causes, explaining why one food is not enough, distinguishing symptoms from effects, arguing tablets against diet, matching three diseases to their missing nutrients, stating symptoms, explaining how rickets is prevented, naming the nutrient and symptoms of kwashiorkor, explaining why anaemia causes tiredness, naming iron-rich foods, diagnosing two diseases from a village description, and advising the families what to do"),
]:
    w("| " + q_ + " | " + a_ + " |")
w("")
w("### EXAMINER NOTES")
w("")
for n_ in [
 "Question 4(a) is the one most pupils muddle. They use 'symptoms' and 'effects' as if they were the same word. They are not: the symptom is what you can see or what the patient complains of, such as bleeding gums; the effect is the harm that follows, such as a child being too weak to walk to school. The note pays one mark for each half and caps the answer at 3 if only one is explained.",
 "Question 6(b) is the discriminator. Nearly every pupil can say 'the blood is not enough', but the marks are on the chain behind it: too little iron means too little haemoglobin, too little haemoglobin means less oxygen carried, and less oxygen means less energy released. Teach that chain as three linked sentences and the marks follow.",
 "Question 2(a) is the paper's factual core, and the two blanks that catch pupils out are (iii) and (v). Protein is for GROWTH and REPAIR, not for energy - pupils give 'energy' for almost every nutrient. Fat gives energy and warmth and helps absorb some vitamins.",
 "Question 1(b) is marked on the match, not on the list. A pupil who writes three correct uses but attaches them to the wrong classes scores nothing. Tell them to write the class and the use together in one sentence.",
 "Question 7 is the task that carries the indicator's real demand: the curriculum asks pupils to RELATE the nutrients they lack to the foods they normally eat. The note requires advice on protein and on vitamin A, and it rewards answers that use foods the village already grows rather than foods it would have to buy.",
 "Topic weighting is 30 marks for 17.1, 32 for 17.2 and 38 for 17.3. The named diseases carry the most, because Exemplar 4 asks for the symptoms, effects and prevention of several of them. If you spent longer on nutrients than on the diseases, move marks towards Questions 1 and 2.",
 "Two cheap practicals that raise marks sharply: (1) bring in a week of real food labels or empty wrappers and let pupils sort them by the nutrient they mainly supply, and (2) look at a sample of dark green leafy vegetables, red palm oil and beans on a table and ask which disease each would prevent. The first teaches Questions 1 and 2, the second teaches Questions 5 and 7.",
 "The companion paper covers topics 17.4 to 17.7 - the nature of viral diseases, COVID-19, Ebola and H1N1, and the roles of individuals, communities and government in managing them - under content standard B7/JHS1.5.2.2. Use the two papers together for a full end-of-term examination on this sub-strand, or separately as two class tests.",
 "Edit the school name, academic year and examination title on page 1 before printing.",
 "This is an original, teacher-made mock. It is not a reproduction of any WAEC or NaCCA examination paper.",
]:
    w("- " + n_)
w()

open("/home/user/Basic7_Integrated_Science_Mock_Strand5_HumanHealth1.md", "w", encoding="utf-8").write("\n".join(L))
print("md written", len("\n".join(L)), "chars")
