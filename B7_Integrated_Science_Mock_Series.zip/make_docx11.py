# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "/home/user")
from build_energy import *

from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT

doc = Document()
sec = doc.sections[0]
sec.left_margin = Inches(0.7); sec.right_margin = Inches(0.7)
sec.top_margin = Inches(0.7); sec.bottom_margin = Inches(0.6)

st = doc.styles["Normal"]; st.font.name = "Calibri"; st.font.size = Pt(11)


def set_font(run, size=11, bold=False, italic=False, mono=False, color=None):
    run.font.size = Pt(size); run.bold = bold; run.italic = italic
    run.font.name = "Consolas" if mono else "Calibri"
    if color: run.font.color.rgb = color
    return run


def para(text="", size=11, bold=False, italic=False, align=None, mono=False,
         space_before=0, space_after=4, color=None):
    p = doc.add_paragraph()
    if align == "c": p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    elif align == "j": p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p.paragraph_format.space_before = Pt(space_before)
    p.paragraph_format.space_after = Pt(space_after)
    if text: set_font(p.add_run(text), size, bold, italic, mono, color)
    return p


def rule():
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(6); p.paragraph_format.space_before = Pt(2)
    set_font(p.add_run("_" * 78), 9, color=RGBColor(0x99, 0x99, 0x99))


def add_table(headers, rows, widths=None, size=9, head_size=9):
    t = doc.add_table(rows=1, cols=len(headers)); t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, h in enumerate(headers):
        c = t.rows[0].cells[i]; c.text = ""
        p = c.paragraphs[0]; p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_font(p.add_run(str(h)), head_size, bold=True)
    for row in rows:
        cells = t.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = ""
            p = cells[i].paragraphs[0]; p.paragraph_format.space_after = Pt(1)
            set_font(p.add_run(str(v)), size)
    if widths:
        for r_ in t.rows:
            for i, w in enumerate(widths): r_.cells[i].width = Inches(w)
    return t


def draw_diagram(lines, caption):
    t = doc.add_table(rows=2, cols=1); t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = t.rows[0].cells[0]
    for k, line in enumerate(lines):
        p = cell.paragraphs[0] if k == 0 else cell.add_paragraph()
        p.paragraph_format.space_after = Pt(0); p.paragraph_format.space_before = Pt(0)
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_font(p.add_run(line), 10, mono=True)
    c2 = t.rows[1].cells[0].paragraphs[0]
    c2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_font(c2.add_run(caption), 9, italic=True)
    t.rows[0].cells[0].width = Inches(6.6)
    t.rows[1].cells[0].width = Inches(6.6)


# ============================================================= TITLE BLOCK
para(SCHOOL, size=15, bold=True, align="c", space_after=2)
para(SUBJECT, size=13, bold=True, align="c", space_after=2)
para(EXAM, size=12, bold=True, align="c", space_after=2)
para(YEAR, size=10, italic=True, align="c", space_after=8)

info = doc.add_table(rows=1, cols=3); info.style = "Table Grid"
info.alignment = WD_TABLE_ALIGNMENT.CENTER
for i, v in enumerate([f"Class: {CLASS}", f"Time: {TIME}", f"Total Marks: {MARKS}"]):
    c = info.rows[0].cells[i]; c.text = ""
    set_font(c.paragraphs[0].add_run(v), 10, bold=True)
para("", space_after=6)

para("INSTRUCTIONS", size=11, bold=True, space_after=3)
for txt in [
    "1. Write your name and class clearly in the spaces provided on your answer sheet.",
    "2. This paper has TWO sections: Section A and Section B.",
    "3. Answer ALL the questions in both sections.",
    "4. Section A has 40 multiple-choice questions. Each question carries 1 mark. Choose the best answer "
    "(A, B, C or D) and record it on the answer sheet provided.",
    "5. Section B has 7 theory questions totalling 60 marks. Write your answers clearly and neatly in your "
    "answer booklet. Draw and label diagrams or tables where you are asked to.",
    "6. Read every question carefully before you answer it.",
    "7. Do not use correction fluid. Cancel any mistake neatly with a single line.",
    "8. Hand in your answer sheet and your answer booklet at the end of the examination.",
]:
    para(txt, size=10.5, space_after=2)
rule()

# =============================================================== SECTION A
para("SECTION A - OBJECTIVE TEST (40 marks)", size=12, bold=True, align="c", space_after=2)
para("Answer ALL questions. Each question carries 1 mark. Choose the BEST answer and write its letter "
     "(A, B, C or D) against the question number on your answer sheet.",
     size=10, italic=True, align="c", space_after=8)

for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(1); p.paragraph_format.space_before = Pt(4)
    set_font(p.add_run(f"{i}. {q}"), 10.5)
    for j, o in enumerate(opts):
        p2 = doc.add_paragraph()
        p2.paragraph_format.left_indent = Inches(0.28)
        p2.paragraph_format.space_after = Pt(0); p2.paragraph_format.space_before = Pt(0)
        set_font(p2.add_run(f"{'ABCD'[j]}. {o}"), 10.5)

doc.add_page_break()

# =============================================================== SECTION B
para("SECTION B - THEORY (60 marks)", size=12, bold=True, align="c", space_after=2)
para("Answer ALL questions. Write your answers in your answer booklet. The marks for each question are "
     "shown in brackets.", size=10, italic=True, align="c", space_after=8)

for qb in SECTION_B:
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(8); p.paragraph_format.space_after = Pt(2)
    set_font(p.add_run(f"Question {qb['num']}"), 11, bold=True)
    set_font(p.add_run(f"  [{qb['total']} marks]"), 10, bold=True, italic=True)
    para(qb["stem"], size=10.5, space_after=4)
    if qb.get("table") == "energy":
        add_table(EN_HEADERS, EN_ROWS, widths=[1.1, 2.4, 2.6], size=8.5, head_size=8.5)
        para("Table 1: Forms of energy", size=9, italic=True, align="c", space_after=6)
        para("", space_after=2)
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Inches(0.25)
        p.paragraph_format.space_after = Pt(3); p.paragraph_format.space_before = Pt(2)
        set_font(p.add_run(f"{lab} {text}  "), 10.5)
        set_font(p.add_run(f"[{mk} mark{'s' if mk > 1 else ''}]"), 10, bold=True)

doc.add_page_break()

# ============================================================== ANSWER KEY
para("ANSWER KEY", size=13, bold=True, align="c", space_after=6)
para("SECTION A - OBJECTIVE TEST", size=11, bold=True, space_after=4)
rows = [[i, ans, TOPIC[tp], cog] for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1)]
add_table(["Question", "Answer", "Curriculum Area (Topic)", "Cognitive Level"],
          rows, widths=[0.8, 0.7, 3.6, 1.5], size=9)
counts = {L: sum(1 for q in MCQ if q[2] == L) for L in "ABCD"}
para("", space_after=4)
para("Correct-answer distribution: " + ", ".join(f"{L} = {counts[L]}" for L in "ABCD") + " (30 items).",
     size=9, italic=True)

para("", space_after=8)
para("SECTION B - THEORY (summary answers; see the Marking Scheme for full detail)",
     size=11, bold=True, space_after=4)
sba = [
 ("1 (a)", "Energy is the ability to do work. The SI unit of energy is the joule (J).", "11.1", "Understand"),
 ("1 (b)", "Any three of: lighting a room with a bulb (electrical); cooking food (heat); ringing the school bell (electrical/sound); moving a car or tro-tro (chemical in fuel); playing a radio (electrical); ironing a uniform (heat).", "11.1", "Remember"),
 ("1 (c)", "No - the water has potential energy because it is high above the ground, and if the tap were opened it would fall and could do work, so it could change into kinetic energy.", "11.1", "Evaluate"),
 ("2 (a)", "(i) the energy a body has because of its position or height, or because it is stretched; (ii) the energy a body has because it is moving; (iii) a charcoal pot or a pressing iron; (iv) the energy that travels through the air and makes our ears hear; (v) energy that comes from the sun; (vi) energy stored in food, in fuel and in dry cells and batteries.", "11.2", "Understand"),
 ("2 (b)", "Electrical energy and nuclear energy.", "11.2", "Remember"),
 ("2 (c)", "Electrical energy is used to light the home, to run a fridge or to power a radio. Nuclear energy is used in a nuclear power station to generate electricity, and in medicine such as X-rays.", "11.2", "Understand"),
 ("3 (a)", "Potential energy is the energy a body has because of its position or height, or because it is stretched; kinetic energy is the energy a body has because it is moving.", "11.3", "Understand"),
 ("3 (b)", "At the top the stone has its greatest potential energy and hardly any kinetic energy. As it falls the potential energy decreases and changes into kinetic energy, so the stone speeds up. Just before it hits the ground the kinetic energy is greatest and the potential energy is almost zero.", "11.3", "Analyse"),
 ("3 (c)", "Mechanical energy is the total energy a body has because of its position and its motion. Mechanical Energy = Potential Energy + Kinetic Energy (ME = PE + KE).", "11.3", "Understand"),
 ("4 (a)", "PE = mgh = 40 x 10 x 2 = 800 J.", "11.4", "Apply"),
 ("4 (b)", "KE = 1/2 mv2 = 1/2 x 0.5 x 20 x 20 = 100 J.", "11.4", "Apply"),
 ("4 (c)", "(i) PE = mgh = 3 x 10 x 4 = 120 J. (ii) The kinetic energy just before it hits the ground is also 120 J, because all the potential energy at the top has changed into kinetic energy.", "11.4", "Apply"),
 ("5 (a)", "(i) a pressing iron - electrical energy; (ii) a radio - electrical energy; (iii) a solar calculator - solar energy; (iv) a kerosene lamp - chemical energy stored in the kerosene.", "11.5", "Understand"),
 ("5 (b)", "Heat energy is used at home to cook food, to boil water or to iron clothes. Sound energy is used at school when the bell is rung to end lessons, or when the teacher speaks and the pupils hear.", "11.5", "Understand"),
 ("5 (c)", "Solar energy (energy from the sun). One reason: it costs nothing, or it does not smoke the maize the way a fire does.", "11.5", "Understand"),
 ("6 (a)", "Conduction - heat passes through a solid from particle to particle. Convection - heat is carried through a liquid or a gas by the liquid or the gas itself moving. Radiation - heat travels as waves and needs no material at all.", "11.6", "Understand"),
 ("6 (b)", "Fix one end of a metal rod in a flame and stick drawing pins or wax along it. The far end becomes hot and the pins drop off one after another, starting from the hot end, which shows that heat has travelled along the metal.", "11.6", "Create"),
 ("6 (c)", "Radiation. The sun's heat crosses the air and the glass without heating the air much, the seats and glass absorb it, and the warm air is then trapped inside the closed car.", "11.6", "Analyse"),
 ("7 (a)", "Take three pieces of cardboard with a hole in each, stand them in a straight line and put a lit candle behind the first. The flame can be seen only when the three holes are in one straight line; move one card sideways and it disappears.", "11.7", "Apply"),
 ("7 (b)", "Reflection is the bouncing back of light when it falls on a shiny or polished surface such as a mirror. Refraction is the bending of light as it passes from one material into another, for example from air into water.", "11.7", "Understand"),
 ("7 (c)", "The process is dispersion. Sunlight is made of seven colours; when it enters a raindrop it is refracted and each colour bends by a different amount, so the colours separate and appear as a rainbow.", "11.7", "Understand"),
]
add_table(["Question", "Expected Answer", "Curriculum Area", "Cognitive Level"],
          [list(r) for r in sba], widths=[0.8, 4.2, 1.2, 1.2], size=9)

doc.add_page_break()

# =========================================================== MARKING SCHEME
para("MARKING SCHEME - SECTION B (60 marks)", size=13, bold=True, align="c", space_after=4)
para("General rules: (1) Accept any other correct and relevant answer. (2) Award marks for correct points, "
     "not for repeating the question. (3) For procedures, award method marks. (4) Do not deduct marks for "
     "spelling unless the meaning is changed. (5) Where a candidate gives more answers than are asked for, "
     "mark only the first ones up to the number required.",
     size=9.5, italic=True, space_after=8)

for qb in SECTION_B:
    n = qb["num"]
    para(f"Question {n}  ({qb['total']} marks)", size=11, bold=True, space_before=8, space_after=3)
    for (lab, points, note) in MARKING[n]:
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(2)
        set_font(p.add_run(f"{lab} "), 10.5, bold=True)
        mkv = [p_[2] for p_ in qb["parts"] if p_[0] == lab]
        if mkv: set_font(p.add_run(f"[{mkv[0]} mark{'s' if mkv[0] > 1 else ''}]"), 10, bold=True)
        for pt in points:
            pp = doc.add_paragraph()
            pp.paragraph_format.left_indent = Inches(0.35); pp.paragraph_format.space_after = Pt(1)
            set_font(pp.add_run("- " + pt), 10.5)
        pp = doc.add_paragraph()
        pp.paragraph_format.left_indent = Inches(0.35); pp.paragraph_format.space_after = Pt(6)
        set_font(pp.add_run("Marking note: " + note), 9.5, italic=True)

doc.add_page_break()

# ================================================================ BLUEPRINT
para("CURRICULUM ASSESSMENT BLUEPRINT", size=13, bold=True, align="c", space_after=3)
para(f"Strand: {STRAND}   |   Sub-strand: {SUBSTRAND}   |   Class: {CLASS}",
     size=10, italic=True, align="c", space_after=3)
para(f"Content Standard: {CS} - {CS_TEXT}", size=9, italic=True, align="c", space_after=3)
para("Source: NaCCA Science Common Core Programme Curriculum (B7/JHS1-B9/JHS3), September 2020, "
     "Strand 4: Forces and Energy, Sub-strand 1: Energy, pp. 26-29. Indicators are quoted, not "
     "invented.",
     size=9, italic=True, space_after=8)

hdr = ["Qn", "Sub-strand", "Content Standard", "Indicator (NaCCA) - Indicator Text", "Topic / Content",
       "Cognitive Level", "Marks"]

rows = [[f"A{i}", SUBSTRAND, CS_BY_TOPIC[tp], f"{IND[tp]} - {IND_TEXT[tp]}", TOPIC[tp], cog, 1]
        for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1)]
add_table(hdr, rows, widths=[0.35, 0.75, 0.75, 1.75, 1.4, 0.8, 0.35], size=7, head_size=7.5)

para("", space_after=8)
rows = []
for qb in SECTION_B:
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        key = tp if tp in TOPIC else tp.split(",")[0].strip()
        rows.append([f"B{qb['num']}{lab.strip('()')}", SUBSTRAND, CS_BY_TOPIC[key],
                     f"{IND[key]} - {IND_TEXT[key]}", TOPIC[key], cog, mk])
add_table(hdr, rows, widths=[0.35, 0.75, 0.75, 1.75, 1.4, 0.8, 0.35], size=7, head_size=7.5)

doc.add_page_break()

# ----------------------------------------------------------------- helpers
def topic_totals():
    m = {k: 0 for k in TOPIC}; it = {k: 0 for k in TOPIC}
    for q in MCQ:
        m[q[3]] += 1; it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk; it[key] += 1
    return m, it

def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}; b = {k: 0 for k in order}
    for q in MCQ: a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: b[cog] += mk
    return order, a, b

def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ: d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: d[diff] += mk
    return d

m, it = topic_totals(); diff = difficulty_totals(); order, ca, cb = cognitive_by_section()

para("SUMMARY 1 - COVERAGE BY CURRICULUM AREA (TOPIC)", size=12, bold=True, space_after=4)
rows = [[TOPIC[k], it[k], m[k], f"{(m[k]/100)*100:.1f}%", CC[k]] for k in TOPIC]
rows.append(["TOTAL", sum(it.values()), sum(m.values()), "100%", "-"])
add_table(["Topic / Content Area", "No. of Items", "Marks", "% of Total Marks", "Core Competencies"],
          rows, widths=[2.7, 0.8, 0.6, 1.0, 1.1], size=8.5)
para("CC = Communication and Collaboration; CP = Critical Thinking and Problem Solving; "
     "DL = Digital Literacy; CI = Creativity and Innovation.", size=8.5, italic=True, space_after=2)

para("", space_after=8)
para("SUMMARY 2 - COGNITIVE-LEVEL DISTRIBUTION (Bloom's Taxonomy)", size=12, bold=True, space_after=4)
rows = []
for lv in order:
    tot = ca[lv] + cb[lv]
    rows.append([lv, ca[lv], cb[lv], tot, f"{(tot/100)*100:.1f}%"])
rows.append(["TOTAL", sum(ca.values()), sum(cb.values()), sum(ca.values()) + sum(cb.values()), "100%"])
add_table(["Cognitive Level", "Section A Marks", "Section B Marks", "Total Marks", "% of Total"],
          rows, widths=[1.6, 1.3, 1.3, 1.1, 1.1], size=9.5)

para("", space_after=8)
para("SUMMARY 3 - DIFFICULTY DISTRIBUTION", size=12, bold=True, space_after=4)
rows = [[k, v, f"{(v/100)*100:.1f}%"] for k, v in diff.items()]
rows.append(["TOTAL", sum(diff.values()), "100%"])
add_table(["Difficulty", "Marks", "% of Total Marks"], rows, widths=[2.0, 1.2, 1.5], size=9.5)
para("Target in the master prompt: approximately 30% easy / 50% moderate / 20% challenging.",
     size=9, italic=True, space_after=2)

para("", space_after=8)
para("SUMMARY 4 - SECTION WEIGHTING", size=12, bold=True, space_after=4)
add_table(["Section", "Question Type", "Items", "Marks", "% of Total"],
          [["A", "Objective (multiple choice)", 40, 40, "40%"],
           ["B", "Theory / constructed response", 21, 60, "60%"],
           ["TOTAL", "-", 61, 100, "100%"]],
          widths=[0.9, 2.4, 0.8, 0.8, 1.0], size=9.5)

doc.add_page_break()

# ===================================================== QUALITY-CONTROL
para("QUALITY-CONTROL SUMMARY", size=13, bold=True, align="c", space_after=4)
para("Carried out against the 14-point validation list in the master prompt before the examination was "
     "finalised.", size=9.5, italic=True, space_after=8)

qc = [
 ("Does every question belong to the supplied curriculum scope?",
  "Yes. All 61 items - 40 objectives and 21 theory sub-questions - trace to Strand 4 (Forces and "
  "Energy), Sub-Strand 1 (Energy), topics 11.1-11.7, "
  "and to the four official B7 indicators (B7/JHS1.4.1.1.1, B7/JHS1.4.1.1.2, B7/JHS1.4.1.2.1 and "
  "B7/JHS1.4.1.3.1). Magnetism, force, pressure, work and power, energy conversion chains, electric "
  "current and circuits appear only as distractors or as neighbouring work that pupils are told "
  "about, never as things they must answer on."),
 ("Is the examination appropriate for the stated class?",
  "Yes. The B7 curriculum requires learners to identify the nine forms of energy, show how PE and "
  "KE are related, use PE = mgh and KE = 1/2 mv2, discuss daily applications including the factors "
  "that affect PE and KE, explain and demonstrate heat transfer through different media, and "
  "demonstrate straight-line travel, reflection, refraction and dispersion of light. Every "
  "calculation uses g = 10 m/s2 and round numbers, and no item needs algebra beyond substitution "
  "into a given formula. The principle of conservation of energy is deliberately left to "
  "Sub-strand 3 (B7/JHS1.4.3.1.1), so no item here asks pupils to state that law."),
 ("Are the questions genuinely BECE-style?",
  "Yes: Section A is 40 four-option objectives worth 1 mark each, and Section B is structured "
  "theory with sub-questions carrying printed mark allocations. A completion table is included, "
  "matching the BECE science convention and exemplar 1 of B7/JHS1.4.1.1.1, which asks pupils to "
  "list the forms of energy."),
 ("Are there enough application and reasoning questions?",
  "Yes. 32 of 100 marks (32%) are at Apply level or above (Apply 20, Analyse 6, Evaluate 3, Create "
  "3). The calculations in Question 4 are Apply, Question 1(c) asks pupils to judge a wrong claim, "
  "Question 3(b) asks them to explain a conversion, and Questions 6(b) and 7(a) are design tasks "
  "that follow directly from the 'carry out an activity' and 'perform experiments' exemplars."),
 ("Are the MCQ distractors plausible?",
  "Yes. Distractors are drawn from the same content family as the key: another form of energy "
  "(A8, A11, A23), a quantity that is not a form of energy at all (A4), a wrong unit (A2, A5), a "
  "wrong formula with the right letters (A17, A18), and the common arithmetic slips of forgetting "
  "to square the speed (A20) or of using the wrong factor (A19)."),
 ("Is there only one best answer for each MCQ?",
  "Yes. Every item was reviewed for a single defensible key. Special care was taken with A9, where "
  "'heat energy' is not offered as an option because heat from the sun is solar energy, and with "
  "A23, where a kerosene lamp USES chemical energy even though it PRODUCES light, so the stem asks "
  "specifically for the energy stored in the kerosene."),
 ("Are the marks internally consistent?",
  "Yes. Section A = 40 items x 1 mark = 40. Section B = 8 + 10 + 9 + 9 + 8 + 8 + 8 = 60. "
  "Each Section B sub-question's printed marks match its marking-scheme allocation, and every "
  "N-mark sub-question asks for N things."),
 ("Does the total add up correctly?",
  "Yes: 40 + 60 = 100 marks, matching the stated total on the front page."),
 ("Are the answers in the answer key correct?",
  "Yes. All 40 objective keys and all 21 Section B answers were verified against the marking "
  "scheme. The three calculations were checked independently: 40 x 10 x 2 = 800 J, "
  "1/2 x 0.5 x 20 x 20 = 100 J, and 3 x 10 x 4 = 120 J."),
 ("Does the marking scheme match the questions?",
  "Yes. Every Section B sub-question has an expected-answer list and a marking note covering "
  "partial credit, acceptable alternatives, common wrong answers and method marks. Each "
  "calculation is split into a formula mark, a substitution mark and an answer mark, so a pupil "
  "who gets the arithmetic wrong still earns method marks. The completion table is marked blank by "
  "blank, and the two design tasks state exactly which three things earn the marks."),
 ("Are the questions free from unnecessary ambiguity?",
  "Yes. Open items are anchored with 'name three', 'state one' and the mark allocation. Question "
  "2(a) numbers every blank, (i) to (vi). Question 4 states that g = 10 m/s2 and that working must "
  "be shown. Question 5(a) asks for the form of energy each appliance USES, and the note warns "
  "against giving light for the kerosene lamp. Question 6(a) asks for what moves in each method, "
  "so 'name three ways' alone does not earn full marks."),
 ("Are Ghanaian contexts used naturally and accurately?",
  "Yes: water stored behind the Akosombo Dam, a tro-tro on the Accra-Kumasi road, a car parked in "
  "the sun at Madina, maize drying on a mat, a charcoal pot, a kerosene lantern, a solar panel on "
  "a house roof, a water tank on a two-storey building, the school bell ending lessons, and "
  "school uniforms."),
 ("Has any content outside the supplied curriculum been introduced?",
  "No. Every item sits inside topics 11.1-11.7. The nine forms tested are exactly the nine named "
  "in exemplar 1 of B7/JHS1.4.1.1.1. No item asks about energy conversion chains, electricity "
  "generation or electronic components, all of which belong to later sub-strands."),
 ("Are the questions sufficiently varied?",
  "Yes. Item types include definition, listing, judging a claim, completing a comparison table, "
  "identifying the two missing forms, calculation with working, matching appliances to forms of "
  "energy, describing the three heat-transfer methods, planning two class activities, and "
  "explaining a rainbow."),
]
for i, (q, a) in enumerate(qc, start=1):
    p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(2)
    set_font(p.add_run(f"{i}. {q}"), 10.5, bold=True)
    p2 = doc.add_paragraph()
    p2.paragraph_format.left_indent = Inches(0.3); p2.paragraph_format.space_after = Pt(6)
    set_font(p2.add_run(a), 10)

para("", space_after=8)
para("EXAMINER NOTES (for the teacher, not for candidates)", size=11, bold=True, space_after=4)
for n in [
 "Questions 6(b) and 7(a) are the two design tasks, and they come straight from the exemplars - "
 "'carry out an activity to show how heat is transferred' and 'perform experiments to show that "
 "light travels in a straight line'. Award method marks generously: any workable plan that is "
 "clearly described deserves credit, even if the apparatus is not the one in the scheme.",
 "Question 4 is the calculation question, and it is marked in three steps - formula, substitution, "
 "answer - so a pupil who forgets to square the 20 in KE = 1/2 mv2 still earns the formula mark. "
 "Remind pupils to write the formula first and to show the substitution, because an answer alone "
 "loses two marks.",
 "The single most common error in this sub-strand is saying that potential energy 'finishes' or "
 "'is used up' as a body falls. Question 3(b) is written to catch it, and the marking note allows "
 "at most 2 of 3 marks if the pupil says the energy disappears.",
 "Question 2(a) is the completion table. The six blanks are numbered (i) to (vi), so marking is "
 "quick and fair: 1 mark each, and the blank number must be matched to the answer.",
 "Watch for the pair of confusions in Question 5(a): a kerosene lamp USES chemical energy even "
 "though it PRODUCES light, and a solar calculator USES solar energy. The note tells you which "
 "answer to accept for each.",
 "Topic weightings are deliberately even here - every topic carries 14 or 15 marks - because the "
 "content standard covers three separate ideas (forms of energy, heat transfer, and light). If "
 "your scheme of work spent longer on one of them, move marks towards Questions 2 to 4, 6 or 7.",
 "B7 does not expect pupils to state the law of conservation of energy; that is Sub-strand 3 "
 "(B7/JHS1.4.3.1.1). Here they only need to say that PE changes into KE, which Question 3(b) and "
 "Question 4(c)(ii) both test.",
 "If your school has a science set, run the three-card activity and the drawing-pin-on-a-rod "
 "activity before the mock. Pupils who have done them write far better answers to Questions 6(b) "
 "and 7(a).",
 "Edit the school name, academic year and examination title on page 1 before printing.",
 "This is an original, teacher-made mock. It is not a reproduction of any WAEC or NaCCA examination "
 "paper.",
]:
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Inches(0.3); p.paragraph_format.space_after = Pt(3)
    set_font(p.add_run("- " + n), 10)

doc.save("/home/user/Basic7_Integrated_Science_Mock_Strand4_Energy.docx")
print("docx written")

print("Section A:", len(MCQ), "items")
print("Section B total:", sum(q["total"] for q in SECTION_B))
print("Topic marks:", m, "sum", sum(m.values()))
print("Difficulty:", diff, "sum", sum(diff.values()))
print("Cognitive A:", ca)
print("Cognitive B:", cb)
print("Answer counts:", counts)
print("Totals:", sum(m.values()), sum(diff.values()),
      sum(ca.values()) + sum(cb.values()))
