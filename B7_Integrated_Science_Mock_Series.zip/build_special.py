# -*- coding: utf-8 -*-
"""BASIC 7 SPECIAL MOCK EXAMINATION - the whole B7 Integrated Science curriculum.

Section A: 100 multiple-choice questions, 2 marks each   = 200 marks
Section B: 20 essay questions with sub-questions         = 200 marks
                                                   TOTAL = 400 marks

The 22 sub-strand papers each tested their own sub-strand in depth. This paper tests the
whole year and deliberately asks the questions those papers left out. No question here is
repeated from any of the 22 sub-strand papers.

All content standards and indicators are quoted from the official NaCCA Science CCP
(B7/JHS1-B9/JHS3, September 2020). One content standard per sub-strand group."""

SCHOOL = "[SCHOOL NAME]"
SUBJECT = "INTEGRATED SCIENCE (SCIENCE)"
EXAM = "SPECIAL MOCK EXAMINATION - END OF BASIC 7"
CLASS = "Basic 7 (JHS 1)"
TIME = "3 hours 30 minutes (Suggested: Section A - 1 h 30 min; Section B - 2 h). May also be sat in two sittings."
MARKS = "400"
YEAR = "2025/2026 Academic Year"

STRAND = "Whole Basic 7 Curriculum: Strands 1 to 5"
SUBSTRAND = "All 22 sub-strands"

TOPIC = {
    "S1.1": "Materials (1.1-1.6)",
    "S1.2": "Living Cells (2.1-2.6)",
    "S2.1": "Earth Science: Water (3.1-3.5)",
    "S2.2": "Life Cycle of Organisms (4.1-4.6)",
    "S2.3": "Crop Production (5.1-5.6)",
    "S2.4": "Animal Production (6.1-6.5)",
    "S3.1": "The Human Body System (7.1-7.7)",
    "S3.2": "The Solar System (8.1-8.6)",
    "S3.3": "Ecosystem (9.1-9.5)",
    "S3.4": "Farming Systems (10.1-10.7)",
    "S4.1": "Energy (11.1-11.7)",
    "S4.2": "Electricity and Electronics (12.1-12.6)",
    "S4.3": "Conversion and Conservation of Energy (13.1-13.4)",
    "S4.4": "Force and Motion 1 (14.1-14.8)",
    "S4.5": "Simple Machines (14.9-14.11)",
    "S4.6": "Agricultural Tools (15.1-15.4)",
    "S5.1": "Waste Management (16.1-16.4)",
    "S5.2": "Human Health (17.1-17.7)",
    "S5.3": "Science and Industry (18.1-18.4)",
    "S5.4": "Climate Change and Green Economy (19.1-19.4)",
    "S5.5": "Understanding the Environment (20.1-20.5)",
}

STRAND_NAME = {
    "S1": "Diversity of Matter",
    "S2": "Cycles",
    "S3": "Systems",
    "S4": "Forces and Energy",
    "S5": "Humans and the Environment",
}

CS_BY_TOPIC = {
    "S1.1": "B7/JHS1.1.1.1 / B7/JHS1.1.1.2",
    "S1.2": "B7/JHS1.1.2.1",
    "S2.1": "B7/JHS1.2.1.1",
    "S2.2": "B7/JHS1.2.2.1",
    "S2.3": "B7/JHS1.2.3.1",
    "S2.4": "B7/JHS1.2.4.1 / B7/JHS1.2.4.2",
    "S3.1": "B7/JHS1.3.1.1",
    "S3.2": "B7/JHS1.3.2.1",
    "S3.3": "B7/JHS1.3.3.1",
    "S3.4": "B7/JHS1.3.4.1",
    "S4.1": "B7/JHS1.4.1.1 / B7/JHS1.4.1.2 / B7/JHS1.4.1.3",
    "S4.2": "B7/JHS1.4.2.1 / B7/JHS1.4.2.2",
    "S4.3": "B7/JHS1.4.3.1",
    "S4.4": "B7/JHS1.4.4.1",
    "S4.5": "B7/JHS1.4.4.2",
    "S4.6": "B7/JHS1.4.5.1",
    "S5.1": "B7/JHS1.5.1.1",
    "S5.2": "B7/JHS1.5.2.1",
    "S5.3": "B7/JHS1.5.3.1",
    "S5.4": "B7/JHS1.5.4.1",
    "S5.5": "B7/JHS1.5.5.1",
}

IND_BY_TOPIC = {
    "S1.1": "B7/JHS1.1.1.1.1 / B7/JHS1.1.1.1.2 / B7/JHS1.1.1.1.3 / B7/JHS1.1.1.2.1",
    "S1.2": "B7/JHS1.1.2.1.1 / B7/JHS1.1.2.1.2",
    "S2.1": "B7/JHS1.2.1.1.1 / B7/JHS1.2.1.1.2",
    "S2.2": "B7/JHS1.2.2.1.1 / B7/JHS1.2.2.1.2",
    "S2.3": "B7/JHS1.2.3.1.1 / B7/JHS1.2.3.1.2",
    "S2.4": "B7/JHS1.2.4.1.1 / B7/JHS1.2.4.1.2 / B7/JHS1.2.4.2.1 / B7/JHS1.2.4.2.2",
    "S3.1": "B7/JHS1.3.1.1.1 / B7/JHS1.3.1.1.2 / B7/JHS1.3.1.1.3",
    "S3.2": "B7/JHS1.3.2.1.1 / B7/JHS1.3.2.1.2",
    "S3.3": "B7/JHS1.3.3.1.1",
    "S3.4": "B7/JHS1.3.4.1.1 / B7/JHS1.3.4.1.2",
    "S4.1": "B7/JHS1.4.1.1.1 / B7/JHS1.4.1.1.2 / B7/JHS1.4.1.2.1 / B7/JHS1.4.1.3.1",
    "S4.2": "B7/JHS1.4.2.1.1 / B7/JHS1.4.2.1.2 / B7/JHS1.4.2.2.1 / B7/JHS1.4.2.2.2",
    "S4.3": "B7/JHS1.4.3.1.1 / B7/JHS1.4.3.1.2 / B7/JHS1.4.3.1.3",
    "S4.4": "B7/JHS1.4.4.1.1 / B7/JHS1.4.4.1.2 / B7/JHS1.4.4.1.3 / B7/JHS1.4.4.1.4",
    "S4.5": "B7/JHS1.4.4.2.1 / B7/JHS1.4.4.2.2 / B7/JHS1.4.4.2.3",
    "S4.6": "B7/JHS1.4.5.1.1 / B7/JHS1.4.5.1.2",
    "S5.1": "B7/JHS1.5.1.1.1",
    "S5.2": "B7/JHS1.5.2.1.1",
    "S5.3": "B7/JHS1.5.3.1.1",
    "S5.4": "B7/JHS1.5.4.1.1",
    "S5.5": "B7/JHS1.5.5.1.1 / B7/JHS1.5.5.1.2",
}

CC = {"S1.1": "CP, DL, CC, CI", "S1.2": "CP, DL, CC, CI", "S2.1": "CP, DL, CC, CI", "S2.2": "CP, DL, CC, CI", "S2.3": "CP, DL, CC, CI", "S2.4": "CP, DL, CC, CI", "S3.1": "CP, DL, CC, CI", "S3.2": "CP, DL, CC, CI", "S3.3": "CP, DL, CC, CI", "S3.4": "CP, DL, CC, CI", "S4.1": "CP, DL, CC, CI", "S4.2": "CP, DL, CC, CI", "S4.3": "CP, DL, CC, CI", "S4.4": "CP, DL, CC, CI", "S4.5": "CP, DL, CC, CI", "S4.6": "CP, DL, CC, CI", "S5.1": "CP, DL, CC, CI", "S5.2": "CP, DL, CC, CI", "S5.3": "CP, DL, CC, CI", "S5.4": "CP, DL, CC, CI", "S5.5": "CP, DL, CC, CI"}

CC_BY_TOPIC = CC

# ========== SECTION A: 100 multiple-choice questions, 2 marks each = 200 marks
MCQ = [
 ("Which property of a metal makes it suitable for making cooking pots?",
  ["it conducts heat well", "it is a poor conductor of heat", "it is very light", "it does not melt at any temperature"],
  "A", "S1.1", "Apply", "Challenging"),
 ("A substance that cannot be broken down into anything simpler by chemical means is called",
  ["a mixture", "a solution", "a compound", "an element"],
  "D", "S1.1", "Remember", "Moderate"),
 ("Sodium reacts with chlorine to form table salt. Table salt is therefore",
  ["a mixture", "a metal", "a compound", "an element"],
  "C", "S1.1", "Understand", "Moderate"),
 ("Noble gases are used to fill electric bulbs mainly because they",
  ["give off a bright light", "do not react with the hot filament", "conduct electricity well", "are very cheap"],
  "B", "S1.1", "Understand", "Moderate"),
 ("Which of these is a physical change?",
  ["souring of milk", "burning firewood", "rusting of an iron nail", "melting margarine in a pan"],
  "D", "S1.1", "Understand", "Moderate"),
 ("Which of these is a property of most metals?",
  ["they conduct electricity", "they break easily when hit", "they are all liquids", "they do not conduct heat"],
  "A", "S1.1", "Understand", "Easy"),
 ("Plastic is used to cover electrical wires because plastic is",
  ["a good conductor", "easily melted by the current", "an insulator", "very heavy"],
  "C", "S1.1", "Apply", "Moderate"),
 ("The particles of a gas move about freely and are far apart. This explains why a gas",
  ["has no definite shape of its own", "cannot be squeezed", "has a fixed volume", "always feels cold"],
  "A", "S1.1", "Understand", "Easy"),
 ("Which of these is a chemical change?",
  ["the rusting of an iron nail", "the melting of ice", "the boiling of water", "the dissolving of sugar in water"],
  "A", "S1.1", "Understand", "Moderate"),
 ("A pupil wants to separate sand from a mixture of sand and water. The best method is",
  ["evaporation", "filtration", "distillation", "magnetism"],
  "B", "S1.1", "Apply", "Challenging"),
 ("The cell membrane is described as selectively permeable. This means that it",
  ["lets nothing pass through", "allows some substances through but not others", "lets everything pass through", "allows only solids to pass"],
  "B", "S1.2", "Understand", "Moderate"),
 ("A pupil is looking at onion cells under a microscope. To make the parts clearer she should add",
  ["a drop of cooking oil", "more water only", "a drop of iodine solution", "a drop of ink"],
  "C", "S1.2", "Understand", "Moderate"),
 ("Which of these would a pupil NOT see when looking at a human cheek cell under a microscope?",
  ["a cell membrane", "cytoplasm", "a nucleus", "a cell wall"],
  "D", "S1.2", "Apply", "Challenging"),
 ("Mitochondria are often called the power house of the cell because they",
  ["store water", "release energy from food", "make the cell green", "control what enters the cell"],
  "B", "S1.2", "Understand", "Moderate"),
 ("The large vacuole in a plant cell mainly helps to",
  ["control the cell", "release energy", "store water and keep the cell firm", "make food for the plant"],
  "C", "S1.2", "Understand", "Moderate"),
 ("Which of these is the correct order from smallest to largest?",
  ["cell, organ, tissue", "tissue, cell, organ", "organ, tissue, cell", "cell, tissue, organ"],
  "D", "S1.2", "Understand", "Moderate"),
 ("A group of similar cells working together to do the same job is called",
  ["a tissue", "an organ", "a system", "an organism"],
  "A", "S1.2", "Remember", "Easy"),
 ("A plant cell needs a cell wall as well as a cell membrane mainly because the wall",
  ["releases energy from food", "gives the plant support and a fixed shape", "makes food for the cell", "controls what enters the cell"],
  "B", "S1.2", "Understand", "Moderate"),
 ("Which structure would you expect to find in very large numbers in a cell that needs a lot of energy?",
  ["ribosomes", "vacuoles", "mitochondria", "chloroplasts"],
  "C", "S1.2", "Apply", "Challenging"),
 ("A pupil draws a cell and wants to show that it is a plant cell and not an animal cell. She must include",
  ["a cell membrane and a nucleus", "a nucleus and cytoplasm only", "many small vacuoles and a round shape", "a cell wall, a chloroplast and a large vacuole"],
  "D", "S1.2", "Understand", "Moderate"),
 ("A village fetches its drinking water from a stream. The safest thing to do before drinking it is to",
  ["add salt to it", "filter it through a cloth only", "boil it", "leave it in the sun for an hour"],
  "C", "S2.1", "Apply", "Moderate"),
 ("Water is often called the universal solvent because it",
  ["is the only liquid that is pure", "can dissolve nothing at all", "is found everywhere on the earth", "dissolves more substances than any other liquid"],
  "D", "S2.1", "Understand", "Moderate"),
 ("Dew forms on grass in the early morning. This happens because",
  ["it rains very lightly every night", "water vapour in the air cools and condenses on the cold grass", "the grass gives out water during the night", "the soil pushes water up through the grass"],
  "B", "S2.1", "Apply", "Challenging"),
 ("All the trees around a stream are cut down. This is most likely to",
  ["make the stream flow faster all year round", "have no effect on the stream at all", "increase the water in the stream, because the trees no longer drink it", "reduce the water in the stream, because less rain soaks into the ground"],
  "D", "S2.1", "Apply", "Challenging"),
 ("A pupil puts one saucer of water in the sun and another in the shade. The one in the sun dries faster because",
  ["there is less air in the sun", "heat makes evaporation faster", "the saucer in the sun is bigger", "the sun pulls the water upwards"],
  "B", "S2.1", "Apply", "Moderate"),
 ("Which of these is the correct order in the life cycle of a bean plant?",
  ["germination, seed, adult plant, seedling", "seedling, seed, adult plant, germination", "seed, germination, seedling, adult plant", "adult plant, seedling, seed, germination"],
  "C", "S2.2", "Understand", "Easy"),
 ("A tadpole is the young stage of",
  ["a housefly", "a frog", "a lizard", "a cockroach"],
  "B", "S2.2", "Remember", "Easy"),
 ("A butterfly passes through a caterpillar stage. The caterpillar is the",
  ["larva", "pupa", "adult", "egg"],
  "A", "S2.2", "Understand", "Moderate"),
 ("A maize seed is kept in a dry tin for six months. It does not grow because",
  ["maize seeds need fertiliser to start", "a seed needs water to germinate", "the seed is too old to ever grow", "the tin is too dark"],
  "B", "S2.2", "Apply", "Moderate"),
 ("A hen sits on her eggs for about twenty-one days. She does this mainly to",
  ["keep them warm so the chicks can develop", "make the shells harder", "hide them from other hens", "stop the eggs from rolling away"],
  "A", "S2.2", "Understand", "Easy"),
 ("A farmer's maize plants have pale yellow leaves and poor growth. The nutrient most likely missing is",
  ["calcium", "sodium", "nitrogen", "iron"],
  "C", "S2.3", "Apply", "Challenging"),
 ("Compost is made mainly from",
  ["rotted plant and animal waste", "sand and clay", "crushed rocks", "chemical fertiliser and water"],
  "A", "S2.3", "Understand", "Easy"),
 ("Which of these is a disadvantage of using too much inorganic fertiliser?",
  ["it makes the crops grow too slowly", "it makes the soil too dark", "it can be washed into streams and harm the living things there", "it stops the rain from reaching the roots"],
  "C", "S2.3", "Understand", "Moderate"),
 ("A farmer plants beans and maize on the same piece of land. The beans help the maize mainly because they",
  ["give the maize shade", "hold the maize stems up", "put nitrogen into the soil", "keep the weeds away"],
  "C", "S2.3", "Analyse", "Challenging"),
 ("The best time to apply fertiliser to a maize crop is",
  ["during the long dry season", "on the day the maize is harvested", "just before the land is cleared", "after the rains have started and the plants are growing"],
  "D", "S2.3", "Apply", "Challenging"),
 ("A goat is a ruminant. This means that it",
  ["chews the cud and has a four-chambered stomach", "lays eggs", "has a single-chambered stomach", "eats only meat"],
  "A", "S2.4", "Understand", "Moderate"),
 ("Which of these farm animals is a monogastric?",
  ["a pig", "a goat", "a cow", "a sheep"],
  "A", "S2.4", "Remember", "Easy"),
 ("Which of these is a by-product of cattle that is used on the farm itself rather than "
  "being sold?",
  ["meat", "milk", "hides taken to the tannery", "dung used as manure"],
  "D", "S2.4", "Understand", "Easy"),
 ("Poultry kept on a deep-litter system produce a useful by-product because the droppings",
  ["dry out and are thrown away", "make the floor slippery and unsafe", "are eaten by the birds again", "mix with the litter and make good manure"],
  "D", "S2.4", "Understand", "Moderate"),
 ("The main reason for vaccinating poultry is to",
  ["make their feathers shine", "protect the birds from disease", "make them lay more eggs at once", "make them grow larger"],
  "B", "S2.4", "Understand", "Easy"),
 ("Food is mixed with saliva when it is chewed. Saliva helps by",
  ["turning protein into fat", "making the food acid", "starting the digestion of starch", "killing all the germs in the mouth"],
  "C", "S3.1", "Understand", "Moderate"),
 ("The small intestine is long and its inner wall has many folds. This mainly helps it to",
  ["absorb more digested food", "push the food along faster", "make the food smaller", "make the food taste better"],
  "A", "S3.1", "Apply", "Challenging"),
 ("The end product of the digestion of protein is",
  ["starch", "glucose", "fatty acids and glycerol", "amino acids"],
  "D", "S3.1", "Remember", "Easy"),
 ("A pupil adds iodine solution to a food sample and it turns blue-black. The food contains",
  ["protein", "glucose", "starch", "fat"],
  "C", "S3.1", "Apply", "Moderate"),
 ("Which of these would a pupil use to test a food sample for glucose?",
  ["Benedict's solution, then heat it", "iodine solution", "clean cold water", "a piece of dry paper"],
  "A", "S3.1", "Remember", "Moderate"),
 ("The sun is best described as",
  ["a star", "a moon", "a planet", "a comet"],
  "A", "S3.2", "Remember", "Easy"),
 ("We have day and night mainly because the earth",
  ["is tilted away from the sun", "rotates on its axis", "moves round the sun once a year", "stops moving at night"],
  "B", "S3.2", "Understand", "Easy"),
 ("It takes the earth about 365 days to",
  ["go once round the moon", "spin once on its axis", "travel through the Milky Way", "go once round the sun"],
  "D", "S3.2", "Remember", "Easy"),
 ("Which of these is the largest body in the solar system?",
  ["Jupiter", "the earth", "the moon", "the sun"],
  "D", "S3.2", "Remember", "Easy"),
 ("A year on Mercury is much shorter than a year on the earth. The best explanation is that Mercury",
  ["is a much smaller planet", "is nearer the sun and has a shorter path to travel", "spins faster than the earth", "has no moon going round it"],
  "B", "S3.2", "Apply", "Challenging"),
 ("In a food chain, the arrow shows",
  ["the direction in which energy flows", "which plant is the tallest", "which animal is the biggest", "how long the animal lives"],
  "A", "S3.3", "Understand", "Easy"),
 ("Which of these is an abiotic component of an ecosystem?",
  ["the grass on the field", "the temperature of the soil", "the grasshoppers in the grass", "the bacteria in the soil"],
  "B", "S3.3", "Understand", "Easy"),
 ("A hawk, a lizard, a grasshopper and a maize plant are all part of one food chain. The correct order is",
  ["grasshopper, maize, lizard, hawk", "maize, grasshopper, lizard, hawk", "hawk, lizard, grasshopper, maize", "maize, lizard, grasshopper, hawk"],
  "B", "S3.3", "Apply", "Challenging"),
 ("All the lizards in an area are killed. The number of grasshoppers would most likely",
  ["stay exactly the same", "fall to zero at once", "increase, because fewer of them are eaten", "increase, because they eat the lizards"],
  "C", "S3.3", "Analyse", "Challenging"),
 ("Dry leaves that fall on the forest floor disappear after a few weeks. The main reason is that they are",
  ["washed away by the rain", "burnt up by the sun", "blown away by the wind", "broken down by decomposers"],
  "D", "S3.3", "Understand", "Moderate"),
 ("A farmer grows maize on a piece of land this year and groundnuts on the same land next year. This is called",
  ["mixed farming", "mixed cropping", "crop rotation", "land rotation"],
  "C", "S3.4", "Understand", "Moderate"),
 ("A farmer keeps cattle and also grows maize on the same farm. This is",
  ["organic farming", "mixed cropping", "mixed farming", "crop rotation"],
  "C", "S3.4", "Understand", "Easy"),
 ("A farmer leaves a piece of land without crops for two seasons. The main reason is to",
  ["give the farmer a holiday", "allow the soil to get back its nutrients", "stop the rain from washing the soil", "let the weeds grow tall"],
  "B", "S3.4", "Apply", "Challenging"),
 ("Shifting cultivation harms the environment mainly because it often involves",
  ["cutting and burning the forest before moving on", "keeping too many animals", "using too many tractors", "planting the same crop every year"],
  "A", "S3.4", "Understand", "Moderate"),
 ("A farmer with a small piece of land near a town wants vegetables all year round. The most suitable system is",
  ["land rotation with a long fallow", "shifting cultivation", "large-scale mixed farming", "mixed cropping with watering in the dry season"],
  "D", "S3.4", "Apply", "Challenging"),
 ("A stone is dropped from a height. As it falls, its potential energy changes into",
  ["light energy", "kinetic energy", "chemical energy", "sound energy"],
  "B", "S4.1", "Understand", "Moderate"),
 ("A metal spoon is left standing in a bowl of hot soup and the handle soon becomes hot. This is an example of",
  ["convection", "radiation", "evaporation", "conduction"],
  "D", "S4.1", "Understand", "Moderate"),
 ("Which of these is the best example of light being reflected?",
  ["seeing your face in a mirror", "a shadow falling on the ground", "a pencil looking bent in a cup of water", "light passing through a window"],
  "A", "S4.1", "Understand", "Easy"),
 ("A battery is needed in an electric circuit because it",
  ["switches the circuit on and off", "makes the wires thicker", "stores the light for later", "pushes the current round the circuit"],
  "D", "S4.2", "Understand", "Easy"),
 ("Two bulbs are joined one after the other in a single loop. If one of the bulbs breaks",
  ["the battery stops working for ever", "the other bulb becomes brighter", "the other bulb is not affected at all", "the other bulb goes out"],
  "D", "S4.2", "Apply", "Challenging"),
 ("Which of these makes electricity without burning any fuel?",
  ["a diesel generator", "a coal power station", "a solar panel", "a dry cell"],
  "C", "S4.2", "Understand", "Easy"),
 ("The law of conservation of energy says that energy",
  ["cannot be created or destroyed, but can be changed from one form to another", "is used up completely whenever a machine runs", "always stays in the same form", "can be made from nothing"],
  "A", "S4.3", "Remember", "Easy"),
 ("Which of these changes electrical energy mainly into sound energy?",
  ["a radio set", "an electric bulb", "an electric pressing iron", "a ceiling fan"],
  "A", "S4.3", "Understand", "Easy"),
 ("A maize mill at the village changes electrical energy into",
  ["nuclear energy", "sound energy only", "kinetic energy", "light energy"],
  "C", "S4.3", "Apply", "Challenging"),
 ("The unit in which force is measured is the",
  ["watt", "newton", "metre", "joule"],
  "B", "S4.4", "Remember", "Easy"),
 ("A ball rolling along the ground slowly slows down and stops. The force that slows it is",
  ["friction", "gravity", "inertia", "magnetism"],
  "A", "S4.4", "Understand", "Moderate"),
 ("Two equal forces pull a box in opposite directions at the same time. The box",
  ["does not move", "moves upwards", "spins round", "moves in the direction of the stronger force"],
  "A", "S4.4", "Apply", "Challenging"),
 ("The north pole of one magnet is brought close to the north pole of another magnet. The two magnets",
  ["do not affect each other", "attract each other", "repel each other", "join together permanently"],
  "C", "S4.4", "Understand", "Moderate"),
 ("A seesaw in a children's playground is an example of",
  ["a pulley", "a lever", "a wedge", "a screw"],
  "B", "S4.5", "Understand", "Easy"),
 ("A wheel with a rope running over it, used for lifting a bucket from a well, is",
  ["an inclined plane", "a screw", "a pulley", "a lever"],
  "C", "S4.5", "Remember", "Easy"),
 ("The efficiency of a machine is always less than 100 per cent. The best explanation is that",
  ["the machine is not strong enough", "the machine makes energy disappear", "the load is always too heavy", "some of the energy put in is wasted as heat and sound"],
  "D", "S4.5", "Analyse", "Challenging"),
 ("After using a cutlass, the best thing to do is to",
  ["leave it on the ground until it is needed again", "clean it, dry it and rub a little oil on the blade", "put it away still covered with mud", "throw it into the nearest bush"],
  "B", "S4.6", "Understand", "Easy"),
 ("A garden rake is mainly used to",
  ["cut down a tree", "gather leaves and cut grass together", "carry water", "dig a deep hole"],
  "B", "S4.6", "Remember", "Easy"),
 ("A hoe blade is rubbed with oil before it is stored mainly to",
  ["make it sharper", "make it heavier", "make it look new", "stop it from rusting"],
  "D", "S4.6", "Understand", "Easy"),
 ("Which of these is the safest way to carry a cutlass?",
  ["holding the blade in front of you", "with the blade over the shoulder", "with the blade pointing down and away from the body", "tied to the wrist with string"],
  "C", "S4.6", "Understand", "Easy"),
 ("A school decides to burn all of its plastic waste. The main danger of doing this is that",
  ["the smoke can poison the air and harm people", "it costs more than buying new plastic", "it makes the plastic smell sweet", "the plastic will not burn at all"],
  "A", "S5.1", "Apply", "Moderate"),
 ("Composting kitchen and garden waste helps the environment mainly because it",
  ["makes the waste disappear completely", "turns the waste into manure instead of leaving it to rot in a dump", "uses a lot of electricity", "makes the waste smell pleasant"],
  "B", "S5.1", "Understand", "Easy"),
 ("Used engine oil from a garage should be",
  ["poured on the soil behind the garage", "poured into the nearest drain", "mixed with water and thrown away", "taken to a place where it can be treated or used again"],
  "D", "S5.1", "Apply", "Challenging"),
 ("A community wants to reduce the amount of waste it produces. The best first step is to",
  ["use fewer things that are thrown away after one use", "dig a deeper pit", "buy a bigger dustbin", "burn the waste every evening"],
  "A", "S5.1", "Apply", "Moderate"),
 ("A child has a swollen stomach, thin reddish hair and is very weak. The deficiency disease is most likely",
  ["night blindness", "rickets", "scurvy", "kwashiorkor"],
  "D", "S5.2", "Apply", "Moderate"),
 ("Night blindness is caused mainly by a lack of",
  ["vitamin A", "calcium", "iron", "vitamin C"],
  "A", "S5.2", "Remember", "Easy"),
 ("Which of these is the best way to stop the spread of a disease that is carried in dirty water?",
  ["eating more fruit", "sleeping under a net", "wearing a warm coat", "boiling or treating the drinking water"],
  "D", "S5.2", "Apply", "Moderate"),
 ("A person with a viral disease is told to rest and drink plenty of fluids. This is mainly because",
  ["the virus is washed out of the body", "it makes the medicine work faster", "the body needs rest and water to fight the virus", "it stops the person from infecting others"],
  "C", "S5.2", "Understand", "Moderate"),
 ("Which of these is an example of technology being used in industry?",
  ["a machine that sorts and grades cocoa beans", "a pupil reading a textbook", "a farmer digging with a hoe", "a trader selling at the market"],
  "A", "S5.3", "Understand", "Easy"),
 ("A scientist working in a food factory is most likely to",
  ["sell the food at the market", "test the food to make sure it is safe to eat", "drive the delivery lorry", "design the label for the packet"],
  "B", "S5.3", "Apply", "Moderate"),
 ("Science helps industry mainly by",
  ["making the workers work longer hours", "finding better and cheaper ways of making things", "building bigger factories", "selling more goods abroad"],
  "B", "S5.3", "Understand", "Moderate"),
 ("The work of a medical researcher is important to a community mainly because it",
  ["trains more nurses", "makes medicine cheaper to transport", "finds new treatments and vaccines for diseases", "builds more hospitals"],
  "C", "S5.3", "Understand", "Moderate"),
 ("Which of these gases is NOT a greenhouse gas?",
  ["carbon dioxide", "water vapour", "nitrogen", "methane"],
  "C", "S5.4", "Understand", "Moderate"),
 ("A village wants to cut down the greenhouse gases it produces. The most useful change would be to",
  ["cook the evening meal in the open air", "cook with biogas made from animal waste instead of firewood", "buy a larger cooking pot", "collect more firewood in the dry season"],
  "B", "S5.4", "Apply", "Moderate"),
 ("Solar panels on the roof of a clinic save the clinic money mainly because",
  ["the panels make the clinic cooler", "the panels never need looking after", "the panels work better at night", "the energy from the sun is free and does not have to be bought"],
  "D", "S5.4", "Understand", "Easy"),
 ("Which of these is the best reason for planting trees in a town?",
  ["they make the roads wider", "they keep the shops open longer", "they take in carbon dioxide and give shade", "they stop the rain from falling"],
  "C", "S5.4", "Understand", "Easy"),
 ("A frog that lives in a valley is different from a lizard that lives on a dry plain mainly because the frog",
  ["has a thicker skin to save water", "can run faster across open ground", "needs less food than the lizard", "needs water to keep its skin damp and to lay its eggs"],
  "D", "S5.5", "Analyse", "Challenging"),
 ("Plants growing on an exposed mountain top are usually small and low. The best explanation is that",
  ["the sun does not shine on a mountain", "they are sheltering from the wind and holding on to warmth", "no animals ever visit the mountain", "the soil there has no food in it at all"],
  "B", "S5.5", "Understand", "Moderate"),
 ("A parasite is different from a predator mainly because a parasite",
  ["lives on or in its host and does not usually kill it quickly", "only eats plants", "kills its prey at once and eats it", "is always bigger than its host"],
  "A", "S5.5", "Analyse", "Challenging"),
 ("Which of these landforms in Ghana would most likely have the wettest soil?",
  ["a bare mountain peak", "an open dry plain", "a valley", "the flat top of a plateau"],
  "C", "S5.5", "Apply", "Moderate")
]
SECTION_B = [
# ------------------------------------------------ STRAND 1: DIVERSITY OF MATTER
 dict(num=1, total=12, topic="S1.1",
   stem="Everything around us is made of matter, and matter can change in different ways.",
   parts=[
     ("(a)", "Explain the difference between a physical change and a chemical change, and give "
      "ONE example of each.", 4, "Understand", "S1.1", "Moderate"),
     ("(b)", "State THREE properties that make metals useful for making tools.",
      3, "Remember", "S1.1", "Easy"),
     ("(c)", "Explain why a cooking pot is made of metal while its handle is often made of wood "
      "or plastic.", 5, "Apply", "S1.1", "Challenging"),
   ]),
 dict(num=2, total=10, topic="S1.1",
   stem="Most substances we meet are not pure. They are mixtures that can be separated.",
   parts=[
     ("(a)", "Name THREE methods of separating mixtures. For each one, say what kind of mixture "
      "it is used to separate.", 6, "Understand", "S1.1", "Moderate"),
     ("(b)", "Explain where metals, non-metals and noble gases are found in the periodic table.",
      4, "Understand", "S1.1", "Moderate"),
   ]),
 dict(num=3, total=10, topic="S1.2",
   stem="All living things are made of cells, but plant cells and animal cells are not the same.",
   parts=[
     ("(a)", "Name FOUR parts that are found in BOTH a plant cell and an animal cell.",
      4, "Remember", "S1.2", "Easy"),
     ("(b)", "Name TWO parts found in a plant cell but NOT in an animal cell, and give ONE "
      "function of each.", 6, "Understand", "S1.2", "Moderate"),
   ]),
 dict(num=4, total=8, topic="S1.2",
   stem="Cells do not work alone. They are arranged in an order of increasing size and "
        "complexity.",
   parts=[
     ("(a)", "Explain the difference between a cell, a tissue and an organ, giving ONE example "
      "of each from the human body.", 6, "Understand", "S1.2", "Moderate"),
     ("(b)", "Explain why a microscope is needed in order to see cells.",
      2, "Understand", "S1.2", "Easy"),
   ]),
# ------------------------------------------------------------ STRAND 2: CYCLES
 dict(num=5, total=12, topic="S2.1",
   stem="Water is essential to life, and every community needs a supply of safe water.",
   parts=[
     ("(a)", "Name FOUR natural sources of water found in Ghana.",
      4, "Remember", "S2.1", "Easy"),
     ("(b)", "Explain the difference between surface water and underground water, giving ONE "
      "example of each.", 4, "Understand", "S2.1", "Moderate"),
     ("(c)", "A village draws its water from a stream. Explain TWO things the village should do "
      "to the water before drinking it, and say why each one helps.",
      4, "Apply", "S2.1", "Challenging"),
   ]),
 dict(num=6, total=10, topic="S2.1",
   stem="The water cycle moves water round and round the environment.",
   parts=[
     ("(a)", "Name the FOUR main stages of the water cycle and explain what happens at each "
      "stage.", 8, "Understand", "S2.1", "Moderate"),
     ("(b)", "Explain why the water cycle is described as a repeated pattern in nature.",
      2, "Understand", "S2.1", "Easy"),
   ]),
 dict(num=7, total=10, topic="S2.3",
   stem="A farmer saves maize seeds from one season and plants them the next.",
   parts=[
     ("(a)", "Describe the life cycle of a maize plant, from the seed to the adult plant that "
      "makes new seeds.", 6, "Understand", "S2.3", "Moderate"),
     ("(b)", "Design an experiment to show that a maize seed needs WATER in order to "
      "germinate. Say what you would set up, what you would keep the same, and what you would "
      "expect to see.", 4, "Create", "S2.3", "Challenging"),
   ]),
 dict(num=8, total=8, topic="S2.4",
   stem="Many Ghanaian families keep animals as well as growing crops.",
   parts=[
     ("(a)", "Give THREE ways in which domestic animals are useful to a Ghanaian family.",
      3, "Remember", "S2.4", "Easy"),
     ("(b)", "Explain ONE difference between a ruminant and a monogastric animal, and give ONE "
      "example of each.", 5, "Understand", "S2.4", "Moderate"),
   ]),
# ---------------------------------------------------------- STRAND 3: SYSTEMS
 dict(num=9, total=12, topic="S3.1",
   stem="The food a person eats passes through a long tube inside the body.",
   parts=[
     ("(a)", "Name, in the correct order, the parts of the alimentary canal that food passes "
      "through, starting at the mouth.", 5, "Remember", "S3.1", "Moderate"),
     ("(b)", "Explain what happens to food in the mouth and in the stomach.",
      4, "Understand", "S3.1", "Moderate"),
     ("(c)", "Explain why the small intestine, and not the stomach, is where most digested food "
      "is absorbed.", 3, "Apply", "S3.1", "Challenging"),
   ]),
 dict(num=10, total=10, topic="S3.2",
   stem="The earth is one of several planets moving round the sun.",
   parts=[
     ("(a)", "Write down the names of the four planets that lie between the sun and the "
      "asteroid belt, beginning with the one closest to the sun.",
      4, "Remember", "S3.2", "Easy"),
     ("(b)", "Explain the difference between the rotation of the earth and its revolution, and "
      "say how long each one takes.", 6, "Understand", "S3.2", "Moderate"),
   ]),
 dict(num=11, total=10, topic="S3.3",
   stem="A pond near a village contains water, soil, fish, frogs, water plants and insects.",
   parts=[
     ("(a)", "Explain the difference between the biotic and the abiotic components of an "
      "ecosystem, giving TWO examples of each from the pond.",
      6, "Understand", "S3.3", "Moderate"),
     ("(b)", "Write out a food chain with four links, using plants and animals found in Ghana, "
      "and explain what the arrows in a food chain mean.", 4, "Apply", "S3.3", "Moderate"),
   ]),
 dict(num=12, total=8, topic="S3.4",
   stem="A farmer has only one small piece of land and wants to keep it productive for many "
        "years.",
   parts=[
     ("(a)", "Explain the difference between crop rotation and mixed cropping.",
      4, "Understand", "S3.4", "Moderate"),
     ("(b)", "This farmer has only one small piece of land and wants crops every year. "
      "Evaluate which farming system would suit this farmer best, and say why.",
      4, "Evaluate", "S3.4", "Challenging"),
   ]),
# -------------------------------------------------- STRAND 4: FORCES AND ENERGY
 dict(num=13, total=12, topic="S4.1",
   stem="A boy holds a stone high above the ground and then lets it go.",
   parts=[
     ("(a)", "Explain the difference between potential energy and kinetic energy, giving ONE "
      "example of each.", 4, "Understand", "S4.1", "Easy"),
     ("(b)", "Describe what happens to the energy of the stone from the moment it is held high "
      "until it hits the ground.", 4, "Apply", "S4.1", "Moderate"),
     ("(c)", "State the law of conservation of energy and explain what it means for the falling "
      "stone.", 4, "Understand", "S4.1", "Challenging"),
   ]),
 dict(num=14, total=10, topic="S4.2",
   stem="A pupil wants to light a small bulb using a battery and some wire.",
   parts=[
     ("(a)", "Name THREE components needed to make a simple circuit, and say what each one "
      "does.", 6, "Understand", "S4.2", "Moderate"),
     ("(b)", "Explain what happens to the bulb if a switch in the circuit is opened.",
      2, "Understand", "S4.2", "Easy"),
     ("(c)", "Evaluate which ONE way of saving electricity at home makes the biggest "
      "difference, and say why.", 2, "Evaluate", "S4.3", "Moderate"),
   ]),
 dict(num=15, total=10, topic="S4.4",
   stem="Forces are at work all around us, every day.",
   parts=[
     ("(a)", "Explain what is meant by a force, and name THREE effects a force can have on an "
      "object.", 6, "Understand", "S4.4", "Moderate"),
     ("(b)", "Explain why a passenger standing in a bus falls forward when the bus stops "
      "suddenly.", 4, "Apply", "S4.4", "Challenging"),
   ]),
 dict(num=16, total=8, topic="S4.5",
   stem="People use machines to make work easier.",
   parts=[
     ("(a)", "Name THREE simple machines and give ONE use of each.",
      6, "Remember", "S4.5", "Easy"),
     ("(b)", "Explain why the efficiency of a machine is always less than 100 per cent.",
      2, "Analyse", "S4.5", "Challenging"),
   ]),
# ------------------------------------------ STRAND 5: HUMANS AND THE ENVIRONMENT
 dict(num=17, total=12, topic="S5.2",
   stem="Some diseases are caused not by germs but by what is missing from a person's food.",
   parts=[
     ("(a)", "Name THREE deficiency diseases and the nutrient that is missing in each case.",
      6, "Remember", "S5.2", "Easy"),
     ("(b)", "Explain TWO ways in which a community can prevent deficiency diseases.",
      4, "Apply", "S5.2", "Moderate"),
     ("(c)", "Explain why a viral disease cannot be cured by taking antibiotics.",
      2, "Understand", "S5.2", "Challenging"),
   ]),
 dict(num=18, total=10, topic="S5.1",
   stem="Every home and every school produces waste.",
   parts=[
     ("(a)", "Explain the difference between biodegradable and non-biodegradable waste, giving "
      "TWO examples of each.", 6, "Understand", "S5.1", "Easy"),
     ("(b)", "Explain TWO problems caused by dumping waste in the open.",
      4, "Apply", "S5.1", "Moderate"),
   ]),
 dict(num=19, total=10, topic="S5.4",
   stem="Ghana, like every country, needs energy that will still be there for the next "
        "generation.",
   parts=[
     ("(a)", "Explain what is meant by sustainable energy, and give TWO examples of a "
      "sustainable source of energy.", 6, "Understand", "S5.4", "Moderate"),
     ("(b)", "Explain ONE way in which science and technology can help a Ghanaian industry to "
      "produce what it needs while doing less harm to the environment.",
      4, "Apply", "S5.3", "Challenging"),
   ]),
 dict(num=20, total=8, topic="S5.5",
   stem="The plants and animals of Ghana change as the land changes.",
   parts=[
     ("(a)", "Name TWO landforms found in Ghana and describe each of them.",
      4, "Remember", "S5.5", "Easy"),
     ("(b)", "Explain ONE way in which a plant that lives on a dry plain is adapted to survive "
      "there, and say how the adaptation helps.", 4, "Apply", "S5.5", "Moderate"),
   ]),
]

# ================================================ MARKING SCHEME - SECTION B
MARKING = {
 1: [("(a)", [
      "A physical change is one in which no new substance is made. The substance only changes "
      "its form, its size or its state, and the change can usually be undone. Example: ice "
      "melting to water, or margarine melting in a pan.",
      "A chemical change is one in which a new substance is made. The change cannot easily be "
      "undone. Example: the rusting of an iron nail, or the burning of firewood.",
     ], "Up to 4 marks: 1 for saying that in a physical change NO NEW SUBSTANCE is made, 1 for "
        "a correct example of a physical change, 1 for saying that in a chemical change A NEW "
        "SUBSTANCE IS MADE, and 1 for a correct example of a chemical change. Give 0 for an "
        "example that is placed under the wrong heading."),
     ("(b)", [
      "Any three: they are strong and hard; they can be hammered or bent into shape without "
      "breaking (malleable); they conduct heat; they conduct electricity; they can be made "
      "sharp; they have a shiny surface; they often have a high melting point.",
     ], "1 mark each for any THREE sensible properties (3 marks). Do NOT accept the same "
        "property written twice in different words, and do NOT accept 'they are heavy'."),
     ("(c)", [
      "The pot itself is made of metal because metal conducts heat well, so heat from the fire "
      "passes quickly through the pot and cooks the food.",
      "The handle is made of wood or plastic because those materials are insulators. They do "
      "not conduct heat, so the handle stays cool enough to hold and the person does not burn "
      "a hand.",
     ], "Up to 5 marks: up to 2 for explaining that metal conducts heat so the food cooks, 1 "
        "for saying that wood or plastic does not conduct heat, 1 for saying the handle "
        "therefore stays cool, and 1 for saying the person can lift the pot without being "
        "burned. A pupil who says only 'metal is strong' earns 1 at most.")],
 2: [("(a)", [
      "Filtration - used to separate an insoluble solid from a liquid, such as sand from water.",
      "Evaporation - used to separate a dissolved solid from a liquid, such as salt from sea "
      "water.",
      "Decanting - used to pour a liquid off a solid that has settled, such as water off "
      "settled rice.",
      "Sieving - used to separate solids of different sizes, such as stones from sand.",
      "Using a magnet - used to pull iron or steel out of a mixture.",
      "Distillation - used to collect the liquid from a solution.",
     ], "Up to 6 marks: up to 2 for each of THREE methods, 1 for naming the method and 1 for "
        "saying what mixture it separates. Give 1 for a method that is named but not "
        "explained."),
     ("(b)", [
      "Metals are found on the left-hand side and in the middle of the periodic table.",
      "Non-metals are found on the right-hand side of the periodic table.",
      "Noble gases are in the last group, the far right-hand column of the periodic table.",
     ], "Up to 4 marks: 1 each for the position of metals, non-metals and noble gases, and 1 "
        "for using positional words such as 'left', 'right' or 'last column' correctly. Do NOT "
        "accept 'noble gases are at the top'.")],
 3: [("(a)", [
      "Any four: cell membrane, cytoplasm, nucleus, mitochondria, ribosomes, vacuole (a small "
      "one is present in animal cells too).",
     ], "1 mark each for any FOUR parts found in BOTH kinds of cell (4 marks). Do NOT accept "
        "cell wall, chloroplast or large central vacuole - these are not found in an animal "
        "cell, and the question asks for parts found in both."),
     ("(b)", [
      "Cell wall - it is made of cellulose and gives the plant cell a firm shape and support.",
      "Chloroplast - it contains chlorophyll and is where the plant makes its food by "
      "photosynthesis.",
      "Large central vacuole - it stores water and dissolved substances and helps to keep the "
      "cell firm.",
     ], "Up to 6 marks: up to 3 for each of TWO parts, 1 for naming the part, 1 for saying it "
        "is absent from an animal cell, and 1 for a correct function. Give 0 for a part that "
        "is also found in an animal cell.")],
 4: [("(a)", [
      "A cell is the smallest unit of living matter, for example a muscle cell or a nerve cell.",
      "A tissue is a group of similar cells working together to do the same job, for example "
      "muscle tissue.",
      "An organ is made of several tissues working together to do a bigger job, for example "
      "the heart, the stomach or the eye.",
     ], "Up to 6 marks: up to 2 for each of the three terms, 1 for a correct definition and 1 "
        "for a correct human example. Give 0 for a definition that does not mention what the "
        "level is made of."),
     ("(b)", [
      "Cells are far too small to be seen with the naked eye, so a microscope is needed to "
      "magnify them.",
     ], "Up to 2 marks: 1 for saying cells are very small and 1 for saying the microscope "
        "magnifies them. Do NOT accept 'because they are inside the body'.")],
 5: [("(a)", [
      "Any four: rain, rivers, streams, lakes, springs, wells, boreholes, ponds, lagoons, "
      "underground water.",
     ], "1 mark each for any FOUR natural sources (4 marks). Do NOT accept 'the sea' unless "
        "the pupil explains it is a natural source, and do NOT accept 'pipe-borne water' or "
        "'sachet water' - those are not sources."),
     ("(b)", [
      "Surface water is water that flows or stands on top of the ground, such as a river, a "
      "stream, a lake or a pond.",
      "Underground water is water that has soaked into the ground and is held in the soil and "
      "rock below, such as the water in a well or a borehole.",
      "Surface water is more easily polluted and dries up more quickly; underground water has "
      "been filtered by the soil and is usually cleaner.",
     ], "Up to 4 marks: 1 for a correct description of surface water, 1 for a correct example, "
        "1 for a correct description of underground water and 1 for a correct example. Accept "
        "a correct extra point about cleanliness in place of an example."),
     ("(c)", [
      "Boil the water for several minutes and let it cool. Boiling kills the germs that cause "
      "dysentery, cholera and typhoid.",
      "Filter the water first through a clean cloth and then through a sand and gravel filter. "
      "This removes the dirt, the leaves and the small animals that carry disease.",
      "Let the water stand so that the mud settles, then pour off the clear water. This "
      "removes most of the solid dirt.",
      "Add chlorine or a water-treatment tablet. This kills the germs that are left.",
     ], "Up to 4 marks: up to 2 for each of TWO things, 1 for what is done and 1 for why it "
        "helps. A pupil who says only 'boil it' earns 1 for that part. Do NOT accept 'put it "
        "in the sun' on its own.")],
 6: [("(a)", [
      "Evaporation: the sun heats water in rivers, lakes and the sea, and the water changes "
      "into water vapour and rises into the air.",
      "Condensation: the water vapour rises, cools, and changes back into tiny drops of liquid "
      "water, which join together to form clouds.",
      "Precipitation: the drops in the clouds get bigger and heavier and fall back to the "
      "earth as rain, hail or snow.",
      "Transpiration: plants take in water through their roots and lose water vapour through "
      "the small openings in their leaves.",
      "Also accept 'collection', where the water gathers again in rivers, lakes and the sea.",
     ], "Up to 8 marks: up to 2 for each of FOUR stages, 1 for naming the stage and 1 for "
        "explaining what happens. A stage that is named but not explained earns 1. Do NOT "
        "accept 'the water goes up' on its own for evaporation."),
     ("(b)", [
      "The same water is used over and over again. Nothing is lost, and the stages follow one "
      "another in the same order without stopping.",
     ], "Up to 2 marks: 1 for saying the stages follow one another in the same order and 1 for "
        "saying the water is reused and nothing is lost. Do NOT accept 'it goes round and "
        "round' on its own.")],
 7: [("(a)", [
      "The dry seed lies in the soil. When there is water, air and warmth it germinates.",
      "The seed coat splits and the root grows downwards first, then the shoot grows upwards "
      "towards the light.",
      "The shoot grows into a seedling with its first leaves, and the plant begins to make its "
      "own food.",
      "The seedling grows into an adult maize plant with tall stems, long leaves, tassels at "
      "the top and cobs on the side.",
      "The adult plant flowers, is pollinated by the wind, and makes new seeds on the cob. The "
      "seeds ripen, are harvested, and the cycle can begin again.",
     ], "Up to 6 marks: 1 for each correct stage described, up to 6. Accept any valid "
        "description of the life cycle of a named crop. Do NOT award marks for stages that are "
        "out of order."),
     ("(b)", [
      "SET UP: take two identical dishes or tins and put cotton wool or soil in each. Put the "
      "same number of maize seeds, of the same kind, in each. Water the seeds in dish A and "
      "leave the seeds in dish B completely dry. Put both dishes in the same warm, light "
      "place.",
      "KEEP THE SAME: the kind of seed, the number of seeds, the dish, the soil or cotton "
      "wool, the warmth and the light. The only thing that is different is the water. This "
      "makes it a fair test.",
      "EXPECTED RESULT: the seeds in dish A swell, split and send out a root and a shoot. The "
      "seeds in dish B stay dry, hard and unchanged.",
      "CONCLUSION: because everything else was kept the same, the difference shows that water "
      "is needed for germination.",
      "Air (oxygen). Without air the seed cannot respire to release the energy it needs to "
      "grow, and it rots instead.",
     ], "Up to 4 marks: 1 for setting up two dishes or groups, 1 for saying that only the "
        "water is different while everything else is kept the same, 1 for the expected "
        "result, and 1 for the conclusion. A pupil who describes a fair test but forgets to "
        "say what would be seen earns 3 at most. Do NOT accept an experiment with no "
        "comparison.")],
 8: [("(a)", [
      "Any three: they give food such as meat, milk and eggs; they give income when they are "
      "sold; they give manure for the farm; they provide hides, skin and wool; they provide "
      "transport or draught power; they are used for ceremonies and dowry; they eat the "
      "left-over crop residue; they provide employment.",
     ], "1 mark each for any THREE sensible uses (3 marks). Do NOT accept the same use written "
        "twice in different words."),
     ("(b)", [
      "A ruminant has a four-chambered stomach and chews the cud; it can digest grass and "
      "other rough plant material. A monogastric has a simple, single-chambered stomach and "
      "cannot digest large amounts of grass.",
      "Example of a ruminant: a cow, a goat, a sheep or a deer. Example of a monogastric: a "
      "pig, a rabbit or a human being.",
     ], "Up to 5 marks: up to 3 for the difference, 2 for describing the ruminant's stomach "
        "and cud-chewing and 1 for describing the monogastric stomach; then 1 for a correct "
        "example of a ruminant and 1 for a correct example of a monogastric. Do NOT accept "
        "'ruminants eat more'.")],
 9: [("(a)", [
      "Mouth, oesophagus (gullet), stomach, small intestine, large intestine, rectum, anus.",
     ], "1 mark each for the parts in the CORRECT ORDER, up to 5 marks. Stop awarding marks at "
        "the first part that is out of order. Do NOT accept the liver, the pancreas or the "
        "gall bladder - food does not pass through them."),
     ("(b)", [
      "In the mouth the teeth chew the food and break it into smaller pieces, which gives a "
      "bigger surface for the digestive juice to work on. Saliva mixes with the food and "
      "begins the digestion of starch. The tongue rolls the food into a ball so it can be "
      "swallowed.",
      "In the stomach the food is churned and mixed with gastric juice, which contains acid. "
      "The acid kills many germs and the juice begins the digestion of protein. The food is "
      "turned into a thick liquid.",
     ], "Up to 4 marks: up to 2 for the mouth and 2 for the stomach. In each case 1 mark for "
        "what physically happens and 1 for the juice and what it digests. Do NOT accept 'the "
        "stomach absorbs the food'."),
     ("(c)", [
      "The small intestine is very long, so the food takes a long time to pass along it.",
      "Its inner wall is folded and covered with villi, which give it a very large surface "
      "area for absorption.",
      "Its wall is thin and has many blood vessels close to the surface, so the digested food "
      "passes quickly into the blood.",
      "The stomach mainly churns and mixes food; very little digested food is absorbed "
      "through its wall.",
     ], "Up to 3 marks: 1 mark each for any THREE correct reasons. Accept only reasons that "
        "refer to length, surface area, villi, a thin wall or a rich blood supply. Do NOT "
        "accept 'it is small'.")],
 10: [("(a)", [
      "Any four: Mercury, Venus, Earth, Mars.",
     ], "1 mark each for the four inner planets IN THE CORRECT ORDER starting from the sun (4 "
        "marks). Do NOT accept Jupiter or any outer planet, and stop awarding marks at the "
        "first planet that is out of order."),
     ("(b)", [
      "Rotation is the earth spinning on its own axis. It takes about 24 hours, and it gives "
      "us day and night.",
      "Revolution is the earth moving round the sun along its orbit. It takes about 365 days, "
      "which is one year.",
     ], "Up to 6 marks: up to 3 for rotation, 1 for what it is, 1 for how long it takes and 1 "
        "for what it causes; and up to 3 for revolution on the same pattern. A pupil who "
        "confuses the two earns half the marks for each only if the definitions are otherwise "
        "correct.")],
 11: [("(a)", [
      "Biotic components are the living parts of the ecosystem. From the pond: the fish, the "
      "frogs, the water plants, the insects, the bacteria.",
      "Abiotic components are the non-living parts. From the pond: the water, the sunlight, "
      "the temperature, the dissolved oxygen, the soil and stones at the bottom.",
     ], "Up to 6 marks: 1 for a correct definition of biotic, 1 mark each for TWO correct "
        "biotic examples from the pond (2 marks), 1 for a correct definition of abiotic, and "
        "1 mark each for TWO correct abiotic examples (2 marks). Do NOT accept a 'dead leaf' "
        "as biotic."),
     ("(b)", [
      "For example: maize - grasshopper - lizard - hawk. Also accept grass - grasshopper - "
      "toad - snake, or algae - tadpole - fish - kingfisher.",
      "The arrow means 'is eaten by', so it shows the direction in which the energy and the "
      "food pass.",
     ], "Up to 4 marks: up to 3 for a correct four-link food chain, 1 for starting with a "
        "plant (producer) and 1 for each correct feeding link, and 1 for explaining what the "
        "arrow means. Give 0 if the chain starts with an animal, and 0 if the arrows point "
        "the wrong way.")],
 12: [("(a)", [
      "Crop rotation is growing different crops one after another on the same piece of land in "
      "different seasons or years.",
      "Mixed cropping is growing two or more different crops together on the same piece of "
      "land at the same time.",
     ], "Up to 4 marks: up to 2 for each explanation, 1 for the idea of 'one after another' "
        "for crop rotation and 1 for 'at the same time' for mixed cropping. That one word - "
        "time - is the whole difference, so accept only answers that make it clear. Give 1 "
        "for a correct named example of each even if the explanation is weak."),
     ("(b)", [
      "Accept any sensible choice that is argued. The strongest answer is mixed cropping with "
      "compost and watering in the dry season: it gives two or more crops from the same small "
      "piece of land at the same time, spreads the risk if one crop fails, keeps the soil "
      "covered so it does not wash away, and gives the family food across the year.",
      "Accept also intensive mixed farming with irrigation, argued well.",
      "Do NOT give full marks for shifting cultivation or land rotation with a long fallow - "
      "with one small piece of land there is nowhere to move to and no spare land to rest.",
     ], "Up to 4 marks: 1 for a clear choice, 1 for explaining why it suits a SMALL piece of "
        "land, 1 for a reason based on the soil or on having food across the year, and 1 for "
        "comparing it with a system that would not work here. A pupil who chooses but gives "
        "no reason earns 1 only.")],
 13: [("(a)", [
      "Potential energy is stored energy, energy a body has because of its position or its "
      "condition. Example: a stone held high above the ground, or water held behind a dam.",
      "Kinetic energy is the energy a body has because it is moving. Example: a rolling ball, "
      "a moving car, or running water.",
     ], "Up to 4 marks: 1 for a correct definition of potential energy, 1 for a correct "
        "example, 1 for a correct definition of kinetic energy and 1 for a correct example. "
        "Give 0 for an example placed under the wrong heading. Do NOT accept 'potential "
        "energy is energy that has not been used yet'."),
     ("(b)", [
      "While the boy holds the stone still, it has only potential energy.",
      "As soon as he lets go, the stone falls and its potential energy changes into kinetic "
      "energy. The higher it was, the more it had.",
      "As it falls it loses height, so its potential energy falls, and it gains speed, so its "
      "kinetic energy rises.",
      "Just before it hits the ground almost all of its energy is kinetic.",
      "When it hits the ground the energy changes into heat, sound and the work of making a "
      "dent in the ground.",
     ], "Up to 4 marks: 1 for saying it starts with potential energy, 1 for saying that energy "
        "changes into kinetic energy as it falls, 1 for saying potential energy decreases "
        "while kinetic energy increases, and 1 for saying what happens to the energy at "
        "impact. A pupil who says only 'it falls' earns 0."),
     ("(c)", [
      "The law says that energy cannot be created or destroyed. It can only be changed from "
      "one form into another.",
      "For the falling stone this means that no energy is lost. The potential energy the stone "
      "had at the top is not destroyed; it becomes kinetic energy as the stone falls, and "
      "then heat, sound and the work done on the ground when it lands.",
     ], "Up to 4 marks: up to 2 for a correct statement of the law, 1 for 'cannot be created "
        "or destroyed' and 1 for 'changed from one form to another'. Then up to 2 for "
        "applying it to the stone. A pupil who states the law but does not apply it earns 2 "
        "at most. Do NOT accept 'energy is used up'.")],
 14: [("(a)", [
      "A battery (or cell) - it pushes the electric current round the circuit.",
      "A bulb (or LED) - it lights up and shows that current is flowing; it changes "
      "electrical energy into light.",
      "A switch - it closes the circuit to let current flow, or opens it to stop the current.",
      "Connecting wire - it gives the current a path to flow along.",
     ], "Up to 6 marks: up to 2 for each of THREE components, 1 for naming it and 1 for what "
        "it does. Give 1 for a component that is named but not explained. Do NOT accept 'a "
        "plug' unless the pupil says it connects the circuit to a supply."),
     ("(b)", [
      "Opening the switch breaks the circuit, so the path is no longer complete. The current "
      "stops flowing and the bulb goes out.",
     ], "Up to 2 marks: 1 for saying the circuit is broken and 1 for saying the bulb goes "
        "out. Do NOT accept 'the battery stops working'."),
     ("(c)", [
      "The strongest answer is switching off the air conditioner or using a fan instead, "
      "because cooling uses far more electricity than lighting or a radio.",
      "Accept also: replacing filament bulbs with LED bulbs, because lighting is on for many "
      "hours every evening and an LED uses a small fraction of the electricity for the same "
      "light.",
      "Accept any ONE way, provided the pupil says WHY it makes the biggest difference, for "
      "example by comparing it with something that uses less.",
     ], "Up to 2 marks: 1 for naming a way and 1 for comparing it with another use and saying "
        "why it saves more. A pupil who names a way without any comparison earns 1 at most. "
        "Do NOT accept 'do not use electricity'.")],
 15: [("(a)", [
      "A force is a push or a pull on an object.",
      "A force can make a stationary object move.",
      "A force can make a moving object stop, speed up or slow down.",
      "A force can change the direction in which an object is moving.",
      "A force can change the shape of an object, by stretching, squashing, bending or "
      "twisting it.",
     ], "Up to 6 marks: up to 2 for the definition, 1 for 'push' and 1 for 'pull'; then 1 "
        "mark each for any THREE correct effects, up to 3, and 1 more for a fourth. Do NOT "
        "accept 'a force can make something heavy'."),
     ("(b)", [
      "Before the bus stops, both the bus and the passenger are moving forward together.",
      "The brakes act on the wheels of the bus, so the bus slows down. Nothing pushes the "
      "passenger backwards to slow him down.",
      "Because of inertia the passenger keeps on moving forward at the old speed, so he falls "
      "towards the front of the bus.",
      "Accept also: the passenger's feet stop with the bus but the upper part of the body "
      "keeps moving.",
     ], "Up to 4 marks: 1 for saying both were moving together, 1 for saying the bus is slowed "
        "by the brakes, 1 for saying the passenger keeps moving because of inertia, and 1 for "
        "saying he therefore falls forward. A pupil who says only 'because of inertia' earns "
        "1. Do NOT accept 'a force pushes him forward'.")],
 16: [("(a)", [
      "Lever - used to lift a heavy stone, or a cutlass used to split a coconut.",
      "Inclined plane - a ramp used to push a drum into a lorry.",
      "Pulley - used to draw water from a well.",
      "Wheel and axle - the winding handle of a well, or a steering wheel.",
      "Screw - used to hold two pieces of wood together.",
      "Wedge - an axe or a cutlass used for splitting.",
     ], "Up to 6 marks: up to 2 for each of THREE machines, 1 for naming it and 1 for a "
        "correct use. Accept only genuine simple machines; do NOT accept 'a car engine' or "
        "'a tractor'."),
     ("(b)", [
      "Some of the energy put into the machine is always changed into forms that are not "
      "useful, mainly heat and sound, because of friction between the moving parts.",
      "That wasted energy is not destroyed - it has gone into the surroundings - but it is no "
      "longer doing the job the machine was built for, so the useful energy out is always "
      "less than the energy put in.",
     ], "Up to 2 marks: 1 for saying some energy is wasted, and 1 for naming friction, heat "
        "or sound as the cause. Do NOT accept 'because the machine is old'.")],
 17: [("(a)", [
      "Kwashiorkor - protein.", "Night blindness - vitamin A.", "Rickets - vitamin D, calcium "
      "or phosphorus.", "Scurvy - vitamin C.", "Anaemia - iron.",
      "Goitre - iodine.",
     ], "Up to 6 marks: up to 2 for each of THREE diseases, 1 for the disease and 1 for the "
        "missing nutrient. Give 0 if the nutrient is paired with the wrong disease."),
     ("(b)", [
      "Eat a balanced diet with foods from all the food groups, especially beans, fish, eggs, "
      "green vegetables and fruit.",
      "Grow a kitchen garden or keep a few animals so that the family has its own supply of "
      "vegetables, eggs and milk.",
      "Use fortified foods, such as iodised salt, vitamin A-fortified oil or iron-fortified "
      "flour.",
      "Teach mothers and pupils about the causes of deficiency diseases at the clinic and at "
      "school.",
      "Take children for regular weighing and check-ups at the clinic so that a problem is "
      "caught early.",
     ], "Up to 4 marks: up to 2 for each of TWO ways, 1 for the way and 1 for how it helps. "
        "Give 1 for a bare 'eat good food'. Do NOT accept 'take medicine' on its own."),
     ("(c)", [
      "Antibiotics kill bacteria. They have no effect on viruses, because viruses are not "
      "bacteria and are not alive in the same way; they grow inside the body's own cells.",
      "Taking antibiotics for a viral illness does not cure it and can allow resistant "
      "bacteria to grow.",
     ], "Up to 2 marks: 1 for saying antibiotics act on bacteria and not viruses, and 1 for "
        "saying viruses are different or live inside the body's cells. Do NOT accept 'because "
        "viruses are stronger'.")],
 18: [("(a)", [
      "Biodegradable waste is waste that can rot or be broken down by bacteria and other "
      "decomposers. Examples: food remains, vegetable peels, dry leaves, maize husks, paper, "
      "animal dung.",
      "Non-biodegradable waste is waste that cannot rot, or takes a very long time to break "
      "down. Examples: polythene bags, plastic bottles, glass, metal tins, tyres.",
     ], "Up to 6 marks: 1 for a correct definition of biodegradable, 1 mark each for TWO "
        "correct biodegradable examples (2 marks), 1 for a correct definition of "
        "non-biodegradable, and 1 mark each for TWO correct non-biodegradable examples (2 "
        "marks). Give 0 for an example placed under the wrong heading."),
     ("(b)", [
      "It attracts flies, rats and other animals that carry disease to people's homes.",
      "It blocks drains and gutters, so rain water cannot run away and the area floods.",
      "It poisons the soil and the water when rain washes harmful chemicals out of the waste.",
      "Burning the waste, especially plastic, fills the air with smoke that damages the lungs.",
      "It smells bad and spoils the look of the town, which drives visitors away.",
     ], "Up to 4 marks: up to 2 for each of TWO problems, 1 for the problem and 1 for how it "
        "affects people or the environment. A pupil who says only 'it is dirty' earns 1 for "
        "that part, not 2.")],
 19: [("(a)", [
      "Sustainable energy is energy from a source that will not run out, because it is "
      "replaced by nature as fast as people use it.",
      "Examples: the sun (solar energy), the wind, moving water behind a dam, biogas made "
      "from animal and food waste, heat from inside the earth.",
      "Accept also: a source that can be managed, such as wood from a plantation where new "
      "trees are planted as they are cut.",
     ], "Up to 6 marks: up to 2 for the definition, 1 for 'will not run out' and 1 for the "
        "idea that nature replaces it; then 1 mark each for TWO correct examples, and 1 more "
        "for a third. Do NOT accept petrol, diesel, charcoal, coal, kerosene or LPG - none "
        "of these will last. Do NOT accept bare 'electricity', because it depends on the "
        "source it is made from."),
     ("(b)", [
      "Accept any sensible example, for instance: a cocoa or shea factory fits solar panels "
      "and a solar dryer, so it no longer burns firewood or runs a diesel dryer, which cuts "
      "smoke, cuts the carbon dioxide given out, and saves money on fuel.",
      "Or: a factory treats its waste water before it goes into the river, so the fish and "
      "the drinking water downstream are not poisoned.",
      "Or: a mill fits a more efficient motor and insulates its steam pipes, so it uses less "
      "electricity for the same amount of maize.",
      "Or: a mine or a large farm uses a biogas plant to turn its own waste into fuel.",
     ], "Up to 4 marks: 1 for naming a real Ghanaian industry or a realistic one, 1 for the "
        "science or technology used, 1 for how it harms the environment less, and 1 for the "
        "result. A pupil who suggests something sensible but vague, such as 'use solar "
        "power', earns 2 at most. Give 0 for an answer that does not mention the "
        "environment.")],
 20: [("(a)", [
      "Any two, described: a plateau is a flat area of land raised high above the land around "
      "it, for example the Kwahu Plateau. A plain is a large area of low, nearly level land, "
      "for example the Accra Plains. A mountain is land that rises very high, with a peak, "
      "for example Mount Afadjato. A valley is low land between hills or mountains, often "
      "with a river, for example the Volta valley.",
     ], "Up to 4 marks: up to 2 for each of TWO landforms, 1 for naming it and 1 for "
        "describing it. Accept a named Ghanaian example in place of the description. Do NOT "
        "accept things that are not landforms, such as 'a forest' or 'a river'."),
     ("(b)", [
      "Any one, explained: it stores water in a swollen trunk, a thick stem or an underground "
      "bulb, so it can keep living through the long dry season.",
      "It sheds its leaves in the dry season, so no water is lost from them while there is "
      "none in the soil.",
      "It has small, tough or waxy leaves, which lose water very slowly.",
      "It sends a very long root down to reach water far below the surface.",
      "Its seeds wait in the soil until there has been enough rain before they grow.",
     ], "Up to 4 marks: up to 4 for ONE adaptation explained well, or up to 2 each for TWO "
        "adaptations named with a brief explanation. Give 1 for an adaptation that is named "
        "but not explained. Do NOT accept 'it is green' or 'it has roots'.")],
}

# ------------------------------------------------------------------ helpers
def topic_totals():
    """(marks, items) per sub-strand. Each MCQ is worth 2 marks."""
    m = {k: 0 for k in TOPIC}; it = {k: 0 for k in TOPIC}
    for q in MCQ:
        m[q[3]] += 2; it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            m[tp] += mk; it[tp] += 1
    return m, it


def strand_totals():
    m = {k: 0 for k in STRAND_NAME}; it = {k: 0 for k in STRAND_NAME}
    for q in MCQ:
        m[q[3][:2]] += 2; it[q[3][:2]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            m[tp[:2]] += mk; it[tp[:2]] += 1
    return m, it


def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}; b = {k: 0 for k in order}
    for q in MCQ: a[q[4]] += 2
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: b[cog] += mk
    return order, a, b


def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ: d[q[5]] += 2
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: d[diff] += mk
    return d


def section_totals():
    return 2 * len(MCQ), sum(qb["total"] for qb in SECTION_B)


def topic_totals_by_section():
    """(marksA, marksB, itemsA, itemsB) per sub-strand, Section A and Section B separately."""
    am = {k: 0 for k in TOPIC}; bm = {k: 0 for k in TOPIC}
    ai = {k: 0 for k in TOPIC}; bi = {k: 0 for k in TOPIC}
    for q in MCQ:
        am[q[3]] += 2; ai[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            bm[tp] += mk; bi[tp] += 1
    return am, bm, ai, bi


def strand_totals_by_section():
    am = {k: 0 for k in STRAND_NAME}; bm = {k: 0 for k in STRAND_NAME}
    ai = {k: 0 for k in STRAND_NAME}; bi = {k: 0 for k in STRAND_NAME}
    for q in MCQ:
        am[q[3][:2]] += 2; ai[q[3][:2]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            bm[tp[:2]] += mk; bi[tp[:2]] += 1
    return am, bm, ai, bi


def difficulty_by_section():
    da = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    db = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ: da[q[5]] += 2
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: db[diff] += mk
    return da, db
