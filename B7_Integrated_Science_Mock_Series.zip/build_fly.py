# -*- coding: utf-8 -*-
"""Basic 7 Integrated Science mock - Strand 2 Sub-strand 2: LIFE CYCLE OF ORGANISMS. 100 marks.
Indicators sourced from the official NaCCA Science CCP curriculum (B7/JHS1-B9/JHS3, Sept 2020),
Strand 2: Cycles, Sub-strand 2: Life Cycle of Organisms, printed pages 9-10."""

SCHOOL = "[SCHOOL NAME]"
SUBJECT = "INTEGRATED SCIENCE (SCIENCE)"
EXAM = "END-OF-TERM MOCK EXAMINATION"
CLASS = "Basic 7 (JHS 1)"
TIME = "2 hours (Suggested: Section A - 40 min; Section B - 80 min)"
MARKS = "100"
YEAR = "2025/2026 Academic Year"

STRAND = "Cycles"
SUBSTRAND = "Life Cycle of Organisms"

TOPIC = {
    "4.1": "4.1 What is a Life Cycle?",
    "4.2": "4.2 Stages of the Life Cycle of the Housefly: Egg \u2192 Larva \u2192 Pupa \u2192 Adult",
    "4.3": "4.3 Feeding Habits of the Housefly",
    "4.4": "4.4 How the Housefly Affects Human Health",
    "4.5": "4.5 Diseases Spread by the Housefly",
    "4.6": "4.6 How to Reduce the Effects of Housefly Activities",
}

CS = "B7/JHS1.2.2.1"
CS_TEXT = "Demonstrate the skills of carrying out activities to show the stages of the life cycle of a " \
          "housefly, the effects of its activities on humans and how to reduce them"

IND = {
    "4.1": "B7/JHS1.2.2.1.1 (Ex. 1)",
    "4.2": "B7/JHS1.2.2.1.1 (Ex. 1, 2, 3, 4)",
    "4.3": "B7/JHS1.2.2.1.2 (Ex. 1)",
    "4.4": "B7/JHS1.2.2.1.2 (Ex. 2)",
    "4.5": "B7/JHS1.2.2.1.2 (Ex. 2a)",
    "4.6": "B7/JHS1.2.2.1.2 (Ex. 3)",
}
IND_TEXT = {
    "4.1": "Identify and describe what a life cycle is; show that the stages repeat to form a cycle.",
    "4.2": "Identify and describe the stages of the life cycle of the housefly; show the order "
           "(egg \u2192 larva \u2192 pupa \u2192 adult); draw and link the stages; write notes on each stage.",
    "4.3": "Demonstrate knowledge of the housefly's feeding habit, e.g. feeding on dead animals, rotten food, "
           "manure, solid and liquid waste.",
    "4.4": "Discuss how the activities of the housefly affect humans in terms of transfer of diseases, "
           "food poisoning, and nuisance in the environment.",
    "4.5": "Name and discuss the types of diseases the housefly transfers to humans (such as dysentery).",
    "4.6": "Design an intervention that can reduce the effects of the activities of the housefly on humans "
           "and educate the community about it.",
}
CC = {
    "4.1": "CC, DL", "4.2": "CC, DL, CI", "4.3": "CC, DL",
    "4.4": "CC, DL", "4.5": "CC, DL", "4.6": "CI, CC, DL",
}

# ---------------------------------------------------------------- SECTION A
# (question, [A,B,C,D], answer, topic, cognitive, difficulty)
MCQ = [
 ("The series of changes that a living thing goes through from the beginning of its life to the time it "
  "produces young ones of its own is called its",
  ["habitat", "adaptation", "life cycle", "reproduction"], "C", "4.1", "Remember", "Easy"),

 ("A life cycle is described as a cycle because",
  ["it begins and ends in the same way, with the adult producing the stage it started from",
   "it happens only once in the life of the organism",
   "the organism dies at the end of it",
   "it is always very short"], "A", "4.1", "Understand", "Moderate"),

 ("The main purpose of reproduction in living things is to",
  ["make the organism grow taller", "help the organism to find food",
   "make the organism live for ever",
   "produce young ones so that the kind of organism does not die out"], "D", "4.1", "Understand", "Easy"),

 ("All of the following have a life cycle EXCEPT",
  ["a housefly", "a maize plant", "a human being", "a stone"], "D", "4.1", "Understand", "Easy"),

 ("Which of the following correctly shows a life cycle?",
  ["Egg \u2192 larva \u2192 pupa, and then it stops", "Egg \u2192 larva \u2192 pupa \u2192 adult \u2192 egg",
   "Adult \u2192 pupa \u2192 larva \u2192 egg", "Larva \u2192 egg \u2192 pupa \u2192 adult"],
  "B", "4.1", "Understand", "Moderate"),

 ("Why is it useful for pupils to study the life cycle of an organism?",
  ["It helps us to give names to all living things.", "It makes the organism grow faster.",
   "It helps us to know when and where the organism can be controlled or protected.",
   "It tells us only how long the organism lives."], "C", "4.1", "Understand", "Moderate"),

 ("The first stage in the life cycle of the housefly is the",
  ["egg", "larva", "pupa", "adult"], "A", "4.2", "Remember", "Easy"),

 ("The larva of a housefly is commonly called a",
  ["caterpillar", "nymph", "grub", "maggot"], "D", "4.2", "Remember", "Moderate"),

 ("Which of the following gives the correct order of the stages in the life cycle of the housefly?",
  ["Egg, pupa, larva, adult", "Egg, larva, pupa, adult", "Larva, egg, pupa, adult",
   "Pupa, egg, larva, adult"], "B", "4.2", "Remember", "Easy"),

 ("The stage of the housefly that does not feed and is usually inactive is the",
  ["egg", "larva", "pupa", "adult"], "C", "4.2", "Understand", "Moderate"),

 ("A female housefly usually lays her eggs",
  ["on moist, decaying matter such as refuse and animal droppings",
   "on dry, clean glass", "inside water only", "on green leaves only"],
  "A", "4.2", "Understand", "Moderate"),

 ("The larva of the housefly feeds continuously so that it can",
  ["become an adult immediately", "grow quickly before it changes into a pupa",
   "produce eggs", "fly away at once"], "B", "4.2", "Understand", "Moderate"),

 ("Which stage of the housefly has wings and can fly?",
  ["The egg", "The larva", "The pupa", "The adult"], "D", "4.2", "Remember", "Easy"),

 ("During the pupa stage the housefly",
  ["changes into its adult form inside a brown case", "lays eggs",
   "feeds on refuse", "flies from place to place"], "A", "4.2", "Understand", "Moderate"),

 ("A housefly lays many eggs at a time mainly because",
  ["it cannot count", "many of the eggs and young ones will not survive to become adults",
   "all the eggs hatch at the same time", "it has nowhere to keep them"],
  "B", "4.2", "Understand", "Moderate"),

 ("Houseflies feed mainly on liquid food because",
  ["they have teeth", "their mouthparts can only take in liquid or food dissolved in liquid",
   "they do not like solid food", "they have no mouth at all"],
  "B", "4.3", "Understand", "Moderate"),

 ("Which of the following describes the way a housefly takes in solid food?",
  ["It chews the food with its teeth.", "It swallows the food whole.", "It only drinks water.",
   "It drops saliva and vomit on the food to dissolve it, then sucks up the liquid."],
  "D", "4.3", "Understand", "Moderate"),

 ("Which of the following would a housefly NOT normally feed on?",
  ["Fresh bread covered and kept in a clean cupboard", "Rotten food",
   "Animal droppings (manure)", "Dead animals"], "A", "4.3", "Understand", "Moderate"),

 ("Houseflies are often found around refuse dumps because",
  ["refuse is warm and dry",
   "refuse provides both food for the adults and a place for the females to lay eggs",
   "refuse keeps them away from people", "refuse is their only source of water"],
  "B", "4.3", "Understand", "Moderate"),

 ("A housefly that has just fed on faeces lands on a plate of cooked rice. The most likely result is that",
  ["the rice becomes poisonous", "the rice becomes colder", "the rice dries up quickly",
   "disease organisms from the faeces are left on the rice"], "D", "4.3", "Apply", "Challenging"),

 ("The feeding habit that makes the housefly most dangerous to humans is that it",
  ["feeds on both filthy matter and human food, often within a short time",
   "feeds only at night", "feeds only on plants", "feeds only once in its life"],
  "A", "4.3", "Understand", "Moderate"),

 ("Which of the following is a way in which the housefly affects human health?",
  ["It bites people and sucks blood.", "It stings people.",
   "It transfers disease organisms to human food.", "It destroys crops in the field."],
  "C", "4.4", "Understand", "Easy"),

 ("Houseflies are a nuisance in the environment because they",
  ["build large nests in houses", "destroy clothing",
   "disturb people, settle on food and on people's bodies, and make places dirty",
   "bite people and draw blood"], "C", "4.4", "Understand", "Easy"),

 ("Food is left uncovered on a table and a housefly settles on it. The food is most likely to become",
  ["sweeter", "contaminated with disease organisms", "colder", "drier"],
  "B", "4.4", "Apply", "Easy"),

 ("Food poisoning caused by houseflies is likely to cause",
  ["a broken bone", "loss of sight", "tooth decay", "stomach pain, vomiting and diarrhoea"],
  "D", "4.4", "Understand", "Moderate"),

 ("Which group of people is most at risk from diseases spread by houseflies?",
  ["Only adults who work in offices", "Only people who live in cities",
   "Young children and people who eat uncovered food", "Only people who keep cats"],
  "C", "4.4", "Apply", "Moderate"),

 ("The housefly affects humans in all of the following ways EXCEPT",
  ["by injecting venom into the blood", "by transferring diseases",
   "by causing food poisoning", "by being a nuisance in the environment"],
  "A", "4.4", "Analyse", "Challenging"),

 ("Which of the following diseases can be spread by the housefly?",
  ["Malaria", "Dysentery", "Measles", "Rabies"], "B", "4.5", "Remember", "Moderate"),

 ("Dysentery is a disease that",
  ["causes a sore throat", "makes the skin turn yellow",
   "causes tooth decay", "causes severe diarrhoea, often with blood"],
  "D", "4.5", "Understand", "Moderate"),

 ("Cholera, typhoid fever and dysentery are all spread by houseflies because the organisms that cause them",
  ["are breathed in from the air", "live only in clean water",
   "live in faeces and dirty matter and are carried to food on the fly's body",
   "are injected by the fly when it bites"], "C", "4.5", "Understand", "Moderate"),

 ("A housefly carries disease organisms mainly on",
  ["its legs and body hairs, and in its droppings and vomit", "its wings only",
   "its head only", "the inside of its eggs"], "A", "4.5", "Remember", "Moderate"),

 ("Diseases spread by the housefly are most common in areas where",
  ["it rains every day", "refuse and faeces are left uncovered near homes",
   "there are many hospitals", "people sleep under mosquito nets"],
  "B", "4.5", "Apply", "Moderate"),

 ("Which of the following is NOT usually spread by houseflies?",
  ["Dysentery", "Cholera", "Typhoid fever", "Malaria"], "D", "4.5", "Analyse", "Challenging"),

 ("A pupil in Bolgatanga had severe diarrhoea after eating food that was left uncovered. The most likely "
  "cause was",
  ["the food was too cold", "the food was not cooked long enough",
   "disease organisms carried to the food by houseflies", "the food was eaten too quickly"],
  "C", "4.5", "Apply", "Challenging"),

 ("The most effective way to reduce the number of houseflies in a community is to",
  ["remove and properly dispose of the refuse and droppings where they breed",
   "kill the adult flies only", "spray perfume in the house", "keep all the windows closed"],
  "A", "4.6", "Understand", "Moderate"),

 ("Covering food and refuse bins helps to control houseflies because it",
  ["makes the food taste better",
   "stops the flies from reaching the food and the places where they lay eggs",
   "kills the flies instantly", "makes the bins last longer"],
  "B", "4.6", "Understand", "Easy"),

 ("Which of the following would NOT help to reduce the effects of housefly activities?",
  ["Covering all food", "Disposing of refuse properly", "Washing hands before eating",
   "Leaving refuse to rot in the open compound"], "D", "4.6", "Understand", "Moderate"),

 ("Screening windows and doors with wire mesh helps to control houseflies by",
  ["killing the flies", "making the house cooler", "keeping the flies out of the house",
   "attracting the flies away"], "C", "4.6", "Understand", "Easy"),

 ("Which of the following is the best long-term method of controlling houseflies in a school?",
  ["Proper refuse disposal and regular cleaning of the compound",
   "Spraying insecticide every morning", "Keeping all the windows shut", "Painting the walls white"],
  "A", "4.6", "Evaluate", "Challenging"),

 ("A community wants to reduce the diseases spread by houseflies. The best first step is to",
  ["give everyone medicine", "build more roads",
   "educate the community about proper refuse disposal, covering food and hand washing",
   "plant more trees"], "C", "4.6", "Evaluate", "Moderate"),
]

# --------------------------------------------------------- SECTION B DIAGRAM
LIFE_CYCLE = [
    "      1                2                3                4",
    "+-----------+ -> +-----------+ -> +-----------+ -> +-----------+",
    "|    EGG    | -> |   LARVA   | -> |    PUPA   | -> |   ADULT   |",
    "+-----------+ -> +-----------+ -> +-----------+ -> +-----------+",
    "",
    "laid in moist    hatches from     rests inside a   has wings,",
    "decaying         the egg; feeds   brown case;      flies and lays",
    "matter           and grows        changes into     eggs",
    "                                  an adult",
    "",
    "      ^                                                  |",
    "      |                                                  |",
    "      +- the adult lays eggs and the cycle begins again -+"
]

SECTION_B = [
 dict(
   num=1, total=8, topic="4.1",
   stem="Every living thing goes through a series of changes during its life.",
   parts=[
     ("(a)", "What is meant by the life cycle of an organism?", 2, "Understand", "4.1", "Easy"),
     ("(b)", "State three reasons why living things reproduce.", 3, "Understand", "4.1", "Moderate"),
     ("(c)", "Explain why the life cycle of an organism is described as a cycle and not as a straight line.",
      3, "Understand", "4.1", "Moderate"),
   ]),
 dict(
   num=2, total=9, topic="4.2",
   stem="The diagram below shows the life cycle of the housefly. Study it and answer the questions that follow.",
   diagram=True,
   parts=[
     ("(a)", "Name the stages labelled 1, 2, 3 and 4.", 4, "Remember", "4.2", "Easy"),
     ("(b)", "State two features of the stage labelled 2.", 2, "Understand", "4.2", "Moderate"),
     ("(c)", "Explain what happens during the stage labelled 3.", 3, "Understand", "4.2", "Moderate"),
   ]),
 dict(
   num=3, total=6, topic="4.2",
   stem="The four stages of the life cycle of the housefly follow one another in a fixed order.",
   parts=[
     ("(a)", "State where a female housefly lays her eggs and give a reason for your answer.",
      2, "Understand", "4.2", "Moderate"),
     ("(b)", "Arrange the following stages in the correct order: adult, larva, egg, pupa.",
      2, "Remember", "4.2", "Easy"),
     ("(c)", "Explain why a female housefly lays many eggs at a time.",
      2, "Understand", "4.2", "Challenging"),
   ]),
 dict(
   num=4, total=9, topic="4.3",
   stem="The housefly has a feeding habit that makes it very successful.",
   parts=[
     ("(a)", "State three things on which the housefly feeds.", 3, "Remember", "4.3", "Easy"),
     ("(b)", "Explain why the housefly cannot eat solid food in the way that human beings do.",
      3, "Understand", "4.3", "Moderate"),
     ("(c)", "Explain how the feeding habit of the housefly makes it dangerous to human beings.",
      3, "Analyse", "4.3", "Challenging"),
   ]),
 dict(
   num=5, total=11, topic="4.4, 4.5",
   stem="The activities of the housefly are a menace to human beings.",
   parts=[
     ("(a)", "State three ways in which the activities of the housefly affect human beings.",
      3, "Understand", "4.4", "Easy"),
     ("(b)", "Name two diseases that can be spread by the housefly.", 2, "Remember", "4.5", "Moderate"),
     ("(c)", "Explain how a housefly transfers disease organisms from faeces on to human food.",
      3, "Apply", "4.5", "Challenging"),
     ("(d)", "Explain what is meant by food poisoning and how the housefly can cause it.",
      3, "Understand", "4.4", "Moderate"),
   ]),
 dict(
   num=6, total=12, topic="4.6",
   stem="The effects of the activities of the housefly on humans can be reduced.",
   parts=[
     ("(a)", "State three ways of reducing the number of houseflies in the home.",
      3, "Understand", "4.6", "Easy"),
     ("(b)", "Explain why covering food and refuse bins helps to control houseflies.",
      3, "Understand", "4.6", "Moderate"),
     ("(c)", "Design an intervention that your class could carry out in your community to reduce the "
             "effects of the activities of the housefly on humans.",
      6, "Create", "4.6", "Challenging"),
   ]),
 dict(
   num=7, total=5, topic="4.2",
   stem="Pupils can show the life cycle of the housefly without keeping live flies.",
   parts=[
     ("(a)", "Describe how you would make a model or a set of flashcards to show the four stages of the "
             "life cycle of the housefly.", 3, "Create", "4.2", "Moderate"),
     ("(b)", "State two reasons why making such a model helps pupils to understand the life cycle.",
      2, "Evaluate", "4.2", "Moderate"),
   ]),
]

# ------------------------------------------------------- MARKING SCHEME
MARKING = {
 1: [
   ("(a)", ["A life cycle is the series of changes a living thing goes through during its life.",
            "It runs from the start of the organism's life (e.g. the egg or the seed) to the time that "
            "organism produces young ones of its own.",
            "The stages then repeat in the next generation."],
    "1 mark each for any TWO correct points (2 marks). Award 1 mark for 'the stages in the life of an "
    "organism' if it is not developed further."),
   ("(b)", ["So that the kind of organism does not die out (so the species continues).",
            "So that the organism replaces those that die.",
            "So that the organism can increase in number.",
            "So that the organism can spread to new places."],
    "1 mark each for any THREE correct reasons (3 marks). Accept 'to produce young ones' once. Do NOT "
    "award three marks for the same reason worded three times."),
   ("(c)", ["The last stage (the adult) produces the first stage (the egg) again, so the series comes "
            "back to where it started.",
            "It has no real beginning or end - each generation repeats the same stages.",
            "A straight line has a beginning and an end, but a life cycle goes round and round."],
    "1 mark each for any THREE correct points (3 marks). The key idea is that the adult produces the "
    "egg and the sequence repeats."),
 ],
 2: [
   ("(a)", ["1 = egg", "2 = larva", "3 = pupa", "4 = adult"],
    "1 mark each (4 marks). The number must be matched to the correct stage. Accept 'maggot' for 2. "
    "Do NOT award a mark if the label number is missing."),
   ("(b)", ["The larva (maggot) is a soft, whitish, legless worm-like creature.",
            "It hatches from the egg.",
            "It feeds continuously and grows quickly.",
            "It has no wings."],
    "1 mark each for any TWO correct features (2 marks). Accept 'it looks like a small white worm'."),
   ("(c)", ["The larva stops feeding and becomes inactive.",
            "It forms a brown case around itself.",
            "Inside the case its body changes completely into the adult form.",
            "The adult housefly then breaks out of the case."],
    "1 mark each for any THREE correct points (3 marks). Award at least 1 mark for stating that the "
    "change into the adult happens inside the pupa case."),
 ],
 3: [
   ("(a)", ["On moist, decaying matter such as refuse, rotten food and animal droppings (manure).",
            "Reason: when the eggs hatch, the larvae have food to eat immediately."],
    "1 mark for the place. 1 mark for the reason (the larvae need food as soon as they hatch). Accept "
    "'in rubbish / in faeces' for the place."),
   ("(b)", ["egg \u2192 larva \u2192 pupa \u2192 adult"],
    "1 mark for starting with the egg. 1 mark for the correct order of all four stages. Award 0 if any "
    "stage is out of order."),
   ("(c)", ["Many of the eggs and larvae are destroyed by heat, rain, animals and people.",
            "Only a few of the eggs are likely to survive to become adults.",
            "Laying many eggs makes it more likely that some will survive to continue the life cycle."],
    "1 mark each for any TWO correct points (2 marks). The key idea is that most will not survive. Do "
    "NOT award a mark for 'so that there will be many flies' on its own."),
 ],
 4: [
   ("(a)", ["Dead animals", "Rotten food", "Animal droppings (manure)",
            "Solid waste (refuse / rubbish)", "Liquid waste", "Human food and drink",
            "Faeces"],
    "1 mark each for any THREE correct items (3 marks). All of these are named in the curriculum "
    "exemplar. Accept 'sugar and other sweet things' as an additional correct answer."),
   ("(b)", ["The housefly has no teeth and cannot chew or bite solid food.",
            "Its mouthparts are made for sucking up liquid only.",
            "So it has to turn solid food into a liquid before it can take it in."],
    "1 mark each for any THREE correct points (3 marks). Award at least 1 mark for stating that the "
    "housefly can only take in liquid."),
   ("(c)", ["The housefly feeds on filthy matter such as faeces, rotten food and refuse.",
            "It then lands on the same food that people eat, often within a short time.",
            "It carries disease organisms on its legs and body hairs, and leaves them behind in its "
            "droppings and vomit.",
            "So the dirty places it feeds on and the clean food people eat are linked by the same fly."],
    "1 mark each for any THREE correct points (3 marks). The chain must link the filthy feeding place to "
    "human food. Do NOT award a mark for 'the fly is dirty' on its own."),
 ],
 5: [
   ("(a)", ["It transfers disease organisms to human food and drink.",
            "It causes food poisoning.",
            "It contaminates food, making it unfit to eat.",
            "It is a nuisance - it disturbs people, settles on food and on people's bodies, and makes "
            "places dirty."],
    "1 mark each for any THREE correct points (3 marks). The three areas named in the curriculum "
    "exemplar are transfer of diseases, food poisoning and nuisance in the environment."),
   ("(b)", ["Dysentery", "Cholera", "Typhoid fever", "Diarrhoea (as a symptom)"],
    "1 mark each for any TWO correct diseases (2 marks). Do NOT accept malaria, measles or HIV/AIDS - "
    "these are not spread by houseflies."),
   ("(c)", ["The fly first lands and feeds on faeces or other dirty matter.",
            "Disease organisms from the faeces stick to the hairs on its legs and body.",
            "The fly then lands on uncovered human food and walks over it.",
            "It also drops its droppings and vomit on the food, leaving the disease organisms behind."],
    "1 mark each for any THREE correct points (3 marks). The answer must describe the transfer from the "
    "dirty source to the food. Award at least 1 mark for stating that the organisms are carried on the "
    "fly's legs and body."),
   ("(d)", ["Food poisoning is an illness caused by eating food that contains harmful organisms or their "
            "poisons.",
            "The housefly carries these organisms from faeces, refuse and rotten matter on to the food.",
            "A person who eats that food may suffer stomach pain, vomiting and diarrhoea."],
    "1 mark each for any THREE correct points (3 marks). Award at least 1 mark for a correct meaning of "
    "food poisoning and 1 mark for the role of the fly."),
 ],
 6: [
   ("(a)", ["Cover all food and drinking water.",
            "Keep refuse in covered bins and dispose of it properly.",
            "Clean the house and compound regularly.",
            "Screen windows and doors with wire mesh.",
            "Wash hands with soap before eating and after using the toilet.",
            "Keep animal droppings away from homes and dispose of them properly."],
    "1 mark each for any THREE correct ways (3 marks). Accept the use of insecticides or fly traps as "
    "one correct point, but the better answers deal with breeding places."),
   ("(b)", ["Covering food stops the flies from landing on it and contaminating it.",
            "It also stops them from dropping their droppings and vomit on the food.",
            "Covering refuse bins stops flies from reaching the decaying matter where they feed and lay "
            "eggs.",
            "So covering breaks the link between the breeding place and human food."],
    "1 mark each for any THREE correct points (3 marks). The answer must say something about BOTH food "
    "and refuse bins to earn full marks."),
   ("(c)", ["Identify the problem in the community, e.g. open refuse, uncovered food, uncovered latrines.",
            "Choose an intervention, e.g. a clean-up campaign, providing covered refuse bins, digging a "
            "refuse pit, or screening food in the market.",
            "Say who will take part (the class, teachers, the assembly member, parents, the health "
            "worker).",
            "Say when and where it will happen, e.g. every Saturday morning in the school compound and "
            "the market.",
            "Plan how to educate the community - posters, drama, announcements at church or mosque, "
            "talking to market women and food sellers.",
            "Say how the class will check whether the intervention worked, e.g. counting flies on a "
            "trap or checking that refuse is no longer left open."],
    "6 marks. Award 1 mark each for any SIX of the following: (i) a clearly identified problem, "
    "(ii) a practical intervention, (iii) who carries it out, (iv) when or where, (v) how the community "
    "is educated, and (vi) how the intervention will be checked. Award method marks generously - this is "
    "a design task, and any sensible, safe, workable intervention earns credit. Do NOT award marks for "
    "an intervention that involves handling insecticides or other chemicals without adult supervision."),
 ],
 7: [
   ("(a)", ["Draw or collect a picture of each of the four stages: egg, larva (maggot), pupa and adult.",
            "Put each picture on its own card (or make a small model of each stage from clay, paper or "
            "other local material).",
            "Arrange the cards in the correct order: egg \u2192 larva \u2192 pupa \u2192 adult.",
            "Use arrows to join the stages, and draw an arrow from the adult back to the egg to close "
            "the cycle.",
            "Label each stage and write one short note about it."],
    "1 mark each for any THREE correct points (3 marks). Award at least 1 mark for producing four "
    "separate stages and 1 mark for linking them in the correct order with arrows."),
   ("(b)", ["It makes the order of the stages clear, and shows that the cycle comes back to the egg.",
            "Pupils can see and handle the stages instead of only hearing about them, so they remember "
            "them better.",
            "It is safer and cleaner than trying to keep live houseflies in the classroom."],
    "1 mark each for any TWO correct reasons (2 marks). Accept any sensible reason. Do NOT award a mark "
    "for 'it is fun' on its own."),
 ],
}


# --------------------------------------------- derive summary statistics
def topic_totals():
    m = {k: 0 for k in TOPIC}
    it = {k: 0 for k in TOPIC}
    for q in MCQ:
        m[q[3]] += 1
        it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk
            it[key] += 1
    return m, it

def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}
    b = {k: 0 for k in order}
    for q in MCQ:
        a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            b[cog] += mk
    return order, a, b

def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ:
        d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            d[diff] += mk
    return d
