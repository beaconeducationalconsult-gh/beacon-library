# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "/home/user")
from build_special import *

from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT

doc = Document()
_s = doc.sections[0]
_s.left_margin = Inches(0.7); _s.right_margin = Inches(0.7)
_s.top_margin = Inches(0.7); _s.bottom_margin = Inches(0.6)
st = doc.styles["Normal"]; st.font.name = "Calibri"; st.font.size = Pt(11)


def set_font(run, size=11, bold=False, italic=False, mono=False, color=None):
    run.font.size = Pt(size); run.bold = bold; run.italic = italic
    run.font.name = "Consolas" if mono else "Calibri"
    if color: run.font.color.rgb = color
    return run


def para(text="", size=11, bold=False, italic=False, align=None, mono=False,
         space_before=0, space_after=4, color=None):
    p = doc.add_paragraph()
    if align == "c": p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    elif align == "j": p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p.paragraph_format.space_before = Pt(space_before)
    p.paragraph_format.space_after = Pt(space_after)
    if text: set_font(p.add_run(text), size, bold, italic, mono, color)
    return p


def rule():
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(6); p.paragraph_format.space_before = Pt(2)
    set_font(p.add_run("_" * 88), 9, color=RGBColor(0x99, 0x99, 0x99))


def add_table(headers, rows, widths=None, size=9, head_size=9):
    t = doc.add_table(rows=1, cols=len(headers)); t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, h in enumerate(headers):
        c = t.rows[0].cells[i]; c.text = ""
        p = c.paragraphs[0]; p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_font(p.add_run(str(h)), head_size, bold=True)
    for row in rows:
        cells = t.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = ""
            p = cells[i].paragraphs[0]; p.paragraph_format.space_after = Pt(1)
            set_font(p.add_run(str(v)), size)
    if widths:
        for r_ in t.rows:
            for i, w in enumerate(widths): r_.cells[i].width = Inches(w)
    return t


A_TOTAL, B_TOTAL = section_totals()
GRAND = A_TOTAL + B_TOTAL
N_B_PARTS = sum(len(q["parts"]) for q in SECTION_B)

# =============================================================== TITLE BLOCK
para(SCHOOL, size=14, bold=True, align="c", space_after=2)
para(SUBJECT, size=12, bold=True, align="c", space_after=2)
para(EXAM, size=12, bold=True, align="c", space_after=2)
para("CLASS: %s" % CLASS, size=10, align="c", space_after=1)
para("TIME: %s" % TIME, size=10, align="c", space_after=1)
para("TOTAL MARKS: %s          %s" % (MARKS, YEAR), size=10, bold=True, align="c", space_after=4)
rule()

for t in [
 "INSTRUCTIONS TO CANDIDATES",
 "1. This paper has TWO sections, A and B. Answer ALL the questions in BOTH sections.",
 "2. SECTION A has 100 multiple-choice questions. Each question carries 2 marks. Total = 200 marks.",
 "3. SECTION B has 20 essay questions with sub-questions. The marks for each question are printed "
 "beside it. Total = 200 marks.",
 "4. Write your answers to Section A on the answer sheet provided. Write your answers to Section B "
 "in the answer book.",
 "5. For Section A, choose the BEST answer and write its letter (A, B, C or D) against the "
 "question number.",
 "6. For Section B, answer the sub-questions in the order given and number them clearly. Where a "
 "question asks for a stated number of points, give that number - extra answers are not marked.",
 "7. Write clearly and show all your working. Marks are awarded for correct points, not for "
 "repeating the question.",
]:
    para(t, size=9.5, bold=t.endswith("CANDIDATES"), space_after=2)
rule()

# ============================================================ SECTION A
para("SECTION A - OBJECTIVE TEST (100 questions)", size=13, bold=True, align="c", space_after=2)
para("Answer ALL questions. Each question carries 2 marks. Total = 200 marks. Choose the BEST "
     "answer and write its letter (A, B, C or D) against the question number on your answer "
     "sheet.", size=10, italic=True, align="c", space_after=6)

for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, 1):
    para("%d. %s" % (i, q), size=10.5, space_after=2)
    for L, o in zip("ABCD", opts):
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Inches(0.28); p.paragraph_format.space_after = Pt(0)
        set_font(p.add_run("%s. %s" % (L, o)), 10)

doc.add_page_break()

# ============================================================ ANSWER KEY
para("ANSWER KEY - SECTION A", size=13, bold=True, align="c", space_after=4)
para("Each question carries 2 marks.", size=9.5, italic=True, align="c", space_after=6)
rows = []
for r0 in range(25):
    row = []
    for k in range(4):
        n = r0 + 25 * k + 1
        row += [n, MCQ[n - 1][2]] if n <= 100 else ["", ""]
    rows.append(row)
add_table(["Q", "Ans", "Q", "Ans", "Q", "Ans", "Q", "Ans"], rows,
          widths=[0.45, 0.5, 0.45, 0.5, 0.45, 0.5, 0.45, 0.5], size=9)
para("", size=6, space_after=2)

doc.add_page_break()

# ============================================================ SECTION B
para("SECTION B - ESSAY QUESTIONS (20 questions)", size=13, bold=True, align="c", space_after=2)
para("Answer ALL questions. The marks for each question are printed beside it. Total = 200 "
     "marks.", size=10, italic=True, align="c", space_after=6)

for qb in SECTION_B:
    para("Question %d   [%d marks]   %s" % (qb["num"], qb["total"], TOPIC[qb["topic"]]),
         size=11, bold=True, space_before=8, space_after=3)
    para(qb["stem"], size=10.5, space_after=4)
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Inches(0.25); p.paragraph_format.space_after = Pt(3)
        set_font(p.add_run("%s  %s" % (lab, text)), 10.5)
        set_font(p.add_run("   [%d mark%s]" % (mk, "" if mk == 1 else "s")), 10, bold=True)
    rule()

doc.add_page_break()

# ============================================== EXPECTED ANSWERS (short form)
para("SECTION B - EXPECTED ANSWERS (SUMMARY)", size=13, bold=True, align="c", space_after=4)
sba = []
for qb in SECTION_B:
    m = {lab: ans for (lab, ans, note) in MARKING[qb["num"]]}
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        sba.append(("%d %s" % (qb["num"], lab.strip("()")), " ".join(m[lab]), tp, cog))
add_table(["Question", "Expected Answer", "Curriculum Area", "Cognitive Level"],
          [list(r) for r in sba], widths=[0.7, 4.3, 1.1, 1.1], size=8.5)

doc.add_page_break()

# ============================================================ MARKING SCHEME
para("MARKING SCHEME - SECTION B (200 marks)", size=13, bold=True, align="c", space_after=4)
para("General rules: (1) Accept any other correct and relevant answer. (2) Award marks for "
     "correct points, not for repeating the question. (3) For procedures, award method marks. "
     "(4) Do not deduct marks for spelling unless the meaning is changed. (5) Where a candidate "
     "gives more answers than are asked for, mark only the first ones up to the number asked "
     "for. (6) Each sub-question is marked out of the figure printed beside it.",
     size=9, italic=True, space_after=6)

for qb in SECTION_B:
    para("Question %d   [%d marks]" % (qb["num"], qb["total"]), size=11, bold=True,
         space_before=8, space_after=3)
    for (lab, ans_list, note) in MARKING[qb["num"]]:
        para(lab, size=10.5, bold=True, space_before=3, space_after=2)
        for a_ in ans_list:
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Inches(0.3); p.paragraph_format.space_after = Pt(2)
            set_font(p.add_run("- " + a_), 10)
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Inches(0.3); p.paragraph_format.space_after = Pt(4)
        set_font(p.add_run("Marking note: " + note), 9.5, italic=True)
    rule()

doc.add_page_break()

# ============================================================ BLUEPRINT
para("BLUEPRINT / TEST SPECIFICATION", size=13, bold=True, align="c", space_after=4)

m, it = topic_totals()
sm, si = strand_totals()
para("Summary 1 - Coverage by Strand", size=11, bold=True, space_before=4, space_after=3)
srows = [[STRAND_NAME[k], k, si[k], sm[k], "%.1f%%" % (100.0 * sm[k] / GRAND)] for k in sorted(sm)]
srows.append(["TOTAL", "-", sum(si.values()), sum(sm.values()), "100%"])
add_table(["Strand", "Code", "No. of Items", "Marks", "% of Total Marks"], srows,
          widths=[3.0, 0.7, 1.0, 0.8, 1.1], size=9)

para("Summary 2 - Coverage by Sub-strand", size=11, bold=True, space_before=8, space_after=3)
trows = [[TOPIC[k], CS_BY_TOPIC[k], it[k], m[k], "%.1f%%" % (100.0 * m[k] / GRAND), CC[k]]
         for k in sorted(m, key=lambda x: (x[1:2], float(x[2:])))]
trows.append(["TOTAL", "-", sum(it.values()), sum(m.values()), "100%", "-"])
add_table(["Sub-strand / Content Area", "Content Standard", "No. of Items", "Marks",
           "% of Total Marks", "Core Competencies"], trows,
          widths=[2.5, 1.5, 0.7, 0.6, 0.8, 0.9], size=8)

para("Summary 3 - Distribution by Cognitive Level", size=11, bold=True, space_before=8,
     space_after=3)
order, ca, cb = cognitive_by_section()
crows = [[k, ca[k], cb[k], ca[k] + cb[k], "%.1f%%" % (100.0 * (ca[k] + cb[k]) / GRAND)]
         for k in order]
crows.append(["TOTAL", sum(ca.values()), sum(cb.values()), GRAND, "100%"])
add_table(["Cognitive Level", "Section A Marks", "Section B Marks", "Total Marks",
           "% of Total"], crows, widths=[1.6, 1.3, 1.3, 1.1, 0.9], size=9)

para("Summary 4 - Distribution by Difficulty", size=11, bold=True, space_before=8, space_after=3)
diff = difficulty_totals()
drows = [[k, diff[k], "%.1f%%" % (100.0 * diff[k] / GRAND)] for k in ("Easy", "Moderate",
                                                                      "Challenging")]
drows.append(["TOTAL", sum(diff.values()), "100%"])
add_table(["Difficulty", "Marks", "% of Total Marks"], drows, widths=[1.6, 1.0, 1.3], size=9)

para("Summary 5 - Structure of the Paper", size=11, bold=True, space_before=8, space_after=3)
add_table(["Section", "Question Type", "Items", "Marks", "% of Total"],
          [["A", "Multiple choice (2 marks each)", 100, A_TOTAL,
            "%.0f%%" % (100.0 * A_TOTAL / GRAND)],
           ["B", "Essay questions with sub-questions", N_B_PARTS, B_TOTAL,
            "%.0f%%" % (100.0 * B_TOTAL / GRAND)],
           ["TOTAL", "-", 100 + N_B_PARTS, GRAND, "100%"]],
          widths=[0.8, 3.0, 0.8, 0.8, 1.0], size=9)

doc.add_page_break()

# ===================================================== QUALITY-CONTROL
para("QUALITY-CONTROL SUMMARY", size=13, bold=True, align="c", space_after=4)
para("Every question was checked against the following fourteen points.", size=9.5, italic=True,
     align="c", space_after=6)

qc = [
 ("Does every question belong to the supplied curriculum scope?",
  "Yes. All %d items - 100 objectives and %d essay sub-questions - trace to the Basic 7 "
  "Integrated Science curriculum, Strands 1 to 5, all 22 sub-strands. Every question carries a "
  "content standard and an official indicator code, shown in the blueprint. Nothing outside the "
  "B7 curriculum is tested." % (100 + N_B_PARTS, N_B_PARTS)),
 ("Is the examination appropriate for the stated class?",
  "Yes. The whole B7 syllabus is covered at B7 depth. No calculation is harder than simple "
  "arithmetic, no classification goes beyond what the curriculum names, and the essay tasks ask "
  "for the number of points a JHS 1 pupil can reasonably produce in the time allowed."),
 ("Are the questions genuinely BECE-style?",
  "Yes: Section A is 100 four-option objectives, and Section B is 20 essay questions with "
  "sub-questions, each carrying a printed mark allocation. The instruction block, the answer "
  "sheet and the mark-per-question layout all follow the BECE format."),
 ("Are there enough application and reasoning questions?",
  "Yes. 120 of 400 marks (30%%) are at Apply level or above: Apply 98, Analyse 12, Evaluate 6, "
  "Create 4. Create appears in Question 7(b), where pupils design a fair-test experiment on "
  "germination; Evaluate in Questions 12(b) and 14(c), where they must weigh options and "
  "justify a choice."),
 ("Are the MCQ distractors plausible?",
  "Yes. Distractors are drawn from the same content family as the key: a real process that "
  "happens at a different stage, a real organism placed in the wrong habitat, a real component "
  "that does something else in the circuit, and a real property that belongs to the other "
  "category. None is obviously absurd, so guessing does not reward a pupil who has not "
  "studied."),
 ("Is there only one best answer for each MCQ?",
  "Yes. Every item was reviewed for a single defensible key, and all 100 option lists were "
  "machine-checked so that the declared key sits on the correct answer. Special care was taken "
  "with the planets-in-order item, where only one ordering is correct, and with the "
  "alimentary-canal item, where the order is part of the answer."),
 ("Are the marks internally consistent?",
  "Yes. Section A = 100 items x 2 marks = %d. Section B = %s = %d. Each sub-question's printed "
  "marks match its marking-scheme allocation, and every N-mark sub-question asks for N things."
  % (A_TOTAL, " + ".join(str(q["total"]) for q in SECTION_B), B_TOTAL)),
 ("Does the total add up correctly?",
  "Yes: %d + %d = %d marks, matching the stated total on the front page. The strand table, the "
  "sub-strand table, the cognitive table, the difficulty table and the structure table all sum "
  "to the same figure." % (A_TOTAL, B_TOTAL, GRAND)),
 ("Are the answers in the answer key correct?",
  "Yes. All 100 objective keys and all %d Section B answers were verified against the marking "
  "scheme, and the objective keys were re-derived from first principles as a cross-check." %
  N_B_PARTS),
 ("Does the marking scheme match the questions?",
  "Yes. Every sub-question has an expected-answer list and a marking note covering partial "
  "credit, acceptable alternatives, common wrong answers and method marks. Notes that bite: "
  "the alimentary canal is marked in order and stops at the first error; a food chain that "
  "starts with an animal scores 0; 'sunlight' is not accepted for germination; and choosing a "
  "farming system without a reason earns 1 of 4."),
 ("Are the questions free from unnecessary ambiguity?",
  "Yes. Open items are anchored with 'name four', 'state three', 'explain TWO' and 'give ONE' "
  "plus the mark allocation. Where a question could be read two ways, the marking note states "
  "which reading is intended, as in Question 19(b), where a vague 'use solar power' is capped "
  "at 2 of 4."),
 ("Are Ghanaian contexts used naturally and accurately?",
  "Yes: maize, beans and groundnuts, cocoa and shea, the Kwahu Plateau, the Accra Plains and "
  "Mount Afadjato, streams and boreholes, wells and pulleys, tro-tro travel, sachet water, "
  "iodised salt, and a village pond. The contexts carry the question rather than decorate it."),
 ("Has any content outside the supplied curriculum been introduced?",
  "No. Every item sits inside the 22 sub-strands. No organic chemistry, no numerical physics "
  "beyond simple arithmetic, and no classification scheme the curriculum does not name. Where "
  "a term such as 'malleable' or 'inertia' appears, it is one the B7 syllabus itself uses."),
 ("Are the questions sufficiently varied?",
  "Yes. Item types include explaining physical and chemical change, justifying material "
  "choices, separating mixtures, comparing plant and animal cells, ordering levels of "
  "organisation, treating unsafe water, describing the water cycle and a crop life cycle, "
  "designing a germination experiment, ordering the alimentary canal, describing rotation and "
  "revolution, building a food chain, comparing farming systems, evaluating one for a small "
  "farm, tracing energy changes in a falling stone, building a circuit, explaining inertia, "
  "pairing deficiency diseases with nutrients, and weighing a factory's energy choice."),
]
for i, (q_, a_) in enumerate(qc, start=1):
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Inches(0.28); p.paragraph_format.space_after = Pt(2)
    set_font(p.add_run("%d. %s" % (i, q_)), 10, bold=True)
    p2 = doc.add_paragraph()
    p2.paragraph_format.left_indent = Inches(0.28); p2.paragraph_format.space_after = Pt(5)
    set_font(p2.add_run(a_), 10)

doc.add_page_break()
para("EXAMINER NOTES (for the teacher, not for candidates)", size=11, bold=True, space_after=4)
for n in [
 "The 22 sub-strand papers each test one sub-strand in depth. This paper is deliberately "
 "different: it tests the whole year in one sitting and it asks the questions those papers "
 "left out. No question here is repeated from any of them, so a class can sit both without "
 "seeing the same item twice.",
 "Difficulty is set at 30% easy, 50% moderate and 20% challenging, and 30% of the marks are at "
 "Apply level or above. If you want a harder paper, move the Section A items marked "
 "Challenging into an earlier block; they are identified in the module, not on the paper.",
 "Question 7(b) is the only Create item and it is the one pupils find hardest. They can name "
 "the conditions a seed needs but cannot set up a fair test. The marking note requires two "
 "groups, one difference, the expected result and a conclusion - teach that shape explicitly "
 "and the marks follow.",
 "Questions 12(b) and 14(c) are the Evaluate items, and both are capped at 1 mark if the pupil "
 "makes a choice with no reason. That is deliberate: the skill being tested is the "
 "justification, not the choice. There is no single right answer to either.",
 "Question 9(a) is marked in order and stops at the first part that is out of sequence. Tell "
 "the class this before the examination - it is the single easiest place to lose 5 marks "
 "through carelessness rather than ignorance.",
 "Question 11(b) scores 0 if the food chain begins with an animal, and 0 again if the arrows "
 "point the wrong way. Drill the direction: the arrow means 'is eaten by' and the chain always "
 "starts with a plant.",
 "Question 17(c) - why antibiotics do not cure a viral disease - is the kind of item that "
 "separates pupils who have understood from pupils who have memorised. It is worth a whole "
 "lesson, and it connects directly to the COVID-19 and Ebola work.",
 "Each strand carries exactly 80 marks and four essay questions. If your scheme of work spent "
 "longer on one strand than another, re-weight by moving Section A items rather than by "
 "changing the essays, so that the marking scheme stays valid.",
 "At 400 marks this paper is longer than anything a JHS 1 class will sit officially. It works "
 "best as two sittings - Section A in one session and Section B in another - or as a "
 "revision bank from which you draw items for shorter class tests.",
 "Three cheap revision activities that raise marks across the whole paper: (1) set up the "
 "germination experiment from Question 7(b) on a windowsill and leave it for a week; (2) build "
 "the Question 14 circuit with a battery, a bulb and a switch from the electronics kit; and "
 "(3) walk the class to the nearest water source and ask them to design a treatment chain for "
 "it, which is Question 5(c) done for real.",
 "Edit the school name, academic year and examination title on page 1 before printing.",
 "This is an original, teacher-made mock. It is not a reproduction of any WAEC or NaCCA "
 "examination paper.",
]:
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Inches(0.3); p.paragraph_format.space_after = Pt(3)
    set_font(p.add_run("- " + n), 10)

doc.save("/home/user/Basic7_Integrated_Science_SPECIAL_MOCK_FullCurriculum.docx")

print("docx written")
print("Section A:", len(MCQ), "questions x 2 =", A_TOTAL)
print("Section B:", len(SECTION_B), "questions /", N_B_PARTS, "sub-parts =", B_TOTAL)
print("GRAND TOTAL:", GRAND)
print("Strand marks:", dict(sorted(sm.items())), "sum", sum(sm.values()))
print("Difficulty:", diff, "sum", sum(diff.values()))
print("Cognitive:", {k: ca[k] + cb[k] for k in order}, "sum", sum(ca[k] + cb[k] for k in order))
print("Answer counts:", {L: sum(1 for q in MCQ if q[2] == L) for L in "ABCD"})
