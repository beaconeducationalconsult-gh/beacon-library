# -*- coding: utf-8 -*-
"""Basic 7 Integrated Science mock - Strand 1 Sub-strand 1: MATERIALS. 100 marks.
Indicators sourced from the official NaCCA Science CCP curriculum (B7/JHS1-B9/JHS3, Sept 2020),
Strand 1: Diversity of Matter, Sub-strand 1: Materials, printed pages 2-4."""

SCHOOL = "[SCHOOL NAME]"
SUBJECT = "INTEGRATED SCIENCE (SCIENCE)"
EXAM = "END-OF-TERM MOCK EXAMINATION"
CLASS = "Basic 7 (JHS 1)"
TIME = "2 hours (Suggested: Section A - 40 min; Section B - 80 min)"
MARKS = "100"
YEAR = "2025/2026 Academic Year"

STRAND = "Diversity of Matter"
SUBSTRAND = "Materials"

TOPIC = {
    "1.1": "1.1 States of Matter: Solids, Liquids and Gases",
    "1.2": "1.2 Properties and Differences Among Solids, Liquids and Gases",
    "1.3": "1.3 Importance of Liquids to Human Life",
    "1.4": "1.4 Importance of Solids to Human Life",
    "1.5": "1.5 The Periodic Table: Metals, Non-Metals and Noble Gases",
    "1.6": "1.6 Arrangement of Elements in the Periodic Table",
}

CS = {
    "1.1": "B7/JHS1.1.1.1", "1.2": "B7/JHS1.1.1.1",
    "1.3": "B7/JHS1.1.1.1", "1.4": "B7/JHS1.1.1.1",
    "1.5": "B7/JHS1.1.1.2", "1.6": "B7/JHS1.1.1.2",
}
CS_TEXT = {
    "B7/JHS1.1.1.1": "Recognise materials as important resources for providing human needs",
    "B7/JHS1.1.1.2": "Understand the periodic table as different elements made up of metals and non-metals "
                     "and noble gases arranged in an order",
}
IND = {
    "1.1": "B7/JHS1.1.1.1.1 (Ex. 2, 4)",
    "1.2": "B7/JHS1.1.1.1.1 (Ex. 1, 3)",
    "1.3": "B7/JHS1.1.1.1.2",
    "1.4": "B7/JHS1.1.1.1.3",
    "1.5": "B7/JHS1.1.1.2.1 (Ex. 2)",
    "1.6": "B7/JHS1.1.1.2.1 (Ex. 3)",
}
IND_TEXT = {
    "1.1": "Classify materials into liquids, solids and gases; give examples of each from the environment.",
    "1.2": "Create and complete a table to record the texture, appearance, colour and shape of materials; "
           "discuss the differences among liquids, solids and gases.",
    "1.3": "Discuss the importance of liquids in the life of humans.",
    "1.4": "Discuss the importance of specific solids to life.",
    "1.5": "Demonstrate the knowledge of the orderly arrangement of metals, non-metals and noble gases in the "
           "periodic table (identify metals, non-metals and noble gases).",
    "1.6": "Demonstrate the knowledge of the orderly arrangement of metals, non-metals and noble gases in the "
           "periodic table (deduce that elements are arranged in order of atomic number and that elements in "
           "the same group have common properties).",
}
CC = {
    "1.1": "CI, CP, CC", "1.2": "CI, CP, CC",
    "1.3": "CC, CP", "1.4": "CP, CI",
    "1.5": "DL, CP", "1.6": "DL, CP",
}

# ---------------------------------------------------------------- SECTION A
# (question, [A,B,C,D], answer, topic, cognitive, difficulty)
MCQ = [
 ("Matter is best defined as anything that",
  ["has mass but does not occupy space", "has mass and occupies space",
   "occupies space but has no mass", "can change its shape easily"], "B", "1.1", "Remember", "Easy"),

 ("Which of the following substances is a gas at room temperature?",
  ["Petrol", "Kerosene", "Palm oil", "Cooking gas (LPG)"], "D", "1.1", "Understand", "Easy"),

 ("Water that has been kept in a freezer turns into ice. The ice is water in the",
  ["liquid state", "vapour state", "solid state", "gaseous state"], "C", "1.1", "Remember", "Easy"),

 ("The process by which a liquid changes into a gas is called",
  ["evaporation", "condensation", "freezing", "melting"], "A", "1.1", "Remember", "Easy"),

 ("Which of the following is a liquid at room temperature?",
  ["A stone", "Charcoal", "Cooking gas", "Cooking oil"], "D", "1.1", "Understand", "Easy"),

 ("A pupil is given a stone, a bottle of water, an empty balloon and the same balloon filled with air. "
  "Which observation best shows that a gas has mass?",
  ["The stone sinks when it is put into water.",
   "The balloon filled with air is heavier than the empty balloon.",
   "The water takes the shape of the bottle.",
   "The stone keeps its own shape."], "B", "1.1", "Apply", "Moderate"),

 ("Which of the following statements correctly describes a solid?",
  ["It has no definite shape and no definite volume.",
   "It has a definite shape but no definite volume.",
   "It has a definite shape and a definite volume.",
   "It has no definite shape but a definite volume."], "C", "1.2", "Understand", "Easy"),

 ("The particles in a solid are",
  ["closely packed and vibrating in fixed positions",
   "far apart and moving freely",
   "far apart and vibrating in fixed positions",
   "closely packed and moving from place to place"], "A", "1.2", "Understand", "Challenging"),

 ("Akosua pours 100 cm\u00b3 of water from a short wide cup into a tall narrow bottle. What happens to the water?",
  ["Its volume becomes more than 100 cm\u00b3.",
   "Its mass increases.",
   "It changes into a solid.",
   "Its volume remains 100 cm\u00b3 but its shape changes."], "D", "1.2", "Apply", "Challenging"),

 ("Which of the following statements about gases is correct?",
  ["Gases cannot be compressed.",
   "Gases can be compressed and they fill any container.",
   "Gases have a definite shape.",
   "Gases have a definite volume but no definite shape."], "B", "1.2", "Understand", "Moderate"),

 ("Liquids and gases are both called fluids because they",
  ["are colourless", "have a definite shape", "can flow", "cannot be compressed"],
  "C", "1.2", "Understand", "Easy"),

 ("Kwame squeezes a plastic bottle that is full of air and the bottle becomes smaller. This observation "
  "shows that",
  ["air can be compressed", "air is a liquid", "air has no mass", "air has a definite shape"],
  "A", "1.2", "Apply", "Moderate"),

 ("Cooking oil that is poured from a bottle into a pot will",
  ["keep the shape of the bottle", "change into a gas at once", "lose all its mass",
   "take the shape of the pot and keep the same volume"], "D", "1.2", "Apply", "Moderate"),

 ("Which of the following statements about liquids is correct?",
  ["A liquid has a definite shape and a definite volume.",
   "A liquid has a definite volume but no definite shape.",
   "A liquid has no definite volume and no definite shape.",
   "A liquid has a definite shape but no definite volume."], "B", "1.2", "Understand", "Moderate"),

 ("Which of the following materials can be compressed most easily?",
  ["A stone", "Water", "Air", "A metal block"], "C", "1.2", "Understand", "Moderate"),

 ("Which of the following liquids is commonly used in Ghanaian hospitals and clinics to clean wounds?",
  ["Methylated spirit", "Petrol", "Kerosene", "Engine oil"], "A", "1.3", "Remember", "Easy"),

 ("Which of the following is the most important reason why human beings need water?",
  ["It makes food taste sweet.",
   "It is used only for washing clothes.",
   "It gives the body energy just as food does.",
   "It is needed for digestion, for carrying substances in the body and for cooling the body."],
  "D", "1.3", "Understand", "Moderate"),

 ("Blood is an important liquid in the human body because it",
  ["gives the body its shape",
   "carries oxygen and digested food to all parts of the body",
   "protects the body from the sun only",
   "is produced by the bones"], "B", "1.3", "Understand", "Moderate"),

 ("A farmer in Wenchi wants his maize plants to grow well during the dry season. The best liquid to apply "
  "in the right quantity is",
  ["kerosene", "methylated spirit", "water", "petrol"], "C", "1.3", "Apply", "Moderate"),

 ("Which of the following liquids is used as a fuel for a lamp in many Ghanaian homes?",
  ["Kerosene", "Water", "Cooking oil", "Methylated spirit"], "A", "1.3", "Remember", "Easy"),

 ("A pupil does not drink enough water on a hot day. Which of the following is most likely to happen?",
  ["The pupil will grow taller.",
   "The pupil's blood will stop carrying oxygen.",
   "The pupil will never need to urinate again.",
   "The pupil may become dehydrated because the body loses water through sweat."],
  "D", "1.3", "Apply", "Moderate"),

 ("Which of the following solid materials is commonly used for building houses in Ghana?",
  ["Cement blocks", "Cooking oil", "Kerosene", "Oxygen"], "A", "1.4", "Remember", "Easy"),

 ("Solid foods such as yam, rice and maize are important to the human body because they",
  ["cool the body during the harmattan",
   "carry oxygen in the blood",
   "provide energy and materials for growth and repair",
   "clean wounds in hospitals"], "C", "1.4", "Understand", "Moderate"),

 ("A carpenter at Suame Magazine needs a suitable material for making the handle of a hoe. The best choice is",
  ["glass", "wood", "a plastic sheet", "chalk"], "B", "1.4", "Evaluate", "Moderate"),

 ("Aluminium is suitable for making cooking pots mainly because it",
  ["is a non-metal that is cheap",
   "does not allow heat to pass through it",
   "breaks easily when it is heated",
   "allows heat to pass through it easily"], "D", "1.4", "Understand", "Moderate"),

 ("Which of the following solids is used to make cutlasses and hoes because it is strong?",
  ["Chalk", "Wood", "Iron", "Glass"], "C", "1.4", "Remember", "Moderate"),

 ("Why are school desks and chairs usually made from wood or metal rather than from glass?",
  ["Wood and metal are strong and do not break easily, while glass breaks easily.",
   "Glass is heavier than wood and metal.",
   "Glass cannot be found in Ghana.",
   "Wood and metal are liquids."], "A", "1.4", "Understand", "Moderate"),

 ("Which of the following is a metal?",
  ["Sulphur", "Iron", "Oxygen", "Carbon"], "B", "1.5", "Remember", "Easy"),

 ("Which of the following properties best shows that a substance is a metal?",
  ["It is dull and breaks easily.",
   "It is a gas at room temperature.",
   "It does not allow electricity to pass through it.",
   "It is shiny and allows heat and electricity to pass through it."], "D", "1.5", "Understand", "Moderate"),

 ("Which non-metal is needed by human beings for breathing?",
  ["Nitrogen", "Helium", "Oxygen", "Argon"], "C", "1.5", "Understand", "Easy"),

 ("The noble gases are found in",
  ["Group 8 (also called Group 0) of the periodic table.",
   "Group 1 of the periodic table.",
   "Group 2 of the periodic table.",
   "Group 7 of the periodic table."], "A", "1.5", "Remember", "Moderate"),

 ("Which of the following statements about the noble gases is correct?",
  ["They are very reactive and catch fire easily.",
   "They do not react easily and are used in balloons and in fluorescent lamps.",
   "They are all metals used for building.",
   "They are liquids at room temperature."], "B", "1.5", "Understand", "Challenging"),

 ("An electrician in Accra needs a material for making electric cables. The best choice is",
  ["sulphur", "wood", "chlorine", "copper"], "D", "1.5", "Apply", "Moderate"),

 ("Which of the following is a non-metal?",
  ["Iron", "Copper", "Sulphur", "Aluminium"], "C", "1.5", "Remember", "Easy"),

 ("Metals are used for making electric cables and cooking utensils because they",
  ["allow heat and electricity to pass through them easily",
   "are dull and break easily",
   "are gases at room temperature",
   "cannot be hammered into shape"], "A", "1.5", "Understand", "Moderate"),

 ("In the modern periodic table, the elements are arranged in order of increasing",
  ["mass number", "atomic number", "number of neutrons", "number of shells"],
  "B", "1.6", "Remember", "Challenging"),

 ("The horizontal rows in the periodic table are called",
  ["groups", "families", "series", "periods"], "D", "1.6", "Remember", "Easy"),

 ("The vertical columns in the periodic table are called",
  ["periods", "rows", "groups", "blocks"], "C", "1.6", "Remember", "Easy"),

 ("Element X is in Group 1 and Period 3 of the periodic table. Element X is most likely to be",
  ["a metal that reacts strongly with water",
   "a noble gas",
   "a non-metal used for breathing",
   "a gas used to fill balloons"], "A", "1.6", "Analyse", "Challenging"),

 ("Elements that are placed in the same group of the periodic table",
  ["have the same atomic mass",
   "have common (similar) properties",
   "are all metals",
   "are all gases"], "B", "1.6", "Understand", "Moderate"),
]

# --------------------------------------------------------- SECTION B DIAGRAMS
PARTICLES = [
    "          P                            Q                            R",
    "+-------------------+        +-------------------+        +-------------------+",
    "|   •  •  •  •  •   |        |                   |        |      •            |",
    "|                   |        |                   |        |                   |",
    "|   •  •  •  •  •   |        |   •  •     •  •   |        |             •     |",
    "|                   |        |     •  •  •   •   |        |    •              |",
    "|   •  •  •  •  •   |        |   •    •  •  •    |        |                   |",
    "|                   |        |     •   •  •  •   |        |          •    •   |",
    "|   •  •  •  •  •   |        |   •  •   •    •   |        |       •       •   |",
    "+-------------------+        +-------------------+        +-------------------+"
]
Q2_TABLE_HEAD = ["Property", "Solid", "Liquid", "Gas"]
Q2_TABLE_ROWS = [
    ["Has a definite shape", "Yes", "(i)", "(ii)"],
    ["Has a definite volume", "Yes", "Yes", "(iii)"],
    ["Can be compressed easily", "No", "No", "(iv)"],
    ["Can flow", "(v)", "Yes", "Yes"],
]
Q2_ANS = {"(i)": "No", "(ii)": "No", "(iii)": "No", "(iv)": "Yes", "(v)": "No"}

SECTION_B = [
 dict(
   num=1, total=8, topic="1.1, 1.2",
   stem="The figure below shows how the particles are arranged in three different states of "
        "matter. Study it carefully and answer the questions that follow.",
   diagram=True,
   parts=[
     ("(a)", "Name the state of matter shown in each of the boxes labelled P, Q and R.",
      3, "Understand", "1.1", "Moderate"),
     ("(b)", "In which of P, Q and R are the particles closely packed and only vibrating in fixed positions?",
      1, "Remember", "1.2", "Moderate"),
     ("(c)", "Which of P, Q and R can be compressed easily? Give one reason for your answer.",
      2, "Analyse", "1.2", "Challenging"),
     ("(d)", "Name the process by which a liquid changes into a gas, and give one everyday example of it.",
      2, "Understand", "1.1", "Easy"),
   ]),
 dict(
   num=2, total=7, topic="1.2",
   stem="Copy and complete the table below by writing YES or NO in the spaces numbered (i) to (v).",
   table=True,
   parts=[
     ("(a)", "Complete the table.", 5, "Understand", "1.2", "Moderate"),
     ("(b)", "State two properties that liquids and gases have in common.", 2, "Understand", "1.2", "Moderate"),
   ]),
 dict(
   num=3, total=7, topic="1.2",
   stem="Kofi wants to prove to his class that air has mass.",
   parts=[
     ("(a)", "Name two apparatus Kofi will need.", 1, "Remember", "1.2", "Easy"),
     ("(b)", "Describe briefly what Kofi should do.", 2, "Create", "1.2", "Moderate"),
     ("(c)", "State what Kofi would observe and the conclusion he would draw.", 2, "Analyse", "1.2", "Moderate"),
     ("(d)", "Explain why the smell of fried plantain spreads across the whole compound.",
      2, "Apply", "1.2", "Challenging"),
   ]),
 dict(
   num=4, total=8, topic="1.3",
   stem="Liquids are very important to human life.",
   parts=[
     ("(a)", "State three ways in which water is important to the human body.",
      3, "Understand", "1.3", "Easy"),
     ("(b)", "Name two liquids, other than water, that are useful at home and give one use of each.",
      2, "Apply", "1.3", "Moderate"),
     ("(c)", "Explain what may happen to a person who does not drink enough water for several days.",
      3, "Apply", "1.3", "Challenging"),
   ]),
 dict(
   num=5, total=8, topic="1.4",
   stem="Solids are also important to human life.",
   parts=[
     ("(a)", "State three reasons why solid materials are important in everyday life.",
      3, "Understand", "1.4", "Easy"),
     ("(b)", "Give two examples of solid materials and one use of each.", 2, "Apply", "1.4", "Moderate"),
     ("(c)", "Explain why cooking pots are made from metals such as aluminium rather than from wood or plastic.",
      3, "Evaluate", "1.4", "Challenging"),
   ]),
 dict(
   num=6, total=12, topic="1.5",
   stem="The periodic table contains metals, non-metals and noble gases.",
   parts=[
     ("(a)", "State three properties of metals.", 3, "Understand", "1.5", "Easy"),
     ("(b)", "State two properties of non-metals.", 2, "Understand", "1.5", "Easy"),
     ("(c)", "Give one example each of a metal, a non-metal and a noble gas.",
      3, "Remember", "1.5", "Moderate"),
     ("(d)", "Explain why noble gases are used to fill balloons and fluorescent lamps.",
      2, "Understand", "1.5", "Moderate"),
     ("(e)", "Explain why copper is used for making electric cables but sulphur is not.",
      2, "Evaluate", "1.5", "Challenging"),
   ]),
 dict(
   num=7, total=10, topic="1.6, 1.5",
   stem="The elements in the periodic table are arranged in a particular order.",
   parts=[
     ("(a)", "What name is given to the vertical columns in the periodic table?",
      1, "Remember", "1.6", "Easy"),
     ("(b)", "What name is given to the horizontal rows in the periodic table?",
      1, "Remember", "1.6", "Easy"),
     ("(c)", "State the order in which the elements are arranged in the modern periodic table.",
      1, "Remember", "1.6", "Easy"),
     ("(d)", "In which group of the periodic table are the noble gases found?",
      1, "Remember", "1.5", "Moderate"),
     ("(e)", "Explain why scientists arrange the elements in a periodic table.",
      3, "Understand", "1.6", "Moderate"),
     ("(f)", "A classmate says that all the elements in the periodic table are metals. Do you agree? "
             "Give one reason for your answer.", 3, "Evaluate", "1.6", "Challenging"),
   ]),
]

# ------------------------------------------------------- MARKING SCHEME
MARKING = {
 1: [
   ("(a)", ["P = solid", "Q = liquid", "R = gas"],
    "1 mark each. Accept 'P is a solid / Q is a liquid / R is a gas'. No mark if the label is not matched "
    "to a state."),
   ("(b)", ["P"],
    "1 mark. Accept 'P (the solid)'. No half marks."),
   ("(c)", ["R (the gas) can be compressed easily.",
            "Reason: the particles in a gas are far apart, so there is a lot of empty space between them "
            "that can be pushed closer together."],
    "1 mark for naming R. 1 mark for a correct reason. Accept any reason that refers to the particles being "
    "far apart / much empty space. Do NOT award the reason mark for 'because it is light' or 'because it is "
    "a gas' on its own."),
   ("(d)", ["Evaporation.",
            "Everyday example: water drying from clothes on a line; water disappearing from a bowl left in "
            "the sun; sweat drying on the skin; water drying up from the floor after washing."],
    "1 mark for naming evaporation. 1 mark for a correct everyday example. Accept boiling as an answer only "
    "if the pupil makes clear that the liquid turns to a gas; the expected answer is evaporation."),
 ],
 2: [
   ("(a)", ["(i) No", "(ii) No", "(iii) No", "(iv) Yes", "(v) No"],
    "1 mark each. Accept 'NO'/'N' written clearly. No mark for a blank or for 'Yes/No'."),
   ("(b)", ["Both can flow (they are fluids).",
            "Neither has a definite shape - both take the shape of their container."],
    "1 mark each for any TWO correct properties (2 marks). Accept 'both take the shape of their container'. "
    "Do NOT accept 'both are colourless' or 'both have no mass'."),
 ],
 3: [
   ("(a)", ["A balance (or a lever balance / scale)", "A balloon",
            "A pump (or the mouth, to blow the balloon up)"],
    "1 mark for naming any TWO suitable apparatus. Accept a simple metre-rule balance, string and two "
    "balloons. No mark for naming only one apparatus."),
   ("(b)", ["Weigh (find the mass of) the deflated balloon on the balance and record the reading.",
            "Blow air into the balloon, weigh the inflated balloon again and compare the two readings."],
    "1 mark for weighing the deflated balloon and recording its mass. 1 mark for inflating it and weighing it "
    "again / comparing readings. Accept any safe, workable method. Award method marks even if the pupil's "
    "conclusion is wrong."),
   ("(c)", ["Observation: the inflated balloon has a greater mass (is heavier) than the deflated balloon.",
            "Conclusion: air has mass."],
    "1 mark for the correct observation. 1 mark for the conclusion that air has mass. If the pupil gives the "
    "conclusion only, award 1 mark."),
   ("(d)", ["The smell is carried by particles of a gas.",
            "The particles of the gas are far apart and move freely (they spread out / diffuse) in all "
            "directions until they reach every part of the compound."],
    "1 mark for stating that the smell is carried by gas particles. 1 mark for explaining that the particles "
    "move freely and spread out in all directions. Accept 'diffusion' with an explanation. Do NOT award a "
    "mark for 'because of the wind' alone."),
 ],
 4: [
   ("(a)", ["It is used for digestion / to break down food.",
            "It carries dissolved substances (e.g. digested food and waste) around the body.",
            "It cools the body (through sweat).",
            "It is the main part of blood, which carries oxygen.",
            "It keeps the body hydrated / prevents dehydration."],
    "1 mark each for any THREE correct points (3 marks). Give credit to body-related uses first."),
   ("(b)", ["Kerosene - for lighting a lamp / starting fire.",
            "Methylated spirit - for cleaning wounds / cleaning surfaces.",
            "Petrol - for running a vehicle or generator engine.",
            "Cooking oil - for frying food.",
            "Disinfectant - for cleaning the floor or toilet."],
    "1 mark for each correctly named liquid WITH its matching use (2 marks). The name and the use must go "
    "together. Accept any other correct household liquid."),
   ("(c)", ["The body loses water through sweat, urine and breathing and cannot replace it.",
            "The person becomes dehydrated (thirsty, dizzy, weak, with a dry mouth and little urine).",
            "If it continues, the body cannot carry substances around or cool itself properly, and the "
            "person may become very ill."],
    "1 mark each for any THREE correct points (3 marks). Award marks for the mechanism (water loss), the "
    "symptom (dehydration) and the consequence. Accept 'the person may die' as part of a developed answer, "
    "not on its own."),
 ],
 5: [
   ("(a)", ["They are used to build houses, schools and bridges (e.g. cement blocks, stone, wood, iron rods).",
            "They are used to make tools, furniture and farm implements (e.g. hoes, cutlasses, tables).",
            "Solid foods such as yam, rice and maize give the body energy and materials for growth and repair.",
            "They are used to make cooking utensils and containers (e.g. aluminium pots, clay pots).",
            "They are used to make clothing, books, medicine and other things we use daily."],
    "1 mark each for any THREE correct points (3 marks). Accept any reasonable, well-stated importance of a "
    "solid. Do NOT award a mark for merely naming a solid without saying what it is used for."),
   ("(b)", ["Cement blocks - for building houses.", "Wood - for making furniture and tool handles.",
            "Iron - for making cutlasses, hoes and roofing sheets.",
            "Aluminium - for making cooking pots.", "Clay - for making pots for storing water."],
    "1 mark for each correctly named solid WITH its matching use (2 marks). The name and the use must go "
    "together. Accept any other correct solid material."),
   ("(c)", ["Metals such as aluminium allow heat to pass through them easily, so food cooks quickly.",
            "Wood and plastic do not allow heat to pass through easily, so cooking would take a very long time.",
            "Wood would burn and plastic would melt on the fire."],
    "1 mark each for any THREE correct points (3 marks). As a minimum, award 1 mark for stating that metals "
    "conduct heat and 1 mark for stating that wood/plastic are poor conductors (or that wood burns / plastic "
    "melts). Award 1 mark for a partial but correct answer."),
 ],
 6: [
   ("(a)", ["They allow heat to pass through them easily (good conductors of heat).",
            "They allow electricity to pass through them (good conductors of electricity).",
            "They are shiny / can be polished.",
            "They are strong and can be hammered or bent into shape without breaking (malleable).",
            "They are mostly solids at room temperature."],
    "1 mark each for any THREE correct properties (3 marks). Accept clearly stated correct properties only."),
   ("(b)", ["They do not allow heat and electricity to pass through them easily (poor conductors).",
            "They are dull, not shiny.",
            "They break easily (they are brittle) and cannot be hammered into shape.",
            "Many of them are gases at room temperature."],
    "1 mark each for any TWO correct properties (2 marks). Accept 'they are not shiny' and 'they are poor "
    "conductors'. Do NOT accept 'they are liquids'."),
   ("(c)", ["Metal: iron / copper / aluminium / gold / silver / sodium.",
            "Non-metal: oxygen / sulphur / carbon / chlorine / nitrogen.",
            "Noble gas: helium / neon / argon / krypton / xenon."],
    "1 mark each (3 marks). Any correct example from each class is accepted. No mark for hydrogen as a noble "
    "gas or for a compound such as water or common salt."),
   ("(d)", ["Noble gases do not react easily (they are unreactive), so they do not catch fire or explode.",
            "Helium is very light, so it is used to fill balloons.",
            "Neon and argon glow when electricity passes through them, so they are used in fluorescent lamps "
            "and advertising signs."],
    "1 mark each for any TWO correct points (2 marks). As a minimum, award 1 mark for stating that they do "
    "not react easily and 1 mark for a correct use linked to that property."),
   ("(e)", ["Copper allows electricity to pass through it easily, so it is a good conductor.",
            "Sulphur does not allow electricity to pass through it, so it cannot be used for cables.",
            "Copper can also be drawn into thin wires without breaking."],
    "1 mark each for any TWO correct points (2 marks). Award 1 mark for stating that copper conducts "
    "electricity and 1 mark for stating that sulphur does not."),
 ],
 7: [
   ("(a)", ["Groups"], "1 mark. Accept 'a group' or 'groups'."),
   ("(b)", ["Periods"], "1 mark. Accept 'a period' or 'periods'."),
   ("(c)", ["In order of increasing atomic number."],
    "1 mark. Accept 'by their atomic number'. Do NOT accept 'by mass number' or 'alphabetically'."),
   ("(d)", ["Group 8 (also called Group 0)."], "1 mark. Accept 'Group 8' or 'Group 0'."),
   ("(e)", ["It puts elements with similar (common) properties together in the same group.",
            "It arranges the elements in an orderly way so they are easy to find and study.",
            "It allows scientists to predict the properties of an element from its position.",
            "It shows the relationship between the elements."],
    "1 mark each for any THREE correct points (3 marks). Accept any sensible reason. Do NOT award a mark for "
    "'so that it looks neat'."),
   ("(f)", ["Disagree. The periodic table also contains non-metals (e.g. oxygen, sulphur) and noble gases.",
            "Reason: elements are grouped by their properties, and not all of them have the properties of "
            "metals - many are gases and poor conductors of heat and electricity."],
    "3 marks. Award 1 mark for a clear position (disagree), 1 mark for naming another class of elements in "
    "the table, and 1 mark for a correct reason based on properties. A bare 'no' scores 0."),
 ],
}


# --------------------------------------------- derive summary statistics
def topic_totals():
    m = {k: 0 for k in TOPIC}
    it = {k: 0 for k in TOPIC}
    for q in MCQ:
        m[q[3]] += 1
        it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk
            it[key] += 1
    return m, it

def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}
    b = {k: 0 for k in order}
    for q in MCQ:
        a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            b[cog] += mk
    return order, a, b

def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ:
        d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            d[diff] += mk
    return d
