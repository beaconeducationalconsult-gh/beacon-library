# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "/home/user")
from build_machines import *

from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT

doc = Document()
sec = doc.sections[0]
sec.left_margin = Inches(0.7); sec.right_margin = Inches(0.7)
sec.top_margin = Inches(0.7); sec.bottom_margin = Inches(0.6)

st = doc.styles["Normal"]; st.font.name = "Calibri"; st.font.size = Pt(11)


def set_font(run, size=11, bold=False, italic=False, mono=False, color=None):
    run.font.size = Pt(size); run.bold = bold; run.italic = italic
    run.font.name = "Consolas" if mono else "Calibri"
    if color: run.font.color.rgb = color
    return run


def para(text="", size=11, bold=False, italic=False, align=None, mono=False,
         space_before=0, space_after=4, color=None):
    p = doc.add_paragraph()
    if align == "c": p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    elif align == "j": p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p.paragraph_format.space_before = Pt(space_before)
    p.paragraph_format.space_after = Pt(space_after)
    if text: set_font(p.add_run(text), size, bold, italic, mono, color)
    return p


def rule():
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(6); p.paragraph_format.space_before = Pt(2)
    set_font(p.add_run("_" * 78), 9, color=RGBColor(0x99, 0x99, 0x99))


def add_table(headers, rows, widths=None, size=9, head_size=9):
    t = doc.add_table(rows=1, cols=len(headers)); t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, h in enumerate(headers):
        c = t.rows[0].cells[i]; c.text = ""
        p = c.paragraphs[0]; p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_font(p.add_run(str(h)), head_size, bold=True)
    for row in rows:
        cells = t.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = ""
            p = cells[i].paragraphs[0]; p.paragraph_format.space_after = Pt(1)
            set_font(p.add_run(str(v)), size)
    if widths:
        for r_ in t.rows:
            for i, w in enumerate(widths): r_.cells[i].width = Inches(w)
    return t


def draw_diagram(lines, caption):
    t = doc.add_table(rows=2, cols=1); t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = t.rows[0].cells[0]
    for k, line in enumerate(lines):
        p = cell.paragraphs[0] if k == 0 else cell.add_paragraph()
        p.paragraph_format.space_after = Pt(0); p.paragraph_format.space_before = Pt(0)
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_font(p.add_run(line), 10, mono=True)
    c2 = t.rows[1].cells[0].paragraphs[0]
    c2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_font(c2.add_run(caption), 9, italic=True)
    t.rows[0].cells[0].width = Inches(6.6)
    t.rows[1].cells[0].width = Inches(6.6)


# ============================================================= TITLE BLOCK
para(SCHOOL, size=15, bold=True, align="c", space_after=2)
para(SUBJECT, size=13, bold=True, align="c", space_after=2)
para(EXAM, size=12, bold=True, align="c", space_after=2)
para(YEAR, size=10, italic=True, align="c", space_after=8)

info = doc.add_table(rows=1, cols=3); info.style = "Table Grid"
info.alignment = WD_TABLE_ALIGNMENT.CENTER
for i, v in enumerate([f"Class: {CLASS}", f"Time: {TIME}", f"Total Marks: {MARKS}"]):
    c = info.rows[0].cells[i]; c.text = ""
    set_font(c.paragraphs[0].add_run(v), 10, bold=True)
para("", space_after=6)

para("INSTRUCTIONS", size=11, bold=True, space_after=3)
for txt in [
    "1. Write your name and class clearly in the spaces provided on your answer sheet.",
    "2. This paper has TWO sections: Section A and Section B.",
    "3. Answer ALL the questions in both sections.",
    "4. Section A has 40 multiple-choice questions. Each question carries 1 mark. Choose the best answer "
    "(A, B, C or D) and record it on the answer sheet provided.",
    "5. Section B has 7 theory questions totalling 60 marks. Write your answers clearly and neatly in your "
    "answer booklet. Draw and label diagrams or tables where you are asked to.",
    "6. Read every question carefully before you answer it.",
    "7. Do not use correction fluid. Cancel any mistake neatly with a single line.",
    "8. Hand in your answer sheet and your answer booklet at the end of the examination.",
]:
    para(txt, size=10.5, space_after=2)
rule()

# =============================================================== SECTION A
para("SECTION A - OBJECTIVE TEST (40 marks)", size=12, bold=True, align="c", space_after=2)
para("Answer ALL questions. Each question carries 1 mark. Choose the BEST answer and write its letter "
     "(A, B, C or D) against the question number on your answer sheet.",
     size=10, italic=True, align="c", space_after=8)

for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(1); p.paragraph_format.space_before = Pt(4)
    set_font(p.add_run(f"{i}. {q}"), 10.5)
    for j, o in enumerate(opts):
        p2 = doc.add_paragraph()
        p2.paragraph_format.left_indent = Inches(0.28)
        p2.paragraph_format.space_after = Pt(0); p2.paragraph_format.space_before = Pt(0)
        set_font(p2.add_run(f"{'ABCD'[j]}. {o}"), 10.5)

doc.add_page_break()

# =============================================================== SECTION B
para("SECTION B - THEORY (60 marks)", size=12, bold=True, align="c", space_after=2)
para("Answer ALL questions. Write your answers in your answer booklet. The marks for each question are "
     "shown in brackets.", size=10, italic=True, align="c", space_after=8)

for qb in SECTION_B:
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(8); p.paragraph_format.space_after = Pt(2)
    set_font(p.add_run(f"Question {qb['num']}"), 11, bold=True)
    set_font(p.add_run(f"  [{qb['total']} marks]"), 10, bold=True, italic=True)
    para(qb["stem"], size=10.5, space_after=4)
    if qb.get("diagram"):
        draw_diagram(LEVER, "Fig. 1: A lever")
        para("", space_after=2)
    if qb.get("table") == "machines":
        add_table(SM_HEADERS, SM_ROWS, widths=[1.5, 2.3, 2.2], size=8.5, head_size=8.5)
        para("Table 1: Common simple machines", size=9, italic=True, align="c",
             space_after=6)
        para("", space_after=2)
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Inches(0.25)
        p.paragraph_format.space_after = Pt(3); p.paragraph_format.space_before = Pt(2)
        set_font(p.add_run(f"{lab} {text}  "), 10.5)
        set_font(p.add_run(f"[{mk} mark{'s' if mk > 1 else ''}]"), 10, bold=True)

doc.add_page_break()

# ============================================================== ANSWER KEY
para("ANSWER KEY", size=13, bold=True, align="c", space_after=6)
para("SECTION A - OBJECTIVE TEST", size=11, bold=True, space_after=4)
rows = [[i, ans, TOPIC[tp], cog] for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1)]
add_table(["Question", "Answer", "Curriculum Area (Topic)", "Cognitive Level"],
          rows, widths=[0.8, 0.7, 3.6, 1.5], size=9)
counts = {L: sum(1 for q in MCQ if q[2] == L) for L in "ABCD"}
para("", space_after=4)
para("Correct-answer distribution: " + ", ".join(f"{L} = {counts[L]}" for L in "ABCD") + " (30 items).",
     size=9, italic=True)

para("", space_after=8)
para("SECTION B - THEORY (summary answers; see the Marking Scheme for full detail)",
     size=11, bold=True, space_after=4)
sba = [
 ("1 (a)", "A simple machine is a device that makes work easier. It lets a small effort move a large load, or it changes the size or the direction of the force applied. It has few or no moving parts.", "14.9", "Understand"),
 ("1 (b)", "Any four of: a lever; a pulley; an inclined plane; a wheel and axle; a screw; a wedge.", "14.9", "Remember"),
 ("1 (c)", "Simple machines make work easier, so a smaller effort can move a bigger load. They let a force be applied in a more convenient direction, and they save time and energy.", "14.9", "Understand"),
 ("2 (a)", "(i) a crowbar lifting a stone, a see-saw, the handle of a hand pump, a bottle opener. (ii) a sloping surface or slope used to raise a load. (iii) raising a bucket from a well, raising a flag up a pole, lifting a load on a building site. (iv) a large wheel joined to a smaller rod (the axle) so that the two turn together. (v) holding two pieces of wood together, a corkscrew, a car jack. (vi) a piece of metal or wood that is thick at one end and thin at the other.", "14.9", "Understand"),
 ("2 (b)", "Any one machine from the table with a correct job - e.g. a lever: a crowbar is used to lift a heavy stone or to pull out a nail.", "14.9", "Apply"),
 ("3 (a)", "(i) effort, (ii) fulcrum, (iii) load.", "14.10", "Understand"),
 ("3 (b)", "A lever is a bar or a rigid rod that turns about a fixed point. The fixed point is called the fulcrum, and an effort applied at one point moves a load at another.", "14.10", "Understand"),
 ("3 (c)", "In a first-class lever the fulcrum is BETWEEN the effort and the load. One end is pushed down as the effort while the other end goes up and lifts the load. Example: a see-saw, a pair of scissors, a claw hammer pulling out a nail, the handle of a hand pump.", "14.10", "Understand"),
 ("4 (a)", "A second-class lever is one in which the LOAD lies between the fulcrum and the effort, so that the effort and the load are on the same side of the fulcrum. Example: a wheelbarrow, a nutcracker, a bottle opener.", "14.10", "Understand"),
 ("4 (b)", "A third-class lever is one in which the EFFORT lies between the fulcrum and the load, so that the effort is the nearer of the two to the fulcrum. Example: a pair of sugar tongs, a broom being used to sweep, a fishing rod, the human forearm.", "14.10", "Understand"),
 ("4 (c)", "Find the fulcrum first, then see which of the other two lies in the middle. Fulcrum in the middle means first class, e.g. a see-saw. Load in the middle means second class, e.g. a wheelbarrow. Effort in the middle means third class, e.g. a pair of sugar tongs.", "14.10", "Analyse"),
 ("5 (a)", "A claw hammer pulling a nail out of wood - FIRST class. A wheelbarrow - SECOND class. A broom being used to sweep - THIRD class. A nutcracker - SECOND class.", "14.10", "Apply"),
 ("5 (b)", "Any two: a claw hammer - the long handle means a small effort gives a large pulling force on the nail; a wheelbarrow - the load sits between the wheel and the handles, so a small lift moves a heavy load; a broom - a small movement of the upper hand sweeps a large area; a nutcracker - the effort is further from the hinge than the nut, so a small squeeze gives a large crushing force.", "14.10", "Understand"),
 ("5 (c)", "Use a lever such as a crowbar or a spanner on a bolt. Try it first with a short handle and then with a long one, pushing at the very end each time and comparing the effort needed. Keep the load and the position of the fulcrum the same, so that only the length of the handle changes. The class would find that the longer handle needs a much smaller effort.", "14.10", "Create"),
 ("6 (a)", "Work input is the work done ON a machine, that is, the work put into it. Work output is the useful work done BY the machine, that is, the work that comes out of it. Both are measured in joules (J).", "14.11", "Understand"),
 ("6 (b)", "50 J did not come out as useful work (200 J in minus 150 J out). It was used to overcome friction in the moving parts and was changed into heat, and some into sound, which spread out into the surroundings. The energy was not destroyed, only changed into forms that are not useful.", "14.11", "Apply"),
 ("6 (c)", "Some of the work put in is always used to overcome friction in the moving parts, and some is used to lift the moving parts of the machine itself. That energy is changed into heat and sound, which are not useful, so the useful work out is always less than the work put in.", "14.11", "Understand"),
 ("7 (a)", "Efficiency is the ratio of work output to work input, given as a percentage. Efficiency = (work output / work input) x 100%. It measures how much of the work put into a machine comes out as useful work.", "14.11", "Understand"),
 ("7 (b)", "Efficiency = (work output / work input) x 100% = (300 / 400) x 100% = 0.75 x 100% = 75%.", "14.11", "Apply"),
 ("7 (c)", "The 75 per cent machine, because it turns more of the work put into it into useful work and wastes less energy as heat and sound, so it will cost less to run. Accept the 40 per cent machine only if the pupil gives a good reason, such as that it is the only one the school can afford or repair.", "14.11", "Evaluate"),
]
add_table(["Question", "Expected Answer", "Curriculum Area", "Cognitive Level"],
          [list(r) for r in sba], widths=[0.8, 4.2, 1.2, 1.2], size=9)

doc.add_page_break()

# =========================================================== MARKING SCHEME
para("MARKING SCHEME - SECTION B (60 marks)", size=13, bold=True, align="c", space_after=4)
para("General rules: (1) Accept any other correct and relevant answer. (2) Award marks for correct points, "
     "not for repeating the question. (3) For procedures, award method marks. (4) Do not deduct marks for "
     "spelling unless the meaning is changed. (5) Where a candidate gives more answers than are asked for, "
     "mark only the first ones up to the number required.",
     size=9.5, italic=True, space_after=8)

for qb in SECTION_B:
    n = qb["num"]
    para(f"Question {n}  ({qb['total']} marks)", size=11, bold=True, space_before=8, space_after=3)
    for (lab, points, note) in MARKING[n]:
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(2)
        set_font(p.add_run(f"{lab} "), 10.5, bold=True)
        mkv = [p_[2] for p_ in qb["parts"] if p_[0] == lab]
        if mkv: set_font(p.add_run(f"[{mkv[0]} mark{'s' if mkv[0] > 1 else ''}]"), 10, bold=True)
        for pt in points:
            pp = doc.add_paragraph()
            pp.paragraph_format.left_indent = Inches(0.35); pp.paragraph_format.space_after = Pt(1)
            set_font(pp.add_run("- " + pt), 10.5)
        pp = doc.add_paragraph()
        pp.paragraph_format.left_indent = Inches(0.35); pp.paragraph_format.space_after = Pt(6)
        set_font(pp.add_run("Marking note: " + note), 9.5, italic=True)

doc.add_page_break()

# ================================================================ BLUEPRINT
para("CURRICULUM ASSESSMENT BLUEPRINT", size=13, bold=True, align="c", space_after=3)
para(f"Strand: {STRAND}   |   Sub-strand: {SUBSTRAND}   |   Class: {CLASS}",
     size=10, italic=True, align="c", space_after=3)
para(f"Content Standard: {CS} - {CS_TEXT}", size=9, italic=True, align="c", space_after=3)
para("Source: NaCCA Science Common Core Programme Curriculum (B7/JHS1-B9/JHS3), September 2020, "
     "Strand 4: Forces and Energy, Sub-strand 4: Force and Motion (topics 14.9-14.11), "
     "pp. 38-40. Indicators are quoted, not invented.",
     size=9, italic=True, space_after=8)

hdr = ["Qn", "Sub-strand", "Content Standard", "Indicator (NaCCA) - Indicator Text", "Topic / Content",
       "Cognitive Level", "Marks"]

rows = [[f"A{i}", SUBSTRAND, CS_BY_TOPIC[tp], f"{IND[tp]} - {IND_TEXT[tp]}", TOPIC[tp], cog, 1]
        for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1)]
add_table(hdr, rows, widths=[0.35, 0.75, 0.75, 1.75, 1.4, 0.8, 0.35], size=7, head_size=7.5)

para("", space_after=8)
rows = []
for qb in SECTION_B:
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        key = tp if tp in TOPIC else tp.split(",")[0].strip()
        rows.append([f"B{qb['num']}{lab.strip('()')}", SUBSTRAND, CS_BY_TOPIC[key],
                     f"{IND[key]} - {IND_TEXT[key]}", TOPIC[key], cog, mk])
add_table(hdr, rows, widths=[0.35, 0.75, 0.75, 1.75, 1.4, 0.8, 0.35], size=7, head_size=7.5)

doc.add_page_break()

# ----------------------------------------------------------------- helpers
def topic_totals():
    m = {k: 0 for k in TOPIC}; it = {k: 0 for k in TOPIC}
    for q in MCQ:
        m[q[3]] += 1; it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk; it[key] += 1
    return m, it

def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}; b = {k: 0 for k in order}
    for q in MCQ: a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: b[cog] += mk
    return order, a, b

def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ: d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: d[diff] += mk
    return d

m, it = topic_totals(); diff = difficulty_totals(); order, ca, cb = cognitive_by_section()

para("SUMMARY 1 - COVERAGE BY CURRICULUM AREA (TOPIC)", size=12, bold=True, space_after=4)
rows = [[TOPIC[k], it[k], m[k], f"{(m[k]/100)*100:.1f}%", CC[k]] for k in TOPIC]
rows.append(["TOTAL", sum(it.values()), sum(m.values()), "100%", "-"])
add_table(["Topic / Content Area", "No. of Items", "Marks", "% of Total Marks", "Core Competencies"],
          rows, widths=[2.7, 0.8, 0.6, 1.0, 1.1], size=8.5)
para("CC = Communication and Collaboration; CP = Critical Thinking and Problem Solving; "
     "DL = Digital Literacy; CI = Creativity and Innovation.", size=8.5, italic=True, space_after=2)

para("", space_after=8)
para("SUMMARY 2 - COGNITIVE-LEVEL DISTRIBUTION (Bloom's Taxonomy)", size=12, bold=True, space_after=4)
rows = []
for lv in order:
    tot = ca[lv] + cb[lv]
    rows.append([lv, ca[lv], cb[lv], tot, f"{(tot/100)*100:.1f}%"])
rows.append(["TOTAL", sum(ca.values()), sum(cb.values()), sum(ca.values()) + sum(cb.values()), "100%"])
add_table(["Cognitive Level", "Section A Marks", "Section B Marks", "Total Marks", "% of Total"],
          rows, widths=[1.6, 1.3, 1.3, 1.1, 1.1], size=9.5)

para("", space_after=8)
para("SUMMARY 3 - DIFFICULTY DISTRIBUTION", size=12, bold=True, space_after=4)
rows = [[k, v, f"{(v/100)*100:.1f}%"] for k, v in diff.items()]
rows.append(["TOTAL", sum(diff.values()), "100%"])
add_table(["Difficulty", "Marks", "% of Total Marks"], rows, widths=[2.0, 1.2, 1.5], size=9.5)
para("Target in the master prompt: approximately 30% easy / 50% moderate / 20% challenging.",
     size=9, italic=True, space_after=2)

para("", space_after=8)
para("SUMMARY 4 - SECTION WEIGHTING", size=12, bold=True, space_after=4)
add_table(["Section", "Question Type", "Items", "Marks", "% of Total"],
          [["A", "Objective (multiple choice)", 40, 40, "40%"],
           ["B", "Theory / constructed response", 20, 60, "60%"],
           ["TOTAL", "-", 60, 100, "100%"]],
          widths=[0.9, 2.4, 0.8, 0.8, 1.0], size=9.5)

doc.add_page_break()

# ===================================================== QUALITY-CONTROL
para("QUALITY-CONTROL SUMMARY", size=13, bold=True, align="c", space_after=4)
para("Carried out against the 14-point validation list in the master prompt before the examination was "
     "finalised.", size=9.5, italic=True, space_after=8)

qc = [
 ("Does every question belong to the supplied curriculum scope?",
  "Yes. All 60 items - 40 objectives and 20 theory sub-questions - trace to Strand 4 (Forces and "
  "Energy), Sub-Strand 4 (Force and Motion), topics 14.9-14.11, and to the three official B7 "
  "indicators under content standard B7/JHS1.4.4.2 (B7/JHS1.4.4.2.1 to B7/JHS1.4.4.2.3). Force, "
  "motion, inertia, Newton's First Law and the behaviour of magnets are deliberately excluded - "
  "they form the companion paper on B7/JHS1.4.4.1. Only six simple machines are named, which is "
  "the list the curriculum asks for."),
 ("Is the examination appropriate for the stated class?",
  "Yes. The B7 curriculum requires learners to identify simple machines and list examples, to "
  "name the types of levers and explain their functions, to classify levers into first, second "
  "and third classes and show how each class makes work easier in everyday life, and to explain "
  "work input, work output and efficiency, including efficiency as the ratio of work output to "
  "work input expressed as a percentage, and how efficiency can be improved. Mechanical "
  "advantage, velocity ratio and pulley-system force calculations are nowhere tested."),
 ("Are the questions genuinely BECE-style?",
  "Yes: Section A is 40 four-option objectives worth 1 mark each, and Section B is structured "
  "theory with sub-questions carrying printed mark allocations. The only arithmetic is the "
  "efficiency percentage in Question 7(b) and the subtraction in Question 6(b), both of which "
  "the curriculum explicitly requires."),
 ("Are there enough application and reasoning questions?",
  "Yes. 33 of 100 marks (33%) are at Apply level or above (Apply 25, Analyse 4, Evaluate 2, "
  "Create 2). Create appears in Question 5(c), where pupils must plan a fair demonstration, and "
  "Evaluate in Question 7(c), where they must choose between two machines and justify the "
  "choice."),
 ("Are the MCQ distractors plausible?",
  "Yes. Distractors are drawn from the same content family as the key: another simple machine "
  "(A9, A10, A11, A12, A13, A14), another part of a lever (A17, A18, A19), the wrong class of "
  "lever (A21, A22, A23, A24, A25), the inverted efficiency formula (A30), and a genuine way of "
  "caring for a machine that does not improve its efficiency (A39)."),
 ("Is there only one best answer for each MCQ?",
  "Yes. Every item was reviewed for a single defensible key, and the option order was rebuilt so "
  "that each declared key sits on the correct answer. Special care was taken with A17, where "
  "'pivot pin' was replaced by 'the bar' because a pivot is another name for a fulcrum, with "
  "A12, where the stem says 'winding handle' so that the wheel-and-axle answer is the only one, "
  "and with A40, where 100 J is the energy wasted and 400 J is the useful work."),
 ("Are the marks internally consistent?",
  "Yes. Section A = 40 items x 1 mark = 40. Section B = 9 + 8 + 9 + 9 + 8 + 9 + 8 = 60. "
  "Each Section B sub-question's printed marks match its marking-scheme allocation, and every "
  "N-mark sub-question asks for N things."),
 ("Does the total add up correctly?",
  "Yes: 40 + 60 = 100 marks, matching the stated total on the front page."),
 ("Are the answers in the answer key correct?",
  "Yes. All 40 objective keys and all 20 Section B answers were verified against the marking "
  "scheme. Question 7(b) was checked: 300 / 400 = 0.75, so the efficiency is 75 per cent. "
  "Question 6(b) was checked: 200 J in minus 150 J out leaves 50 J wasted."),
 ("Does the marking scheme match the questions?",
  "Yes. Every Section B sub-question has an expected-answer list and a marking note covering "
  "partial credit, acceptable alternatives, common wrong answers and method marks. The "
  "efficiency calculation in Question 7(b) is marked on three separate points - formula, "
  "substitution and answer - and the note allows the substitution and answer marks even when "
  "the formula is not written."),
 ("Are the questions free from unnecessary ambiguity?",
  "Yes. Open items are anchored with 'name four', 'state two' and the mark allocation. "
  "Question 6(a) requires BOTH work input and work output to be explained and the unit to be "
  "given; Question 4(a) and 4(b) each require a definition AND an example; Question 5(a) requires "
  "the class and the tool to be matched; and Question 5(c) says 'your class could carry out', so "
  "pupils know a fair test is expected, not just an opinion."),
 ("Are Ghanaian contexts used naturally and accurately?",
  "Yes: a drum of palm oil rolled up a ramp into a lorry, a cutlass splitting a coconut, the "
  "winding handle of a well, a see-saw in a playground, a flag raised at school, a building site "
  "in town, a bicycle chain, and a school choosing between two machines."),
 ("Has any content outside the supplied curriculum been introduced?",
  "No. Every item sits inside topics 14.9-14.11. Force, motion, inertia, Newton's First Law and "
  "magnets belong to the companion paper on B7/JHS1.4.4.1 and are excluded here. Mechanical "
  "advantage, velocity ratio, effort-load calculations for pulley systems and the joule as a "
  "derived unit are not required anywhere in the paper."),
 ("Are the questions sufficiently varied?",
  "Yes. Item types include defining a simple machine, listing examples, completing a six-row "
  "table of machines, describing a job for one machine, naming labelled parts on a lever "
  "diagram, defining a lever, placing the fulcrum in a first-class lever, defining and exemplifying "
  "the second and third classes, explaining how to classify a lever, giving the class of four "
  "everyday tools, explaining how two levers make work easier, planning a fair demonstration, "
  "defining work input and output with the unit, accounting for missing energy, explaining why "
  "output is always less than input, defining efficiency, calculating efficiency, and choosing "
  "between two machines."),
]
for i, (q, a) in enumerate(qc, start=1):
    p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(2)
    set_font(p.add_run(f"{i}. {q}"), 10.5, bold=True)
    p2 = doc.add_paragraph()
    p2.paragraph_format.left_indent = Inches(0.3); p2.paragraph_format.space_after = Pt(6)
    set_font(p2.add_run(a), 10)

para("", space_after=8)
para("EXAMINER NOTES (for the teacher, not for candidates)", size=11, bold=True, space_after=4)
for n in [
 "Question 5(a) is the discriminator. Nearly every pupil gets the claw hammer and the "
 "wheelbarrow right; the broom and the nutcracker sort the top from the rest. A broom is third "
 "class because the lower hand is the effort, the upper hand is the fulcrum and the load is at "
 "the far end - so the effort sits between the other two. Teach that one twice.",
 "Question 5(c) is the design task and it is marked on a fair test, not on a brilliant idea. The "
 "note awards 1 mark for the set-up and 1 mark for what the class would find, and it explicitly "
 "looks for the idea that only the length of the handle changes. Do not insist on the crowbar - a "
 "spanner on a bolt, or a door pushed near the hinge and then at the handle, works just as well.",
 "Question 7(b) is the only real calculation, and the note splits it three ways: formula, "
 "substitution and answer. Give the method marks generously. A pupil who writes 300 / 400 and "
 "then mis-handles the percentage has understood the idea and should not lose everything.",
 "Question 4(c) is the hardest item on the paper. The reliable route is to find the fulcrum "
 "first, then ask which of the other two lies in the middle. Pupils who try to memorise three "
 "separate definitions without that rule usually mix up the second and third classes.",
 "Topic weighting is 32 marks for 14.9, 36 for 14.10 and 32 for 14.11. Levers carry the most "
 "because the curriculum asks for naming, classifying AND demonstrating all three classes. If you "
 "spent longer on machines than on efficiency, move marks towards Questions 1 and 2.",
 "Two cheap practicals that raise marks sharply: (1) push a door open first near the hinge and "
 "then at the handle, and (2) lift a stone with a short crowbar and then with a long one. The "
 "first teaches Questions 3 to 5, the second teaches Question 5(c).",
 "The companion paper covers topics 14.1 to 14.8 - force, balanced and unbalanced forces, "
 "inertia, Newton's First Law and its applications, and the types, behaviour and uses of magnets "
 "- under content standard B7/JHS1.4.4.1. Use the two papers together for a full end-of-term "
 "examination on this sub-strand, or separately as two class tests.",
 "Edit the school name, academic year and examination title on page 1 before printing.",
 "This is an original, teacher-made mock. It is not a reproduction of any WAEC or NaCCA examination "
 "paper.",
]:
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Inches(0.3); p.paragraph_format.space_after = Pt(3)
    set_font(p.add_run("- " + n), 10)

doc.save("/home/user/Basic7_Integrated_Science_Mock_Strand4_ForceAndMotion2.docx")
print("docx written")

print("Section A:", len(MCQ), "items")
print("Section B total:", sum(q["total"] for q in SECTION_B))
print("Topic marks:", m, "sum", sum(m.values()))
print("Difficulty:", diff, "sum", sum(diff.values()))
print("Cognitive A:", ca)
print("Cognitive B:", cb)
print("Answer counts:", counts)
print("Totals:", sum(m.values()), sum(diff.values()),
      sum(ca.values()) + sum(cb.values()))
