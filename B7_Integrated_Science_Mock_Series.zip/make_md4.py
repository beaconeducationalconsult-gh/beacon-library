# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "/home/user")
from build_fly import *

L = []
def w(s=""): L.append(s)

w(f"# {SCHOOL}"); w()
w(f"## {SUBJECT}"); w()
w(f"### {EXAM}"); w()
w(f"**Class:** {CLASS}  ")
w(f"**Time:** {TIME}  ")
w(f"**Total Marks:** {MARKS}  ")
w(f"**Academic Year:** {YEAR}"); w()
w("---"); w()
w("### INSTRUCTIONS"); w()
for i, t in enumerate([
    "Write your name and class clearly in the spaces provided on your answer sheet.",
    "This paper has TWO sections: Section A and Section B.",
    "Answer ALL the questions in both sections.",
    "Section A has 40 multiple-choice questions. Each question carries 1 mark. Choose the best answer (A, B, C or D) and record it on the answer sheet provided.",
    "Section B has 7 theory questions totalling 60 marks. Write your answers clearly and neatly in your answer booklet. Draw and label diagrams where you are asked to.",
    "Read every question carefully before you answer it.",
    "Do not use correction fluid. Cancel any mistake neatly with a single line.",
    "Hand in your answer sheet and your answer booklet at the end of the examination.",
], start=1):
    w(f"{i}. {t}")
w(); w("---"); w()

w("## SECTION A: OBJECTIVE TEST (40 marks)"); w()
w("*Answer ALL questions. Each question carries 1 mark. Choose the BEST answer and write its letter "
  "(A, B, C or D) against the question number on your answer sheet.*"); w()
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"**{i}. {q}**"); w()
    for j, o in enumerate(opts): w(f"{'ABCD'[j]}. {o}")
    w()
w("---"); w()

w("## SECTION B: THEORY (60 marks)"); w()
w("*Answer ALL questions. Write your answers in your answer booklet. The marks for each question are shown "
  "in brackets.*"); w()
for qb in SECTION_B:
    w(f"### Question {qb['num']}  [{qb['total']} marks]"); w()
    w(qb["stem"]); w()
    if qb.get("diagram"):
        w("```")
        for line in LIFE_CYCLE: w(line)
        w("```")
        w("*Fig. 1: The life cycle of the housefly (not drawn to scale)*"); w()
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        w(f"**{lab}** {text}  **[{mk} mark{'s' if mk > 1 else ''}]**"); w()
w("---"); w()

w("## ANSWER KEY"); w()
w("### Section A - Objective Test"); w()
w("| Question | Answer | Curriculum Area (Topic) | Cognitive Level |")
w("| -------- | ------ | ----------------------- | --------------- |")
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"| {i} | {ans} | {TOPIC[tp]} | {cog} |")
counts = {L2: sum(1 for q in MCQ if q[2] == L2) for L2 in "ABCD"}
w()
w("Correct-answer distribution: " + ", ".join(f"{L2} = {counts[L2]}" for L2 in "ABCD") + " (40 items).")
w()
w("### Section B - Theory (summary answers; full detail in the Marking Scheme)"); w()
w("| Question | Expected Answer | Curriculum Area | Cognitive Level |")
w("| -------- | --------------- | --------------- | --------------- |")
sba = [
 ("1 (a)", "The series of changes a living thing goes through from the start of its life to the time it produces young ones of its own.", "4.1", "Understand"),
 ("1 (b)", "Any three of: so the kind of organism does not die out; to replace those that die; to increase in number; to spread to new places.", "4.1", "Understand"),
 ("1 (c)", "The adult produces the egg again, so the series comes back to where it started; it has no real beginning or end, unlike a straight line.", "4.1", "Understand"),
 ("2 (a)", "1 = egg; 2 = larva (maggot); 3 = pupa; 4 = adult", "4.2", "Remember"),
 ("2 (b)", "Any two of: soft, whitish, legless and worm-like; hatches from the egg; feeds continuously and grows; has no wings.", "4.2", "Understand"),
 ("2 (c)", "The larva stops feeding and becomes inactive, forms a brown case, and inside it the body changes completely into the adult, which then breaks out.", "4.2", "Understand"),
 ("3 (a)", "On moist, decaying matter such as refuse, rotten food and animal droppings - because the larvae have food to eat as soon as they hatch.", "4.2", "Understand"),
 ("3 (b)", "egg -> larva -> pupa -> adult", "4.2", "Remember"),
 ("3 (c)", "Many of the eggs and larvae are destroyed by heat, rain, animals and people, so laying many makes it likely that some will survive.", "4.2", "Understand"),
 ("4 (a)", "Any three of: dead animals; rotten food; animal droppings (manure); solid waste (refuse); liquid waste; faeces; human food.", "4.3", "Remember"),
 ("4 (b)", "It has no teeth and cannot chew; its mouthparts can only suck up liquid, so it must turn solid food into liquid first.", "4.3", "Understand"),
 ("4 (c)", "It feeds on filthy matter and then lands on human food, carrying disease organisms on its legs and body hairs and leaving them in its droppings and vomit.", "4.3", "Analyse"),
 ("5 (a)", "Any three of: transfers disease organisms to food; causes food poisoning; contaminates food; is a nuisance in the environment.", "4.4", "Understand"),
 ("5 (b)", "Any two of: dysentery; cholera; typhoid fever; diarrhoea.", "4.5", "Remember"),
 ("5 (c)", "It feeds on faeces, organisms stick to the hairs on its legs and body, then it walks over uncovered food and leaves droppings and vomit carrying the organisms.", "4.5", "Apply"),
 ("5 (d)", "Illness caused by eating food containing harmful organisms or their poisons; the fly carries these from faeces and refuse on to the food, causing stomach pain, vomiting and diarrhoea.", "4.4", "Understand"),
 ("6 (a)", "Any three of: cover all food and water; covered refuse bins and proper disposal; regular cleaning; screen windows and doors; wash hands with soap; keep droppings away from homes.", "4.6", "Understand"),
 ("6 (b)", "Covering food stops flies landing on and contaminating it; covering refuse bins stops them reaching the decaying matter where they feed and lay eggs.", "4.6", "Understand"),
 ("6 (c)", "Any six of: identified problem; practical intervention; who carries it out; when and where; how the community is educated; how it will be checked. Must be safe and workable.", "4.6", "Create"),
 ("7 (a)", "Make a card or small model for each of the four stages, arrange them egg -> larva -> pupa -> adult, join them with arrows, and draw an arrow from the adult back to the egg.", "4.2", "Create"),
 ("7 (b)", "Any two of: makes the order of the stages clear; pupils can see and handle the stages so they remember them; safer and cleaner than keeping live flies.", "4.2", "Evaluate"),
]
for r in sba: w(f"| {r[0]} | {r[1]} | {r[2]} | {r[3]} |")
w(); w("---"); w()

w("## MARKING SCHEME - SECTION B (60 marks)"); w()
w("*General rules: (1) Accept any other correct and relevant answer. (2) Award marks for correct points, not "
  "for repeating the question. (3) For procedures, award method marks. (4) Do not deduct marks for spelling "
  "unless the meaning is changed. (5) Where a candidate gives more answers than are asked for, mark only the "
  "first ones up to the number required.*"); w()
for qb in SECTION_B:
    n = qb["num"]
    w(f"### Question {n} ({qb['total']} marks)"); w()
    for (lab, points, note) in MARKING[n]:
        mkv = [p_[2] for p_ in qb["parts"] if p_[0] == lab]
        head = f"**{lab}**"
        if mkv: head += f" [{mkv[0]} mark{'s' if mkv[0] > 1 else ''}]"
        w(head); w()
        for pt in points: w(f"- {pt}")
        w(f"  - *Marking note: {note}*"); w()
w("---"); w()

w("## CURRICULUM ASSESSMENT BLUEPRINT"); w()
w(f"**Strand:** {STRAND} | **Sub-strand:** {SUBSTRAND} | **Class:** {CLASS}"); w()
w(f"**Content Standard:** {CS} - {CS_TEXT}"); w()
w("> Source: NaCCA Science Common Core Programme Curriculum (B7/JHS1-B9/JHS3), September 2020, "
  "Strand 2: Cycles, Sub-strand 2: Life Cycle of Organisms, pp. 9-10. Indicators are quoted, not "
  "invented."); w()

w("### Section A"); w()
w("| Qn | Sub-strand | Content Standard | Indicator (NaCCA) - Indicator Text | Topic / Content | Cognitive Level | Marks |")
w("| -- | ---------- | ---------------- | ---------------------------------- | --------------- | --------------- | ----- |")
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"| A{i} | {SUBSTRAND} | {CS} | {IND[tp]} - {IND_TEXT[tp]} | {TOPIC[tp]} | {cog} | 1 |")
w()
w("### Section B"); w()
w("| Qn | Sub-strand | Content Standard | Indicator (NaCCA) - Indicator Text | Topic / Content | Cognitive Level | Marks |")
w("| -- | ---------- | ---------------- | ---------------------------------- | --------------- | --------------- | ----- |")
for qb in SECTION_B:
    for (lab, text, mkv, cog, tp, diff) in qb["parts"]:
        key = tp if tp in TOPIC else tp.split(",")[0].strip()
        w(f"| B{qb['num']}{lab.strip('()')} | {SUBSTRAND} | {CS} | {IND[key]} - {IND_TEXT[key]} | {TOPIC[key]} | {cog} | {mkv} |")
w(); w("---"); w()

def topic_totals():
    m = {k: 0 for k in TOPIC}; it = {k: 0 for k in TOPIC}
    for q in MCQ: m[q[3]] += 1; it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk; it[key] += 1
    return m, it

def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}; b = {k: 0 for k in order}
    for q in MCQ: a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: b[cog] += mk
    return order, a, b

def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ: d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: d[diff] += mk
    return d

m, it = topic_totals(); diff_ = difficulty_totals(); order, ca, cb = cognitive_by_section()

w("### Summary 1 - Coverage by Curriculum Area (Topic)"); w()
w("| Topic / Content Area | No. of Items | Marks | % of Total Marks | Core Competencies |")
w("| -------------------- | ------------ | ----- | ---------------- | ----------------- |")
for k in TOPIC: w(f"| {TOPIC[k]} | {it[k]} | {m[k]} | {(m[k]/100)*100:.1f}% | {CC[k]} |")
w(f"| **TOTAL** | **{sum(it.values())}** | **{sum(m.values())}** | **100%** | - |")
w()
w("*CC = Communication and Collaboration; CP = Critical Thinking and Problem Solving; DL = Digital Literacy; "
  "CI = Creativity and Innovation.*"); w()
w("### Summary 2 - Cognitive-Level Distribution (Bloom's Taxonomy)"); w()
w("| Cognitive Level | Section A Marks | Section B Marks | Total Marks | % of Total |")
w("| --------------- | --------------- | --------------- | ----------- | ---------- |")
for lv in order:
    tot = ca[lv] + cb[lv]
    w(f"| {lv} | {ca[lv]} | {cb[lv]} | {tot} | {(tot/100)*100:.1f}% |")
w(f"| **TOTAL** | **{sum(ca.values())}** | **{sum(cb.values())}** | **{sum(ca.values())+sum(cb.values())}** | **100%** |")
w()
w("### Summary 3 - Difficulty Distribution"); w()
w("| Difficulty | Marks | % of Total Marks |")
w("| ---------- | ----- | ---------------- |")
for k, v in diff_.items(): w(f"| {k} | {v} | {(v/100)*100:.1f}% |")
w(f"| **TOTAL** | **{sum(diff_.values())}** | **100%** |")
w()
w("*Target in the master prompt: approximately 30% easy / 50% moderate / 20% challenging.*"); w()
w("### Summary 4 - Section Weighting"); w()
w("| Section | Question Type | Items | Marks | % of Total |")
w("| ------- | ------------- | ----- | ----- | ---------- |")
w("| A | Objective (multiple choice) | 40 | 40 | 40% |")
w("| B | Theory / constructed response | 21 | 60 | 60% |")
w("| **TOTAL** | - | **61** | **100** | **100%** |")
w(); w("---"); w()

w("## QUALITY-CONTROL SUMMARY")
w("")
w("| Check | Status |")
w("| --- | --- |")
for q_, a_ in [
 ("Every question within supplied curriculum scope",
  "Yes - topics 4.1-4.6 of Strand 2, Sub-Strand 2 (Life Cycle of Organisms), mapped to indicators B7/JHS1.2.2.1.1 and B7/JHS1.2.2.1.2"),
 ("Appropriate for the class",
  "Yes - B7 level; no other insect's life cycle, no genetics, no insect anatomy beyond the curriculum"),
 ("Genuinely BECE-style",
  "Yes - 40 four-option objectives plus structured theory with printed mark allocations and a labelled life-cycle diagram"),
 ("Sufficient application and reasoning",
  "Yes - 26 of 100 marks (26%) at Apply level or above (Apply 8, Analyse 5, Evaluate 4, Create 9)"),
 ("Plausible MCQ distractors",
  "Yes - drawn from the same content family as the key: other stages, stages in the wrong order, and real diseases not spread by houseflies"),
 ("Single best answer per MCQ",
  "Yes - reviewed item by item; special care with A18, where the keyed option is the only one a housefly cannot normally reach"),
 ("Marks internally consistent",
  "Yes - Section A 40 x 1 = 40; Section B 8 + 9 + 6 + 9 + 11 + 12 + 5 = 60; sub-question marks match the marking scheme"),
 ("Total adds up correctly",
  "Yes - 40 + 60 = 100"),
 ("Answer key correct",
  "Yes - all 40 keys and all 21 Section B answers verified against the marking scheme"),
 ("Marking scheme matches questions",
  "Yes - expected answers plus marking notes covering partial credit, alternatives, common wrong answers and method marks; the 6-mark design task has a six-point grid"),
 ("Free from unnecessary ambiguity",
  "Yes - open items are anchored with 'state three', 'name two' and the mark allocation; each diagram number points to exactly one stage"),
 ("Ghanaian contexts natural and accurate",
  "Yes - refuse dumps, chop bars, markets, covered bins, wire-mesh screening, a pupil in Bolgatanga, education through churches, mosques and market women"),
 ("No content beyond the curriculum",
  "No - Question 5 uses the three areas named in the curriculum exemplar (transfer of diseases, food poisoning, nuisance); Question 4(a) uses the exemplar's own feeding list"),
 ("Questions sufficiently varied",
  "Yes - definition, sequencing, diagram labelling, diagram description, mechanism explanation, scenario application, evaluation of control methods, design of an intervention"),
]:
    w("| " + q_ + " | " + a_ + " |")
w("")
w("### EXAMINER NOTES")
w("")
for n_ in [
 "The curriculum exemplar for indicator B7/JHS1.2.2.1.2 names three effects: transfer of diseases, food poisoning, and nuisance in the environment. Question 5 is built on exactly those three, and the feeding list in Question 4(a) is taken from the exemplar's own list (dead animals, rotten food, manure, solid and liquid waste).",
 "Question 6(c) is the curriculum's 'design an intervention' task and carries 6 marks. It is marked against a six-point grid (problem, intervention, who, when/where, community education, checking). Because it is open, two markers should agree on the grid before marking a whole class.",
 "Apply is the thinnest strand in this paper (8 of 100 marks) because most of the higher-order demand sits in Create (9 marks, the intervention), Evaluate (4 marks) and Analyse (5 marks). That balance follows the indicator, which asks pupils to design and to discuss rather than to calculate or predict.",
 "Topic 4.2 carries 29 of 100 marks (29%), the highest weighting, because describing the four stages in order is the core of indicator B7/JHS1.2.2.1.1. If you want a flatter spread, move marks from Questions 2, 3 and 7 to Questions 4 and 5.",
 "The life-cycle diagram is drawn with text characters. Replace the characters with real boxes and arrows, or paste in a hand-drawn figure - the numbering (1-4) is what the questions depend on.",
 "Question 7 deliberately asks pupils to model the cycle rather than to breed houseflies. Do not set any task that requires keeping live flies in the classroom.",
 "Edit the school name, academic year and examination title on page 1 before printing.",
 "This is an original, teacher-made mock. It is not a reproduction of any WAEC or NaCCA examination paper.",
]:
    w("- " + n_)
w()

open("/home/user/Basic7_Integrated_Science_Mock_Strand2_LifeCycleOfOrganisms.md", "w", encoding="utf-8").write("\n".join(L))
print("md written", len("\n".join(L)), "chars")
