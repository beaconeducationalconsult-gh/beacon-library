# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "/home/user")
from build_land import *

L = []
def w(s=""): L.append(s)

w(f"# {SCHOOL}"); w()
w(f"## {SUBJECT}"); w()
w(f"### {EXAM}"); w()
w(f"**Class:** {CLASS}  ")
w(f"**Time:** {TIME}  ")
w(f"**Total Marks:** {MARKS}  ")
w(f"**Academic Year:** {YEAR}"); w()
w("---"); w()
w("### INSTRUCTIONS"); w()
for i, t in enumerate([
    "Write your name and class clearly in the spaces provided on your answer sheet.",
    "This paper has TWO sections: Section A and Section B.",
    "Answer ALL the questions in both sections.",
    "Section A has 40 multiple-choice questions. Each question carries 1 mark. Choose the best answer (A, B, C or D) and record it on the answer sheet provided.",
    "Section B has 7 theory questions totalling 60 marks. Write your answers clearly and neatly in your answer booklet. Draw and label diagrams or tables where you are asked to.",
    "Read every question carefully before you answer it.",
    "Do not use correction fluid. Cancel any mistake neatly with a single line.",
    "Hand in your answer sheet and your answer booklet at the end of the examination.",
], start=1):
    w(f"{i}. {t}")
w(); w("---"); w()

w("## SECTION A: OBJECTIVE TEST (40 marks)"); w()
w("*Answer ALL questions. Each question carries 1 mark. Choose the BEST answer and write its letter "
  "(A, B, C or D) against the question number on your answer sheet.*"); w()
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"**{i}. {q}**"); w()
    for j, o in enumerate(opts): w(f"{'ABCD'[j]}. {o}")
    w()
w("---"); w()

w("## SECTION B: THEORY (60 marks)"); w()
w("*Answer ALL questions. Write your answers in your answer booklet. The marks for each question are shown "
  "in brackets.*"); w()
for qb in SECTION_B:
    w(f"### Question {qb['num']}  [{qb['total']} marks]"); w()
    w(qb["stem"]); w()
    if qb.get("table") == "landform":
        w("| " + " | ".join(LANDFORM_HEADERS) + " |")
        w("| " + " | ".join(["---"] * len(LANDFORM_HEADERS)) + " |")
        for r in LANDFORM_ROWS:
            w("| " + " | ".join(r) + " |")
        w()
        w("*Table 1: Living things found in different landforms in Ghana*"); w()
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        w(f"**{lab}** {text}  **[{mk} mark{'s' if mk > 1 else ''}]**"); w()
w("---"); w()

w("## ANSWER KEY"); w()
w("### Section A - Objective Test"); w()
w("| Question | Answer | Curriculum Area (Topic) | Cognitive Level |")
w("| -------- | ------ | ----------------------- | --------------- |")
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"| {i} | {ans} | {TOPIC[tp]} | {cog} |")
counts = {L2: sum(1 for q in MCQ if q[2] == L2) for L2 in "ABCD"}
w()
w("Correct-answer distribution: " + ", ".join(f"{L2} = {counts[L2]}" for L2 in "ABCD") + " (40 items).")
w()
w("### Section B - Theory (summary answers; full detail in the Marking Scheme)"); w()
w("| Question | Expected Answer | Curriculum Area | Cognitive Level |")
w("| -------- | --------------- | --------------- | --------------- |")
sba = [
 ("1 a", "Any four: plateau, plain, mountain, valley, hill, escarpment, ridge, basin, coastal plain, savanna plain.", "20.1", "Remember"),
 ("1 b", "A plateau stands high above the land around it and is flat or gently undulating on top, while a plain lies low and is nearly level. A plateau usually ends in a steep side or an escarpment, while a plain has no steep edge. A plateau is usually cooler than a plain, because the air gets cooler the higher you go above the sea. A plateau is often harder to reach and harder to farm on machinery, while a plain is easy to build and farm on.", "20.1", "Understand"),
 ("1 c", "A mountain: Mount Afadjato, in the Volta Region. Also accept Mount Gemi or the Akwapim-Togo ranges. A plain: the Accra Plains, in the Greater Accra Region. Also accept the Keta sand plains or the savanna plains of the Northern Region.", "20.1", "Understand"),
 ("2 i", "Any one plant of the dry savanna plains: baobab, shea, dawadawa, neem, acacia, kapok, or any of the savanna grasses.", "20.2", "Understand"),
 ("2 ii", "Any one animal of a wooded plateau: monkey, duiker, bushbuck, forest bird, squirrel, snake.", "20.2", "Understand"),
 ("2 iii", "Any one plant of a mountain: moss, fern, lichen, or a small hard-leaved mountain shrub.", "20.2", "Understand"),
 ("2 iv", "Any one animal of a valley: frog, toad, crocodile, fish, freshwater crab, heron, kingfisher, dragonfly.", "20.2", "Understand"),
 ("3 a", "Adaptation is any feature or behaviour of a living thing that helps it to survive in the place where it lives. For example, a grasscutter has strong front teeth for cutting tough roots, and it lives in a burrow to escape the heat of the day.", "20.3", "Understand"),
 ("3 b", "Long legs, so that the animal can run fast across open ground where there is nowhere to hide. A coat the same colour as the dry grass, so that enemies cannot see it easily. Living in a burrow, which is cooler than the open ground and hides the animal from enemies. Large ears or thin skin, which let the body give off heat and keep cool. The ability to go for a long time without drinking.", "20.3", "Understand"),
 ("3 c", "An animal on a mountain would need thicker covering against the cold and feet that grip rock, while an animal on a plain needs to run fast and to keep cool. The reason is that the mountain is colder, wetter and steeper, while the plain is hot, dry and open.", "20.3", "Apply"),
 ("4 a", "It may shed its leaves in the dry season, so that no water is lost from them while there is none in the soil. It may have small, tough or waxy leaves, which lose water very slowly. It may store water in a swollen trunk, a thick stem or an underground bulb. It may send a very long root down to reach water far below the surface. It may die back to a bulb or a swollen root underground and grow again when the rains come. Its seeds may lie in the soil and wait until there has been enough rain.", "20.4", "Understand"),
 ("4 b", "Water is plentiful in the valley and scarce on the plateau, so valley plants can afford broad, thin leaves, while a plant with broad leaves on a dry plateau would lose water faster than its roots could replace it. The valley is sheltered and its soil is usually deeper and richer, so plants there can grow larger, while the plateau is open to wind and strong sun.", "20.4", "Apply"),
 ("5 a", "Commensalism is an association between two living things in which one benefits and the other is neither helped nor harmed. For example, a small bird builds its nest in a tree. The bird gets a safe place and the tree is not affected.", "20.5", "Understand"),
 ("5 b", "Mutualism - for example, bees and flowering plants. The bee gets nectar for food and the plant gets its pollen carried to another flower so that it can make seeds. Both benefit. Parasitism - for example, a tick on a goat, or mistletoe on a tree. The tick gets blood and the goat loses blood and may grow weak or fall sick, so the parasite benefits and the host is harmed.", "20.5", "Understand"),
 ("5 c", "Parasitism, because the parasite takes food or blood from its host, so the host grows slowly, becomes weak and may die before it can reproduce. Accept also: a heavy growth of mistletoe or a strangler fig can kill the trees, which then removes the shelter and the food that other living things depend on.", "20.5", "Analyse"),
 ("6 a", "(i) The egrets and the cattle - commensalism. The egrets get the insects the cattle disturb, and the cattle are not affected. (ii) The ticks and the cattle - parasitism. The ticks get blood and the cattle are harmed. (iii) The fig and the other tree - parasitism. The fig gets support and light, and the other tree is killed.", "20.5", "Apply"),
 ("6 b", "The ticks are the most harmful, because they feed on the cattle's blood, make them weak and can give them disease, so the farmer loses milk, meat and work from the animals. Accept also the fig, if it is argued well: it kills a tree that gives shade, fruit or protection to the soil on the farm.", "20.5", "Evaluate"),
 ("6 c", "Spray or dip the cattle to kill the ticks, and do it again so that the eggs which hatch later are killed too. Clear the bushes where the ticks wait, or move the cattle to another pasture for a time to break the cycle. Keep the cattle in a clean, dry kraal at night and check them often for ticks. Cut down the fig before it kills the tree, and plant another tree in its place.", "20.5", "Apply"),
 ("7 a", "The name of the landform and where in Ghana it is found, for example the Kwahu Plateau in the Eastern Region. Pictures or drawings of the plants and animals found there, each one named. A note on the conditions there - whether it is wet or dry, hot or cool. A note on any adaptation that helps a plant or an animal to survive there.", "20.2", "Understand"),
 ("7 b", "Accept any sensible design. For example: the album will have ten pages - a title page, two pages for each of the four landforms (plateau, plain, mountain and valley), and a page at the back comparing them. Each landform gets a left-hand page with a drawing of its shape and a short note on its soil, water and weather, and a right-hand page with pictures of three plants and three animals found there, each named underneath. A contents page at the front lists the four landforms. Every page is titled with the landform and the region of Ghana where it is found.", "20.2", "Create"),
 ("7 c", "Find the information from the class textbook, the school library, the internet or the district agriculture office, and check each plant and animal against a second source or a person who knows, such as the science teacher or an elder who farms there. Draw the plants and animals from life during a field visit, or print pictures and check the name under each one before using it. Take the finished album to the science teacher to check, and correct anything that is wrong before making the final copy.", "20.2", "Apply"),
]
for r in sba: w(f"| {r[0]} | {r[1]} | {r[2]} | {r[3]} |")
w(); w("---"); w()

w("## MARKING SCHEME - SECTION B (60 marks)"); w()
w("*General rules: (1) Accept any other correct and relevant answer. (2) Award marks for correct points, not "
  "for repeating the question. (3) For procedures, award method marks. (4) Do not deduct marks for spelling "
  "unless the meaning is changed. (5) Where a candidate gives more answers than are asked for, mark only the "
  "first ones up to the number required.*"); w()
for qb in SECTION_B:
    n = qb["num"]
    w(f"### Question {n} ({qb['total']} marks)"); w()
    for (lab, points, note) in MARKING[n]:
        mkv = [p_[2] for p_ in qb["parts"] if p_[0] == lab]
        head = f"**{lab}**"
        if mkv: head += f" [{mkv[0]} mark{'s' if mkv[0] > 1 else ''}]"
        w(head); w()
        for pt in points: w(f"- {pt}")
        w(f"  - *Marking note: {note}*"); w()
w("---"); w()

w("## CURRICULUM ASSESSMENT BLUEPRINT"); w()
w(f"**Strand:** {STRAND} | **Sub-strand:** {SUBSTRAND} | **Class:** {CLASS}"); w()
w(f"**Content Standard:** {CS} - {CS_TEXT}"); w()
w("> Source: NaCCA Science Common Core Programme Curriculum (B7/JHS1-B9/JHS3), September 2020, "
  "Strand 5: Humans and the Environment, Sub-strand 5: Understanding the Environment "
  "(topics 20.1-20.5), pp. 49-50. Indicators are quoted, not invented."); w()

w("### Section A"); w()
w("| Qn | Sub-strand | Content Standard | Indicator (NaCCA) - Indicator Text | Topic / Content | Cognitive Level | Marks |")
w("| -- | ---------- | ---------------- | ---------------------------------- | --------------- | --------------- | ----- |")
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"| A{i} | {SUBSTRAND} | {CS_BY_TOPIC[tp]} | {IND[tp]} - {IND_TEXT[tp]} | {TOPIC[tp]} | {cog} | 1 |")
w()
w("### Section B"); w()
w("| Qn | Sub-strand | Content Standard | Indicator (NaCCA) - Indicator Text | Topic / Content | Cognitive Level | Marks |")
w("| -- | ---------- | ---------------- | ---------------------------------- | --------------- | --------------- | ----- |")
for qb in SECTION_B:
    for (lab, text, mkv, cog, tp, diff) in qb["parts"]:
        key = tp if tp in TOPIC else tp.split(",")[0].strip()
        w(f"| B{qb['num']}{lab.strip('()')} | {SUBSTRAND} | {CS_BY_TOPIC[key]} | {IND[key]} - {IND_TEXT[key]} | {TOPIC[key]} | {cog} | {mkv} |")
w(); w("---"); w()

def topic_totals():
    m = {k: 0 for k in TOPIC}; it = {k: 0 for k in TOPIC}
    for q in MCQ: m[q[3]] += 1; it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk; it[key] += 1
    return m, it

def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}; b = {k: 0 for k in order}
    for q in MCQ: a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: b[cog] += mk
    return order, a, b

def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ: d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: d[diff] += mk
    return d

m, it = topic_totals(); diff_ = difficulty_totals(); order, ca, cb = cognitive_by_section()

w("### Summary 1 - Coverage by Curriculum Area (Topic)"); w()
w("| Topic / Content Area | No. of Items | Marks | % of Total Marks | Core Competencies |")
w("| -------------------- | ------------ | ----- | ---------------- | ----------------- |")
for k in TOPIC: w(f"| {TOPIC[k]} | {it[k]} | {m[k]} | {(m[k]/100)*100:.1f}% | {CC[k]} |")
w(f"| **TOTAL** | **{sum(it.values())}** | **{sum(m.values())}** | **100%** | - |")
w()
w("*CC = Communication and Collaboration; CP = Critical Thinking and Problem Solving; DL = Digital Literacy; "
  "CI = Creativity and Innovation.*"); w()
w("### Summary 2 - Cognitive-Level Distribution (Bloom's Taxonomy)"); w()
w("| Cognitive Level | Section A Marks | Section B Marks | Total Marks | % of Total |")
w("| --------------- | --------------- | --------------- | ----------- | ---------- |")
for lv in order:
    tot = ca[lv] + cb[lv]
    w(f"| {lv} | {ca[lv]} | {cb[lv]} | {tot} | {(tot/100)*100:.1f}% |")
w(f"| **TOTAL** | **{sum(ca.values())}** | **{sum(cb.values())}** | **{sum(ca.values())+sum(cb.values())}** | **100%** |")
w()
w("### Summary 3 - Difficulty Distribution"); w()
w("| Difficulty | Marks | % of Total Marks |")
w("| ---------- | ----- | ---------------- |")
for k, v in diff_.items(): w(f"| {k} | {v} | {(v/100)*100:.1f}% |")
w(f"| **TOTAL** | **{sum(diff_.values())}** | **100%** |")
w()
w("*Target in the master prompt: approximately 30% easy / 50% moderate / 20% challenging.*"); w()
w("### Summary 4 - Section Weighting"); w()
w("| Section | Question Type | Items | Marks | % of Total |")
w("| ------- | ------------- | ----- | ----- | ---------- |")
w("| A | Objective (multiple choice) | 40 | 40 | 40% |")
w("| B | Theory / constructed response | 21 | 60 | 60% |")
w("| **TOTAL** | - | **61** | **100** | **100%** |")
w(); w("---"); w()

w("## QUALITY-CONTROL SUMMARY")
w("")
w("| Check | Status |")
w("| --- | --- |")
for q_, a_ in [
 ("Every question within supplied curriculum scope",
  "Yes - all 61 items (40 objectives and 21 theory sub-questions) sit in topics 20.1-20.5 of Strand 5, Sub-Strand 5 (Understanding the Environment), under the single content standard B7/JHS1.5.5.1. Topics 20.1-20.4 map to indicator B7/JHS1.5.5.1.1 and topic 20.5 to B7/JHS1.5.5.1.2, exactly as the curriculum sets them out. Every landform, plant and animal named is one a Basic 7 pupil in Ghana would meet"),
 ("Appropriate for the class",
  "Yes - the B7 curriculum asks learners to identify the plants and animals found in different landforms with emphasis on Ghana; to describe the characteristics that enable animals to live and plants to survive in those landforms; to make an album of them; and to describe mutualism, parasitism and commensalism and explain their effects on habitats. Nothing beyond that is tested"),
 ("Genuinely BECE-style",
  "Yes - 40 four-option objectives plus structured theory with printed mark allocations, a three-column completion table, 'name', 'state' and 'explain' items, and open tasks requiring application, analysis, evaluation and design"),
 ("Sufficient application and reasoning",
  "Yes - 37 of 100 marks (37%) at Apply level or above (Apply 23, Analyse 6, Evaluate 4, Create 4)"),
 ("Plausible MCQ distractors",
  "Yes - a real feature that sounds useful but would not help in that landform, a real living thing placed in the wrong landform, a real association that is not the one described, and a real term that is the wrong side of the relationship (A34, where the goat is the host and not the parasite)"),
 ("Single best answer per MCQ",
  "Yes - reviewed item by item and each option list was checked so that the declared key sits on the correct answer; in A6 three options are landforms and only one is not, in A13 three are animals of a dry plain and only one needs standing water, in A37 three describe real associations but only one states the difference between parasitism and commensalism, and in A40 three are replies but only one is scientifically correct"),
 ("Marks internally consistent",
  "Yes - Section A 40 x 1 = 40; Section B 9 + 8 + 9 + 8 + 9 + 8 + 9 = 60; sub-question marks match the marking scheme"),
 ("Total adds up correctly",
  "Yes - 40 + 60 = 100"),
 ("Answer key correct",
  "Yes - all 40 keys and all 21 Section B answers verified against the marking scheme; the facts were checked item by item - Mount Afadjato is in the Volta Region, a sudden drop in the land carrying a waterfall is an escarpment and not a valley floor, the animal a tick feeds on is the host, and bees carrying pollen while taking nectar is mutualism and not commensalism"),
 ("Marking scheme matches questions",
  "Yes - expected answers plus marking notes covering partial credit, alternatives, common wrong answers and method marks; Question 3(a) gives at most 1 to 'adaptation is when an animal changes', Question 5(a) gives 0 to 'both benefit' which is mutualism, Question 2(iii) does not accept baobab or oil palm, Question 4(a) allows no more than 1 mark in total for ways named but not explained, Question 6(a) gives 0 where the association is right but paired with the wrong living things, and Question 7(b) caps 'we will put pictures in it' at 2 of 4"),
 ("Free from unnecessary ambiguity",
  "Yes - open items are anchored with 'name four', 'state three', 'give one', 'explain four' and 'describe two' plus the mark allocation; Question 1(c) demands a NAMED example and not a region, Question 6(a) names the three pairs to be identified, Question 4(b) asks for two reasons and not one, and Question 7(b) requires the number of pages, the organisation and the contents of each page"),
 ("Ghanaian contexts natural and accurate",
  "Yes - Mount Afadjato in the Volta Region, the Accra Plains, the Kwahu Plateau, the wooded plateau of the Ashanti Region, Wli and Boti waterfalls, the dry savanna plains of the north with baobab, shea, dawadawa and neem, grasscutter and guinea fowl, cattle egrets among grazing cattle, ticks on cattle, a fig killing a tree on the farm, bush fires on the savanna, and bamboo and ferns in the valleys"),
 ("No content beyond the curriculum",
  "No - every item sits inside topics 20.1-20.5; no plant physiology beyond what a Basic 7 pupil observes is required, no landform beyond the four named plus escarpment is tested, no association beyond mutualism, parasitism and commensalism is asked for, and no landform outside Ghana is required"),
 ("Questions sufficiently varied",
  "Yes - comparing a plain with a plateau, choosing a landform for a crop, locating a named mountain, explaining why a plateau town is cooler, identifying an escarpment, spotting what is not a landform, explaining why valleys hold more plant life, matching plants and animals to landforms, completing a four-blank landform table, defining adaptation, explaining plains adaptations, comparing mountain and plain animals, listing four ways a plant survives drought, comparing valley and plateau plants, defining commensalism, giving examples of mutualism and parasitism, judging which association reduces numbers, and designing, sourcing and checking an album"),
]:
    w("| " + q_ + " | " + a_ + " |")
w("")
w("### EXAMINER NOTES")
w("")
for n_ in [
 "Question 5 is where most marks will be lost. Pupils mix up the three associations, and the commonest error is writing 'both benefit' for commensalism, which earns 0. Drill the three as a fixed pattern: mutualism - both gain; parasitism - one gains, one is harmed; commensalism - one gains, the other is not affected at all. Insist they state all three words in every answer.",
 "Question 3(a) and Question 5(b) both turn on definitions, and pupils lose marks for saying 'adaptation is when an animal changes to fit in'. An adaptation is a feature or behaviour the living thing already has. Correct this before the examination, not after.",
 "Question 2 is the completion table. Blank (iii) is the hard one - pupils will put baobab or oil palm on the mountain, and the note does not accept them. Moss, fern and lichen are the answers to teach. Blank (i) is the easy one, so a pupil who scores 2 of 8 has probably only guessed at the savanna.",
 "Question 4(a) asks for FOUR explained ways, and pupils tend to write one way four times. The note allows no more than 1 mark in total for ways that are named but not explained. Teach them four clearly different mechanisms: shedding leaves, small or waxy leaves, storing water, and a deep root.",
 "Question 7(b) is the Create task. Pupils find it easy to say 'we will put pictures in it' and hard to specify pages, organisation and contents, which is why that answer is capped at 2 of 4. Practise one album plan on paper in class before the examination and the marks rise sharply.",
 "Topic weighting is 25 marks each for 20.2 and 20.5, 17 each for 20.1 and 20.3, and 16 for 20.4. The two heavier topics carry two Section B questions each. If your class found associations hard, spend the extra time on Question 5 and Question 6.",
 "Three cheap activities that raise marks: (1) take the class to the nearest slope, flat ground and stream and have them list what lives in each, which teaches Questions 1, 2 and 3; (2) collect a waxy leaf, a hairy leaf and a broad thin leaf and pass them round, which teaches Question 4; and (3) have each group find one real example of each association on the school compound, which teaches Questions 5 and 6.",
 "This sub-strand has one content standard and two indicators, so it is a single paper and not split. The companion papers cover Sub-strand 2 (Human Health) in two parts, Sub-strand 3 (Science and Industry), and Sub-strand 4 (Climate Change and Green Economy).",
 "This version is a full rebuild. Every question is new, and none is repeated from the earlier version of this paper, so you can use either as a mock and the other as a second sitting without pupils seeing the same items twice.",
 "Edit the school name, academic year and examination title on page 1 before printing.",
 "This is an original, teacher-made mock. It is not a reproduction of any WAEC or NaCCA examination paper.",
]:
    w("- " + n_)
w()

open("/home/user/Basic7_Integrated_Science_Mock_Strand5_UnderstandingTheEnvironment.md", "w", encoding="utf-8").write("\n".join(L))
print("md written", len("\n".join(L)), "chars")
