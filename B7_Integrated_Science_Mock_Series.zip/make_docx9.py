# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "/home/user")
from build_eco import *

from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT

doc = Document()
sec = doc.sections[0]
sec.left_margin = Inches(0.7); sec.right_margin = Inches(0.7)
sec.top_margin = Inches(0.7); sec.bottom_margin = Inches(0.6)

st = doc.styles["Normal"]; st.font.name = "Calibri"; st.font.size = Pt(11)


def set_font(run, size=11, bold=False, italic=False, mono=False, color=None):
    run.font.size = Pt(size); run.bold = bold; run.italic = italic
    run.font.name = "Consolas" if mono else "Calibri"
    if color: run.font.color.rgb = color
    return run


def para(text="", size=11, bold=False, italic=False, align=None, mono=False,
         space_before=0, space_after=4, color=None):
    p = doc.add_paragraph()
    if align == "c": p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    elif align == "j": p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p.paragraph_format.space_before = Pt(space_before)
    p.paragraph_format.space_after = Pt(space_after)
    if text: set_font(p.add_run(text), size, bold, italic, mono, color)
    return p


def rule():
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(6); p.paragraph_format.space_before = Pt(2)
    set_font(p.add_run("_" * 78), 9, color=RGBColor(0x99, 0x99, 0x99))


def add_table(headers, rows, widths=None, size=9, head_size=9):
    t = doc.add_table(rows=1, cols=len(headers)); t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, h in enumerate(headers):
        c = t.rows[0].cells[i]; c.text = ""
        p = c.paragraphs[0]; p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_font(p.add_run(str(h)), head_size, bold=True)
    for row in rows:
        cells = t.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = ""
            p = cells[i].paragraphs[0]; p.paragraph_format.space_after = Pt(1)
            set_font(p.add_run(str(v)), size)
    if widths:
        for r_ in t.rows:
            for i, w in enumerate(widths): r_.cells[i].width = Inches(w)
    return t


def draw_diagram(lines, caption):
    t = doc.add_table(rows=2, cols=1); t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = t.rows[0].cells[0]
    for k, line in enumerate(lines):
        p = cell.paragraphs[0] if k == 0 else cell.add_paragraph()
        p.paragraph_format.space_after = Pt(0); p.paragraph_format.space_before = Pt(0)
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_font(p.add_run(line), 10, mono=True)
    c2 = t.rows[1].cells[0].paragraphs[0]
    c2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_font(c2.add_run(caption), 9, italic=True)
    t.rows[0].cells[0].width = Inches(6.6)
    t.rows[1].cells[0].width = Inches(6.6)


# ============================================================= TITLE BLOCK
para(SCHOOL, size=15, bold=True, align="c", space_after=2)
para(SUBJECT, size=13, bold=True, align="c", space_after=2)
para(EXAM, size=12, bold=True, align="c", space_after=2)
para(YEAR, size=10, italic=True, align="c", space_after=8)

info = doc.add_table(rows=1, cols=3); info.style = "Table Grid"
info.alignment = WD_TABLE_ALIGNMENT.CENTER
for i, v in enumerate([f"Class: {CLASS}", f"Time: {TIME}", f"Total Marks: {MARKS}"]):
    c = info.rows[0].cells[i]; c.text = ""
    set_font(c.paragraphs[0].add_run(v), 10, bold=True)
para("", space_after=6)

para("INSTRUCTIONS", size=11, bold=True, space_after=3)
for txt in [
    "1. Write your name and class clearly in the spaces provided on your answer sheet.",
    "2. This paper has TWO sections: Section A and Section B.",
    "3. Answer ALL the questions in both sections.",
    "4. Section A has 40 multiple-choice questions. Each question carries 1 mark. Choose the best answer "
    "(A, B, C or D) and record it on the answer sheet provided.",
    "5. Section B has 7 theory questions totalling 60 marks. Write your answers clearly and neatly in your "
    "answer booklet. Draw and label diagrams or tables where you are asked to.",
    "6. Read every question carefully before you answer it.",
    "7. Do not use correction fluid. Cancel any mistake neatly with a single line.",
    "8. Hand in your answer sheet and your answer booklet at the end of the examination.",
]:
    para(txt, size=10.5, space_after=2)
rule()

# =============================================================== SECTION A
para("SECTION A - OBJECTIVE TEST (40 marks)", size=12, bold=True, align="c", space_after=2)
para("Answer ALL questions. Each question carries 1 mark. Choose the BEST answer and write its letter "
     "(A, B, C or D) against the question number on your answer sheet.",
     size=10, italic=True, align="c", space_after=8)

for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(1); p.paragraph_format.space_before = Pt(4)
    set_font(p.add_run(f"{i}. {q}"), 10.5)
    for j, o in enumerate(opts):
        p2 = doc.add_paragraph()
        p2.paragraph_format.left_indent = Inches(0.28)
        p2.paragraph_format.space_after = Pt(0); p2.paragraph_format.space_before = Pt(0)
        set_font(p2.add_run(f"{'ABCD'[j]}. {o}"), 10.5)

doc.add_page_break()

# =============================================================== SECTION B
para("SECTION B - THEORY (60 marks)", size=12, bold=True, align="c", space_after=2)
para("Answer ALL questions. Write your answers in your answer booklet. The marks for each question are "
     "shown in brackets.", size=10, italic=True, align="c", space_after=8)

for qb in SECTION_B:
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(8); p.paragraph_format.space_after = Pt(2)
    set_font(p.add_run(f"Question {qb['num']}"), 11, bold=True)
    set_font(p.add_run(f"  [{qb['total']} marks]"), 10, bold=True, italic=True)
    para(qb["stem"], size=10.5, space_after=4)
    if qb.get("table") == "pond":
        add_table(POND_HEADERS, POND_ROWS, widths=[3.2, 2.4], size=9, head_size=9)
        para("Table 1: Components of a pond ecosystem", size=9, italic=True, align="c",
             space_after=6)
        para("", space_after=2)
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Inches(0.25)
        p.paragraph_format.space_after = Pt(3); p.paragraph_format.space_before = Pt(2)
        set_font(p.add_run(f"{lab} {text}  "), 10.5)
        set_font(p.add_run(f"[{mk} mark{'s' if mk > 1 else ''}]"), 10, bold=True)

doc.add_page_break()

# ============================================================== ANSWER KEY
para("ANSWER KEY", size=13, bold=True, align="c", space_after=6)
para("SECTION A - OBJECTIVE TEST", size=11, bold=True, space_after=4)
rows = [[i, ans, TOPIC[tp], cog] for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1)]
add_table(["Question", "Answer", "Curriculum Area (Topic)", "Cognitive Level"],
          rows, widths=[0.8, 0.7, 3.6, 1.5], size=9)
counts = {L: sum(1 for q in MCQ if q[2] == L) for L in "ABCD"}
para("", space_after=4)
para("Correct-answer distribution: " + ", ".join(f"{L} = {counts[L]}" for L in "ABCD") + " (30 items).",
     size=9, italic=True)

para("", space_after=8)
para("SECTION B - THEORY (summary answers; see the Marking Scheme for full detail)",
     size=11, bold=True, space_after=4)
sba = [
 ("1 (a)", "A self-sustaining unit in which living things and their non-living surroundings interact; "
  "a community of organisms together with the soil, water, air and sunlight around them.", "9.1",
  "Understand"),
 ("1 (b)", "Any two of: a pond; a forest; a river or stream; a lake; a mangrove swamp; a grassland or "
  "savanna; a farm or school garden; the branches of a large tree.", "9.1", "Remember"),
 ("1 (c)", "The parts supply what each other needs; green plants trap the Sun's energy and make the "
  "food; waste and dead remains are broken down so nutrients go round again; so the unit can keep "
  "itself going.", "9.1", "Understand"),
 ("2 (a)", "Terrestrial, aquatic and arboreal.", "9.2", "Remember"),
 ("2 (b)", "Terrestrial - a forest, a grassland, a farm. Aquatic - a pond, a river, a lake, a mangrove "
  "swamp. Arboreal - the community of organisms living in the branches of one large tree.", "9.2",
  "Understand"),
 ("2 (c)", "An arboreal ecosystem is found up in the branches and on the trunk of trees, while a "
  "terrestrial ecosystem is found on the land surface; an arboreal ecosystem is really the part of a "
  "terrestrial one that lives in the trees.", "9.2", "Understand"),
 ("3 (a)", "(i) abiotic; (ii) biotic; (iii) abiotic; (iv) biotic; (v) abiotic; (vi) biotic.", "9.3",
  "Understand"),
 ("3 (b)", "Any two not already in the table: the temperature of the water; the depth of the water; "
  "the mud at the bottom; rainfall; mineral salts; the amount of light; the wind.", "9.3", "Remember"),
 ("3 (c)", "Biotic components are the living parts - the plants, animals and decay organisms; abiotic "
  "components are the non-living parts - water, air, sunlight, temperature, soil and mineral salts.",
  "9.3", "Understand"),
 ("4 (a)", "Any three of: feeding on one another; carrying pollen from flower to flower; carrying "
  "seeds to new places; providing shelter; breaking down dead remains; competing for food, water, "
  "light and space.", "9.4", "Understand"),
 ("4 (b)", "Sunlight lets the water plants make food; the temperature affects how much oxygen "
  "dissolves in the water; the fish breathe the oxygen dissolved in the water; mineral salts feed the "
  "plants; in the dry season the water level falls and there is less room and less oxygen.", "9.4",
  "Apply"),
 ("4 (c)", "Plants take in carbon dioxide and give out oxygen; dead remains add humus to the soil; "
  "tree roots break up rocks, hold the soil together and stop it being washed away; plants shade the "
  "ground so the soil stays cooler and moister.", "9.4", "Understand"),
 ("5 (a)", "The organisms depend on one another to stay alive: each needs something another provides "
  "- food, shelter, pollination or seed dispersal - so what happens to one affects the others.", "9.5",
  "Understand"),
 ("5 (b)", "Animals depend on plants for food and oxygen; plants depend on animals for carbon dioxide "
  "and for pollination and seed dispersal; animals depend on plants for shelter.", "9.5", "Understand"),
 ("5 (c)", "Any sensible chain starting with a green plant, e.g. maize -> grasshopper -> lizard -> "
  "hawk. Removing a link means the animals that feed on it lose their food and their numbers fall, "
  "while what it used to eat may increase, so the balance of the whole ecosystem is disturbed.", "9.5",
  "Analyse"),
 ("6 (a)", "Any three of: the lizards, birds and frogs that eat insects lose their food; flowers are "
  "not pollinated and produce fewer seeds and fruits; pest insects may return in larger numbers; the "
  "yield may fall; the chemical may wash into the soil and water; animals that eat poisoned insects "
  "may be poisoned.", "9.5", "Analyse"),
 ("6 (b)", "The organisms are interdependent, so whatever happens to the insects passes along the food "
  "chain to the animals that eat them and then to those that eat those, and the plants lose their "
  "pollinators too.", "9.5", "Analyse"),
 ("6 (c)", "Any two of: mixed cropping or crop rotation; a mild local method such as neem extract or "
  "wood ash; leaving a strip uncultivated for useful insects and birds; spraying only in the evening; "
  "spraying only the affected part; hand-picking pests; adding compost or manure.", "9.5", "Create"),
 ("7 (a)", "Choose one ecosystem near the school; visit it more than once and observe quietly; note "
  "the abiotic components and list the biotic ones; record where each organism was found; draw or "
  "photograph it; record everything in a two-column table; note any interaction seen; work in groups "
  "and write a short report.", "9.3", "Create"),
 ("7 (b)", "Any two of: it shows that the living and non-living parts really do interact; it makes the "
  "class notice how the organisms depend on one another; it shows what happens when people damage an "
  "ecosystem; group work lets everyone join in. Precaution: do not pick flowers or break branches, "
  "put back any stone or log turned over, do not take animals home, leave no litter, keep to the "
  "paths.", "9.4", "Evaluate"),
]
add_table(["Question", "Expected Answer", "Curriculum Area", "Cognitive Level"],
          [list(r) for r in sba], widths=[0.8, 4.2, 1.2, 1.2], size=9)

doc.add_page_break()

# =========================================================== MARKING SCHEME
para("MARKING SCHEME - SECTION B (60 marks)", size=13, bold=True, align="c", space_after=4)
para("General rules: (1) Accept any other correct and relevant answer. (2) Award marks for correct points, "
     "not for repeating the question. (3) For procedures, award method marks. (4) Do not deduct marks for "
     "spelling unless the meaning is changed. (5) Where a candidate gives more answers than are asked for, "
     "mark only the first ones up to the number required.",
     size=9.5, italic=True, space_after=8)

for qb in SECTION_B:
    n = qb["num"]
    para(f"Question {n}  ({qb['total']} marks)", size=11, bold=True, space_before=8, space_after=3)
    for (lab, points, note) in MARKING[n]:
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(2)
        set_font(p.add_run(f"{lab} "), 10.5, bold=True)
        mkv = [p_[2] for p_ in qb["parts"] if p_[0] == lab]
        if mkv: set_font(p.add_run(f"[{mkv[0]} mark{'s' if mkv[0] > 1 else ''}]"), 10, bold=True)
        for pt in points:
            pp = doc.add_paragraph()
            pp.paragraph_format.left_indent = Inches(0.35); pp.paragraph_format.space_after = Pt(1)
            set_font(pp.add_run("- " + pt), 10.5)
        pp = doc.add_paragraph()
        pp.paragraph_format.left_indent = Inches(0.35); pp.paragraph_format.space_after = Pt(6)
        set_font(pp.add_run("Marking note: " + note), 9.5, italic=True)

doc.add_page_break()

# ================================================================ BLUEPRINT
para("CURRICULUM ASSESSMENT BLUEPRINT", size=13, bold=True, align="c", space_after=3)
para(f"Strand: {STRAND}   |   Sub-strand: {SUBSTRAND}   |   Class: {CLASS}",
     size=10, italic=True, align="c", space_after=3)
para(f"Content Standard: {CS} - {CS_TEXT}", size=9, italic=True, align="c", space_after=3)
para("Source: NaCCA Science Common Core Programme Curriculum (B7/JHS1-B9/JHS3), September 2020, "
     "Strand 3: Systems, Sub-strand 3: Ecosystem, pp. 21-22. Indicators are quoted, not invented.",
     size=9, italic=True, space_after=8)

hdr = ["Qn", "Sub-strand", "Content Standard", "Indicator (NaCCA) - Indicator Text", "Topic / Content",
       "Cognitive Level", "Marks"]

rows = [[f"A{i}", SUBSTRAND, CS_BY_TOPIC[tp], f"{IND[tp]} - {IND_TEXT[tp]}", TOPIC[tp], cog, 1]
        for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1)]
add_table(hdr, rows, widths=[0.35, 0.75, 0.75, 1.75, 1.4, 0.8, 0.35], size=7, head_size=7.5)

para("", space_after=8)
rows = []
for qb in SECTION_B:
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        key = tp if tp in TOPIC else tp.split(",")[0].strip()
        rows.append([f"B{qb['num']}{lab.strip('()')}", SUBSTRAND, CS_BY_TOPIC[key],
                     f"{IND[key]} - {IND_TEXT[key]}", TOPIC[key], cog, mk])
add_table(hdr, rows, widths=[0.35, 0.75, 0.75, 1.75, 1.4, 0.8, 0.35], size=7, head_size=7.5)

doc.add_page_break()

# ----------------------------------------------------------------- helpers
def topic_totals():
    m = {k: 0 for k in TOPIC}; it = {k: 0 for k in TOPIC}
    for q in MCQ:
        m[q[3]] += 1; it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk; it[key] += 1
    return m, it

def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}; b = {k: 0 for k in order}
    for q in MCQ: a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: b[cog] += mk
    return order, a, b

def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ: d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: d[diff] += mk
    return d

m, it = topic_totals(); diff = difficulty_totals(); order, ca, cb = cognitive_by_section()

para("SUMMARY 1 - COVERAGE BY CURRICULUM AREA (TOPIC)", size=12, bold=True, space_after=4)
rows = [[TOPIC[k], it[k], m[k], f"{(m[k]/100)*100:.1f}%", CC[k]] for k in TOPIC]
rows.append(["TOTAL", sum(it.values()), sum(m.values()), "100%", "-"])
add_table(["Topic / Content Area", "No. of Items", "Marks", "% of Total Marks", "Core Competencies"],
          rows, widths=[2.7, 0.8, 0.6, 1.0, 1.1], size=8.5)
para("CC = Communication and Collaboration; CP = Critical Thinking and Problem Solving; "
     "DL = Digital Literacy; CI = Creativity and Innovation.", size=8.5, italic=True, space_after=2)

para("", space_after=8)
para("SUMMARY 2 - COGNITIVE-LEVEL DISTRIBUTION (Bloom's Taxonomy)", size=12, bold=True, space_after=4)
rows = []
for lv in order:
    tot = ca[lv] + cb[lv]
    rows.append([lv, ca[lv], cb[lv], tot, f"{(tot/100)*100:.1f}%"])
rows.append(["TOTAL", sum(ca.values()), sum(cb.values()), sum(ca.values()) + sum(cb.values()), "100%"])
add_table(["Cognitive Level", "Section A Marks", "Section B Marks", "Total Marks", "% of Total"],
          rows, widths=[1.6, 1.3, 1.3, 1.1, 1.1], size=9.5)

para("", space_after=8)
para("SUMMARY 3 - DIFFICULTY DISTRIBUTION", size=12, bold=True, space_after=4)
rows = [[k, v, f"{(v/100)*100:.1f}%"] for k, v in diff.items()]
rows.append(["TOTAL", sum(diff.values()), "100%"])
add_table(["Difficulty", "Marks", "% of Total Marks"], rows, widths=[2.0, 1.2, 1.5], size=9.5)
para("Target in the master prompt: approximately 30% easy / 50% moderate / 20% challenging.",
     size=9, italic=True, space_after=2)

para("", space_after=8)
para("SUMMARY 4 - SECTION WEIGHTING", size=12, bold=True, space_after=4)
add_table(["Section", "Question Type", "Items", "Marks", "% of Total"],
          [["A", "Objective (multiple choice)", 40, 40, "40%"],
           ["B", "Theory / constructed response", 20, 60, "60%"],
           ["TOTAL", "-", 60, 100, "100%"]],
          widths=[0.9, 2.4, 0.8, 0.8, 1.0], size=9.5)

doc.add_page_break()

# ===================================================== QUALITY-CONTROL
para("QUALITY-CONTROL SUMMARY", size=13, bold=True, align="c", space_after=4)
para("Carried out against the 14-point validation list in the master prompt before the examination was "
     "finalised.", size=9.5, italic=True, space_after=8)

qc = [
 ("Does every question belong to the supplied curriculum scope?",
  "Yes. All 46 items trace to Strand 3 (Systems), Sub-Strand 3 (Ecosystem), topics 9.1-9.5, and to "
  "the single official B7 indicator B7/JHS1.3.3.1.1 and its five exemplars. Food webs, energy "
  "pyramids, nutrient cycles, population graphs and conservation legislation appear only as "
  "distractors, never as things pupils must answer on."),
 ("Is the examination appropriate for the stated class?",
  "Yes. The B7 curriculum requires learners to describe an ecosystem as a self-sustaining unit, group "
  "ecosystems into terrestrial, aquatic and arboreal, list their biotic and abiotic components, "
  "differentiate among their organisms, and explain how the components affect one another. No energy "
  "pyramid, no chemical cycling detail and no quantitative population study are tested, as these fall "
  "outside the B7 indicator."),
 ("Are the questions genuinely BECE-style?",
  "Yes: Section A is 40 four-option objectives worth 1 mark each, and Section B is structured theory "
  "with sub-questions carrying printed mark allocations. A completion table is included, matching the "
  "BECE science convention and exemplar 3, which asks pupils to identify and list the biotic and "
  "abiotic components of each category."),
 ("Are there enough application and reasoning questions?",
  "Yes. 28 of 100 marks (28%) are at Apply level or above (Apply 7, Analyse 11, Evaluate 4, Create 6). "
  "Analyse is well represented because the indicator opens with the word 'analyse', and Create appears "
  "through the farm-management suggestion in Question 6(c) and the ecosystem study in Question 7(a)."),
 ("Are the MCQ distractors plausible?",
  "Yes. Distractors are drawn from the same content family as the key: examples offered as if they "
  "were categories (A14), the wrong category for a named ecosystem (A15), the wrong classification of "
  "a component (A21), and an interaction of the wrong kind in the two-direction items (A30, A31)."),
 ("Is there only one best answer for each MCQ?",
  "Yes. Every item was reviewed for a single defensible key. Special care was taken with A14, where "
  "'forest, farm and town' is a tempting wrong answer, so the stem asks for the three CATEGORIES and "
  "not for examples."),
 ("Are the marks internally consistent?",
  "Yes. Section A = 40 items x 1 mark = 40. Section B = 9 + 9 + 10 + 9 + 8 + 8 + 7 = 60. "
  "Each Section B sub-question's printed marks match its marking-scheme allocation."),
 ("Does the total add up correctly?",
  "Yes: 40 + 60 = 100 marks, matching the stated total on the front page."),
 ("Are the answers in the answer key correct?",
  "Yes. All 40 objective keys and all 20 Section B answers were verified against the marking scheme."),
 ("Does the marking scheme match the questions?",
  "Yes. Every Section B sub-question has an expected-answer list and a marking note covering partial "
  "credit, acceptable alternatives, common wrong answers and method marks. The completion table, the "
  "food-chain item and both design tasks have explicit marking grids so they can be marked "
  "consistently across a class."),
 ("Are the questions free from unnecessary ambiguity?",
  "Yes. Open items are anchored with 'state three', 'name two' and the mark allocation. Question 3(a) "
  "numbers every blank, (i) to (vi); Question 4(a) insists on living-affecting-living while 4(b) and "
  "4(c) name the direction required; and Question 7(b) asks for two reasons plus one precaution."),
 ("Are Ghanaian contexts used naturally and accurate?",
  "Yes: a village pond, a silk-cotton tree, the Volta Lake, mangrove swamp along the coast, a maize "
  "farm with grasshoppers, lizards and hawks, savanna grassland, the dry season, neem extract and "
  "wood ash, and a class studying an ecosystem beside its own school."),
 ("Has any content outside the supplied curriculum been introduced?",
  "No. Every item sits inside topics 9.1-9.5. Question 1 is built on exemplar 1; Questions 2 and 3 on "
  "exemplars 2, 3 and 4; Question 4 and Question 6 on exemplar 5, the interactions; and Question 5 on "
  "the interdependence named in the content standard itself."),
 ("Are the questions sufficiently varied?",
  "Yes. Item types include definition, giving examples, explaining a key phrase, naming and exemplifying "
  "three categories, classifying components, stating interactions in a required direction, writing a "
  "food chain, predicting the result of removing a link, suggesting safer farming, and designing a "
  "field study."),
]
for i, (q, a) in enumerate(qc, start=1):
    p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(2)
    set_font(p.add_run(f"{i}. {q}"), 10.5, bold=True)
    p2 = doc.add_paragraph()
    p2.paragraph_format.left_indent = Inches(0.3); p2.paragraph_format.space_after = Pt(6)
    set_font(p2.add_run(a), 10)

para("", space_after=8)
para("EXAMINER NOTES (for the teacher, not for candidates)", size=11, bold=True, space_after=4)
for n in [
 "This sub-strand has ONE indicator with FIVE exemplars, so the blueprint shows the same indicator "
 "code throughout and varies only the exemplar number. That is correct and expected here - do not "
 "read it as a mapping error.",
 "Question 3 is exemplar 3, 'identify and list the components'. The six blanks are numbered (i) to "
 "(vi), so marking is quick and fair: 1 mark each, and the blank number must be matched to the answer. "
 "Accept 'living' for biotic and 'non-living' for abiotic.",
 "Questions 4 and 6 are exemplar 5, 'explain how the components affect one another'. The hardest part "
 "for pupils is the DIRECTION of the effect. Question 4(a) wants living-on-living, 4(b) "
 "non-living-on-living, and 4(c) living-on-non-living - mark each against its own direction and do "
 "not accept an answer given in the wrong one.",
 "Question 5(c) expects a food chain, not a food web. The chain must start with a green plant and the "
 "arrows must point the way the food passes. Do NOT expect the words producer, consumer, trophic "
 "level or a pyramid of numbers - all of that is beyond B7.",
 "Question 6 is the insecticide scenario. It is the best single test of interdependence in the paper: "
 "many pupils will answer 'the maize grows better', which is exactly the misconception the question "
 "is written to expose.",
 "Topic 9.5 carries 24 of 100 marks, the highest weighting, because interdependence is named in the "
 "content standard itself, not only in the exemplars. If you want a flatter spread, move marks from "
 "Questions 5 and 6 to Questions 1 and 2.",
 "Question 7 is designed as a real activity. If your school is near a pond, a stream, a patch of bush "
 "or one large tree, run it before the mock and accept what the pupils actually did as evidence. The "
 "safety rule is simple: observe, record, and put back anything that is moved.",
 "Edit the school name, academic year and examination title on page 1 before printing.",
 "This is an original, teacher-made mock. It is not a reproduction of any WAEC or NaCCA examination "
 "paper.",
]:
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Inches(0.3); p.paragraph_format.space_after = Pt(3)
    set_font(p.add_run("- " + n), 10)

doc.save("/home/user/Basic7_Integrated_Science_Mock_Strand3_Ecosystem.docx")
print("docx written")

print("Section A:", len(MCQ), "items")
print("Section B total:", sum(q["total"] for q in SECTION_B))
print("Topic marks:", m, "sum", sum(m.values()))
print("Difficulty:", diff, "sum", sum(diff.values()))
print("Cognitive A:", ca)
print("Cognitive B:", cb)
print("Answer counts:", counts)
print("Totals:", sum(m.values()), sum(diff.values()),
      sum(ca.values()) + sum(cb.values()))
