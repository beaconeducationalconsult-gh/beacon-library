# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "/home/user")
from build_animal import *

L = []
def w(s=""): L.append(s)

w(f"# {SCHOOL}"); w()
w(f"## {SUBJECT}"); w()
w(f"### {EXAM}"); w()
w(f"**Class:** {CLASS}  ")
w(f"**Time:** {TIME}  ")
w(f"**Total Marks:** {MARKS}  ")
w(f"**Academic Year:** {YEAR}"); w()
w("---"); w()
w("### INSTRUCTIONS"); w()
for i, t in enumerate([
    "Write your name and class clearly in the spaces provided on your answer sheet.",
    "This paper has TWO sections: Section A and Section B.",
    "Answer ALL the questions in both sections.",
    "Section A has 40 multiple-choice questions. Each question carries 1 mark. Choose the best answer (A, B, C or D) and record it on the answer sheet provided.",
    "Section B has 7 theory questions totalling 60 marks. Write your answers clearly and neatly in your answer booklet. Draw and label diagrams or tables where you are asked to.",
    "Read every question carefully before you answer it.",
    "Do not use correction fluid. Cancel any mistake neatly with a single line.",
    "Hand in your answer sheet and your answer booklet at the end of the examination.",
], start=1):
    w(f"{i}. {t}")
w(); w("---"); w()

w("## SECTION A: OBJECTIVE TEST (40 marks)"); w()
w("*Answer ALL questions. Each question carries 1 mark. Choose the BEST answer and write its letter "
  "(A, B, C or D) against the question number on your answer sheet.*"); w()
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"**{i}. {q}**"); w()
    for j, o in enumerate(opts): w(f"{'ABCD'[j]}. {o}")
    w()
w("---"); w()

w("## SECTION B: THEORY (60 marks)"); w()
w("*Answer ALL questions. Write your answers in your answer booklet. The marks for each question are shown "
  "in brackets.*"); w()
for qb in SECTION_B:
    w(f"### Question {qb['num']}  [{qb['total']} marks]"); w()
    w(qb["stem"]); w()
    if qb.get("table") == "classify":
        w("| " + " | ".join(CLASSIFY_HEADERS) + " |")
        w("| " + " | ".join(["---"] * len(CLASSIFY_HEADERS)) + " |")
        for r in CLASSIFY_ROWS:
            w("| " + " | ".join(r) + " |")
        w()
        w("*" + CLASSIFY_CAPTION + "*"); w()
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        w(f"**{lab}** {text}  **[{mk} mark{'s' if mk > 1 else ''}]**"); w()
w("---"); w()

w("## ANSWER KEY"); w()
w("### Section A - Objective Test"); w()
w("| Question | Answer | Curriculum Area (Topic) | Cognitive Level |")
w("| -------- | ------ | ----------------------- | --------------- |")
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"| {i} | {ans} | {TOPIC[tp]} | {cog} |")
counts = {L2: sum(1 for q in MCQ if q[2] == L2) for L2 in "ABCD"}
w()
w("Correct-answer distribution: " + ", ".join(f"{L2} = {counts[L2]}" for L2 in "ABCD") + " (40 items).")
w()
w("### Section B - Theory (summary answers; full detail in the Marking Scheme)"); w()
w("| Question | Expected Answer | Curriculum Area | Cognitive Level |")
w("| -------- | --------------- | --------------- | --------------- |")
sba = [
 ("1 (a)", "An animal that people have tamed and keep for their own use; it depends on people for food, water and shelter and is not wild.", "6.1", "Understand"),
 ("1 (b)", "Any four of: cattle; goat; sheep; pig; fowl; duck; guinea fowl; turkey; rabbit; pigeon; donkey; dog; cat.", "6.1", "Remember"),
 ("1 (c)", "Cattle: N'Dama, Sanga or Zebu. Goat: West African Dwarf or Sahelian.", "6.1", "Remember"),
 ("2 (a)", "Ruminant: an animal with a four-chambered stomach that chews the cud. Monogastric: an animal with a simple, single-chambered stomach. Poultry: birds kept by people, such as fowl, duck, guinea fowl, turkey and pigeon.", "6.2", "Understand"),
 ("2 (b)", "Ruminant - cattle, goat or sheep. Monogastric - pig or rabbit. Poultry - fowl, duck, guinea fowl, turkey or pigeon.", "6.2", "Remember"),
 ("2 (c)", "Watch them resting: the goat brings food back up and chews it again (chews the cud) and thrives on grass, while the pig does not and needs grains and kitchen waste. The goat is the ruminant.", "6.2", "Apply"),
 ("3 (a)", "(i) simple, one chamber; (ii) no; (iii) feathers; (iv) born alive; (v) grass and other fibrous plant material (forage, hay, leaves); (vi) no upper front teeth - a hard dental pad.", "6.3", "Understand"),
 ("3 (b)", "Any two of: all are kept by people; all need food, water, shelter and care; all are kept for food (meat, milk or eggs); all reproduce; all produce waste used as manure; all have a backbone; all need protection from disease and heat.", "6.3", "Understand"),
 ("3 (c)", "The goat is a ruminant: micro-organisms in its four-chambered stomach break down the fibre in grass. The pig has a simple stomach and cannot break down much fibre, so it needs grains, kitchen waste and concentrates.", "6.3", "Analyse"),
 ("4 (a)", "Using animals to meet the needs of the family or household - the animal or what it gives is used at home rather than sold.", "6.4", "Understand"),
 ("4 (b)", "Keeping animals in order to sell them or what they produce, in order to earn money.", "6.4", "Understand"),
 ("4 (c)", "Any four of: selling meat; selling eggs; selling milk; selling live animals; selling hides and skins; selling feathers, bones or blood meal; selling manure; ploughing other people's fields or carrying goods for money.", "6.4", "Understand"),
 ("5 (a)", "Any three of: milk, meat or eggs for the family; dung for cooking fuel or the family garden; ploughing or carrying loads; a dog to guard the house; animals for dowry, festivals or ceremonies; company or pets; feathers, wool or hides used at home.", "6.4", "Understand"),
 ("5 (b)", "The family eats what it needs and sells the extra, which gives money for school fees, food and medicine; keeping animals is also a way of saving, because one can be sold when cash is needed.", "6.4", "Analyse"),
 ("5 (c)", "Any three of: a clear picture of each animal; its name and the group it belongs to; what it is kept for (domestic uses); what it eats and how it is housed; its by-products and their uses; short clear sentences under each picture; a title and the class name.", "6.4", "Create"),
 ("6 (a)", "A useful material obtained from an animal apart from the main product - something useful that is left after the meat, milk or eggs have been taken.", "6.5", "Understand"),
 ("6 (b)", "Any five correctly named with an importance: dung - manure; bones - bone meal for feed and fertilizer; hides and skins - leather; feathers - pillows and cushions; blood - blood meal for feed; horns and hooves - glue, buttons and combs; fat - soap and candles; wool and hair - cloth and blankets; urine - compost; eggshells - feed or compost.", "6.5", "Understand"),
 ("6 (c)", "Dung adds plant nutrients, improves the soil structure and helps the soil hold water, and it saves money on fertilizer. It should be heaped and left to rot (composted) for some weeks, then spread on the bed and worked lightly into the soil; fresh dung can scorch young plants.", "6.5", "Apply"),
 ("7 (a)", "Decide the questions; walk round the community and observe the animals; write down each animal and what it is kept for; ask the owners a few set questions; record everything in a table; bring the results together and write a short report.", "6.5", "Create"),
 ("7 (b)", "Any two of: shows which animals are really kept and what they are used for; makes class work real instead of only reading; shows which animals earn money for families; practises observing, recording and group work; the class could advise families on better animal care.", "6.5", "Evaluate"),
]
for r in sba: w(f"| {r[0]} | {r[1]} | {r[2]} | {r[3]} |")
w(); w("---"); w()

w("## MARKING SCHEME - SECTION B (60 marks)"); w()
w("*General rules: (1) Accept any other correct and relevant answer. (2) Award marks for correct points, not "
  "for repeating the question. (3) For procedures, award method marks. (4) Do not deduct marks for spelling "
  "unless the meaning is changed. (5) Where a candidate gives more answers than are asked for, mark only the "
  "first ones up to the number required.*"); w()
for qb in SECTION_B:
    n = qb["num"]
    w(f"### Question {n} ({qb['total']} marks)"); w()
    for (lab, points, note) in MARKING[n]:
        mkv = [p_[2] for p_ in qb["parts"] if p_[0] == lab]
        head = f"**{lab}**"
        if mkv: head += f" [{mkv[0]} mark{'s' if mkv[0] > 1 else ''}]"
        w(head); w()
        for pt in points: w(f"- {pt}")
        w(f"  - *Marking note: {note}*"); w()
w("---"); w()

w("## CURRICULUM ASSESSMENT BLUEPRINT"); w()
w(f"**Strand:** {STRAND} | **Sub-strand:** {SUBSTRAND} | **Class:** {CLASS}"); w()
w(f"**Content Standard:** {CS} - {CS_TEXT}"); w()
w("> Source: NaCCA Science Common Core Programme Curriculum (B7/JHS1-B9/JHS3), September 2020, "
  "Strand 2: Cycles, Sub-strand 4: Animal Production, pp. 12-15. Indicators are quoted, not "
  "invented."); w()

w("### Section A"); w()
w("| Qn | Sub-strand | Content Standard | Indicator (NaCCA) - Indicator Text | Topic / Content | Cognitive Level | Marks |")
w("| -- | ---------- | ---------------- | ---------------------------------- | --------------- | --------------- | ----- |")
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"| A{i} | {SUBSTRAND} | {CS_BY_TOPIC[tp]} | {IND[tp]} - {IND_TEXT[tp]} | {TOPIC[tp]} | {cog} | 1 |")
w()
w("### Section B"); w()
w("| Qn | Sub-strand | Content Standard | Indicator (NaCCA) - Indicator Text | Topic / Content | Cognitive Level | Marks |")
w("| -- | ---------- | ---------------- | ---------------------------------- | --------------- | --------------- | ----- |")
for qb in SECTION_B:
    for (lab, text, mkv, cog, tp, diff) in qb["parts"]:
        key = tp if tp in TOPIC else tp.split(",")[0].strip()
        w(f"| B{qb['num']}{lab.strip('()')} | {SUBSTRAND} | {CS_BY_TOPIC[key]} | {IND[key]} - {IND_TEXT[key]} | {TOPIC[key]} | {cog} | {mkv} |")
w(); w("---"); w()

def topic_totals():
    m = {k: 0 for k in TOPIC}; it = {k: 0 for k in TOPIC}
    for q in MCQ: m[q[3]] += 1; it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk; it[key] += 1
    return m, it

def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}; b = {k: 0 for k in order}
    for q in MCQ: a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: b[cog] += mk
    return order, a, b

def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ: d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: d[diff] += mk
    return d

m, it = topic_totals(); diff_ = difficulty_totals(); order, ca, cb = cognitive_by_section()

w("### Summary 1 - Coverage by Curriculum Area (Topic)"); w()
w("| Topic / Content Area | No. of Items | Marks | % of Total Marks | Core Competencies |")
w("| -------------------- | ------------ | ----- | ---------------- | ----------------- |")
for k in TOPIC: w(f"| {TOPIC[k]} | {it[k]} | {m[k]} | {(m[k]/100)*100:.1f}% | {CC[k]} |")
w(f"| **TOTAL** | **{sum(it.values())}** | **{sum(m.values())}** | **100%** | - |")
w()
w("*CC = Communication and Collaboration; CP = Critical Thinking and Problem Solving; DL = Digital Literacy; "
  "CI = Creativity and Innovation.*"); w()
w("### Summary 2 - Cognitive-Level Distribution (Bloom's Taxonomy)"); w()
w("| Cognitive Level | Section A Marks | Section B Marks | Total Marks | % of Total |")
w("| --------------- | --------------- | --------------- | ----------- | ---------- |")
for lv in order:
    tot = ca[lv] + cb[lv]
    w(f"| {lv} | {ca[lv]} | {cb[lv]} | {tot} | {(tot/100)*100:.1f}% |")
w(f"| **TOTAL** | **{sum(ca.values())}** | **{sum(cb.values())}** | **{sum(ca.values())+sum(cb.values())}** | **100%** |")
w()
w("### Summary 3 - Difficulty Distribution"); w()
w("| Difficulty | Marks | % of Total Marks |")
w("| ---------- | ----- | ---------------- |")
for k, v in diff_.items(): w(f"| {k} | {v} | {(v/100)*100:.1f}% |")
w(f"| **TOTAL** | **{sum(diff_.values())}** | **100%** |")
w()
w("*Target in the master prompt: approximately 30% easy / 50% moderate / 20% challenging.*"); w()
w("### Summary 4 - Section Weighting"); w()
w("| Section | Question Type | Items | Marks | % of Total |")
w("| ------- | ------------- | ----- | ----- | ---------- |")
w("| A | Objective (multiple choice) | 40 | 40 | 40% |")
w("| B | Theory / constructed response | 20 | 60 | 60% |")
w("| **TOTAL** | - | **60** | **100** | **100%** |")
w(); w("---"); w()

w("## QUALITY-CONTROL SUMMARY")
w("")
w("| Check | Status |")
w("| --- | --- |")
for q_, a_ in [
 ("Every question within supplied curriculum scope",
  "Yes - topics 6.1-6.5 of Strand 2, Sub-Strand 4 (Animal Production), mapped to indicators B7/JHS1.2.4.1.1, B7/JHS1.2.4.1.2, B7/JHS1.2.4.2.1 and B7/JHS1.2.4.2.2"),
 ("Appropriate for the class",
  "Yes - B7 level; no stomach anatomy beyond 'four chambers' versus 'simple', no nutrient chemistry and no farm economics, all of which sit outside the B7 indicators"),
 ("Genuinely BECE-style",
  "Yes - 40 four-option objectives plus structured theory with printed mark allocations and a table for pupils to complete"),
 ("Sufficient application and reasoning",
  "Yes - 29 of 100 marks (29%) at Apply level or above (Apply 13, Analyse 7, Evaluate 3, Create 6)"),
 ("Plausible MCQ distractors",
  "Yes - drawn from the same content family as the key: the other animal group, a feature of a different group, real but wrong breeds, and plausible but wrong uses"),
 ("Single best answer per MCQ",
  "Yes - reviewed item by item; special care with A29, where the stem asks specifically for a direct product and not a by-product"),
 ("Marks internally consistent",
  "Yes - Section A 40 x 1 = 40; Section B 9 + 9 + 10 + 8 + 8 + 11 + 5 = 60; sub-question marks match the marking scheme"),
 ("Total adds up correctly",
  "Yes - 40 + 60 = 100"),
 ("Answer key correct",
  "Yes - all 40 keys and all 20 Section B answers verified against the marking scheme"),
 ("Marking scheme matches questions",
  "Yes - expected answers plus marking notes covering partial credit, alternatives, common wrong answers and method marks; the two design tasks have opening marking grids"),
 ("Free from unnecessary ambiguity",
  "Yes - open items are anchored with 'state three', 'name four' and the mark allocation; Question 3(a) numbers every blank (i) to (vi), and Question 6(b) requires both the by-product and its importance"),
 ("Ghanaian contexts natural and accurate",
  "Yes - cattle, goats, sheep, pigs, fowl, ducks and guinea fowl; the breeds N'Dama, Sanga and Zebu, West African Dwarf and Sahelian goats and Djallonke sheep; chevon, mutton and beef at the market; kraals and coops, the harmattan, school fees, tanners and hides, and a community study of compounds and the market"),
 ("No content beyond the curriculum",
  "No - Question 3 uses exemplars 3 and 4 of B7/JHS1.2.4.1.2; Question 5(c) is the poster of exemplar 2 of B7/JHS1.2.4.2.1; Question 7 is the community study of exemplar 1 of B7/JHS1.2.4.2.2; Question 6 is the by-product matching of exemplar 2"),
 ("Questions sufficiently varied",
  "Yes - definition, listing and breed matching, classification, completing a comparison table, stating differences and similarities, explaining a mechanism, distinguishing domestic from commercial use, designing a poster, and designing a community study"),
]:
    w("| " + q_ + " | " + a_ + " |")
w("")
w("### EXAMINER NOTES")
w("")
for n_ in [
 "This sub-strand has TWO content standards, so the blueprint carries both: B7/JHS1.2.4.1 for topics 6.1-6.3 (differences among domestic animals) and B7/JHS1.2.4.2 for topics 6.4-6.5 (usefulness for domestic and commercial purposes). Each blueprint row shows the standard that applies to it.",
 "Follow the curriculum's wording on the three groups: a ruminant has a FOUR-CHAMBERED stomach and chews the cud; a monogastric animal has a SIMPLE, single-chambered stomach; and poultry are birds described as monogastric herbivores, because they have a simple stomach and feed mainly on plant material such as grain (A14).",
 "Question 3(a) turns 'discuss and write the differences' into a completion table with six numbered blanks, (i) to (vi), so marking is quick and fair: 1 mark each, and the blank number must be matched to the answer.",
 "Question 5(c) is the poster exemplar (B7/JHS1.2.4.2.1, Ex. 2) and Question 7 is the community-study exemplar (B7/JHS1.2.4.2.2, Ex. 1). Both are design tasks, so award method marks: any sensible feature or step earns credit. If your class actually makes the poster or does the study, accept what they did as evidence.",
 "Topic 6.1 asks pupils to match animals with their breeds. Keep breeds gentle: N'Dama, Sanga and Zebu for cattle, West African Dwarf and Sahelian for goats, Djallonke for sheep. Accept local names.",
 "Topics 6.4 and 6.5 carry 24 marks each, the highest weightings, because the second content standard is entirely about uses and by-products. If you want a flatter spread, move marks from Questions 4, 5 and 6 to Questions 1 and 2.",
 "A20 and A23 ask why a ruminant can use grass. The expected level is 'micro-organisms in the ruminant stomach break down the fibre' - do not expect any detail about rumen anatomy or about microbial protein.",
 "Edit the school name, academic year and examination title on page 1 before printing.",
 "This is an original, teacher-made mock. It is not a reproduction of any WAEC or NaCCA examination paper.",
]:
    w("- " + n_)
w()

open("/home/user/Basic7_Integrated_Science_Mock_Strand2_AnimalProduction.md", "w", encoding="utf-8").write("\n".join(L))
print("md written", len("\n".join(L)), "chars")
