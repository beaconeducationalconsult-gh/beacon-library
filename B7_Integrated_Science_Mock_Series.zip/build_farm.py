# -*- coding: utf-8 -*-
"""Basic 7 Integrated Science mock - Strand 3 Sub-strand 4: FARMING SYSTEMS. 100 marks.
Indicators sourced from the official NaCCA Science CCP curriculum (B7/JHS1-B9/JHS3, Sept 2020),
Strand 3: Systems, Sub-strand 4: Farming Systems, printed pages 23-24."""

SCHOOL = "[SCHOOL NAME]"
SUBJECT = "INTEGRATED SCIENCE (SCIENCE)"
EXAM = "END-OF-TERM MOCK EXAMINATION"
CLASS = "Basic 7 (JHS 1)"
TIME = "2 hours (Suggested: Section A - 40 min; Section B - 80 min)"
MARKS = "100"
YEAR = "2025/2026 Academic Year"

STRAND = "Systems"
SUBSTRAND = "Farming Systems"

TOPIC = {
    "10.1": "10.1 Types of Farming Systems in Ghana",
    "10.2": "10.2 Land Rotation Farming",
    "10.3": "10.3 Crop Rotation Farming",
    "10.4": "10.4 Mixed Cropping",
    "10.5": "10.5 Mixed Farming",
    "10.6": "10.6 Organic Farming",
    "10.7": "10.7 Merits and Demerits of Each Farming System",
}

CS = "B7/JHS1.3.4.1"
CS_BY_TOPIC = {k: "B7/JHS1.3.4.1" for k in
               ["10.1", "10.2", "10.3", "10.4", "10.5", "10.6", "10.7"]}
CS_TEXT = "Demonstrate an understanding of the differences among the various farming systems: Land " \
          "Rotation, Crop Rotation, Mixed Cropping, Mixed Farming, and Organic Farming"

IND = {
    "10.1": "B7/JHS1.3.4.1.1 (Ex. 1)",
    "10.2": "B7/JHS1.3.4.1.2 (Ex. 1, 2)",
    "10.3": "B7/JHS1.3.4.1.2 (Ex. 1, 2)",
    "10.4": "B7/JHS1.3.4.1.2 (Ex. 1, 2)",
    "10.5": "B7/JHS1.3.4.1.2 (Ex. 1, 2)",
    "10.6": "B7/JHS1.3.4.1.2 (Ex. 1, 2)",
    "10.7": "B7/JHS1.3.4.1.1 (Ex. 2, 3)",
}
IND_TEXT = {
    "10.1": "Identify and define types of farming systems in Ghana and elsewhere.",
    "10.2": "Classify descriptions of farming systems under Land Rotation, Crop Rotation, Mixed "
            "Cropping, Mixed Farming and Organic Farming; group the farming systems prevailing in "
            "their community.",
    "10.3": "Classify descriptions of farming systems under Land Rotation, Crop Rotation, Mixed "
            "Cropping, Mixed Farming and Organic Farming; group the farming systems prevailing in "
            "their community.",
    "10.4": "Classify descriptions of farming systems under Land Rotation, Crop Rotation, Mixed "
            "Cropping, Mixed Farming and Organic Farming; group the farming systems prevailing in "
            "their community.",
    "10.5": "Classify descriptions of farming systems under Land Rotation, Crop Rotation, Mixed "
            "Cropping, Mixed Farming and Organic Farming; group the farming systems prevailing in "
            "their community.",
    "10.6": "Classify descriptions of farming systems under Land Rotation, Crop Rotation, Mixed "
            "Cropping, Mixed Farming and Organic Farming; group the farming systems prevailing in "
            "their community.",
    "10.7": "Discuss the characteristics of the different farming systems in Ghana; compare and "
            "contrast the characteristics of the different farming systems.",
}
CC = {
    "10.1": "DL, CP, CC, CI, CG", "10.2": "DL, CP, CG", "10.3": "DL, CP, CG",
    "10.4": "DL, CP, CG", "10.5": "DL, CP, CG", "10.6": "DL, CP, CG",
    "10.7": "DL, CP, CC, CI, CG",
}

# ---------------------------------------------------------------- SECTION A
# (question, [A,B,C,D], answer, topic, cognitive, difficulty)
MCQ = [
 ("A farming system is",
  ["a machine used on the farm", "the type of soil found on a farm",
   "the particular way in which a farmer organises the land, the crops and the animals",
   "the money a farmer earns each year"],
  "C", "10.1", "Understand", "Easy"),
 ("Which of these is NOT one of the five farming systems named in the Basic 7 curriculum?",
  ["irrigation farming", "land rotation", "crop rotation", "organic farming"],
  "A", "10.1", "Remember", "Easy"),
 ("How many farming systems are named in the Basic 7 curriculum?",
  ["three", "four", "six", "five"], "D", "10.1", "Remember", "Easy"),
 ("The farming system a farmer chooses depends mainly on",
  ["the colour of his house", "the land available, the crops he wants and what he can afford",
   "the day of the week", "the size of his family only"],
  "B", "10.1", "Understand", "Easy"),
 ("A farmer who grows crops and keeps animals on the same farm is practising",
  ["mixed cropping", "crop rotation", "mixed farming", "organic farming"],
  "C", "10.1", "Remember", "Easy"),
 ("Which of these is a farming system in which no artificial fertilizer is used?",
  ["organic farming", "mixed farming", "crop rotation", "land rotation"],
  "A", "10.1", "Remember", "Easy"),
 ("Land rotation is the system in which the farmer",
  ["plants two crops on the same plot at the same time",
   "grows different crops in order on the same land", "keeps animals and crops together",
   "farms a piece of land for a few years, then leaves it to rest and moves to another piece"],
  "D", "10.2", "Understand", "Moderate"),
 ("The period during which farmland is left to rest and regain its fertility is called the",
  ["harvest", "fallow period", "planting season", "rotation"],
  "B", "10.2", "Remember", "Easy"),
 ("The main reason why a farmer practises land rotation is to",
  ["grow more trees", "avoid paying tax",
   "let the soil regain its fertility while the land rests", "keep the animals away"],
  "C", "10.2", "Understand", "Moderate"),
 ("The greatest disadvantage of land rotation is that it",
  ["needs a very large area of land", "needs expensive fertilizer", "cannot grow maize",
   "needs machines"],
  "A", "10.2", "Remember", "Easy"),
 ("Land rotation is most common in places where",
  ["land is very scarce and very expensive", "there are no roads at all",
   "the rainfall is very heavy all year", "there is plenty of land and few people"],
  "D", "10.2", "Understand", "Moderate"),
 ("Which of these is a problem caused by land rotation?",
  ["the soil becomes too fertile", "trees and forest are destroyed when new land is cleared",
   "the farmer earns too much money", "the crops grow far too quickly"],
  "B", "10.2", "Analyse", "Easy"),
 ("Crop rotation is the system in which the farmer",
  ["plants two crops together on the same plot", "leaves the land to rest for many years",
   "grows different crops one after another in a planned order on the same land",
   "keeps animals and crops together"],
  "C", "10.3", "Understand", "Moderate"),
 ("Which of these is an example of crop rotation?",
  ["maize this season, groundnuts next season, cassava the season after",
   "maize, cassava and cocoyam planted together on one plot",
   "maize and a few goats on the same farm", "maize grown with compost only"],
  "A", "10.3", "Apply", "Moderate"),
 ("Crop rotation helps to keep the soil fertile mainly because",
  ["the farmer adds more fertilizer each season", "the land rests every other year",
   "the rain washes the soil",
   "different crops take different nutrients from the soil, and some put nutrients back"],
  "D", "10.3", "Understand", "Moderate"),
 ("Growing a legume such as groundnuts or beans in a rotation is useful because legumes",
  ["need no water at all", "add nitrogen to the soil", "keep all the weeds away",
   "grow faster than any other crop"],
  "B", "10.3", "Understand", "Moderate"),
 ("Another advantage of crop rotation is that it",
  ["makes the rain fall", "needs no labour at all",
   "breaks the life cycle of the pests and diseases that live on one crop",
   "makes the crops grow in a week"],
  "C", "10.3", "Understand", "Moderate"),
 ("A disadvantage of crop rotation is that it",
  ["needs careful planning and knowledge of which crop should follow which",
   "needs a very large area of land", "cannot be done in Ghana", "needs no planning at all"],
  "A", "10.3", "Understand", "Moderate"),
 ("Mixed cropping is the system in which the farmer",
  ["grows one crop only", "leaves the land to rest", "keeps animals with the crops",
   "grows two or more different crops together on the same piece of land at the same time"],
  "D", "10.4", "Understand", "Moderate"),
 ("Which of these is an example of mixed cropping?",
  ["maize this year and beans next year",
   "maize, cassava and cocoyam planted together on one plot",
   "maize and a few goats on the same farm", "maize grown with compost"],
  "B", "10.4", "Apply", "Moderate"),
 ("One advantage of mixed cropping is that",
  ["the farmer can easily use a tractor", "each crop gives a much bigger yield",
   "if one crop fails, the others may still do well", "the land rests every year"],
  "C", "10.4", "Understand", "Moderate"),
 ("In mixed cropping, crops with different root depths are often grown together because they",
  ["take water and nutrients from different layers of the soil", "look nicer in the field",
   "need no rain at all", "all ripen on the same day"],
  "A", "10.4", "Understand", "Easy"),
 ("A disadvantage of mixed cropping is that it",
  ["leaves the land empty", "gives the farmer only one kind of food",
   "cannot be done on a small plot", "is difficult to weed, to spray and to harvest with machines"],
  "D", "10.4", "Understand", "Moderate"),
 ("In mixed cropping, the crops",
  ["help each other and never compete", "compete with one another for light, water and nutrients",
   "need no water at all", "are always the same crop"],
  "B", "10.4", "Remember", "Easy"),
 ("Mixed farming is the system in which the farmer",
  ["grows only one crop", "rotates his crops", "keeps animals and grows crops on the same farm",
   "uses no fertilizer at all"],
  "C", "10.5", "Understand", "Challenging"),
 ("On a mixed farm, the animals help the crops mainly by",
  ["giving droppings that are used as manure", "eating all the weeds",
   "scaring the birds away", "ploughing the land every day"],
  "A", "10.5", "Understand", "Easy"),
 ("On a mixed farm, the crops help the animals mainly by",
  ["giving them shade only", "keeping them cool", "making the soil hard",
   "providing crop waste and leftover parts that can be used as feed"],
  "D", "10.5", "Understand", "Moderate"),
 ("Which of these is an advantage of mixed farming?",
  ["the farmer needs no land at all",
   "the farmer has two sources of food and income, so if one fails the other may not",
   "the animals need no care at all", "the crops need no rain"],
  "B", "10.5", "Understand", "Moderate"),
 ("A disadvantage of mixed farming is that",
  ["the animals are never any trouble", "it needs no extra work",
   "the animals may damage the crops if they are not fenced or tethered",
   "the crops cannot be sold"],
  "C", "10.5", "Remember", "Easy"),
 ("Organic farming is the system in which the farmer",
  ["grows crops without artificial fertilizers, weedicides or pesticides",
   "uses only artificial fertilizers", "rotates his animals from farm to farm",
   "grows crops in water only"],
  "A", "10.6", "Understand", "Moderate"),
 ("Which of these is used in organic farming instead of artificial fertilizer?",
  ["urea", "NPK 15-15-15", "sulphate of ammonia", "compost or animal manure"],
  "D", "10.6", "Remember", "Easy"),
 ("Which of these is NOT part of organic farming?",
  ["mulching", "spraying a strong chemical weedicide", "using neem extract", "crop rotation"],
  "B", "10.6", "Understand", "Easy"),
 ("An advantage of organic farming is that",
  ["it gives the biggest yield at once", "it needs no work at all",
   "the food has no chemical residues and the soil is improved", "it needs no land"],
  "C", "10.6", "Understand", "Easy"),
 ("A disadvantage of organic farming is that",
  ["the yield may be lower at first, and it needs a lot of bulky material and labour",
   "the food is poisonous", "it destroys the soil", "it cannot be done in Africa"],
  "A", "10.6", "Remember", "Easy"),
 ("A farmer wants to control pests on an organic farm. The best method is to",
  ["use the strongest insecticide he can buy", "burn the whole farm", "do nothing at all",
   "use neem extract, crop rotation and hand-picking of the pests"],
  "D", "10.6", "Apply", "Challenging"),
 ("Which farming system needs the largest area of land?",
  ["crop rotation", "land rotation", "mixed cropping", "organic farming"],
  "B", "10.7", "Remember", "Easy"),
 ("Which farming system is the best one for keeping the same piece of land producing year after "
  "year?",
  ["land rotation", "mixed cropping only", "crop rotation", "none of them"],
  "C", "10.7", "Apply", "Moderate"),
 ("A farmer wants food for his family from one small plot and does not want to buy fertilizer. The "
  "most suitable system is",
  ["mixed cropping with organic manure", "land rotation", "keeping only animals",
   "growing one crop with NPK"],
  "A", "10.7", "Apply", "Challenging"),
 ("Which statement comparing the farming systems is correct?",
  ["mixed cropping and crop rotation are the same thing",
   "organic farming means leaving the land empty",
   "mixed farming means growing many crops together",
   "crop rotation changes the crop over time on the same land, while mixed cropping grows several "
   "crops at the same time"],
  "D", "10.7", "Analyse", "Challenging"),
 ("The main reason why a farmer should know the merits and demerits of each farming system is to",
  ["pass an examination only",
   "choose the system that suits his land, his crops and what he can afford",
   "copy exactly what his neighbour does", "use the most expensive method"],
  "B", "10.7", "Evaluate", "Moderate"),
]

# ---------------------------------------------------- SECTION B TABLE (Q7)
SYS_HEADERS = ["Farming system", "What the farmer does", "One demerit"]
SYS_ROWS = [
 ["Land rotation", "(i)", "(ii)"],
 ["Crop rotation", "grows different crops one after another in a planned order on the same land",
  "(iii)"],
 ["Mixed cropping", "(iv)",
  "the crops compete with one another for light, water and nutrients"],
 ["Mixed farming", "(v)", "(vi)"],
 ["Organic farming", "farms without artificial fertilizers, weedicides or pesticides",
  "the yield may be lower at first"],
]

# ---------------------------------------------------------------- SECTION B
SECTION_B = [
 dict(
   num=1, total=8, topic="10.1",
   stem="Ghanaian farmers organise their land, their crops and their animals in different ways.",
   parts=[
     ("(a)", "What is meant by a farming system?", 2, "Understand", "10.1", "Easy"),
     ("(b)", "Name three of the farming systems named in the Basic 7 curriculum.",
      3, "Remember", "10.1", "Easy"),
     ("(c)", "Explain why the farming system a farmer chooses depends on the land available, the "
             "crops wanted and what the farmer can afford.", 3, "Analyse", "10.1", "Moderate"),
   ]),
 dict(
   num=2, total=9, topic="10.2",
   stem="In some parts of Ghana a farmer clears a piece of land, farms it for a few seasons and then "
        "moves on.",
   parts=[
     ("(a)", "Explain what is meant by land rotation farming.", 3, "Understand", "10.2", "Moderate"),
     ("(b)", "State three reasons why a farmer practises land rotation.",
      3, "Understand", "10.2", "Easy"),
     ("(c)", "State three problems caused by land rotation.", 3, "Apply", "10.2", "Challenging"),
   ]),
 dict(
   num=3, total=9, topic="10.3",
   stem="A farmer in the Ashanti Region grows maize every season on the same plot and finds that the "
        "harvest gets smaller each year.",
   parts=[
     ("(a)", "Explain what is meant by crop rotation.", 3, "Understand", "10.3", "Moderate"),
     ("(b)", "Plan a three-season crop rotation for this farmer, and explain why you have put the "
             "crops in that order.", 3, "Create", "10.3", "Challenging"),
     ("(c)", "State three advantages this farmer would gain by rotating his crops instead of growing "
             "maize every season.", 3, "Understand", "10.3", "Moderate"),
   ]),
 dict(
   num=4, total=8, topic="10.4",
   stem="A farmer plants maize, cassava and cocoyam together on one plot.",
   parts=[
     ("(a)", "Explain what is meant by mixed cropping.", 2, "Understand", "10.4", "Moderate"),
     ("(b)", "Explain three ways in which planting these crops together helps the farmer.",
      3, "Apply", "10.4", "Moderate"),
     ("(c)", "State three problems the farmer may meet when using mixed cropping.",
      3, "Understand", "10.4", "Moderate"),
   ]),
 dict(
   num=5, total=8, topic="10.5",
   stem="A farmer grows maize and cassava and also keeps a few goats and some fowls.",
   parts=[
     ("(a)", "Explain what is meant by mixed farming.", 3, "Understand", "10.5", "Moderate"),
     ("(b)", "State two ways in which the crops and the animals help each other on this farm.",
      2, "Understand", "10.5", "Easy"),
     ("(c)", "What name is given to this farming system, and what three problems might the farmer "
             "meet by keeping crops and animals together?", 3, "Analyse", "10.5", "Challenging"),
   ]),
 dict(
   num=6, total=8, topic="10.6",
   stem="A group of farmers near Kumasi have decided to farm without artificial fertilizers, "
        "weedicides or pesticides.",
   parts=[
     ("(a)", "Explain what is meant by organic farming.", 3, "Understand", "10.6", "Moderate"),
     ("(b)", "Name two materials these farmers would use instead of artificial fertilizer.",
      2, "Remember", "10.6", "Easy"),
     ("(c)", "Explain why some farmers do not practise organic farming even though it costs less.",
      3, "Analyse", "10.6", "Challenging"),
   ]),
 dict(
   num=7, total=10, topic="10.7",
   stem="The class was asked to compare and contrast the characteristics of the different farming "
        "systems. Study the incomplete table below and answer the questions that follow.",
   table="systems",
   parts=[
     ("(a)", "Copy and complete the table.", 6, "Understand", "10.7", "Moderate"),
     ("(b)", "State four differences between crop rotation and mixed cropping.",
      4, "Analyse", "10.7", "Challenging"),
   ]),
]

# ------------------------------------------------------- MARKING SCHEME
MARKING = {
 1: [
   ("(a)", ["A farming system is the particular way in which a farmer organises the land, the crops "
            "and the animals.",
            "It is the method or plan a farmer follows in using the land to produce crops and "
            "animals.",
            "It is the pattern of farming a farmer chooses, e.g. land rotation or mixed farming."],
    "1 mark each for any TWO correct points (2 marks). Award 1 mark for 'the way a farmer farms' if "
    "it is not developed further. Do NOT accept 'a type of crop'."),
   ("(b)", ["Land rotation", "Crop rotation", "Mixed cropping", "Mixed farming", "Organic farming"],
    "1 mark each for any THREE correct farming systems (3 marks). Accept any three of the five. Do "
    "NOT accept 'irrigation farming', 'mechanised farming' or 'subsistence farming' - those are not "
    "the five named in the curriculum."),
   ("(c)", ["Land rotation needs a lot of land, so it only suits a place where land is plentiful; "
            "crop rotation and mixed cropping suit a small plot.",
            "The crops a farmer wants decide the system: some crops do well in a rotation, others "
            "are better mixed.",
            "Mixed farming needs money to buy and feed the animals, so a poor farmer may not afford "
            "it.",
            "Organic farming needs labour and bulky manure rather than money, so it suits a farmer "
            "with little cash.",
            "A farmer with a small plot and no money would choose mixed cropping with organic "
            "manure, not land rotation."],
    "1 mark each for any THREE correct points (3 marks). The answer must mention the land, the crops "
    "AND what the farmer can afford to earn full marks; award at most 2 marks if only one or two of "
    "these are dealt with."),
 ],
 2: [
   ("(a)", ["Land rotation is the system in which the farmer farms a piece of land for a few seasons "
            "and then leaves it to rest and moves to another piece.",
            "The abandoned land is left fallow for several years so that it can regain its "
            "fertility.",
            "It is also called shifting cultivation."],
    "1 mark each for any THREE correct points (3 marks). The key ideas are: farm, abandon, move on, "
    "and let the land rest."),
   ("(b)", ["It lets the soil regain its fertility while the land rests.",
            "It needs no artificial fertilizer, so it costs very little money.",
            "It is simple: the farmer needs no special knowledge or expensive tools.",
            "It suits a place where there is plenty of land and few people.",
            "It lets the bush grow back, which helps to restore the land."],
    "1 mark each for any THREE correct reasons (3 marks). Accept 'the land rests and becomes fertile "
    "again' as one reason."),
   ("(c)", ["It needs a very large area of land.",
            "Trees and forest are destroyed each time a new piece of land is cleared.",
            "The abandoned land can be eroded by wind and rain because nothing holds the soil.",
            "The farmer has to keep moving, so he cannot build a permanent home or store.",
            "It cannot feed many people on a small area of land.",
            "Burning the cleared vegetation pollutes the air and destroys the humus in the soil."],
    "1 mark each for any THREE correct problems (3 marks). The two things to look for first are the "
    "large area of land needed and the destruction of trees."),
 ],
 3: [
   ("(a)", ["Crop rotation is growing different crops one after another in a planned order on the "
            "same piece of land.",
            "The crop is changed from season to season or from year to year according to a plan.",
            "The same land is used every season, but not for the same crop."],
    "1 mark each for any THREE correct points (3 marks). The key ideas are: different crops, in "
    "order, on the SAME land."),
   ("(b)", ["A sensible three-season rotation, e.g. maize, then a legume such as groundnuts or "
            "beans, then cassava or a vegetable.",
            "The legume goes in the middle because it puts nitrogen back into the soil, which the "
            "maize took out.",
            "A crop with a different root depth follows, so the nutrients are taken from a "
            "different layer of soil.",
            "Changing the crop breaks the life cycle of the pests and diseases that live on maize.",
            "Accept any sensible order, provided the pupil says WHY the crops are in that order."],
    "1 mark for a sensible three-crop rotation and 1 mark each for any TWO correct reasons for the "
    "order (3 marks). This is a design task: award method marks for any sensible plan that is "
    "explained. The rotation must change the crop each season."),
   ("(c)", ["The soil stays fertile, because different crops take different nutrients and some put "
            "nutrients back.",
            "Pests and diseases that live on one crop die out when that crop is not grown.",
            "The soil structure improves, because different crops have different roots.",
            "The farmer gets a variety of food and produce instead of only maize.",
            "The same piece of land can be used every year, instead of being abandoned."],
    "1 mark each for any THREE correct advantages (3 marks). Accept 'the soil does not get tired'."),
 ],
 4: [
   ("(a)", ["Mixed cropping is growing two or more different crops together on the same piece of "
            "land at the same time.",
            "The crops are planted together and grow together on one plot."],
    "1 mark each for any TWO correct points (2 marks). The key ideas are: two or more crops, "
    "together, at the SAME time. Do NOT accept crop rotation here."),
   ("(b)", ["The maize uses the top layer of soil while the cassava and cocoyam feed deeper, so the "
            "whole plot is used.",
            "If one crop fails, the others may still do well, so the farmer is sure of some food.",
            "The family gets a variety of food - maize, cassava and cocoyam - from one small plot.",
            "The leaves cover the soil, which keeps the moisture in, keeps the weeds down and stops "
            "the soil being washed away.",
            "The tall maize and the low cocoyam use the sunlight at different heights."],
    "1 mark each for any THREE correct points (3 marks). Accept any sensible benefit of growing "
    "these three crops together."),
   ("(c)", ["The crops compete with one another for light, water and soil nutrients.",
            "It is difficult to weed, to spray and to harvest, and harder to use machines.",
            "The yield of each crop is often lower than if it were grown alone.",
            "It is difficult to apply fertilizer to one crop without it reaching the others.",
            "Some crops may shade the others too much if the spacing is wrong.",
            "It is harder to tell how well each crop is doing."],
    "1 mark each for any THREE correct problems (3 marks). The two things to look for first are "
    "competition between the crops and the difficulty of working the plot."),
 ],
 5: [
   ("(a)", ["Mixed farming is the system in which the farmer keeps animals and grows crops on the "
            "same farm.",
            "The crops and the animals are reared together on one piece of land.",
            "For example, growing maize and cassava while keeping goats, sheep, cattle or poultry."],
    "1 mark each for any THREE correct points (3 marks). The key idea is CROPS AND ANIMALS "
    "TOGETHER. Do NOT accept mixed cropping here."),
   ("(b)", ["The animals give droppings which are used as manure on the crops.",
            "The crops give waste and leftover parts - stalks, leaves, peelings and bran - which are "
            "used to feed the animals.",
            "Animals such as cattle can also be used to plough the land before planting.",
            "The animals graze the crop waste after harvest and clear the land for the next "
            "planting."],
    "1 mark each for any TWO correct points (2 marks). One point should show the animals helping the "
    "crops and one the crops helping the animals."),
   ("(c)", ["The system is MIXED FARMING.",
            "The animals may damage or eat the crops if they are not fenced, tethered or housed.",
            "It needs more land, more labour, more capital and more knowledge than growing crops "
            "alone.",
            "The animals need water and care every day of the year, even in the dry season.",
            "Disease can kill the animals and so destroy that part of the farm's income.",
            "The farmer must find feed and housing for the animals as well as tending the crops."],
    "1 mark for naming mixed farming and 1 mark each for any TWO correct problems (3 marks). The "
    "name must be given for the first mark."),
 ],
 6: [
   ("(a)", ["Organic farming is farming without artificial (synthetic) fertilizers, weedicides or "
            "pesticides.",
            "It uses only natural materials such as compost, animal manure, green manure and crop "
            "residue.",
            "Pests and weeds are controlled by natural methods such as neem extract, hand-picking, "
            "mulching and crop rotation."],
    "1 mark each for any THREE correct points (3 marks). The key idea is 'no artificial chemicals'. "
    "Award at least 1 mark for 'farming without chemicals'."),
   ("(b)", ["Compost", "Animal manure (poultry manure, cow dung, goat droppings)", "Green manure",
            "Crop residue", "Wood ash", "Neem extract", "Decayed leaves"],
    "1 mark each for any TWO correct materials (2 marks). Do NOT accept urea, NPK or any "
    "manufactured fertilizer."),
   ("(c)", ["The yield may be lower, at least in the first few seasons, so the farmer earns less.",
            "It needs a lot of bulky material - compost and manure are heavy and difficult to carry "
            "and spread.",
            "It needs more labour: weeding by hand and hand-picking pests takes time.",
            "The results take longer to show than with artificial fertilizer.",
            "Pests and diseases are harder to control without chemicals.",
            "It is harder to farm a large area this way."],
    "1 mark each for any THREE correct points (3 marks). Accept 'it is harder work' and 'the yield "
    "is lower'."),
 ],
 7: [
   ("(a)", ["(i) farms a piece of land for a few seasons, then leaves it to rest and moves to "
            "another piece",
            "(ii) it needs a very large area of land (and trees are destroyed when new land is "
            "cleared)",
            "(iii) it needs careful planning and knowledge of which crop should follow which",
            "(iv) grows two or more different crops together on the same piece of land at the same "
            "time",
            "(v) keeps animals and grows crops on the same farm",
            "(vi) the animals may damage the crops if they are not fenced or tethered (it also needs "
            "more land, labour and capital)"],
    "1 mark each for all SIX blanks correctly filled (6 marks). The blank number must be matched to "
    "the correct answer. Accept any clear equivalent wording."),
   ("(b)", ["Crop rotation changes the crop over time - one crop after another - while mixed "
            "cropping grows several crops together at the same time.",
            "In crop rotation only one crop occupies the land at a time; in mixed cropping two or "
            "more crops share the plot.",
            "Crop rotation is a plan across seasons or years; mixed cropping is a plan for one "
            "season.",
            "Crop rotation keeps the soil fertile mainly by varying the nutrients taken; mixed "
            "cropping uses different root depths and different layers of the soil.",
            "Crop rotation is easier to weed, spray and harvest; mixed cropping is harder to work, "
            "especially with machines.",
            "Crop rotation guards against pests by changing the host plant; mixed cropping guards "
            "against the failure of one crop.",
            "In crop rotation the yield of the single crop is usually higher; in mixed cropping each "
            "crop may yield less."],
    "1 mark each for any FOUR correct differences (4 marks). Each point must contrast the two "
    "systems, not just describe one of them. The single most important difference is time: one after "
    "another versus at the same time."),
 ],
}


# --------------------------------------------- derive summary statistics
def topic_totals():
    m = {k: 0 for k in TOPIC}
    it = {k: 0 for k in TOPIC}
    for q in MCQ:
        m[q[3]] += 1
        it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk
            it[key] += 1
    return m, it


def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}
    b = {k: 0 for k in order}
    for q in MCQ:
        a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            b[cog] += mk
    return order, a, b


def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ:
        d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            d[diff] += mk
    return d
