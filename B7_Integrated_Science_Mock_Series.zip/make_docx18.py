# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "/home/user")
from build_health import *

from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT

doc = Document()
sec = doc.sections[0]
sec.left_margin = Inches(0.7); sec.right_margin = Inches(0.7)
sec.top_margin = Inches(0.7); sec.bottom_margin = Inches(0.6)

st = doc.styles["Normal"]; st.font.name = "Calibri"; st.font.size = Pt(11)


def set_font(run, size=11, bold=False, italic=False, mono=False, color=None):
    run.font.size = Pt(size); run.bold = bold; run.italic = italic
    run.font.name = "Consolas" if mono else "Calibri"
    if color: run.font.color.rgb = color
    return run


def para(text="", size=11, bold=False, italic=False, align=None, mono=False,
         space_before=0, space_after=4, color=None):
    p = doc.add_paragraph()
    if align == "c": p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    elif align == "j": p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p.paragraph_format.space_before = Pt(space_before)
    p.paragraph_format.space_after = Pt(space_after)
    if text: set_font(p.add_run(text), size, bold, italic, mono, color)
    return p


def rule():
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(6); p.paragraph_format.space_before = Pt(2)
    set_font(p.add_run("_" * 78), 9, color=RGBColor(0x99, 0x99, 0x99))


def add_table(headers, rows, widths=None, size=9, head_size=9):
    t = doc.add_table(rows=1, cols=len(headers)); t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, h in enumerate(headers):
        c = t.rows[0].cells[i]; c.text = ""
        p = c.paragraphs[0]; p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_font(p.add_run(str(h)), head_size, bold=True)
    for row in rows:
        cells = t.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = ""
            p = cells[i].paragraphs[0]; p.paragraph_format.space_after = Pt(1)
            set_font(p.add_run(str(v)), size)
    if widths:
        for r_ in t.rows:
            for i, w in enumerate(widths): r_.cells[i].width = Inches(w)
    return t


def draw_diagram(lines, caption):
    t = doc.add_table(rows=2, cols=1); t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = t.rows[0].cells[0]
    for k, line in enumerate(lines):
        p = cell.paragraphs[0] if k == 0 else cell.add_paragraph()
        p.paragraph_format.space_after = Pt(0); p.paragraph_format.space_before = Pt(0)
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_font(p.add_run(line), 10, mono=True)
    c2 = t.rows[1].cells[0].paragraphs[0]
    c2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_font(c2.add_run(caption), 9, italic=True)
    t.rows[0].cells[0].width = Inches(6.6)
    t.rows[1].cells[0].width = Inches(6.6)


# ============================================================= TITLE BLOCK
para(SCHOOL, size=15, bold=True, align="c", space_after=2)
para(SUBJECT, size=13, bold=True, align="c", space_after=2)
para(EXAM, size=12, bold=True, align="c", space_after=2)
para(YEAR, size=10, italic=True, align="c", space_after=8)

info = doc.add_table(rows=1, cols=3); info.style = "Table Grid"
info.alignment = WD_TABLE_ALIGNMENT.CENTER
for i, v in enumerate([f"Class: {CLASS}", f"Time: {TIME}", f"Total Marks: {MARKS}"]):
    c = info.rows[0].cells[i]; c.text = ""
    set_font(c.paragraphs[0].add_run(v), 10, bold=True)
para("", space_after=6)

para("INSTRUCTIONS", size=11, bold=True, space_after=3)
for txt in [
    "1. Write your name and class clearly in the spaces provided on your answer sheet.",
    "2. This paper has TWO sections: Section A and Section B.",
    "3. Answer ALL the questions in both sections.",
    "4. Section A has 40 multiple-choice questions. Each question carries 1 mark. Choose the best answer "
    "(A, B, C or D) and record it on the answer sheet provided.",
    "5. Section B has 7 theory questions totalling 60 marks. Write your answers clearly and neatly in your "
    "answer booklet. Draw and label diagrams or tables where you are asked to.",
    "6. Read every question carefully before you answer it.",
    "7. Do not use correction fluid. Cancel any mistake neatly with a single line.",
    "8. Hand in your answer sheet and your answer booklet at the end of the examination.",
]:
    para(txt, size=10.5, space_after=2)
rule()

# =============================================================== SECTION A
para("SECTION A - OBJECTIVE TEST (40 marks)", size=12, bold=True, align="c", space_after=2)
para("Answer ALL questions. Each question carries 1 mark. Choose the BEST answer and write its letter "
     "(A, B, C or D) against the question number on your answer sheet.",
     size=10, italic=True, align="c", space_after=8)

for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(1); p.paragraph_format.space_before = Pt(4)
    set_font(p.add_run(f"{i}. {q}"), 10.5)
    for j, o in enumerate(opts):
        p2 = doc.add_paragraph()
        p2.paragraph_format.left_indent = Inches(0.28)
        p2.paragraph_format.space_after = Pt(0); p2.paragraph_format.space_before = Pt(0)
        set_font(p2.add_run(f"{'ABCD'[j]}. {o}"), 10.5)

doc.add_page_break()

# =============================================================== SECTION B
para("SECTION B - THEORY (60 marks)", size=12, bold=True, align="c", space_after=2)
para("Answer ALL questions. Write your answers in your answer booklet. The marks for each question are "
     "shown in brackets.", size=10, italic=True, align="c", space_after=8)

for qb in SECTION_B:
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(8); p.paragraph_format.space_after = Pt(2)
    set_font(p.add_run(f"Question {qb['num']}"), 11, bold=True)
    set_font(p.add_run(f"  [{qb['total']} marks]"), 10, bold=True, italic=True)
    para(qb["stem"], size=10.5, space_after=4)
    if qb.get("table") == "nutrient":
        add_table(NUTRIENT_HEADERS, NUTRIENT_ROWS, widths=[1.4, 2.0, 2.6], size=8.5, head_size=8.5)
        para("Table 1: Food nutrients and their work in the body", size=9, italic=True, align="c",
             space_after=6)
        para("", space_after=2)
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Inches(0.25)
        p.paragraph_format.space_after = Pt(3); p.paragraph_format.space_before = Pt(2)
        set_font(p.add_run(f"{lab} {text}  "), 10.5)
        set_font(p.add_run(f"[{mk} mark{'s' if mk > 1 else ''}]"), 10, bold=True)

doc.add_page_break()

# ============================================================== ANSWER KEY
para("ANSWER KEY", size=13, bold=True, align="c", space_after=6)
para("SECTION A - OBJECTIVE TEST", size=11, bold=True, space_after=4)
rows = [[i, ans, TOPIC[tp], cog] for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1)]
add_table(["Question", "Answer", "Curriculum Area (Topic)", "Cognitive Level"],
          rows, widths=[0.8, 0.7, 3.6, 1.5], size=9)
counts = {L: sum(1 for q in MCQ if q[2] == L) for L in "ABCD"}
para("", space_after=4)
para("Correct-answer distribution: " + ", ".join(f"{L} = {counts[L]}" for L in "ABCD") + " (30 items).",
     size=9, italic=True)

para("", space_after=8)
para("SECTION B - THEORY (summary answers; see the Marking Scheme for full detail)",
     size=11, bold=True, space_after=4)
sba = [
 ("1 (a)", "Carbohydrates; proteins; fats and oils (fatty acids); vitamins; mineral salts; water; roughage or fibre.", "17.1", "Remember"),
 ("1 (b)", "Any three matched correctly: carbohydrate - provides energy for work, play and warmth; protein - builds the body and repairs worn-out tissues; fat and oil - provides energy, keeps the body warm, helps absorb some vitamins; vitamin - protects the body and keeps parts such as the eyes and gums healthy; mineral salt - builds bones and teeth and helps make blood; water - carries substances round the body; roughage - keeps food moving through the gut.", "17.1", "Understand"),
 ("1 (c)", "A growing child is making new tissue all the time, and protein is the nutrient the body uses to build and repair tissue. Without enough protein the child stops growing properly, becomes weak, and may develop kwashiorkor.", "17.1", "Understand"),
 ("2 (a)", "(i) rice, maize, yam, cassava, plantain, gari or bread. (ii) fish, meat, eggs, beans, groundnuts, soya beans or milk. (iii) growth, and the repair and replacement of worn-out body tissues. (iv) palm oil, groundnut oil, coconut, shea butter or margarine. (v) provides energy, keeps the body warm and helps the body absorb some vitamins. (vi) liver, eggs, milk, red palm oil, carrots, mango, pawpaw or dark green leafy vegetables.", "17.1", "Understand"),
 ("2 (b)", "Any two with a correct source: iron - liver, beans, dark green leafy vegetables, fish, meat, eggs; calcium - milk, fish with soft bones, groundnuts, green leafy vegetables; iodine - iodised salt, sea fish; phosphorus - milk, fish, eggs, meat, beans.", "17.1", "Apply"),
 ("3 (a)", "A deficiency disease is an illness caused by a lack of an essential nutrient in the diet. It is not caught from another person and it is not caused by germs; it happens when the body does not get enough of a nutrient over a long period, and it can be prevented or cured by eating the missing nutrient.", "17.2", "Understand"),
 ("3 (b)", "Any three: not eating enough food in general; not eating enough of one particular nutrient; eating the same few foods all the time; poverty, so the family cannot afford the needed foods; poor feeding habits; ignorance of what makes a balanced diet; illness that stops the body absorbing the nutrient.", "17.2", "Understand"),
 ("3 (c)", "No single food contains all the classes of nutrient the body needs, so a person who eats only one kind of food gets plenty of one nutrient but misses the others. The missing nutrient is the one that causes the deficiency disease, so eating a variety of foods makes sure that all the nutrients are present.", "17.2", "Understand"),
 ("4 (a)", "SYMPTOMS are the signs that can be seen or felt in the patient and that the doctor or nurse looks for, such as pale eyes or bleeding gums. EFFECTS are what the disease does to the body and to the person's life, such as a child failing to grow or being too weak to walk to school.", "17.2", "Understand"),
 ("4 (b)", "Teaching families to eat a balanced diet is better, because a balanced diet gives all the nutrients and not only the ones in the tablet, because the habit lasts for life while tablets stop when the supply stops, and because local foods are cheaper and always available. Tablets help in an emergency but teach the family nothing.", "17.2", "Evaluate"),
 ("5 (a)", "Night blindness - lack of vitamin A. Rickets - lack of vitamin D, together with calcium and phosphorus. Scurvy - lack of vitamin C.", "17.3", "Understand"),
 ("5 (b)", "Night blindness - the child cannot see clearly in dim light or after dusk and bumps into things. Rickets - the bones are soft and bent, giving bow legs or a bent spine. Scurvy - the gums swell and bleed, teeth may loosen, and wounds heal slowly.", "17.3", "Remember"),
 ("5 (c)", "Eat foods containing vitamin D such as fish, egg yolk and milk, and foods containing calcium and phosphorus such as milk, fish with soft bones, groundnuts and green leafy vegetables. Let the skin get some gentle morning sunlight, which helps the body make its own vitamin D, and take a child with soft or bent bones to the clinic.", "17.3", "Apply"),
 ("6 (a)", "Kwashiorkor is caused by a lack of PROTEIN. The belly swells with fluid, the arms and legs become very thin, the hair becomes dry and reddish, and the child stops growing and loses interest in food.", "17.3", "Understand"),
 ("6 (b)", "Iron is needed to make haemoglobin, the red substance in the blood that carries oxygen. Without enough iron the body cannot make enough healthy red blood cells, so the blood carries less oxygen. Without oxygen the cells cannot release energy from food, so the child has little energy, tires quickly, feels weak and looks pale.", "17.3", "Analyse"),
 ("6 (c)", "Any two: liver; beans and other legumes; dark green leafy vegetables such as kontomire or alefu; fish; meat; eggs; groundnuts; fortified cereals or flour.", "17.3", "Remember"),
 ("7 (a)", "The children with swollen bellies, thin arms and legs and reddish hair have KWASHIORKOR, caused by a lack of PROTEIN. The children who cannot find their way in the evening have NIGHT BLINDNESS, caused by a lack of VITAMIN A.", "17.3", "Apply"),
 ("7 (b)", "Tell the families to add protein foods such as beans, groundnuts, fish, eggs or soya to the children's meals, and foods rich in vitamin A such as red palm oil, eggs, liver, dark green leafy vegetables, mango and pawpaw. Show them how to mix the foods they already grow, explain that the children will then get the nutrients they are missing and will grow properly again, advise them to take the worst-affected children to the clinic, and suggest a demonstration meal at the next community meeting.", "17.3", "Create"),
]
add_table(["Question", "Expected Answer", "Curriculum Area", "Cognitive Level"],
          [list(r) for r in sba], widths=[0.8, 4.2, 1.2, 1.2], size=9)

doc.add_page_break()

# =========================================================== MARKING SCHEME
para("MARKING SCHEME - SECTION B (60 marks)", size=13, bold=True, align="c", space_after=4)
para("General rules: (1) Accept any other correct and relevant answer. (2) Award marks for correct points, "
     "not for repeating the question. (3) For procedures, award method marks. (4) Do not deduct marks for "
     "spelling unless the meaning is changed. (5) Where a candidate gives more answers than are asked for, "
     "mark only the first ones up to the number required.",
     size=9.5, italic=True, space_after=8)

for qb in SECTION_B:
    n = qb["num"]
    para(f"Question {n}  ({qb['total']} marks)", size=11, bold=True, space_before=8, space_after=3)
    for (lab, points, note) in MARKING[n]:
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(2)
        set_font(p.add_run(f"{lab} "), 10.5, bold=True)
        mkv = [p_[2] for p_ in qb["parts"] if p_[0] == lab]
        if mkv: set_font(p.add_run(f"[{mkv[0]} mark{'s' if mkv[0] > 1 else ''}]"), 10, bold=True)
        for pt in points:
            pp = doc.add_paragraph()
            pp.paragraph_format.left_indent = Inches(0.35); pp.paragraph_format.space_after = Pt(1)
            set_font(pp.add_run("- " + pt), 10.5)
        pp = doc.add_paragraph()
        pp.paragraph_format.left_indent = Inches(0.35); pp.paragraph_format.space_after = Pt(6)
        set_font(pp.add_run("Marking note: " + note), 9.5, italic=True)

doc.add_page_break()

# ================================================================ BLUEPRINT
para("CURRICULUM ASSESSMENT BLUEPRINT", size=13, bold=True, align="c", space_after=3)
para(f"Strand: {STRAND}   |   Sub-strand: {SUBSTRAND}   |   Class: {CLASS}",
     size=10, italic=True, align="c", space_after=3)
para(f"Content Standard: {CS} - {CS_TEXT}", size=9, italic=True, align="c", space_after=3)
para("Source: NaCCA Science Common Core Programme Curriculum (B7/JHS1-B9/JHS3), September 2020, "
     "Strand 5: Humans and the Environment, Sub-strand 2: Human Health "
     "(topics 17.1-17.3), p. 45. Indicators are quoted, not invented.",
     size=9, italic=True, space_after=8)

hdr = ["Qn", "Sub-strand", "Content Standard", "Indicator (NaCCA) - Indicator Text", "Topic / Content",
       "Cognitive Level", "Marks"]

rows = [[f"A{i}", SUBSTRAND, CS_BY_TOPIC[tp], f"{IND[tp]} - {IND_TEXT[tp]}", TOPIC[tp], cog, 1]
        for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1)]
add_table(hdr, rows, widths=[0.35, 0.75, 0.75, 1.75, 1.4, 0.8, 0.35], size=7, head_size=7.5)

para("", space_after=8)
rows = []
for qb in SECTION_B:
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        key = tp if tp in TOPIC else tp.split(",")[0].strip()
        rows.append([f"B{qb['num']}{lab.strip('()')}", SUBSTRAND, CS_BY_TOPIC[key],
                     f"{IND[key]} - {IND_TEXT[key]}", TOPIC[key], cog, mk])
add_table(hdr, rows, widths=[0.35, 0.75, 0.75, 1.75, 1.4, 0.8, 0.35], size=7, head_size=7.5)

doc.add_page_break()

# ----------------------------------------------------------------- helpers
def topic_totals():
    m = {k: 0 for k in TOPIC}; it = {k: 0 for k in TOPIC}
    for q in MCQ:
        m[q[3]] += 1; it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk; it[key] += 1
    return m, it

def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}; b = {k: 0 for k in order}
    for q in MCQ: a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: b[cog] += mk
    return order, a, b

def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ: d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: d[diff] += mk
    return d

m, it = topic_totals(); diff = difficulty_totals(); order, ca, cb = cognitive_by_section()

para("SUMMARY 1 - COVERAGE BY CURRICULUM AREA (TOPIC)", size=12, bold=True, space_after=4)
rows = [[TOPIC[k], it[k], m[k], f"{(m[k]/100)*100:.1f}%", CC[k]] for k in TOPIC]
rows.append(["TOTAL", sum(it.values()), sum(m.values()), "100%", "-"])
add_table(["Topic / Content Area", "No. of Items", "Marks", "% of Total Marks", "Core Competencies"],
          rows, widths=[2.7, 0.8, 0.6, 1.0, 1.1], size=8.5)
para("CC = Communication and Collaboration; CP = Critical Thinking and Problem Solving; "
     "DL = Digital Literacy; CI = Creativity and Innovation.", size=8.5, italic=True, space_after=2)

para("", space_after=8)
para("SUMMARY 2 - COGNITIVE-LEVEL DISTRIBUTION (Bloom's Taxonomy)", size=12, bold=True, space_after=4)
rows = []
for lv in order:
    tot = ca[lv] + cb[lv]
    rows.append([lv, ca[lv], cb[lv], tot, f"{(tot/100)*100:.1f}%"])
rows.append(["TOTAL", sum(ca.values()), sum(cb.values()), sum(ca.values()) + sum(cb.values()), "100%"])
add_table(["Cognitive Level", "Section A Marks", "Section B Marks", "Total Marks", "% of Total"],
          rows, widths=[1.6, 1.3, 1.3, 1.1, 1.1], size=9.5)

para("", space_after=8)
para("SUMMARY 3 - DIFFICULTY DISTRIBUTION", size=12, bold=True, space_after=4)
rows = [[k, v, f"{(v/100)*100:.1f}%"] for k, v in diff.items()]
rows.append(["TOTAL", sum(diff.values()), "100%"])
add_table(["Difficulty", "Marks", "% of Total Marks"], rows, widths=[2.0, 1.2, 1.5], size=9.5)
para("Target in the master prompt: approximately 30% easy / 50% moderate / 20% challenging.",
     size=9, italic=True, space_after=2)

para("", space_after=8)
para("SUMMARY 4 - SECTION WEIGHTING", size=12, bold=True, space_after=4)
add_table(["Section", "Question Type", "Items", "Marks", "% of Total"],
          [["A", "Objective (multiple choice)", 40, 40, "40%"],
           ["B", "Theory / constructed response", 18, 60, "60%"],
           ["TOTAL", "-", 58, 100, "100%"]],
          widths=[0.9, 2.4, 0.8, 0.8, 1.0], size=9.5)

doc.add_page_break()

# ===================================================== QUALITY-CONTROL
para("QUALITY-CONTROL SUMMARY", size=13, bold=True, align="c", space_after=4)
para("Carried out against the 14-point validation list in the master prompt before the examination was "
     "finalised.", size=9.5, italic=True, space_after=8)

qc = [
 ("Does every question belong to the supplied curriculum scope?",
  "Yes. All 58 items - 40 objectives and 18 theory sub-questions - trace to Strand 5 (Humans "
  "and the Environment), Sub-Strand 2 (Human Health), topics 17.1-17.3, and to the single "
  "official B7 indicator B7/JHS1.5.2.1.1 under content standard B7/JHS1.5.2.1. Only deficiency "
  "diseases are tested. Viral diseases, COVID-19, Ebola, H1N1 and the roles of individuals, "
  "communities and government are deliberately excluded - they belong to the companion paper on "
  "B7/JHS1.5.2.2."),
 ("Is the examination appropriate for the stated class?",
  "Yes. The B7 curriculum requires learners to name and analyse food nutrients such as "
  "carbohydrates, proteins and fatty acids and their uses in the body; to discuss deficiency "
  "diseases associated with a lack of those nutrients; to relate the nutrients they gain or lack "
  "to the foods they normally eat, the exemplar itself naming protein and kwashiorkor and iron "
  "and anaemia; and to describe the symptoms, effects and prevention of common deficiency "
  "diseases such as night blindness, rickets, scurvy and kwashiorkor."),
 ("Are the questions genuinely BECE-style?",
  "Yes: Section A is 40 four-option objectives worth 1 mark each, and Section B is structured "
  "theory with sub-questions carrying printed mark allocations. There is a three-column "
  "completion table, several 'state' and 'name' items, and open tasks that require explanation, "
  "judgement and planning."),
 ("Are there enough application and reasoning questions?",
  "Yes. 33 of 100 marks (33%) are at Apply level or above (Apply 21, Analyse 4, Evaluate 4, "
  "Create 4). Create appears in Question 7(b), where pupils must advise a village; Analyse in "
  "Question 6(b), where they must explain the chain from a lack of iron to tiredness; and "
  "Evaluate in Question 4(b), where they must argue tablets against better eating."),
 ("Are the MCQ distractors plausible?",
  "Yes. Distractors are drawn from the same content family as the key: the function of a "
  "different nutrient (A1, A5, A7, A8, A10, A11), a different deficiency disease (A14, A15, "
  "A26), a real nutrient that does not cause the disease named (A24, A25, A33, A35), a real "
  "cause that is not the one asked for (A16), and a genuine activity that is simply not a cause "
  "(A17)."),
 ("Is there only one best answer for each MCQ?",
  "Yes. Every item was reviewed for a single defensible key, and each option list was checked so "
  "that the declared key sits on the correct answer. Special care was taken with A5, where the "
  "word 'only' rules out 'build teeth and bones', with A22, where scurvy, kwashiorkor and night "
  "blindness are all vitamin or protein deficiencies so that only iron-deficiency anaemia is a "
  "mineral deficiency, and with A24, where vitamin D is given together with calcium so that the "
  "answer is complete."),
 ("Are the marks internally consistent?",
  "Yes. Section A = 40 items x 1 mark = 40. Section B = 10 + 8 + 9 + 8 + 9 + 8 + 8 = 60. "
  "Each Section B sub-question's printed marks match its marking-scheme allocation, and every "
  "N-mark sub-question asks for N things."),
 ("Does the total add up correctly?",
  "Yes: 40 + 60 = 100 marks, matching the stated total on the front page."),
 ("Are the answers in the answer key correct?",
  "Yes. All 40 objective keys and all 18 Section B answers were verified against the marking "
  "scheme. The table key was checked row by row: carbohydrate from rice and cassava, protein "
  "from beans and fish for growth and repair, fat from palm oil for energy and warmth, and "
  "vitamin A from red palm oil and liver for healthy eyes."),
 ("Does the marking scheme match the questions?",
  "Yes. Every Section B sub-question has an expected-answer list and a marking note covering "
  "partial credit, acceptable alternatives, common wrong answers and method marks. Question "
  "1(b) withholds the mark when a correct use is attached to the wrong class of nutrient; "
  "Question 4(a) insists that one mark come from symptoms and one from effects; Question 5(c) "
  "requires vitamin D and also calcium or sunlight; and Question 7(b) requires advice on protein "
  "and on vitamin A."),
 ("Are the questions free from unnecessary ambiguity?",
  "Yes. Open items are anchored with 'name the five', 'state three', 'state two' and the mark "
  "allocation. Question 1(a) notes that a named food is not a class of nutrient; Question 1(b) "
  "says 'choose three of the classes you named in (a)'; Question 7(a) describes two groups of "
  "children so that the two diseases are distinguishable; and Question 4(b) asks for two reasons "
  "so that pupils know a bare opinion is not enough."),
 ("Are Ghanaian contexts used naturally and accurately?",
  "Yes: rice, maize, yam, cassava, plantain, gari and bread; palm oil, groundnut oil, coconut "
  "and shea butter; beans, groundnuts, soya, kontomire and alefu; red palm oil, mango and "
  "pawpaw; fish with soft bones, liver and eggs; iodised salt; a village visit with a "
  "community meeting; and the clinic or health centre."),
 ("Has any content outside the supplied curriculum been introduced?",
  "No. Every item sits inside topics 17.1-17.3. Viral diseases, COVID-19, Ebola, H1N1, "
  "pandemics, vaccination and the roles of individuals, communities and government are not "
  "required anywhere in the paper; they belong to the companion paper. No disease beyond the "
  "deficiency diseases named in the exemplar is tested, apart from goitre, which appears once "
  "as a further example of a mineral deficiency."),
 ("Are the questions sufficiently varied?",
  "Yes. Item types include naming the classes of nutrient, matching a class to its use, "
  "explaining why a growing child needs protein, completing a six-blank table of nutrients, "
  "naming mineral sources, defining a deficiency disease, listing causes, explaining why one "
  "food is not enough, distinguishing symptoms from effects, arguing tablets against diet, "
  "matching three diseases to their missing nutrients, stating symptoms, explaining how rickets "
  "is prevented, naming the nutrient and symptoms of kwashiorkor, explaining why anaemia causes "
  "tiredness, naming iron-rich foods, diagnosing two diseases from a village description, and "
  "advising the families what to do."),
]
for i, (q, a) in enumerate(qc, start=1):
    p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(2)
    set_font(p.add_run(f"{i}. {q}"), 10.5, bold=True)
    p2 = doc.add_paragraph()
    p2.paragraph_format.left_indent = Inches(0.3); p2.paragraph_format.space_after = Pt(6)
    set_font(p2.add_run(a), 10)

para("", space_after=8)
para("EXAMINER NOTES (for the teacher, not for candidates)", size=11, bold=True, space_after=4)
for n in [
 "Question 4(a) is the one most pupils muddle. They use 'symptoms' and 'effects' as if they were "
 "the same word. They are not: the symptom is what you can see or what the patient complains of, "
 "such as bleeding gums; the effect is the harm that follows, such as a child being too weak to "
 "walk to school. The note pays one mark for each half and caps the answer at 3 if only one is "
 "explained.",
 "Question 6(b) is the discriminator. Nearly every pupil can say 'the blood is not enough', but "
 "the marks are on the chain behind it: too little iron means too little haemoglobin, too little "
 "haemoglobin means less oxygen carried, and less oxygen means less energy released. Teach that "
 "chain as three linked sentences and the marks follow.",
 "Question 2(a) is the paper's factual core, and the two blanks that catch pupils out are (iii) "
 "and (v). Protein is for GROWTH and REPAIR, not for energy - pupils give 'energy' for almost "
 "every nutrient. Fat gives energy and warmth and helps absorb some vitamins.",
 "Question 1(b) is marked on the match, not on the list. A pupil who writes three correct uses "
 "but attaches them to the wrong classes scores nothing. Tell them to write the class and the "
 "use together in one sentence.",
 "Question 7 is the task that carries the indicator's real demand: the curriculum asks pupils to "
 "RELATE the nutrients they lack to the foods they normally eat. The note requires advice on "
 "protein and on vitamin A, and it rewards answers that use foods the village already grows "
 "rather than foods it would have to buy.",
 "Topic weighting is 30 marks for 17.1, 32 for 17.2 and 38 for 17.3. The named diseases carry "
 "the most, because Exemplar 4 asks for the symptoms, effects and prevention of several of them. "
 "If you spent longer on nutrients than on the diseases, move marks towards Questions 1 and 2.",
 "Two cheap practicals that raise marks sharply: (1) bring in a week of real food labels or "
 "empty wrappers and let pupils sort them by the nutrient they mainly supply, and (2) look at a "
 "sample of dark green leafy vegetables, red palm oil and beans on a table and ask which "
 "disease each would prevent. The first teaches Questions 1 and 2, the second teaches "
 "Questions 5 and 7.",
 "The companion paper covers topics 17.4 to 17.7 - the nature of viral diseases, COVID-19, "
 "Ebola and H1N1, and the roles of individuals, communities and government in managing them - "
 "under content standard B7/JHS1.5.2.2. Use the two papers together for a full end-of-term "
 "examination on this sub-strand, or separately as two class tests.",
 "Edit the school name, academic year and examination title on page 1 before printing.",
 "This is an original, teacher-made mock. It is not a reproduction of any WAEC or NaCCA examination "
 "paper.",
]:
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Inches(0.3); p.paragraph_format.space_after = Pt(3)
    set_font(p.add_run("- " + n), 10)

doc.save("/home/user/Basic7_Integrated_Science_Mock_Strand5_HumanHealth1.docx")
print("docx written")

print("Section A:", len(MCQ), "items")
print("Section B total:", sum(q["total"] for q in SECTION_B))
print("Topic marks:", m, "sum", sum(m.values()))
print("Difficulty:", diff, "sum", sum(diff.values()))
print("Cognitive A:", ca)
print("Cognitive B:", cb)
print("Answer counts:", counts)
print("Totals:", sum(m.values()), sum(diff.values()),
      sum(ca.values()) + sum(cb.values()))
