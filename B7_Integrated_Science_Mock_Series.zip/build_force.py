# -*- coding: utf-8 -*-
"""Basic 7 Integrated Science mock - Strand 4 Sub-strand 4: FORCE AND MOTION, part 1 of 2.
Covers topics 14.1 to 14.8 (force, balanced and unbalanced forces, inertia, Newton's First Law,
its applications, and magnets). 100 marks.
Indicators sourced from the official NaCCA Science CCP curriculum (B7/JHS1-B9/JHS3, Sept 2020),
Strand 4: Forces and Energy, Sub-strand 4: Force and Motion, printed pages 35-38.
Content standard: B7/JHS1.4.4.1 only. Simple machines (B7/JHS1.4.4.2) are in the companion paper."""

SCHOOL = "[SCHOOL NAME]"
SUBJECT = "INTEGRATED SCIENCE (SCIENCE)"
EXAM = "END-OF-TERM MOCK EXAMINATION"
CLASS = "Basic 7 (JHS 1)"
TIME = "2 hours (Suggested: Section A - 40 min; Section B - 80 min)"
MARKS = "100"
YEAR = "2025/2026 Academic Year"

STRAND = "Forces and Energy"
SUBSTRAND = "Force and Motion (Part 1: Force, Motion and Magnets)"

TOPIC = {
    "14.1": "14.1 What is Force?",
    "14.2": "14.2 Balanced and Unbalanced Forces",
    "14.3": "14.3 Inertia",
    "14.4": "14.4 Newton's First Law of Motion",
    "14.5": "14.5 Applications of Newton's First Law",
    "14.6": "14.6 Magnets: Types and Characteristics",
    "14.7": "14.7 Repulsion, Attraction and Orientation",
    "14.8": "14.8 Uses of Magnets",
}

CS = "B7/JHS1.4.4.1"
CS_BY_TOPIC = {k: "B7/JHS1.4.4.1" for k in
               ["14.1", "14.2", "14.3", "14.4", "14.5", "14.6", "14.7", "14.8"]}
CS_TEXT = ("Examine the concept of motion, Newton's first law of motion, magnetic force in relation "
           "to motion and understand their applications to life")

IND = {
    "14.1": "B7/JHS1.4.4.1.1 (Ex. 2)",
    "14.2": "B7/JHS1.4.4.1.1 (Ex. 2)",
    "14.3": "B7/JHS1.4.4.1.1 (Ex. 1)",
    "14.4": "B7/JHS1.4.4.1.2 (Ex. 1)",
    "14.5": "B7/JHS1.4.4.1.3 (Ex. 1, 2)",
    "14.6": "B7/JHS1.4.4.1.4 (Ex. 1)",
    "14.7": "B7/JHS1.4.4.1.4 (Ex. 2)",
    "14.8": "B7/JHS1.4.4.1.4 (Ex. 3)",
}
IND_TEXT = {
    "14.1": "Understand that unbalanced forces acting on an object cause it to move. Ex. 2: "
            "Demonstrate how unbalanced forces cause motion.",
    "14.2": "Understand that unbalanced forces acting on an object cause it to move. Ex. 2: "
            "Demonstrate how unbalanced forces cause motion.",
    "14.3": "Understand that unbalanced forces acting on an object cause it to move. Ex. 1: Explain "
            "inertia as a tendency of a body to resist motion.",
    "14.4": "State and explain Newton's First Law of motion. Ex. 1: Research to find what Newton's "
            "first law is and discuss it.",
    "14.5": "Examine the application of Newton's First Law of motion in life. Ex. 1, 2: Discuss "
            "some applications of Newton's First Law of Motion, e.g. when a metallic ball is put "
            "on a smooth surface and given a push it will be in motion until it gets to a blockade "
            "and it stops; use of seat belts in a vehicle. Explain the importance of Newton's "
            "First Law of Motion.",
    "14.6": "Demonstrate the behaviour of magnet and its use to life. Ex. 1: Discuss what magnets "
            "are and describe the types of magnets that exist.",
    "14.7": "Demonstrate the behaviour of magnet and its use to life. Ex. 2: Demonstrate the "
            "characteristics (repulsive, attractive, and orientation N-S direction) of a magnet.",
    "14.8": "Demonstrate the behaviour of magnet and its use to life. Ex. 3: Discuss the uses of "
            "magnet in everyday life.",
}
CC = {
    "14.1": "CP, CI, DL", "14.2": "CP, CI, DL", "14.3": "DL, CC",
    "14.4": "DL, CC, CI", "14.5": "CC, CP, CI",
    "14.6": "CC, CP, CI", "14.7": "CC, CP, CI", "14.8": "CC, CP, CI",
}

# ---------------------------------------------------------------- SECTION A
# (question, [A,B,C,D], answer, topic, cognitive, difficulty)
MCQ = [
 ("A force may be defined as",
  ["the amount of matter in an object", "the energy stored in a moving object",
   "a push or a pull on an object", "the space an object occupies"],
  "C", "14.1", "Remember", "Easy"),
 ("The SI unit of force is the",
  ["newton", "joule", "watt", "kilogram"], "A", "14.1", "Remember", "Easy"),
 ("Which of these is an effect of a force?",
  ["it makes an object heavier", "it changes the colour of an object",
   "it makes an object older", "it can change the shape of an object"],
  "D", "14.1", "Understand", "Moderate"),
 ("Which of these is NOT an effect of a force?",
  ["stopping a moving object", "making an object heavier",
   "changing the direction of a moving object", "making a still object move"],
  "B", "14.1", "Understand", "Moderate"),
 ("A pupil squeezes an empty plastic bottle and it changes shape. This shows that a force can",
  ["change the shape of an object", "change the mass of an object",
   "destroy the object completely", "make the object disappear"],
  "A", "14.1", "Apply", "Moderate"),

 ("Balanced forces acting on an object",
  ["always make the object move faster", "always make the object stop at once",
   "cancel each other out, so the object does not start moving",
   "make the object change direction"],
  "C", "14.2", "Understand", "Moderate"),
 ("An unbalanced force acting on an object causes the object to",
  ["become heavier", "become lighter", "stay exactly as it was", "move, or change its motion"],
  "D", "14.2", "Remember", "Easy"),
 ("Two boys push a box from opposite sides with the same amount of force. The box will",
  ["move towards the stronger boy", "not move at all", "move upwards",
   "move towards both boys at once"],
  "B", "14.2", "Apply", "Moderate"),
 ("In a tug-of-war, team A pulls with 500 N and team B pulls with 450 N. The rope will",
  ["not move at all", "move towards team B",
   "move towards team A, because the forces are not balanced", "move upwards"],
  "C", "14.2", "Apply", "Challenging"),

 ("Inertia is",
  ["the tendency of a body to resist a change in its motion",
   "the force that pulls things to the ground", "the speed of a moving body",
   "the weight of a body"],
  "A", "14.3", "Remember", "Easy"),
 ("A passenger in a tro-tro is thrown forward when the driver brakes suddenly. This happens "
  "because of",
  ["the engine stopping", "inertia", "magnetism", "friction in the tyres"],
  "B", "14.3", "Understand", "Moderate"),
 ("Which of these has the greatest inertia?",
  ["a tennis ball", "an empty sachet of water", "a feather", "a loaded cargo truck"],
  "D", "14.3", "Understand", "Moderate"),
 ("A coin rests on a card placed over a glass. The card is flicked away quickly and the coin "
  "drops into the glass. This shows that the coin",
  ["was pulled down by a magnet", "has no weight at all",
   "tends to stay at rest because of its inertia", "was pushed down by the card"],
  "C", "14.3", "Apply", "Challenging"),
 ("The inertia of a body depends mainly on its",
  ["mass", "colour", "temperature", "shape"], "A", "14.3", "Understand", "Moderate"),

 ("Newton's First Law of Motion is also called the law of",
  ["gravity", "inertia", "friction", "magnetism"], "B", "14.4", "Understand", "Moderate"),
 ("Newton's First Law states that a body at rest will",
  ["start moving on its own after some time", "always move in a circle", "become heavier",
   "remain at rest unless an unbalanced force acts on it"],
  "D", "14.4", "Understand", "Moderate"),
 ("A ball is rolled along a very smooth floor. Newton's First Law tells us that it will",
  ["keep moving in a straight line until a force stops it", "slow down and stop at once",
   "move in circles", "change direction by itself"],
  "A", "14.4", "Understand", "Moderate"),
 ("If no unbalanced force acts on a moving body, the body will",
  ["stop immediately", "slow down and stop",
   "keep moving at the same speed in a straight line", "move faster and faster"],
  "C", "14.4", "Understand", "Moderate"),
 ("Which statement best states Newton's First Law of Motion?",
  ["every action has an equal and opposite reaction",
   "a body continues in its state of rest or of uniform motion in a straight line unless an "
   "unbalanced force acts on it",
   "force equals mass times acceleration", "energy cannot be created or destroyed"],
  "B", "14.4", "Understand", "Moderate"),

 ("Seat belts are worn in cars because",
  ["they make the seat more comfortable", "they make the car go faster",
   "they make the car use less fuel",
   "they stop passengers from continuing to move forward when the car stops suddenly"],
  "D", "14.5", "Understand", "Moderate"),
 ("When a bus stops suddenly, passengers standing in it fall forward. This is an application of",
  ["Newton's First Law of Motion", "the law of conservation of energy",
   "the behaviour of magnets", "the water cycle"],
  "A", "14.5", "Understand", "Moderate"),
 ("A tablecloth can be pulled quickly from under a plate without the plate moving very much, "
  "because the plate",
  ["is very light", "is stuck to the table",
   "tends to stay at rest because of its inertia", "is pushed along by the cloth"],
  "C", "14.5", "Apply", "Challenging"),
 ("Which of these is NOT an application of Newton's First Law of Motion?",
  ["a passenger lurching forward when a car brakes",
   "using a magnet to pick up pins from the floor", "wearing a seat belt in a car",
   "a ball rolling on until it hits a block"],
  "B", "14.5", "Analyse", "Challenging"),

 ("A magnet is a material that",
  ["attracts all metals, including aluminium and copper", "repels everything near it",
   "attracts plastic and wood", "attracts iron and steel"],
  "D", "14.6", "Remember", "Easy"),
 ("The ends of a magnet where the attraction is strongest are called the",
  ["edges", "centre", "poles", "faces"], "C", "14.6", "Remember", "Easy"),
 ("Which of these is NOT attracted by a magnet?",
  ["a plastic ruler", "an iron nail", "a steel pin", "a steel paper clip"],
  "A", "14.6", "Understand", "Easy"),
 ("A bar magnet and a horseshoe magnet are examples of",
  ["two different materials", "two different poles", "two different units",
   "two different shapes of magnet"],
  "D", "14.6", "Remember", "Easy"),
 ("Which of these materials is used to make a permanent magnet?",
  ["copper", "steel", "plastic", "glass"], "B", "14.6", "Understand", "Moderate"),

 ("Like poles of two magnets",
  ["repel each other", "attract each other", "join together", "lose their magnetism"],
  "A", "14.7", "Remember", "Easy"),
 ("Unlike poles of two magnets",
  ["repel each other", "lose their magnetism", "attract each other", "become stronger"],
  "C", "14.7", "Remember", "Easy"),
 ("A bar magnet suspended freely and allowed to swing always comes to rest pointing",
  ["east-west", "up and down", "in any direction", "north-south"],
  "D", "14.7", "Remember", "Easy"),
 ("The end of a freely suspended magnet that points towards the north is called the",
  ["south pole", "north pole", "centre", "middle"], "B", "14.7", "Remember", "Easy"),
 ("Two magnets are placed with their north poles facing each other. The magnets will",
  ["push apart", "pull together", "stay still", "lose their magnetism"],
  "A", "14.7", "Apply", "Moderate"),

 ("Magnets are fitted to the door of a refrigerator to",
  ["make it colder", "make it heavier", "keep the door closed",
   "make it use less electricity"],
  "C", "14.8", "Remember", "Easy"),
 ("A magnetic compass works because a magnetised needle",
  ["is very light", "is painted red", "floats on water",
   "always points in the north-south direction"],
  "D", "14.8", "Understand", "Easy"),
 ("A teacher uses a magnet in the classroom to",
  ["clean the board", "hold notes and charts on a magnetic board", "sharpen a pencil",
   "switch on the lights"],
  "B", "14.8", "Understand", "Easy"),
 ("Which of these uses a magnet?",
  ["a door catch on a kitchen cabinet", "a plastic bucket", "a wooden spoon", "a glass tumbler"],
  "A", "14.8", "Understand", "Easy"),
 ("Iron filings are mixed with sand. The best way to separate the iron filings is to",
  ["add water and filter the mixture", "heat the mixture",
   "pass a magnet over the mixture", "leave the mixture in the sun"],
  "C", "14.8", "Apply", "Moderate"),
 ("A mechanic drops some small steel screws on the floor. The quickest way to pick them up is to "
  "use",
  ["a wet cloth", "a broom", "a plastic spoon", "a magnet"],
  "D", "14.8", "Apply", "Moderate"),
 ("Which of these is NOT a use of magnets?",
  ["a compass for finding direction", "weighing a bag of maize at the market",
   "a catch that keeps a cupboard door shut", "picking up steel pins that have fallen"],
  "B", "14.8", "Understand", "Moderate"),
]

# ---------------------------------------------------------------- SECTION B
SECTION_B = [
 dict(
   num=1, total=8, topic="14.1",
   stem="Forces are at work all around you: opening a door, kicking a ball and squeezing a "
        "sponge are all examples.",
   parts=[
     ("(a)", "Explain what is meant by a force and state its SI unit.",
      2, "Understand", "14.1", "Easy"),
     ("(b)", "State three effects that a force can have on an object.",
      3, "Understand", "14.1", "Moderate"),
     ("(c)", "A goalkeeper catches a fast ball and stops it. Explain what the force does in this "
             "case.", 3, "Apply", "14.1", "Challenging"),
   ]),
 dict(
   num=2, total=9, topic="14.2",
   stem="Two teams take part in a tug-of-war during an inter-house sports meeting at school.",
   parts=[
     ("(a)", "Explain what is meant by balanced forces and by unbalanced forces.",
      4, "Understand", "14.2", "Moderate"),
     ("(b)", "State what happens to an object when the forces acting on it are balanced.",
      2, "Understand", "14.2", "Easy"),
     ("(c)", "Two boys push a box from opposite sides. One pushes with 60 N and the other pushes "
             "with 45 N. State the direction in which the box moves and give a reason for your "
             "answer.", 3, "Apply", "14.2", "Challenging"),
   ]),
 dict(
   num=3, total=8, topic="14.3",
   stem="A tro-tro is travelling along the Accra-Kumasi road with passengers on board.",
   parts=[
     ("(a)", "Explain what is meant by inertia.", 3, "Understand", "14.3", "Moderate"),
     ("(b)", "State what property of a body determines how much inertia the body has.",
      2, "Understand", "14.3", "Easy"),
     ("(c)", "A passenger says that the tro-tro 'threw' him forward when the driver braked "
             "suddenly. Is this a correct description of what happened? Explain your answer.",
      3, "Evaluate", "14.3", "Challenging"),
   ]),
 dict(
   num=4, total=8, topic="14.4",
   stem="Your class has been researching Newton's First Law of Motion.",
   parts=[
     ("(a)", "State Newton's First Law of Motion.", 4, "Remember", "14.4", "Moderate"),
     ("(b)", "Explain why Newton's First Law is also called the law of inertia.",
      2, "Analyse", "14.4", "Moderate"),
     ("(c)", "A ball is rolled along a very smooth floor. State what happens to it and explain "
             "why.", 2, "Apply", "14.4", "Moderate"),
   ]),
 dict(
   num=5, total=9, topic="14.5",
   stem="Newton's First Law of Motion can be seen at work every day on the roads.",
   parts=[
     ("(a)", "Explain what happens to a passenger standing in a bus when the bus starts suddenly, "
             "and state which law this shows.", 3, "Understand", "14.5", "Moderate"),
     ("(b)", "Explain how a seat belt protects a passenger, using Newton's First Law.",
      3, "Apply", "14.5", "Challenging"),
     ("(c)", "Describe one other application of Newton's First Law in daily life and explain how "
             "it works.", 3, "Understand", "14.5", "Moderate"),
   ]),
 dict(
   num=6, total=8, topic="14.6",
   stem="Your class has been given a box of magnets of different shapes to examine.",
   parts=[
     ("(a)", "Explain what a magnet is and name two materials that a magnet attracts.",
      2, "Understand", "14.6", "Easy"),
     ("(b)", "Name three different shapes or types of magnet.", 2, "Remember", "14.6", "Easy"),
     ("(c)", "Your class is given two steel bars that look exactly the same. One is a magnet and "
             "the other is plain steel. Plan a test your class could carry out to find out which "
             "is the magnet, and explain why your test works.",
      4, "Create", "14.6", "Challenging"),
   ]),
 dict(
   num=7, total=10, topic="14.7",
   stem="Your class is investigating how magnets behave towards each other and towards the earth.",
   parts=[
     ("(a)", "Explain what is meant by attraction and by repulsion of magnets, and say when each "
             "one happens.", 3, "Understand", "14.7", "Moderate"),
     ("(b)", "Describe what happens when a bar magnet is suspended freely and allowed to swing, "
             "and explain how this behaviour is used.", 3, "Apply", "14.7", "Moderate"),
     ("(c)", "State four uses of magnets in everyday life.", 4, "Remember", "14.8", "Easy"),
   ]),
]

# ------------------------------------------------------- MARKING SCHEME
MARKING = {
 1: [
   ("(a)", ["A force is a push or a pull on an object.",
            "A force is what makes an object start moving, stop moving, speed up, slow down, "
            "change direction or change shape.",
            "The SI unit of force is the newton (N)."],
    "1 mark for a correct explanation of force and 1 mark for the unit, the newton (2 marks). "
    "Accept 'a push or a pull'. Do NOT accept 'the unit is the joule' - that is energy."),
   ("(b)", ["It can make a still object start to move.",
            "It can make a moving object stop.",
            "It can make a moving object speed up or slow down.",
            "It can change the direction in which an object is moving.",
            "It can change the shape or the size of an object."],
    "1 mark each for any THREE correct effects (3 marks). Accept any three sensible effects. Do "
    "NOT accept 'it makes an object heavier' or 'it changes the colour'."),
   ("(c)", ["The goalkeeper's hands apply a force to the ball.",
            "The force acts in the opposite direction to the motion of the ball.",
            "The force slows the ball down and brings it to a stop.",
            "The force also changes the shape of the ball and of the gloves a little, as they "
            "squash together.",
            "The harder the shot, the bigger the force needed to stop it."],
    "1 mark each for any THREE correct points (3 marks). Look for: a force is applied, it acts "
    "against the motion, and it stops the ball. Award at most 2 marks if the answer does not say "
    "that the force acts against the motion of the ball."),
 ],
 2: [
   ("(a)", ["Balanced forces are forces acting on an object that are equal in size and opposite "
            "in direction.",
            "Balanced forces cancel each other out, so they give no overall (resultant) force.",
            "Unbalanced forces are forces acting on an object that are NOT equal and opposite.",
            "Unbalanced forces do not cancel out; there is an overall force in one direction.",
            "Only an unbalanced force can start an object moving, stop it, speed it up, slow it "
            "down or change its direction."],
    "1 mark each for any FOUR correct points (4 marks). At least ONE point must describe "
    "BALANCED forces and at least one UNBALANCED forces; award at most 3 marks if only one kind "
    "is described."),
   ("(b)", ["It does not start moving; if it was at rest, it stays at rest.",
            "If it was already moving, it keeps moving at the same speed and in the same "
            "direction.",
            "Its motion does not change at all."],
    "1 mark each for any TWO correct points (2 marks). The key idea is that the motion does not "
    "change."),
   ("(c)", ["The box moves towards the boy pushing with the smaller force, that is, towards the "
            "boy pushing with 45 N.",
            "The forces are not balanced, because 60 N is bigger than 45 N.",
            "There is an overall (resultant) force of 15 N acting towards the 45 N side."],
    "1 mark for the correct direction, 1 mark for saying the forces are unbalanced and 1 mark "
    "for the reason (60 N is bigger than 45 N) (3 marks). Accept 'towards the weaker boy'. The "
    "overall force of 15 N earns the reason mark even if not calculated."),
 ],
 3: [
   ("(a)", ["Inertia is the tendency of a body to resist a change in its motion.",
            "It is the tendency of a body at rest to stay at rest.",
            "It is the tendency of a moving body to keep moving at the same speed and in the same "
            "direction.",
            "Inertia is not a force; it is a property of the body itself."],
    "1 mark each for any THREE correct points (3 marks). The key word is 'resist'. Award at most "
    "2 marks if the pupil calls inertia a force."),
   ("(b)", ["The mass of the body.", "How heavy the body is, that is, how much matter it "
            "contains."],
    "1 mark each for any TWO correct points (2 marks). The answer is mass. A heavy body is harder "
    "to start and harder to stop than a light one."),
   ("(c)", ["No, the tro-tro did not push or throw the passenger forward.",
            "The passenger was moving forward at the same speed as the tro-tro before it braked.",
            "When the tro-tro braked, a force slowed the tro-tro down, but no force acted on the "
            "upper part of the passenger's body.",
            "Because of inertia, the passenger kept moving forward at the same speed while the "
            "tro-tro slowed down underneath him.",
            "This is why he lurched forward - it is his own inertia, not a push from the "
            "vehicle."],
    "1 mark for saying no, or that the description is not correct, and 1 mark each for any TWO "
    "correct reasons (3 marks). The essential idea is that the passenger kept moving because of "
    "his own inertia while the vehicle slowed down."),
 ],
 4: [
   ("(a)", ["A body continues in its state of rest, or of uniform motion in a straight line, "
            "unless an unbalanced force acts on it.",
            "If a body is at rest it will stay at rest unless something pushes or pulls it.",
            "If a body is moving it will keep moving at the same speed and in the same straight "
            "line unless something stops it or turns it.",
            "It takes an unbalanced force to change the motion of a body."],
    "1 mark each for any FOUR correct points (4 marks). The three essential ideas are: rest "
    "stays rest, uniform motion in a straight line continues, and an UNBALANCED force is needed "
    "to change either. Award at most 3 marks if the word 'unbalanced' is not used."),
   ("(b)", ["Both are about the same thing: a body keeps doing what it is already doing unless a "
            "force acts on it.",
            "Inertia is the tendency to resist a change in motion, and Newton's First Law "
            "describes exactly that behaviour.",
            "The law explains in words what inertia is; that is why it is called the law of "
            "inertia."],
    "1 mark each for any TWO correct points (2 marks). The answer must LINK the law to inertia, "
    "not just define each one separately."),
   ("(c)", ["The ball keeps rolling at almost the same speed and in a straight line for a long "
            "time.",
            "This is because there is very little friction on a smooth floor to act as the "
            "unbalanced force that would slow it down.",
            "It eventually stops when friction and air resistance slow it down, or when it hits "
            "something."],
    "1 mark for what happens and 1 mark for the reason (2 marks). The key idea is that very "
    "little friction acts, so there is almost no unbalanced force to stop the ball."),
 ],
 5: [
   ("(a)", ["The passenger falls backwards, or is left behind as the bus moves forward.",
            "This is because the lower part of the body moves forward with the bus while the "
            "upper part tends to stay at rest.",
            "The passenger's inertia makes him stay where he was while the bus moves forward "
            "underneath him.",
            "This shows Newton's First Law of Motion - a body at rest stays at rest unless an "
            "unbalanced force acts on it."],
    "1 mark each for any THREE correct points (3 marks). The pupil must say what happens AND "
    "name the law to earn full marks."),
   ("(b)", ["Before the crash the passenger is moving forward at the same speed as the car.",
            "When the car stops suddenly, the passenger keeps moving forward because of inertia.",
            "The seat belt applies an unbalanced force to the passenger, holding him back.",
            "The belt stops him from hitting the dashboard or the windscreen, so it prevents "
            "injury.",
            "Without the belt, the passenger would keep moving forward until something else "
            "stopped him."],
    "1 mark each for any THREE correct points (3 marks). The chain to look for is: passenger "
    "moving, car stops, passenger keeps moving because of inertia, belt applies the force that "
    "stops him."),
   ("(c)", ["A passenger lurching forward when a vehicle brakes suddenly - the body keeps moving "
            "while the vehicle slows down.",
            "Luggage sliding off a seat when a bus turns a corner - it keeps going in the "
            "original straight line.",
            "A ball rolled on a smooth floor keeps rolling until it hits a block or friction "
            "stops it.",
            "Shaking a bottle or a hand to remove water drops - the water keeps moving when the "
            "hand stops.",
            "A tablecloth pulled quickly from under a plate - the plate stays where it is."],
    "1 mark for naming a correct application and 1 mark each for any TWO correct points "
    "explaining how it works (3 marks). Accept any sensible everyday application."),
 ],
 6: [
   ("(a)", ["A magnet is a material or object that attracts iron and steel.",
            "It produces a magnetic force around it that pulls magnetic materials towards it.",
            "Materials it attracts include iron, steel, nickel and cobalt."],
    "1 mark for a correct explanation of what a magnet is and 1 mark for naming two materials it "
    "attracts (2 marks). Iron and steel are the two expected. Do NOT accept 'plastic', 'copper', "
    "'aluminium' or 'wood'."),
   ("(b)", ["A bar magnet", "A horseshoe magnet", "A ring or round magnet",
            "A U-shaped magnet", "A button magnet", "A magnetic strip or fridge magnet"],
    "1 mark each for any TWO correct shapes or types of magnet (2 marks). Accept any two named "
    "shapes. Do NOT accept 'north magnet' or 'south magnet' - those are poles, not types."),
   ("(c)", ["Test 1: Suspend each bar in turn from a thread and let it swing freely. The one that "
            "always comes to rest pointing north-south is the magnet.",
            "This works because only a magnet has poles and lines up with the earth's magnetic "
            "field.",
            "Test 2: Bring one end of bar A close to the MIDDLE of bar B. If it attracts, A is "
            "the magnet.",
            "This works because the middle of a magnet has almost no attraction, so only the pole "
            "of a real magnet would pull there.",
            "Test 3: Dip each bar into a heap of iron pins or paper clips. The one that picks up "
            "a cluster of pins at its ends is the magnet.",
            "This works because a magnet attracts strongly at its poles while plain steel does "
            "not attract at all."],
    "1 mark for a sensible test, 1 mark for what would be seen, 1 mark for how the result would "
    "be used to identify the magnet, and 1 mark for the reason the test works (4 marks). This is "
    "a design task: award method marks for any workable test that is clearly described."),
 ],
 7: [
   ("(a)", ["Attraction is when two magnets pull towards each other.",
            "Attraction happens when unlike poles are brought together, that is a north pole and "
            "a south pole.",
            "Repulsion is when two magnets push each other away.",
            "Repulsion happens when like poles are brought together, that is north and north, or "
            "south and south.",
            "Repulsion is the surest test that both bars are magnets, because a magnet will "
            "attract plain iron but only a magnet will repel."],
    "1 mark each for any THREE correct points (3 marks). At least one point must describe "
    "attraction and at least one repulsion; award at most 2 marks if only one is described."),
   ("(b)", ["The magnet turns and finally comes to rest pointing in the north-south direction.",
            "The same end always points to the north; that end is called the north pole (the "
            "north-seeking pole).",
            "This behaviour is used in a magnetic compass to find direction.",
            "It is useful to travellers, pilots, sailors and anyone who needs to find the way.",
            "The magnet lines up because the earth itself behaves like a very large magnet."],
    "1 mark each for any THREE correct points (3 marks). The pupil must describe what happens "
    "AND say how it is used to earn full marks."),
   ("(c)", ["A magnetic compass for finding direction.",
            "A catch that keeps a refrigerator door or a cupboard door shut.",
            "Holding notes, charts or photographs on a magnetic board at school or in the office.",
            "Picking up small steel pins, nails or screws that have fallen.",
            "Separating iron and steel from a mixture with other materials.",
            "In a door bell, a loudspeaker or an electric motor.",
            "In a magnetic wallet clasp or a bag fastener."],
    "1 mark each for any FOUR correct uses (4 marks). Accept any sensible everyday use of a "
    "magnet."),
 ],
}


# --------------------------------------------- derive summary statistics
def topic_totals():
    m = {k: 0 for k in TOPIC}
    it = {k: 0 for k in TOPIC}
    for q in MCQ:
        m[q[3]] += 1
        it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk
            it[key] += 1
    return m, it


def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}
    b = {k: 0 for k in order}
    for q in MCQ:
        a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            b[cog] += mk
    return order, a, b


def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ:
        d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            d[diff] += mk
    return d
