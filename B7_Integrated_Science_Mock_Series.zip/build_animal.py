# -*- coding: utf-8 -*-
"""Basic 7 Integrated Science mock - Strand 2 Sub-strand 4: ANIMAL PRODUCTION. 100 marks.
Indicators sourced from the official NaCCA Science CCP curriculum (B7/JHS1-B9/JHS3, Sept 2020),
Strand 2: Cycles, Sub-strand 4: Animal Production, printed pages 12-15."""

SCHOOL = "[SCHOOL NAME]"
SUBJECT = "INTEGRATED SCIENCE (SCIENCE)"
EXAM = "END-OF-TERM MOCK EXAMINATION"
CLASS = "Basic 7 (JHS 1)"
TIME = "2 hours (Suggested: Section A - 40 min; Section B - 80 min)"
MARKS = "100"
YEAR = "2025/2026 Academic Year"

STRAND = "Cycles"
SUBSTRAND = "Animal Production"

TOPIC = {
    "6.1": "6.1 Types of Domestic Animals in Ghana",
    "6.2": "6.2 Classifying Domestic Animals: Ruminants, Monogastrics and Poultry",
    "6.3": "6.3 Differences and Similarities Among Ruminants, Monogastrics and Poultry",
    "6.4": "6.4 Domestic and Commercial Uses of Animals",
    "6.5": "6.5 By-Products of Animals and Their Importance",
}

CS = "B7/JHS1.2.4.1 and B7/JHS1.2.4.2"
CS_TEXT = ("B7/JHS1.2.4.1 - Demonstrate an understanding of the differences among domestic animals such as "
           "ruminants, monogastrics and poultry (monogastric herbivore). "
           "B7/JHS1.2.4.2 - Show an understanding of the usefulness of the different types of animals for "
           "domestic and commercial purposes")

CS_BY_TOPIC = {
    "6.1": "B7/JHS1.2.4.1",
    "6.2": "B7/JHS1.2.4.1",
    "6.3": "B7/JHS1.2.4.1",
    "6.4": "B7/JHS1.2.4.2",
    "6.5": "B7/JHS1.2.4.2",
}

IND = {
    "6.1": "B7/JHS1.2.4.1.1 (Ex. 1, 2)",
    "6.2": "B7/JHS1.2.4.1.2 (Ex. 1, 2)",
    "6.3": "B7/JHS1.2.4.1.2 (Ex. 3, 4)",
    "6.4": "B7/JHS1.2.4.2.1 (Ex. 1, 2)",
    "6.5": "B7/JHS1.2.4.2.2 (Ex. 2)",
}
IND_TEXT = {
    "6.1": "Examine and list domestic animals in the community; identify different types of domestic "
           "animals and match them with their breeds.",
    "6.2": "Show the differences and similarities among domestic animals: classify them into ruminants, "
           "monogastrics and poultry, and give examples of each group.",
    "6.3": "Discuss and write the differences among ruminants, monogastrics and poultry; write the "
           "similarities in their nature and characteristics.",
    "6.4": "Discuss and write the domestic and commercial uses of different types of animals; explain the "
           "concepts of domestic use and commercial use.",
    "6.5": "Observe and compare the uses of the different types of animals; list and match domestic "
           "animals to their commercial uses including their by-products (such as animal waste).",
}
CC = {
    "6.1": "DL, CP, CC", "6.2": "DL, CP, CC", "6.3": "DL, CP, CC",
    "6.4": "DL, CC", "6.5": "DL, CP, CC",
}

# ---------------------------------------------------------------- SECTION A
# (question, [A,B,C,D], answer, topic, cognitive, difficulty)
MCQ = [
 ("A domestic animal is",
  ["any animal living in the bush", "any animal that eats only grass",
   "an animal that people have tamed and keep for their own use", "any animal that cannot be eaten"],
  "C", "6.1", "Understand", "Easy"),
 ("Which of the following is NOT a domestic animal?",
  ["lion", "goat", "fowl", "pig"], "A", "6.1", "Remember", "Easy"),
 ("Which of these is a domestic animal commonly kept in Ghana?",
  ["elephant", "antelope", "monkey", "guinea fowl"], "D", "6.1", "Remember", "Moderate"),
 ("The West African Dwarf is a breed of",
  ["cattle", "goat", "sheep", "poultry"], "B", "6.1", "Remember", "Moderate"),
 ("The N'Dama and the Sanga are breeds of",
  ["goat", "sheep", "cattle", "pig"], "C", "6.1", "Remember", "Moderate"),
 ("Which of these is NOT a characteristic usually used to describe a domestic animal?",
  ["the name of the owner", "its body size", "its colour", "the shape of its ears"],
  "A", "6.1", "Understand", "Moderate"),
 ("Which of the following pairs is correctly matched (animal : breed)?",
  ["cattle : West African Dwarf", "goat : N'Dama", "pig : Sanga", "sheep : Djallonke"],
  "D", "6.1", "Understand", "Challenging"),
 ("A ruminant is an animal that",
  ["has no stomach at all",
   "has a four-chambered stomach and chews the cud",
   "has a simple stomach with one chamber", "eats only meat"],
  "B", "6.2", "Understand", "Moderate"),
 ("Which of these animals chews the cud?",
  ["pig", "fowl", "goat", "duck"], "C", "6.2", "Understand", "Easy"),
 ("A monogastric animal is one that",
  ["has a simple, single-chambered stomach", "has four stomach chambers",
   "has no teeth at all", "feeds only on grass"],
  "A", "6.2", "Understand", "Moderate"),
 ("Which of the following is a monogastric animal?",
  ["cattle", "sheep", "goat", "pig"], "D", "6.2", "Remember", "Easy"),
 ("Poultry are",
  ["animals with a four-chambered stomach", "birds kept by people for meat, eggs and feathers",
   "animals that chew the cud", "animals kept only for their milk"],
  "B", "6.2", "Understand", "Easy"),
 ("Which group does a duck belong to?",
  ["ruminant", "monogastric", "poultry", "reptile"], "C", "6.2", "Remember", "Easy"),
 ("Poultry are described as monogastric herbivores mainly because they",
  ["have a simple stomach and feed mainly on plant material such as grain",
   "chew the cud and eat grass", "eat only meat", "have four stomach chambers"],
  "A", "6.2", "Understand", "Challenging"),
 ("A farmer keeps cattle, a pig and some fowls. How many of these groups are ruminants?",
  ["three", "two", "none", "one"], "D", "6.2", "Apply", "Moderate"),
 ("Which of these animals does NOT have a gizzard?",
  ["fowl", "pig", "duck", "guinea fowl"], "B", "6.2", "Understand", "Challenging"),
 ("Which of these is a difference between a ruminant and poultry?",
  ["a ruminant has feathers while poultry have hair",
   "poultry chew the cud while a ruminant does not",
   "a ruminant gives birth to live young while poultry hatch from eggs",
   "poultry give milk while a ruminant does not"],
  "C", "6.3", "Apply", "Moderate"),
 ("The body covering of poultry is",
  ["feathers", "hair", "scales", "bristles"], "A", "6.3", "Remember", "Easy"),
 ("Which statement is TRUE of both ruminants and poultry?",
  ["both chew the cud", "both have feathers", "both hatch from eggs",
   "both are kept by people for food"],
  "D", "6.3", "Understand", "Moderate"),
 ("A ruminant is able to digest grass well because",
  ["it has very strong teeth",
   "micro-organisms in its stomach help to break the fibre down",
   "it drinks a lot of water", "it has a gizzard"],
  "B", "6.3", "Analyse", "Challenging"),
 ("Which of these is a similarity among ruminants, monogastrics and poultry?",
  ["all of them chew the cud", "all of them have feathers",
   "all of them need food, water, shelter and care from people", "all of them hatch from eggs"],
  "C", "6.3", "Understand", "Easy"),
 ("The part of a bird that grinds the food it has swallowed is the",
  ["gizzard", "crop", "rumen", "beak"], "A", "6.3", "Understand", "Moderate"),
 ("A pig cannot digest a diet of grass as well as a goat can, mainly because the pig",
  ["does not like the taste of grass", "has no teeth at all", "is too small to eat enough",
   "has a simple stomach and cannot break down much fibre"],
  "D", "6.3", "Analyse", "Challenging"),
 ("Which of these is a difference between a monogastric animal and a ruminant?",
  ["a monogastric animal has feathers while a ruminant has hair",
   "a monogastric animal has one stomach chamber while a ruminant has four",
   "a monogastric animal chews the cud while a ruminant does not",
   "a monogastric animal hatches from an egg"],
  "B", "6.3", "Understand", "Moderate"),
 ("Keeping a few fowls at home mainly to provide eggs for the family is an example of",
  ["commercial use", "export", "domestic use", "wild use"],
  "C", "6.4", "Understand", "Moderate"),
 ("Rearing cattle in order to sell the meat at the market is an example of",
  ["commercial use", "domestic use", "wild use", "ceremonial use"],
  "A", "6.4", "Understand", "Moderate"),
 ("Which of these is a domestic use of animals?",
  ["selling eggs at the market", "exporting hides to another country",
   "running a poultry farm to sell meat", "keeping a goat to provide milk for the family"],
  "D", "6.4", "Understand", "Easy"),
 ("Which of these is a commercial use of animals?",
  ["eating eggs at home", "selling feathers to a pillow maker",
   "using cattle dung on the family farm", "keeping a dog as a pet"],
  "B", "6.4", "Apply", "Moderate"),
 ("Which of the following is a direct product, and not a by-product, of a dairy cow?",
  ["dung", "bone meal", "milk", "hide"], "C", "6.4", "Apply", "Moderate"),
 ("A farmer keeps animals so that her family can eat and also so that she can sell the extra. This "
  "shows that",
  ["an animal can have both domestic and commercial uses at the same time",
   "commercial use is not allowed in Ghana", "domestic animals may never be sold",
   "only ruminants are useful"],
  "A", "6.4", "Analyse", "Moderate"),
 ("Which use is most likely to earn a farmer money regularly?",
  ["keeping one goat for the family", "using a bull to plough the family field",
   "keeping a dog as a pet", "selling eggs every week from a poultry farm"],
  "D", "6.4", "Apply", "Moderate"),
 ("A farmer wants to start a commercial animal enterprise. The most important thing to think about "
  "first is",
  ["the colour of the animals", "whether there is a ready market and enough feed and water",
   "how many dogs she owns", "the size of her house"],
  "B", "6.4", "Evaluate", "Challenging"),
 ("An animal by-product is",
  ["the animal itself", "a young animal",
   "a useful material obtained from an animal apart from the main product",
   "an animal that lives in the wild"],
  "C", "6.5", "Understand", "Moderate"),
 ("Which of these is a by-product of cattle?",
  ["dung", "milk", "meat", "calves"], "A", "6.5", "Remember", "Moderate"),
 ("Animal dung is important on a farm mainly because it",
  ["kills weeds at once", "keeps the animals warm at night",
   "keeps flies away from the kraal", "adds plant nutrients and improves the soil"],
  "D", "6.5", "Understand", "Easy"),
 ("Before animal dung is used on a crop, it is usually",
  ["burnt to ashes", "heaped and left to rot (composted) first",
   "washed with soap and water", "mixed with sugar"],
  "B", "6.5", "Understand", "Moderate"),
 ("Bones from a slaughter house can be processed into",
  ["cooking oil", "washing soap", "bone meal for animal feed and for fertilizer", "sugar"],
  "C", "6.5", "Understand", "Moderate"),
 ("Feathers from poultry are used for",
  ["pillows, cushions and mattresses", "making soap", "making roofing sheets", "making sugar"],
  "A", "6.5", "Remember", "Easy"),
 ("Which by-product of cattle is used to make leather?",
  ["milk", "hoof", "horn", "hide"], "D", "6.5", "Understand", "Easy"),
 ("The best reason why a farmer should not throw animal waste away is that",
  ["it makes the compound smell pleasant",
   "it can be used as manure to grow more crops, which saves money on fertilizer",
   "it keeps the rain away", "animals like to play in it"],
  "B", "6.5", "Apply", "Moderate"),
]

# ------------------------------------------------------- SECTION B TABLE (Q3)
CLASSIFY_HEADERS = ["Feature", "Ruminant", "Monogastric", "Poultry"]
CLASSIFY_ROWS = [
 ["Type of stomach", "Four chambers", "(i)", "Simple, with a gizzard"],
 ["Chews the cud", "Yes", "(ii)", "No"],
 ["Body covering", "Hair", "Hair or bristles", "(iii)"],
 ["How the young are produced", "(iv)", "Born alive", "Hatched from eggs"],
 ["Main feed", "(v)", "Grains, kitchen waste and concentrates", "Grains, scraps and green feed"],
 ["Front of the mouth", "(vi)", "Teeth in both jaws", "A beak; no teeth"],
]
CLASSIFY_CAPTION = "Table 1: Differences among ruminants, monogastrics and poultry"

# ---------------------------------------------------------------- SECTION B
SECTION_B = [
 dict(
   num=1, total=9, topic="6.1",
   stem="A Basic 7 class was asked to examine and list the domestic animals found in their community.",
   parts=[
     ("(a)", "What is meant by a domestic animal?", 3, "Understand", "6.1", "Easy"),
     ("(b)", "Name four domestic animals kept in Ghana.", 4, "Remember", "6.1", "Easy"),
     ("(c)", "Name one breed of cattle and one breed of goat kept in Ghana.",
      2, "Remember", "6.1", "Moderate"),
   ]),
 dict(
   num=2, total=9, topic="6.2",
   stem="Domestic animals are grouped into ruminants, monogastrics and poultry.",
   parts=[
     ("(a)", "Explain what is meant by a ruminant, a monogastric animal and poultry.",
      3, "Understand", "6.2", "Moderate"),
     ("(b)", "Give one example each of a ruminant, a monogastric animal and poultry.",
      3, "Remember", "6.2", "Easy"),
     ("(c)", "A farmer keeps a goat and a pig. Explain how you would tell which of them is the ruminant.",
      3, "Apply", "6.2", "Challenging"),
   ]),
 dict(
   num=3, total=10, topic="6.3",
   stem="The class was asked to write down the differences and the similarities among ruminants, "
        "monogastrics and poultry. Study the incomplete table below and answer the questions that follow.",
   table="classify",
   parts=[
     ("(a)", "Copy and complete the table.", 6, "Understand", "6.3", "Moderate"),
     ("(b)", "State two similarities among ruminants, monogastrics and poultry.",
      2, "Understand", "6.3", "Moderate"),
     ("(c)", "Explain why a goat can live on grass but a pig cannot do so well.",
      2, "Analyse", "6.3", "Challenging"),
   ]),
 dict(
   num=4, total=8, topic="6.4",
   stem="Animals are kept for domestic use and for commercial use.",
   parts=[
     ("(a)", "Explain what is meant by the domestic use of animals.", 2, "Understand", "6.4", "Easy"),
     ("(b)", "Explain what is meant by the commercial use of animals.", 2, "Understand", "6.4", "Easy"),
     ("(c)", "State four commercial uses of domestic animals in Ghana.",
      4, "Understand", "6.4", "Moderate"),
   ]),
 dict(
   num=5, total=8, topic="6.4",
   stem="Many Ghanaian families keep animals both for the home and for sale.",
   parts=[
     ("(a)", "State three domestic uses of animals in the home.", 3, "Understand", "6.4", "Easy"),
     ("(b)", "Explain why a Ghanaian farmer often keeps animals for both domestic and commercial use.",
      2, "Analyse", "6.4", "Challenging"),
     ("(c)", "Your class is asked to make a poster of two useful domestic animals. Describe what the "
             "poster should show about each animal.", 3, "Create", "6.4", "Challenging"),
   ]),
 dict(
   num=6, total=11, topic="6.5",
   stem="Apart from their main products, animals give a number of by-products that are very useful.",
   parts=[
     ("(a)", "Explain what is meant by an animal by-product.", 2, "Understand", "6.5", "Easy"),
     ("(b)", "Name five by-products of animals and give one importance of each.",
      5, "Understand", "6.5", "Moderate"),
     ("(c)", "Explain why animal dung is important on a Ghanaian farm, and describe how a farmer should "
             "treat it before using it on a crop.", 4, "Apply", "6.5", "Moderate"),
   ]),
 dict(
   num=7, total=5, topic="6.5",
   stem="Your class has been asked to study the animals kept in your community and the ways in which "
        "people use them.",
   parts=[
     ("(a)", "Describe how your class would carry out this study.", 3, "Create", "6.5", "Challenging"),
     ("(b)", "Give two reasons why such a study is useful to your class.",
      2, "Evaluate", "6.5", "Moderate"),
   ]),
]

# ------------------------------------------------------- MARKING SCHEME
MARKING = {
 1: [
   ("(a)", ["A domestic animal is an animal that people have tamed and keep for their own use.",
            "It is an animal that lives with or near people and depends on them for food, water and "
            "shelter.",
            "It is not a wild animal: people control where it lives, what it eats and how it is used."],
    "1 mark each for any THREE correct points (3 marks). Award 1 mark for 'an animal kept by people' if "
    "it is not developed further. Do NOT accept 'an animal that lives in a house' on its own."),
   ("(b)", ["Cattle", "Goat", "Sheep", "Pig", "Fowl (chicken)", "Duck", "Guinea fowl", "Turkey",
            "Rabbit", "Pigeon", "Donkey", "Dog", "Cat"],
    "1 mark each for any FOUR correct domestic animals (4 marks). Accept any animal really kept by "
    "people in Ghana. Do NOT accept wild animals such as antelope, grasscutter kept in the wild, or "
    "elephant."),
   ("(c)", ["Cattle: N'Dama, Sanga or Zebu.", "Goat: West African Dwarf or Sahelian."],
    "1 mark for a correct breed of cattle and 1 mark for a correct breed of goat (2 marks). Accept any "
    "breed really kept in Ghana, including local or common names. Do NOT accept a breed matched to the "
    "wrong animal."),
 ],
 2: [
   ("(a)", ["A ruminant is an animal with a four-chambered stomach that chews the cud.",
            "A monogastric animal is an animal with a simple, single-chambered stomach.",
            "Poultry are birds kept by people, such as fowl, duck, guinea fowl, turkey and pigeon; they "
            "have a beak and a gizzard and they hatch from eggs."],
    "1 mark for each correct group (3 marks). The key word for a ruminant is 'four-chambered stomach' "
    "or 'chews the cud'; for a monogastric animal it is 'simple/single stomach'; for poultry it is "
    "'birds'."),
   ("(b)", ["Ruminant: cattle, goat or sheep.", "Monogastric: pig or rabbit.",
            "Poultry: fowl, duck, guinea fowl, turkey or pigeon."],
    "1 mark for each correct example matched to the right group (3 marks). Do NOT accept a ruminant "
    "given as an example of a monogastric."),
   ("(c)", ["Watch the animals while they are resting: the goat brings food back up from its stomach "
            "and chews it again (chews the cud), while the pig does not.",
            "Look at what they can eat: the goat thrives on grass and leaves, while the pig needs "
            "grains, kitchen waste and concentrates.",
            "The goat is a ruminant because it has a four-chambered stomach and can digest fibrous "
            "plant material; the pig is a monogastric animal with a simple stomach."],
    "1 mark each for any THREE correct points (3 marks). Accept any observation a pupil could really "
    "make: chewing the cud is the strongest one. Award at least 1 mark for naming the goat as the "
    "ruminant."),
 ],
 3: [
   ("(a)", ["(i) Simple, with one chamber.",
            "(ii) No.",
            "(iii) Feathers.",
            "(iv) Born alive.",
            "(v) Grass and other fibrous plant material (forage, hay, leaves).",
            "(vi) No upper front teeth; a hard dental pad instead."],
    "1 mark each for all SIX blanks correctly filled (6 marks). The blank number must be matched to the "
    "correct answer. Accept any clear equivalent, e.g. 'one stomach' for (i) and 'roughage' for (v)."),
   ("(b)", ["All of them are kept by people (they are domestic animals).",
            "All of them need food, water, shelter and care.",
            "All of them are kept for food: meat, milk or eggs.",
            "All of them reproduce and produce young ones.",
            "All of them produce waste that can be used as manure.",
            "All of them have a backbone (they are vertebrates).",
            "All of them must be protected from disease, heat and predators."],
    "1 mark each for any TWO correct similarities (2 marks). Do NOT accept a difference given as a "
    "similarity, and do NOT accept 'they are all animals' on its own."),
   ("(c)", ["The goat is a ruminant: micro-organisms in its four-chambered stomach break down the "
            "fibre in grass, so the goat can use grass as its main feed.",
            "The pig is a monogastric animal with a simple stomach, so it cannot break down much fibre.",
            "A pig therefore needs grains, kitchen waste and concentrates rather than a diet of grass."],
    "1 mark each for any TWO correct points (2 marks). The key idea is the ruminant stomach and the "
    "micro-organisms that digest fibre. Award 1 mark for 'the goat is a ruminant and the pig is a "
    "monogastric' if it is not explained."),
 ],
 4: [
   ("(a)", ["The domestic use of animals is using animals to meet the needs of the family or the home.",
            "It is keeping animals for the household: for food, for work or for company, without "
            "mainly selling them.",
            "The animal or what it gives is used at home rather than sold."],
    "1 mark each for any TWO correct points (2 marks). The key idea is use at home rather than for "
    "sale. Accept 'keeping animals for the family'."),
   ("(b)", ["The commercial use of animals is keeping animals in order to sell them or what they "
            "produce.",
            "It is rearing animals as a business to earn money.",
            "The meat, milk, eggs, hides or by-products are taken to the market."],
    "1 mark each for any TWO correct points (2 marks). The key idea is selling for money. Award 1 mark "
    "for 'to make money' if it is not developed."),
   ("(c)", ["Selling meat (beef, mutton, chevon, pork, chicken) at the market.",
            "Selling eggs from a poultry farm.",
            "Selling milk to a milk collector or to a dairy.",
            "Selling live animals to traders or at a market.",
            "Selling hides and skins to a tanner.",
            "Selling feathers, bones or blood meal to processors.",
            "Selling manure or dung to crop farmers.",
            "Using animals to earn money by ploughing other people's fields or carrying goods."],
    "1 mark each for any FOUR correct commercial uses (4 marks). The use must involve selling or "
    "earning money. Do NOT accept a domestic use such as 'eating eggs at home'."),
 ],
 5: [
   ("(a)", ["Providing milk, meat or eggs for the family to eat.",
            "Providing dung for cooking fuel or for the family garden.",
            "Using cattle or donkeys to plough the family field or to carry loads.",
            "Keeping a dog to guard the house.",
            "Using animals for dowry, festivals or family ceremonies.",
            "Keeping animals as company or as pets.",
            "Using feathers, wool or hides at home."],
    "1 mark each for any THREE correct domestic uses (3 marks). The use must be for the home, not for "
    "sale. Accept any sensible use a Ghanaian family would really make."),
   ("(b)", ["Because the family eats what it needs first and sells whatever is left over.",
            "Because selling the extra gives the family money for school fees, food and medicine.",
            "Because an animal can be eaten at home and still give by-products such as dung and hides "
            "that can be sold.",
            "Because keeping animals is a way of saving money: the animal can be sold when the family "
            "needs cash."],
    "1 mark each for any TWO correct points (2 marks). Accept 'the family eats some and sells the "
    "rest' as one point."),
   ("(c)", ["A clear picture or drawing of each animal.",
            "The name of each animal, and the group it belongs to (ruminant, monogastric or poultry).",
            "What each animal is kept for: the domestic uses such as meat, milk, eggs or dung.",
            "What each animal eats and how it is housed.",
            "The by-products each animal gives and what they are used for.",
            "A short sentence or two under each picture, in large clear writing.",
            "A title for the poster and the name of the class."],
    "1 mark each for any THREE sensible features of the poster (3 marks). This is a design task: award "
    "method marks for any feature that would help another pupil learn the uses of the two animals. "
    "Look first for the animal's name, its group, and what it is used for."),
 ],
 6: [
   ("(a)", ["An animal by-product is a useful material obtained from an animal apart from the main "
            "product.",
            "It is something useful that comes from the animal but is not the meat, milk or eggs the "
            "animal is mainly kept for.",
            "It is what is left after the main product has been taken, and it is still useful."],
    "1 mark each for any TWO correct points (2 marks). The key idea is 'apart from the main product'. "
    "Award 1 mark for 'something useful we get from an animal besides the main one'."),
   ("(b)", ["Dung: used as manure to add plant nutrients to the soil.",
            "Bones: processed into bone meal for animal feed and fertilizer.",
            "Hides and skins: made into leather for shoes, bags and belts.",
            "Feathers: used to stuff pillows, cushions and mattresses.",
            "Blood: dried into blood meal and used in animal feed.",
            "Horns and hooves: made into buttons, glue, combs and ornaments.",
            "Fat (tallow): used to make soap and candles.",
            "Wool and hair: spun into cloth, blankets and carpets.",
            "Urine: mixed with dung and crop waste to make compost.",
            "Eggshells: crushed and added to poultry feed or compost."],
    "1 mark for each by-product correctly named with a sensible importance (5 marks). Both the name "
    "and the importance must be right for the mark. Accept any by-product really used in Ghana."),
   ("(c)", ["Dung is important because it adds plant nutrients to the soil and improves the soil "
            "structure, so crops grow better.",
            "It also helps the soil to hold water, which matters during the dry season and the "
            "harmattan.",
            "Using dung as manure saves the farmer money that would be spent on fertilizer.",
            "Before use the dung should be heaped and left to rot (composted) for some weeks.",
            "Composting kills some of the harmful organisms and weed seeds, and makes the nutrients "
            "easier for the crop to use.",
            "The rotted dung should then be spread on the bed and worked lightly into the soil, or "
            "placed near the roots and covered with soil.",
            "Fresh dung should not be placed straight on a crop, because it can scorch young plants."],
    "1 mark each for any FOUR correct points (4 marks). The answer must say something about BOTH why "
    "dung is important AND how it is treated; award at most 2 marks if only one of these is dealt "
    "with."),
 ],
 7: [
   ("(a)", ["Decide on the questions the class wants answered, e.g. which animals are kept and what "
            "each is used for.",
            "Walk round the community (compounds, kraals, coops, the market) and observe the animals.",
            "Write down each animal seen, how many there are, and what the owner keeps it for.",
            "Ask the owners a few set questions, and write the answers down carefully.",
            "Record the information in a table: animal, group (ruminant, monogastric or poultry), "
            "domestic uses, commercial uses and by-products.",
            "Take drawings or photographs if the class is allowed to, and label them.",
            "Bring the results together, discuss them in groups and write a short report."],
    "1 mark each for any THREE correct points (3 marks). This is a design task: award method marks for "
    "any sensible step. Look first for observing the animals, recording what is found in an orderly "
    "way, and asking the owners."),
   ("(b)", ["It helps the class to see which animals are really kept in their own community and what "
            "they are used for.",
            "It makes the work in class real, instead of only reading about animals in a book.",
            "It shows the class which animals earn money for families, so they understand commercial "
            "use.",
            "It helps the class to practise observing, recording and working in a group.",
            "The class could advise families on better ways of caring for their animals."],
    "1 mark each for any TWO sensible reasons (2 marks). Accept any reason that shows the study was "
    "worth doing. Do NOT accept 'it is fun' on its own."),
 ],
}


# --------------------------------------------- derive summary statistics
def topic_totals():
    m = {k: 0 for k in TOPIC}
    it = {k: 0 for k in TOPIC}
    for q in MCQ:
        m[q[3]] += 1
        it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk
            it[key] += 1
    return m, it


def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}
    b = {k: 0 for k in order}
    for q in MCQ:
        a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            b[cog] += mk
    return order, a, b


def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ:
        d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            d[diff] += mk
    return d
