# -*- coding: utf-8 -*-
"""Basic 7 Integrated Science mock - Strand 5 Sub-strand 3: SCIENCE AND INDUSTRY (rebuild).
Covers topics 18.1 to 18.4 (careers in science and how they improve human life; Ghanaian
scientists and their contributions; international scientists and their impact; and science,
technology and innovation in Ghana). 100 marks.
Indicators sourced from the official NaCCA Science CCP curriculum (B7/JHS1-B9/JHS3, Sept 2020),
Strand 5: Humans and the Environment, Sub-strand 3: Science and Industry, printed page 47.
Content standard: B7/JHS1.5.3.1. One content standard and one indicator, so this is a single
paper and not split.
NOTE ON 'PAUL RATNEI': the curriculum names him among the international scientists. That name
could not be found in any reference source and is very likely a typographical error in the
curriculum document itself. No question here tests a contribution by him; he is accepted only
as a listed name, and this is flagged in the examiner notes.
This is a full rebuild: every question is new and none is repeated from the earlier version."""

SCHOOL = "[SCHOOL NAME]"
SUBJECT = "INTEGRATED SCIENCE (SCIENCE)"
EXAM = "END-OF-TERM MOCK EXAMINATION"
CLASS = "Basic 7 (JHS 1)"
TIME = "2 hours (Suggested: Section A - 40 min; Section B - 80 min)"
MARKS = "100"
YEAR = "2025/2026 Academic Year"

STRAND = "Humans and the Environment"
SUBSTRAND = "Science and Industry"

TOPIC = {
    "18.1": "18.1 Careers in Science and How They Improve Human Life",
    "18.2": "18.2 Ghanaian Scientists and Their Contributions",
    "18.3": "18.3 International Scientists and Their Impact",
    "18.4": "18.4 Science, Technology and Innovation in Ghana",
}

CS = "B7/JHS1.5.3.1"
CS_BY_TOPIC = {k: "B7/JHS1.5.3.1" for k in ["18.1", "18.2", "18.3", "18.4"]}
CS_TEXT = ("Realise how careers in science can improve human life, and research about Ghanaian "
           "and internationally recognised scientists and science educators and model after them")

IND = {
    "18.1": "B7/JHS1.5.3.1.1 (Ex. 1, 2)",
    "18.2": "B7/JHS1.5.3.1.1 (Ex. 1)",
    "18.3": "B7/JHS1.5.3.1.1 (Ex. 2)",
    "18.4": "B7/JHS1.5.3.1.1 (Ex. 3, 4)",
}
IND_TEXT = {
    "18.1": "Discover and explain how careers in science can improve human conditions and "
            "relate these careers to the work of great national and international scientists and "
            "science educators. Ex. 1, 2: Describe various careers in science and relate them to "
            "the work of national and international scientists through presentations.",
    "18.2": "Discover and explain how careers in science can improve human conditions and "
            "relate these careers to the work of great national and international scientists and "
            "science educators. Ex. 1: Describe various careers in science and relate them to "
            "the work of national scientists, e.g. Prof. Ibok Oduro, Prof. Francis Allotey, "
            "Prof. Ewurama Addy, and science educationists Prof. Anamuah-Mensah, Prof. "
            "Theophilus Ossei-Anto, Prof. Christian Anthony-Krueger and others.",
    "18.3": "Discover and explain how careers in science can improve human conditions and "
            "relate these careers to the work of great national and international scientists and "
            "science educators. Ex. 2: Describe various careers in science and relate them to "
            "the work of international scientists - Albert Einstein, Alexander Fleming, Charles "
            "Darwin, Paul Ratnei, Stephen Hawkins, etc. - through presentations.",
    "18.4": "Discover and explain how careers in science can improve human conditions and "
            "relate these careers to the work of great national and international scientists and "
            "science educators. Ex. 3, 4: Research, and build portfolio on the impact of science "
            "and technology and innovation in homes, schools, communities, and the universe and "
            "make a presentation; identify the science and technology careers that Ghana must "
            "focus on and give reasons.",
}
CC = {"18.1": "CP, DL, CC, CI", "18.2": "CP, DL, CC, CI",
      "18.3": "CP, DL, CC, CI", "18.4": "CP, DL, CC, CI"}

# ---------------------------------------------------------------- SECTION A
# (question, [A,B,C,D], answer, topic, cognitive, difficulty)
MCQ = [
 ("A nurse works mainly to",
  ["care for sick people and help them get well", "test the soil on a farm", "repair computers in an office", "make medicines in a factory"],
  "A", "18.1", "Understand", "Easy"),
 ("A food scientist mainly",
  ["drives a lorry to the market", "sells fish at the market", "builds roads between towns", "finds better ways to process and preserve food"],
  "D", "18.1", "Understand", "Easy"),
 ("A pupil who is good at mathematics and wants to design bridges should train as",
  ["a pharmacist", "a civil engineer", "a nurse", "a veterinary doctor"],
  "B", "18.1", "Apply", "Moderate"),
 ("A water quality officer",
  ["tests water to make sure it is safe to drink", "sells water in bottles", "paints the outside of water tanks", "digs wells by hand"],
  "A", "18.1", "Apply", "Moderate"),
 ("An ICT or computer specialist",
  ["tests patients' blood in a laboratory", "plants trees on a farm", "installs and repairs computers and networks", "teaches only mathematics"],
  "C", "18.1", "Apply", "Easy"),
 ("A solar technician",
  ["sells kerosene at the market", "drives a taxi in the town", "makes charcoal in a kiln", "installs and looks after solar panels"],
  "D", "18.1", "Apply", "Easy"),
 ("A veterinary doctor improves human life mainly because",
  ["he builds dams for the district", "he gives medicines to children", "he treats people as well as animals", "healthy farm animals mean food and income for families"],
  "D", "18.1", "Understand", "Easy"),
 ("A soil scientist helps farmers mainly by",
  ["riding a tractor for them", "selling them cutlasses", "testing the soil and advising what to plant and what fertiliser to use", "harvesting their crops"],
  "C", "18.1", "Apply", "Easy"),
 ("Many children in a village are ill because the water they drink is dirty. Which career would help them most?",
  ["a banker", "an environmental health officer", "a geologist", "an architect"],
  "B", "18.1", "Apply", "Moderate"),
 ("An agricultural research scientist",
  ["develops better seeds and better farming methods", "drives a tractor on a farm", "buys and sells farm produce", "makes soap in a factory"],
  "A", "18.1", "Understand", "Easy"),
 ("Kwesi wants to find new ways of treating malaria. The best career for him is",
  ["a geologist", "a medical researcher", "a computer engineer", "a meteorologist"],
  "B", "18.1", "Apply", "Moderate"),
 ("Prof. Ibok Oduro works at",
  ["the University of Ghana at Legon", "UCC in Cape Coast", "UEW in Winneba", "KNUST in Kumasi"],
  "D", "18.2", "Remember", "Easy"),
 ("Prof. Francis Allotey became the first Ghanaian",
  ["full professor of mathematics", "woman professor of science", "Minister of Education", "head of state of Ghana"],
  "A", "18.2", "Remember", "Easy"),
 ("Prof. Ewurama Addy worked at",
  ["the University of Ghana", "UCC in Cape Coast", "KNUST in Kumasi", "UEW in Winneba"],
  "A", "18.2", "Remember", "Easy"),
 ("A science educator is different from a research scientist mainly because a science educator",
  ["makes medicines for a factory", "trains teachers and improves the way science is taught", "works only in a laboratory", "never studies any science at all"],
  "B", "18.2", "Understand", "Moderate"),
 ("Prof. Ibok Oduro's work on fortified sweetpotato helps to reduce",
  ["malaria", "cholera", "vitamin A deficiency", "tooth decay"],
  "C", "18.2", "Understand", "Moderate"),
 ("Which of these is a Ghanaian woman scientist?",
  ["Prof. Ewurama Addy", "Marie Curie", "Rosalind Franklin", "Jane Goodall"],
  "A", "18.2", "Remember", "Easy"),
 ("Prof. Francis Allotey also helped to develop",
  ["cloth weaving", "computer education in Africa", "road building", "the fishing industry of Ghana"],
  "B", "18.2", "Understand", "Moderate"),
 ("A pupil who wants to train science teachers at a university should follow the example of",
  ["Prof. Anamuah-Mensah", "Prof. Ibok Oduro", "Prof. Francis Allotey", "Albert Einstein"],
  "A", "18.2", "Apply", "Easy"),
 ("It is useful for Ghanaian girls to learn about Prof. Addy and Prof. Oduro mainly because it",
  ["is required only in the final year", "helps them to leave school early", "makes the syllabus longer", "shows them that women can reach the very top in science"],
  "D", "18.2", "Apply", "Moderate"),
 ("Which pair of Ghanaian scientists worked in the SAME field?",
  ["Prof. Oduro and Prof. Anamuah-Mensah", "Prof. Allotey and Prof. Oduro", "Prof. Addy and Prof. Allotey", "Prof. Anamuah-Mensah and Prof. Ossei-Anto"],
  "D", "18.2", "Analyse", "Challenging"),
 ("Marie Curie is famous for her work on",
  ["gravity", "penicillin", "evolution", "radioactivity"],
  "D", "18.3", "Remember", "Easy"),
 ("Isaac Newton is famous for his work on",
  ["the first computer", "gravity and the laws of motion", "penicillin", "the circulation of the blood"],
  "B", "18.3", "Remember", "Easy"),
 ("Louis Pasteur showed that",
  ["water is made of hydrogen and oxygen", "the earth moves round the sun", "plants make their own food", "many diseases are caused by germs, and he developed vaccines"],
  "D", "18.3", "Understand", "Moderate"),
 ("Alexander Fleming discovered penicillin when he noticed that",
  ["a piece of metal had rusted", "a mould had killed the bacteria growing near it", "a plant had grown taller than the rest", "his soup had gone sour"],
  "B", "18.3", "Understand", "Moderate"),
 ("A doctor wants to treat a patient with a bacterial infection. The scientist whose work helps most is",
  ["Stephen Hawking", "Albert Einstein", "Alexander Fleming", "Charles Darwin"],
  "C", "18.3", "Apply", "Moderate"),
 ("Jane Goodall is known for studying",
  ["chimpanzees in the wild", "the atom", "the planets", "the bottom of the sea"],
  "A", "18.3", "Remember", "Easy"),
 ("A farmer wants to breed better crops. The scientist whose ideas help most is",
  ["Stephen Hawking", "Charles Darwin", "Alexander Fleming", "Albert Einstein"],
  "B", "18.3", "Apply", "Moderate"),
 ("Einstein's equation E = mc squared showed that",
  ["the earth is round", "plants need light to grow", "mass and energy are related", "water boils at 100 degrees"],
  "C", "18.3", "Understand", "Challenging"),
 ("The work of which of these scientists is used every day in a hospital?",
  ["Alexander Fleming", "Isaac Newton", "Albert Einstein", "Stephen Hawking"],
  "A", "18.3", "Apply", "Challenging"),
 ("A solar dryer helps a fishmonger mainly by",
  ["freezing the fish without ice", "catching more fish from the sea", "drying the fish faster and keeping it clean, so it fetches a better price", "cooking the fish for her"],
  "C", "18.4", "Apply", "Moderate"),
 ("Which of these is an example of technology being used in a Ghanaian school?",
  ["a broom", "a computer used for lessons", "a wooden desk", "a chalkboard duster"],
  "B", "18.4", "Understand", "Easy"),
 ("A biogas digester in a village produces",
  ["salt from sea water", "electricity from the wind", "cooking gas from animal and food waste", "petrol from crude oil"],
  "C", "18.4", "Apply", "Easy"),
 ("It is important for Ghana to develop its own technology mainly because",
  ["other countries have no technology at all", "it is always cheaper than anything else", "it stops people from travelling", "solutions made here suit Ghana's own problems and need not be bought from abroad"],
  "D", "18.4", "Understand", "Moderate"),
 ("A farmer uses a mobile phone to check market prices before selling his maize. This is an example of",
  ["using technology to get a better price", "growing more maize than before", "wasting airtime", "avoiding going to market"],
  "A", "18.4", "Apply", "Moderate"),
 ("A village has no electricity and is far from the national grid. The best choice is",
  ["more kerosene lanterns", "waiting for the grid to arrive one day", "a solar mini-grid", "a diesel generator that needs fuel brought from the city"],
  "C", "18.4", "Apply", "Challenging"),
 ("An invention becomes an innovation when",
  ["it is kept secret from everybody", "people start using it to solve a real problem", "it wins a prize at a science fair", "it is drawn on paper"],
  "B", "18.4", "Understand", "Moderate"),
 ("Researching for a portfolio means mainly",
  ["drawing only pictures", "asking only one person", "copying out a whole book", "finding out information and checking it before using it"],
  "D", "18.4", "Understand", "Easy"),
 ("Which career would most help Ghana to reduce the food it buys from other countries?",
  ["a banker", "a tailor", "an agricultural scientist", "a lorry driver"],
  "C", "18.4", "Apply", "Easy"),
 ("A group of pupils has built a small solar oven. The BEST way to know whether it is successful is to",
  ["ask the teacher whether it looks good", "weigh it and write down the weight", "cook a meal with it and record how it compares with cooking on firewood", "paint it a bright colour"],
  "C", "18.4", "Evaluate", "Challenging"),
]

# ---------------------------------------------------------------- SECTION B
SCIENTIST_HEADERS = ["Name", "Field of Work", "What They Are Known For"]
SCIENTIST_ROWS = [
 ["Prof. Francis Allotey", "(i)", "The Allotey Formalism, from his work on soft X-ray "
  "spectroscopy"],
 ["Prof. Ibok Oduro", "food science", "(ii)"],
 ["(iii)", "biochemistry", "Research into Ghanaian herbal medicines; the first Ghanaian woman "
  "to become a full professor of natural science"],
 ["Prof. Jophus Anamuah-Mensah", "(iv)", "Training science teachers and improving the way "
  "science is taught"],
]

SECTION_B = [
 dict(
   num=1, total=9, topic="18.1",
   stem="Not everyone who works in science wears a white coat or works in a hospital.",
   parts=[
     ("(a)", "Name THREE careers in science that are NOT medicine.",
      3, "Remember", "18.1", "Easy"),
     ("(b)", "For TWO of the careers you named in (a), describe the work the person does.",
      4, "Understand", "18.1", "Moderate"),
     ("(c)", "Explain ONE way in which a veterinary doctor improves human life, even though he "
      "treats animals.", 2, "Understand", "18.1", "Moderate"),
   ]),
 dict(
   num=2, total=8, topic="18.1",
   stem="Adjoa is good at mathematics, she likes working outdoors, and she wants to help her "
        "community grow more food.",
   parts=[
     ("(a)", "Suggest TWO science careers that would suit Adjoa, and give a reason for each.",
      4, "Apply", "18.1", "Moderate"),
     ("(b)", "State TWO things Adjoa should do now, while she is at school, to prepare for a "
      "career in science.", 2, "Understand", "18.1", "Easy"),
     ("(c)", "Give TWO reasons why Ghana needs more people in science careers.",
      2, "Understand", "18.1", "Easy"),
   ]),
 dict(
   num=3, total=9, topic="18.2",
   stem="Ghana has produced both research scientists and science educators, and the country "
        "needs both.",
   parts=[
     ("(a)", "State what is meant by a science educator.", 2, "Understand", "18.2", "Moderate"),
     ("(b)", "Name TWO Ghanaian science educators and describe the work they do.",
      4, "Understand", "18.2", "Moderate"),
     ("(c)", "Give THREE reasons why a country needs good science teachers as well as research "
      "scientists.", 3, "Understand", "18.2", "Moderate"),
   ]),
 dict(
   num=4, total=8, topic="18.2", table="scientist",
   stem="The table below gives the work of some Ghanaian scientists and science educators. "
        "Complete it by filling in the spaces numbered (i) to (iv).",
   parts=[
     ("(i)", "Field of work of Prof. Francis Allotey.", 2, "Understand", "18.2", "Easy"),
     ("(ii)", "What Prof. Ibok Oduro is known for.", 2, "Understand", "18.2", "Moderate"),
     ("(iii)", "The name of the Ghanaian biochemist described.", 2, "Understand", "18.2", "Easy"),
     ("(iv)", "Field of work of Prof. Jophus Anamuah-Mensah.", 2, "Understand", "18.2",
      "Moderate"),
   ]),
 dict(
   num=5, total=9, topic="18.3",
   stem="Scientists from many countries have done work that has changed life everywhere, "
        "including in Ghana.",
   parts=[
     ("(a)", "Give TWO reasons why Ghanaian pupils should learn about international scientists.",
      2, "Understand", "18.3", "Moderate"),
     ("(b)", "Name ONE international scientist, state the branch of science they worked in, "
      "and describe their contribution.", 4, "Understand", "18.3", "Moderate"),
     ("(c)", "Analyse ONE way in which the work of that scientist still affects our lives "
      "today.", 3, "Analyse", "18.3", "Challenging"),
   ]),
 dict(
   num=6, total=6, topic="18.3",
   stem="New knowledge usually spreads from one country to another, but each country also has "
        "problems of its own.",
   parts=[
     ("(a)", "State TWO reasons why scientific knowledge is shared between countries.",
      2, "Understand", "18.3", "Moderate"),
     ("(b)", "Evaluate whether Ghana should train more of its own scientists or buy technology "
      "from other countries. Give reasons.", 4, "Evaluate", "18.3", "Challenging"),
   ]),
 dict(
   num=7, total=11, topic="18.4",
   stem="Your class has been asked to find out and show the impact of science, technology and "
        "innovation (STI) in your home, your school and your community.",
   parts=[
     ("(a)", "State THREE ways in which science and technology have changed life in a Ghanaian "
      "home or community.", 3, "Understand", "18.4", "Moderate"),
     ("(b)", "Design what the class will put in the portfolio for EACH of the home, the school "
      "and the community.", 4, "Create", "18.4", "Challenging"),
     ("(c)", "Describe TWO ways in which the class will check that the information it collects "
      "is correct, and TWO ways in which it will present its findings.",
      4, "Apply", "18.4", "Challenging"),
   ]),
]

# ------------------------------------------------------------ MARKING SCHEME
MARKING = {
 1: [("(a)", [
      "Any three careers in science that are not medicine: agricultural scientist or food "
      "technologist, engineer, geologist, meteorologist, environmental health officer, science "
      "teacher, laboratory technician, veterinary doctor, computer or ICT specialist, soil "
      "scientist, water quality officer, solar technician, medical researcher.",
     ], "1 mark each for any THREE correct careers (3 marks). They must be careers based on "
        "science, and NONE of them may be a medical career such as doctor, nurse, pharmacist or "
        "midwife - the question excludes medicine. Do NOT accept the same career written twice "
        "in different words."),
     ("(b)", [
      "Accept a correct description of the work for any two of the careers named in (a), for "
      "example: a soil scientist takes samples of the soil, tests them and tells the farmer "
      "what crop to plant and what fertiliser to use; an environmental health officer inspects "
      "houses, drains and water sources and advises the community on how to stop disease "
      "spreading; a solar technician fixes panels on a roof, wires them up and returns to clean "
      "and check them.",
     ], "Up to 4 marks: 2 marks for each of the two careers. For each one, 1 mark for naming "
        "what the person actually does and 1 mark for a detail that shows real understanding, "
        "such as the tools used, the place of work or the advice given. Cap each career at 1 if "
        "the description is only 'he works in an office' or 'she helps people'."),
     ("(c)", [
      "A veterinary doctor keeps farm animals healthy and treats them when they are sick, so "
      "families keep the milk, meat and eggs they depend on and do not lose the animals that "
      "plough their fields.",
      "Healthy animals also mean more food in the market and a better income for the farmer, so "
      "the whole family eats better.",
      "Some animal diseases can pass to people, so treating the animals also protects the "
      "people who live with them.",
     ], "Up to 2 marks. 1 mark for saying he keeps animals healthy or productive, and the "
        "second mark for the LINK to human life - food, income, ploughing or protection from "
        "disease. A pupil who says only 'he treats animals' earns 0, because that does not "
        "explain the benefit to people.")],

 2: [("(a)", [
      "Accept any two sensible careers with a reason that fits Adjoa, for example: agricultural "
      "scientist or soil scientist - she wants to help her community grow more food and she "
      "likes working outdoors; agricultural engineer - the work is outdoors and uses "
      "mathematics; environmental scientist - she likes the outdoors and wants to help her "
      "community; mathematics or science teacher - she is good at mathematics and could pass "
      "it on.",
     ], "Up to 4 marks: 1 mark for each career and 1 mark for each reason. The reason must "
        "connect the career to something the stem says about Adjoa - her mathematics, "
        "outdoor work or helping her community grow food. A career that ignores all three, "
        "such as 'a nurse because nurses help people', earns the career mark but not the "
        "reason mark."),
     ("(b)", [
      "Any two: work hard at mathematics and science and pass them well; take the subjects "
      "seriously and not only the ones she likes; ask her science teacher about the careers "
      "and what subjects they need; read books and look for information about science; join "
      "the science club or enter a science competition; finish school and go on to a "
      "university or a training college that teaches the subject.",
     ], "1 mark each for any TWO sensible things (2 marks). Credit practical steps she can "
        "take NOW at school. Do NOT credit vague answers such as 'she must believe in "
        "herself' with nothing practical attached."),
     ("(c)", [
      "Any two: scientists solve the country's own problems in food, health, water and energy; "
      "a country that trains its own scientists does not have to buy every solution from "
      "abroad; science and technology create jobs and income; other countries will not send "
      "their own scientists to fix Ghana's problems; the problems Ghana faces - floods, crop "
      "failure, disease - need people who understand them.",
     ], "1 mark each for any TWO correct reasons (2 marks). Each must say what the country "
        "gains, not merely that 'science is good'.")],

 3: [("(a)", [
      "A science educator is someone who teaches science and works to improve the way it is "
      "taught - training science teachers, designing what is taught and how, rather than "
      "doing research in a laboratory themselves.",
     ], "Up to 2 marks. 1 mark for 'teaches science'; the second mark for 'improves how it is "
        "taught' or 'trains science teachers'. An answer that says only 'a person who teaches' "
        "earns 1."),
     ("(b)", [
      "Accept any two correctly named Ghanaian science educators. Prof. Jophus Anamuah-Mensah - "
      "a science educator who has worked to improve science teaching in Ghana, led a university "
      "and helped shape education policy. Prof. Theophilus Ossei-Anto - a science educator at "
      "the University of Cape Coast who trains science teachers and works on how science is "
      "taught. Prof. Christian Anthony-Krueger - a science educator at the University of Cape "
      "Coast who trains teachers and works on science teaching.",
      "Also accept Prof. Ewurama Addy, who worked to popularise science and directed the "
      "Science Education Programme for Africa.",
     ], "Up to 4 marks: 1 mark for each correct name and 1 mark for each accurate description "
        "of the work. Names may be given without the title 'Prof.'. Cap at 2 if the names are "
        "right but both descriptions are vague or say only 'he teaches'. Do NOT accept a "
        "research scientist such as Prof. Allotey or Prof. Oduro here - this question is about "
        "science EDUCATORS."),
     ("(c)", [
      "Any three: teachers are the ones who produce the next generation of scientists, so "
      "without them there would be no scientists at all; a researcher may discover something, "
      "but it is teachers who make sure the discovery is understood and used; a country needs "
      "many good teachers but only a few researchers, so teachers reach far more people; "
      "teachers find and encourage the pupils who will become the scientists of the future; "
      "good teaching makes sure a discovery does not stay locked inside one laboratory.",
     ], "1 mark each for any THREE correct reasons (3 marks). Credit 'they produce the next "
        "generation', 'they spread what researchers find', 'they reach more people than "
        "researchers do' and 'they spot future scientists'. Do NOT credit reasons that simply "
        "say teachers are better than researchers.")],

 4: [("(i)", ["Mathematical physics.", "Also accept physics."],
      "2 marks for mathematical physics, or 1 mark for physics alone. Do NOT accept "
        "'mathematics' by itself - the Allotey Formalism came from his work on soft X-ray "
        "spectroscopy, which is physics."),
     ("(ii)", ["She reduces post-harvest losses and adds value to Ghanaian foods, so less of "
               "the harvest is wasted after it is picked.",
               "Also accept: her work on fortified sweetpotato products helps to reduce "
               "vitamin A deficiency."],
      "Up to 2 marks. 1 mark for reducing post-harvest losses or adding value to Ghanaian "
        "foods; the second mark for saying why that matters - less food wasted, or more "
        "income for farmers. Do NOT accept 'chemistry', which is where she began but not "
        "the field of her contribution."),
     ("(iii)", ["Prof. Ewurama Addy.", "Also accept Marian Ewurama Addy, or Prof. Addy."],
      "2 marks for the correct name. 1 mark if only the surname 'Addy' is given with no "
        "first name. Do NOT accept Prof. Ibok Oduro, who is a food scientist and not a "
        "biochemist in the sense used here."),
     ("(iv)", ["Science education.", "Also accept science education, or the training of "
               "science teachers."],
      "2 marks for science education, or 1 mark for the vaguer 'education'. Do NOT accept "
        "'teaching' alone at 2 marks - the field is specifically science education.")],

 5: [("(a)", [
      "Any two: scientific knowledge belongs to the whole world, so we use discoveries made in "
      "other countries every day; the medicines, machines and crops developed abroad are used "
      "in Ghana; their stories show pupils what patience, curiosity and hard work can achieve; "
      "learning about them gives pupils ideas they can apply to Ghana's own problems; "
      "understanding where knowledge comes from helps pupils to question and check things for "
      "themselves.",
     ], "1 mark each for any TWO correct reasons (2 marks). Credit 'we use their discoveries "
        "here', 'they are role models' and 'their ideas help us solve our own problems'."),
     ("(b)", [
      "Accept any one correctly matched. Albert Einstein - physics; the theory of relativity "
      "and the equation E = mc squared. Alexander Fleming - medicine and microbiology; the "
      "discovery of penicillin, the first antibiotic. Charles Darwin - biology and natural "
      "history; the theory of evolution by natural selection. Stephen Hawking - physics and "
      "cosmology; his work on black holes and the nature of the universe. Marie Curie - "
      "physics and chemistry; her work on radioactivity. Isaac Newton - physics and "
      "mathematics; gravity and the laws of motion. Louis Pasteur - microbiology; showing that "
      "germs cause disease and developing vaccines.",
     ], "Up to 4 marks: 1 mark for the name, 1 mark for the correct branch of science, and up "
        "to 2 marks for an accurate description of the contribution. Paul Ratnei is accepted "
        "as a name because he is named in the curriculum, but no contribution can be credited "
        "because none could be verified. Cap at 2 if the branch of science is right but the "
        "contribution is wrong or too vague, and give 0 if the contribution belongs to a "
        "different scientist."),
     ("(c)", [
      "Accept any accurate account of how the work named in (b) still matters, for example: "
      "Fleming's penicillin began the age of antibiotics, and antibiotics are still the "
      "treatment for bacterial infections in every Ghanaian hospital today, so without his "
      "work a simple cut or a chest infection could still kill.",
      "Or: Pasteur's idea that germs cause disease is the reason water is treated, milk is "
      "pasteurised, wounds are cleaned and children are vaccinated - all things done every day "
      "in Ghana now.",
      "Or: Einstein's work on energy and matter underlies the physics used in medical scanners, "
      "in satellite communication and in the generation of electricity.",
     ], "Up to 3 marks. 1 mark for naming a present-day use; 1 mark for explaining that use "
        "clearly; and 1 mark for a Ghanaian or everyday detail that shows the pupil has really "
        "thought about it. Cap at 1 if the pupil only repeats the contribution from (b) "
        "without saying how it reaches us today.")],

 6: [("(a)", [
      "Any two: scientists publish their results so others can build on them; problems such as "
      "disease, climate and food do not stop at borders, so countries must work together; a "
      "discovery made in one country can save lives in another; sharing saves each country "
      "from repeating work that has already been done; international journals, conferences and "
      "the internet let results travel quickly.",
     ], "1 mark each for any TWO correct reasons (2 marks). Credit 'results are published', "
        "'problems cross borders' and 'it saves repeating work'."),
     ("(b)", [
      "Either position, with reasons. For training our own scientists: they understand "
      "Ghana's own problems and can work on them directly; the knowledge stays in the country "
      "and trains the next generation; it is cheaper in the long run than buying every "
      "solution from abroad; a country that cannot make or repair anything of its own is "
      "always dependent on others.",
      "For buying technology from abroad: it is quicker than waiting years to train people; "
      "some technology is very expensive to develop and already exists; and the two are not "
      "really opposites - a country can buy technology AND train the people who will maintain, "
      "repair and adapt it.",
      "A strong answer will say that Ghana needs both: to buy what exists and to train "
      "Ghanaians who can run it, repair it and eventually make their own.",
     ], "Up to 4 marks. Credit marks for the REASONS, not for the position taken. 1 mark for a "
        "clear position, 1 mark for a developed reason, 1 mark for a second reason or for "
        "answering the other side, and 1 mark for recognising that Ghana needs both. A pupil "
        "who argues either side, or who says the two go together, can earn full marks if the "
        "reasoning is sound. Do NOT mark down a pupil for disagreeing with the examiner.")],

 7: [("(a)", [
      "Any three: electric light lets children read after dark; a refrigerator or a freezer "
      "keeps food and fish from spoiling; a mobile phone lets families keep in touch and lets "
      "traders check prices; mobile money lets people pay without carrying cash; a borehole "
      "with a hand pump gives clean water close to home; a grinding mill saves hours of "
      "pounding; a motorbike or a truck carries produce to market faster; gas or electric "
      "cookers have replaced some firewood.",
     ], "1 mark each for any THREE correct changes (3 marks). Each must name a technology AND "
        "say what changed because of it. Do NOT credit a bare list of gadgets with no change "
        "described."),
     ("(b)", [
      "HOME: a page listing the technologies used at home - a refrigerator, a mobile phone, "
      "electric light, a gas cooker - each with a picture or drawing and a note of what the "
      "family did before it had them.",
      "SCHOOL: a page on the technologies used in the school - computers, a projector, "
      "calculators, the science laboratory, treated water or a borehole - and what they have "
      "changed about lessons.",
      "COMMUNITY: a page on the technologies seen in the town or village - solar panels, a "
      "borehole, a mobile money agent, a grinding mill, a clinic, a tractor or improved "
      "storage for crops - with a note on who uses each one.",
      "A title page, a contents list, and a short conclusion at the end on what all of this "
      "has changed for the better.",
     ], "Up to 4 marks. 1 mark for a clear page or section for the HOME, 1 mark for the "
        "SCHOOL, 1 mark for the COMMUNITY, and 1 mark for the overall presentation, such as a "
        "title page, a contents list and a conclusion. Credit only if all three of home, "
        "school and community are actually covered - cap at 1 if only one or two are, and cap "
        "at 2 if they are named but nothing is said about what goes on each page."),
     ("(c)", [
      "CHECKING: ask a parent, a teacher or an older person whether what you have written is "
      "true; compare what you found in one place with what a book or a trusted website says; "
      "check a fact found on the internet against a second source before writing it down; ask "
      "someone who uses the technology, such as the miller or the nurse, to confirm how it "
      "helps.",
      "PRESENTING: pin the pages on the classroom wall and walk the class round them; give a "
      "short talk to the class or to another class; demonstrate one of the technologies while "
      "it is being explained; show the album to parents on an open day; act out 'before and "
      "after' for one of the technologies.",
     ], "Up to 4 marks, split into two halves. Up to 2 marks for CHECKING - 1 mark for each of "
        "two different ways of checking, or 2 marks for one way fully explained with a named "
        "person or source. Up to 2 marks for PRESENTING - 1 mark for each of two different "
        "ways, or 2 marks for one way fully described. An answer that covers only checking or "
        "only presenting cannot earn more than 2.")],
}


# ----------------------------------------------------------------- helpers
def topic_totals():
    m = {k: 0 for k in TOPIC}; it = {k: 0 for k in TOPIC}
    for q in MCQ:
        m[q[3]] += 1; it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk; it[key] += 1
    return m, it


def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}; b = {k: 0 for k in order}
    for q in MCQ: a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: b[cog] += mk
    return order, a, b


def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ: d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: d[diff] += mk
    return d
