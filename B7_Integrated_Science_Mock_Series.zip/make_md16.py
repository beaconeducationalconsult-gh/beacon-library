# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "/home/user")
from build_tools import *

L = []
def w(s=""): L.append(s)

w(f"# {SCHOOL}"); w()
w(f"## {SUBJECT}"); w()
w(f"### {EXAM}"); w()
w(f"**Class:** {CLASS}  ")
w(f"**Time:** {TIME}  ")
w(f"**Total Marks:** {MARKS}  ")
w(f"**Academic Year:** {YEAR}"); w()
w("---"); w()
w("### INSTRUCTIONS"); w()
for i, t in enumerate([
    "Write your name and class clearly in the spaces provided on your answer sheet.",
    "This paper has TWO sections: Section A and Section B.",
    "Answer ALL the questions in both sections.",
    "Section A has 40 multiple-choice questions. Each question carries 1 mark. Choose the best answer (A, B, C or D) and record it on the answer sheet provided.",
    "Section B has 7 theory questions totalling 60 marks. Write your answers clearly and neatly in your answer booklet. Draw and label diagrams or tables where you are asked to.",
    "Read every question carefully before you answer it.",
    "Do not use correction fluid. Cancel any mistake neatly with a single line.",
    "Hand in your answer sheet and your answer booklet at the end of the examination.",
], start=1):
    w(f"{i}. {t}")
w(); w("---"); w()

w("## SECTION A: OBJECTIVE TEST (40 marks)"); w()
w("*Answer ALL questions. Each question carries 1 mark. Choose the BEST answer and write its letter "
  "(A, B, C or D) against the question number on your answer sheet.*"); w()
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"**{i}. {q}**"); w()
    for j, o in enumerate(opts): w(f"{'ABCD'[j]}. {o}")
    w()
w("---"); w()

w("## SECTION B: THEORY (60 marks)"); w()
w("*Answer ALL questions. Write your answers in your answer booklet. The marks for each question are shown "
  "in brackets.*"); w()
for qb in SECTION_B:
    w(f"### Question {qb['num']}  [{qb['total']} marks]"); w()
    w(qb["stem"]); w()
    if qb.get("diagram"):
        w("```")
        for line in HOE: w(line)
        w("```")
        w("*Fig. 1: A hoe*"); w()
    if qb.get("table") == "tools":
        w("| " + " | ".join(TOOL_HEADERS) + " |")
        w("| " + " | ".join(["---"] * len(TOOL_HEADERS)) + " |")
        for r in TOOL_ROWS:
            w("| " + " | ".join(r) + " |")
        w()
        w("*Table 1: Common farm tools and their uses*"); w()
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        w(f"**{lab}** {text}  **[{mk} mark{'s' if mk > 1 else ''}]**"); w()
w("---"); w()

w("## ANSWER KEY"); w()
w("### Section A - Objective Test"); w()
w("| Question | Answer | Curriculum Area (Topic) | Cognitive Level |")
w("| -------- | ------ | ----------------------- | --------------- |")
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"| {i} | {ans} | {TOPIC[tp]} | {cog} |")
counts = {L2: sum(1 for q in MCQ if q[2] == L2) for L2 in "ABCD"}
w()
w("Correct-answer distribution: " + ", ".join(f"{L2} = {counts[L2]}" for L2 in "ABCD") + " (40 items).")
w()
w("### Section B - Theory (summary answers; full detail in the Marking Scheme)"); w()
w("| Question | Expected Answer | Curriculum Area | Cognitive Level |")
w("| -------- | --------------- | --------------- | --------------- |")
sba = [
 ("1 (a)", "(i) handle, (ii) blade, (iii) cutting edge.", "15.1", "Understand"),
 ("1 (b)", "Any four other tools: a cutlass; a hoe; a rake; a spade or shovel; a garden fork; a trowel; a watering can; a wheelbarrow; a knapsack sprayer; a sickle; an axe; a dibber; a head pan; a mattock; a pair of secateurs.", "15.1", "Remember"),
 ("1 (c)", "A watering can - used to water young plants and seedlings. A knapsack sprayer - used to apply chemicals such as pesticides and weedicides. A wheelbarrow - used to carry soil, manure, harvested produce or other loads.", "15.1", "Understand"),
 ("2 (a)", "(i) cutting and clearing bushes, weeding, or cutting grass. (ii) digging, turning and loosening the soil, and making mounds. (iii) harvesting rice, guinea corn or grass by cutting the stems. (iv) carrying soil, manure or harvested produce. (v) gathering leaves, grass and rubbish together, and levelling the soil. (vi) watering young plants and seedlings.", "15.1", "Understand"),
 ("2 (b)", "Any two animal-farm tools with a correct use each - e.g. a feeding trough holds feed for the animals; a spray pump is used to dip or spray animals against ticks and lice.", "15.1", "Apply"),
 ("3 (a)", "Handling is the way a tool is carried, used and kept while work is going on. It covers how the tool is picked up, carried to the farm, used and put down, and it means using the tool only for the job it was made for.", "15.2", "Understand"),
 ("3 (b)", "Maintenance is looking after a tool so that it stays in good working order. It includes cleaning, drying, sharpening, oiling and repairing the tool, and it is done after use and during storage so that the tool lasts longer.", "15.2", "Understand"),
 ("3 (c)", "Any three: proper handling prevents accidents and injuries; well-maintained tools last longer, so they do not have to be replaced often; the tools work better and faster, so more work is done; good maintenance saves money on repairs and replacements; clean, sharp tools do a better job.", "15.2", "Understand"),
 ("4 (a)", "Any three: the metal part rusts and becomes weak and blunt; the wooden handle rots or cracks and may break; the tool becomes blunt and does its work badly; it has to be repaired or replaced often, which costs money; a neglected tool can cause accidents; moving parts seize up or the handle works loose.", "15.2", "Understand"),
 ("4 (b)", "Rust makes the blade weak, so it may bend or break, and blunt, so it does not cut into the soil easily. A blunt blade needs much more force, so the farmer tires quickly, and the extra force makes the hoe more likely to slip and cause an injury. Less work is done in the day.", "15.2", "Apply"),
 ("4 (c)", "Look after good tools, because they cost more at first but last for many years and so are cheaper in the long run, because there are fewer repairs and replacements, and because sharp tools do the work better and faster.", "15.2", "Evaluate"),
 ("5 (a)", "Any four: always cut away from the body; carry tools with the blade or sharp edge pointing downwards; use each tool only for the job it was made for; put an unused tool down safely away from the working area; wear boots and gloves; never leave tools lying on a path; repair or report a damaged tool before using it; children should use tools only under adult supervision; read the label before using any chemical and wash afterwards.", "15.3", "Understand"),
 ("5 (b)", "A blunt cutlass does not bite in easily, so the farmer has to use much more force. The extra force makes the blade harder to control, so it is more likely to slip, and when it slips it can cut the leg, hand or foot. A sharp cutlass cuts with a light, controlled stroke and goes where the farmer wants it to go.", "15.3", "Analyse"),
 ("5 (c)", "Any two: wash the hands, face and any exposed skin with soap and clean water; wash or change the clothing worn while spraying; clean the sprayer and put it away safely; do not eat or drink before washing; report any feeling of sickness or dizziness at once.", "15.3", "Understand"),
 ("6 (a)", "A cutlass - always cut away from the body, and carry it with the blade pointing downwards. A hoe - keep the blade pointing down when carrying it, and do not swing it near another person. A knapsack sprayer - read the label, wear a nose cover and gloves, and do not spray against the wind. A wheelbarrow - do not overload it, and keep the load balanced so that it does not tip over.", "15.3", "Apply"),
 ("6 (b)", "Wash or wipe off all the soil and moisture from the blade, dry the hoe thoroughly, sharpen the blade if it is blunt, and oil or grease the metal part lightly to keep rust away. Hang it up or stand it in a dry, covered store rather than leaving it on the ground, and check the handle and tighten or replace it if it is loose or cracked.", "15.3", "Apply"),
 ("7 (a)", "Any three: farmers clean, dry and oil shared tools after use; tools are kept in a dry, locked community store; the community sets rules about who may use the tools and how they are cared for; farmers meet to repair or replace damaged tools together; pupils and farmers assemble tools from the community and practise using and maintaining them; a visit is made to a community farm to observe and report.", "15.4", "Understand"),
 ("7 (b)", "Ask permission from the farm owner and agree a date and time. Decide beforehand what the class is looking for and prepare a short checklist. Move round the farm in a group watching how each tool is carried, used and put down, and look at how the tools are cleaned, dried, sharpened and stored. Ask the farmer or workers about the rules they follow, and write down or draw each tool seen with a note of its condition. Keep clear of the working area so that the class does not cause an accident.", "15.4", "Create"),
 ("7 (c)", "Any two: the names of the tools seen; what each tool is used for; how each tool was handled; how each tool was maintained; the condition the tools were found in and anything that needed repair.", "15.4", "Remember"),
]
for r in sba: w(f"| {r[0]} | {r[1]} | {r[2]} | {r[3]} |")
w(); w("---"); w()

w("## MARKING SCHEME - SECTION B (60 marks)"); w()
w("*General rules: (1) Accept any other correct and relevant answer. (2) Award marks for correct points, not "
  "for repeating the question. (3) For procedures, award method marks. (4) Do not deduct marks for spelling "
  "unless the meaning is changed. (5) Where a candidate gives more answers than are asked for, mark only the "
  "first ones up to the number required.*"); w()
for qb in SECTION_B:
    n = qb["num"]
    w(f"### Question {n} ({qb['total']} marks)"); w()
    for (lab, points, note) in MARKING[n]:
        mkv = [p_[2] for p_ in qb["parts"] if p_[0] == lab]
        head = f"**{lab}**"
        if mkv: head += f" [{mkv[0]} mark{'s' if mkv[0] > 1 else ''}]"
        w(head); w()
        for pt in points: w(f"- {pt}")
        w(f"  - *Marking note: {note}*"); w()
w("---"); w()

w("## CURRICULUM ASSESSMENT BLUEPRINT"); w()
w(f"**Strand:** {STRAND} | **Sub-strand:** {SUBSTRAND} | **Class:** {CLASS}"); w()
w(f"**Content Standard:** {CS} - {CS_TEXT}"); w()
w("> Source: NaCCA Science Common Core Programme Curriculum (B7/JHS1-B9/JHS3), September 2020, "
  "Strand 4: Forces and Energy, Sub-strand 5: Agricultural Tools, pp. 41-43. "
  "Indicators are quoted, not invented."); w()

w("### Section A"); w()
w("| Qn | Sub-strand | Content Standard | Indicator (NaCCA) - Indicator Text | Topic / Content | Cognitive Level | Marks |")
w("| -- | ---------- | ---------------- | ---------------------------------- | --------------- | --------------- | ----- |")
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"| A{i} | {SUBSTRAND} | {CS_BY_TOPIC[tp]} | {IND[tp]} - {IND_TEXT[tp]} | {TOPIC[tp]} | {cog} | 1 |")
w()
w("### Section B"); w()
w("| Qn | Sub-strand | Content Standard | Indicator (NaCCA) - Indicator Text | Topic / Content | Cognitive Level | Marks |")
w("| -- | ---------- | ---------------- | ---------------------------------- | --------------- | --------------- | ----- |")
for qb in SECTION_B:
    for (lab, text, mkv, cog, tp, diff) in qb["parts"]:
        key = tp if tp in TOPIC else tp.split(",")[0].strip()
        w(f"| B{qb['num']}{lab.strip('()')} | {SUBSTRAND} | {CS_BY_TOPIC[key]} | {IND[key]} - {IND_TEXT[key]} | {TOPIC[key]} | {cog} | {mkv} |")
w(); w("---"); w()

def topic_totals():
    m = {k: 0 for k in TOPIC}; it = {k: 0 for k in TOPIC}
    for q in MCQ: m[q[3]] += 1; it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk; it[key] += 1
    return m, it

def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}; b = {k: 0 for k in order}
    for q in MCQ: a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: b[cog] += mk
    return order, a, b

def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ: d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: d[diff] += mk
    return d

m, it = topic_totals(); diff_ = difficulty_totals(); order, ca, cb = cognitive_by_section()

w("### Summary 1 - Coverage by Curriculum Area (Topic)"); w()
w("| Topic / Content Area | No. of Items | Marks | % of Total Marks | Core Competencies |")
w("| -------------------- | ------------ | ----- | ---------------- | ----------------- |")
for k in TOPIC: w(f"| {TOPIC[k]} | {it[k]} | {m[k]} | {(m[k]/100)*100:.1f}% | {CC[k]} |")
w(f"| **TOTAL** | **{sum(it.values())}** | **{sum(m.values())}** | **100%** | - |")
w()
w("*CC = Communication and Collaboration; CP = Critical Thinking and Problem Solving; DL = Digital Literacy; "
  "CI = Creativity and Innovation.*"); w()
w("### Summary 2 - Cognitive-Level Distribution (Bloom's Taxonomy)"); w()
w("| Cognitive Level | Section A Marks | Section B Marks | Total Marks | % of Total |")
w("| --------------- | --------------- | --------------- | ----------- | ---------- |")
for lv in order:
    tot = ca[lv] + cb[lv]
    w(f"| {lv} | {ca[lv]} | {cb[lv]} | {tot} | {(tot/100)*100:.1f}% |")
w(f"| **TOTAL** | **{sum(ca.values())}** | **{sum(cb.values())}** | **{sum(ca.values())+sum(cb.values())}** | **100%** |")
w()
w("### Summary 3 - Difficulty Distribution"); w()
w("| Difficulty | Marks | % of Total Marks |")
w("| ---------- | ----- | ---------------- |")
for k, v in diff_.items(): w(f"| {k} | {v} | {(v/100)*100:.1f}% |")
w(f"| **TOTAL** | **{sum(diff_.values())}** | **100%** |")
w()
w("*Target in the master prompt: approximately 30% easy / 50% moderate / 20% challenging.*"); w()
w("### Summary 4 - Section Weighting"); w()
w("| Section | Question Type | Items | Marks | % of Total |")
w("| ------- | ------------- | ----- | ----- | ---------- |")
w("| A | Objective (multiple choice) | 40 | 40 | 40% |")
w("| B | Theory / constructed response | 19 | 60 | 60% |")
w("| **TOTAL** | - | **59** | **100** | **100%** |")
w(); w("---"); w()

w("## QUALITY-CONTROL SUMMARY")
w("")
w("| Check | Status |")
w("| --- | --- |")
for q_, a_ in [
 ("Every question within supplied curriculum scope",
  "Yes - all 59 items (40 objectives and 19 theory sub-questions) sit in topics 15.1-15.4 of Strand 4, Sub-Strand 5 (Agricultural Tools), under content standard B7/JHS1.4.5.1, mapped to indicators B7/JHS1.4.5.1.1 and B7/JHS1.4.5.1.2. Only basic and simple hand tools are tested; the tractor, combine harvester and plough appear only as distractors"),
 ("Appropriate for the class",
  "Yes - B7 level; no farm machinery, no tractor maintenance, no irrigation and no agro-chemical manufacture"),
 ("Genuinely BECE-style",
  "Yes - 40 four-option objectives plus structured theory with printed mark allocations, a labelled diagram, a completion table, several 'state' and 'name' items, and two open tasks requiring explanation and planning"),
 ("Sufficient application and reasoning",
  "Yes - 32 of 100 marks (32%) at Apply level or above (Apply 22, Analyse 4, Evaluate 2, Create 4)"),
 ("Plausible MCQ distractors",
  "Yes - another farm tool used for a different job, a machine rather than a simple tool, a plausible but wrong way of caring for a tool, the opposite and unsafe practice, and a real activity that is simply not the right answer"),
 ("Single best answer per MCQ",
  "Yes - reviewed item by item and each option list was checked so that the declared key sits on the correct answer; a plough is named alongside the tractor and the harvester in A1 so that only the hoe is a simple tool, a wooden handle left in the rain rots rather than grows in A19, and the blade must point downwards and not merely forwards in A23"),
 ("Marks internally consistent",
  "Yes - Section A 40 x 1 = 40; Section B 10 + 8 + 9 + 8 + 9 + 7 + 9 = 60; sub-question marks match the marking scheme"),
 ("Total adds up correctly",
  "Yes - 40 + 60 = 100"),
 ("Answer key correct",
  "Yes - all 40 keys and all 19 Section B answers verified against the marking scheme; the diagram key was checked against the figure (the long shaft is the handle, the flat box below it is the blade, and the arrow below points to the cutting edge)"),
 ("Marking scheme matches questions",
  "Yes - expected answers plus marking notes covering partial credit, alternatives, common wrong answers and method marks; Question 4(b) insists that one mark come from the difficulty and one from the danger, Question 6(a) withholds the mark when a correct rule is attached to the wrong tool, and Question 7(b) requires at least one point about preparing for the visit and one about what would be recorded"),
 ("Free from unnecessary ambiguity",
  "Yes - open items are anchored with 'name four', 'state three' and 'state two' plus the mark allocation; Question 1(b) says 'four OTHER basic tools' so that pupils do not repeat the hoe in Fig. 1, Question 5(a) asks for rules for handling and the note excludes maintenance answers, and Question 7(b) asks for both the preparation and the observation"),
 ("Ghanaian contexts natural and accurate",
  "Yes - a hoe, cutlass, head pan and wheelbarrow on a Ghanaian farm; rice and guinea corn harvested with a sickle; knapsack sprayers used for pesticides and weedicides; a community farm visit; a shared community tool store; and a class report presented after the visit"),
 ("No content beyond the curriculum",
  "No - every item sits inside topics 15.1-15.4; farm machinery, tractor maintenance, irrigation and agro-chemical manufacture are not required anywhere in the paper"),
 ("Questions sufficiently varied",
  "Yes - naming the labelled parts of a hoe, listing other tools, matching three tools to their uses, completing a six-row tool table, naming animal-farm tools, explaining the meaning of handling and of maintenance, stating why they matter, describing what neglect does, explaining why a rusty hoe is dangerous, arguing a choice between cheap and good tools, stating four safety rules, explaining why blunt is dangerous, giving the steps after spraying, matching a rule to each of four tools, describing end-of-day care for a hoe, describing community maintenance, planning a farm visit, and listing the contents of a report"),
]:
    w("| " + q_ + " | " + a_ + " |")
w("")
w("### EXAMINER NOTES")
w("")
for n_ in [
 "Question 5(b) is the discriminator, and it is the one most pupils get backwards. They assume a sharp cutlass is the dangerous one. It is not: a blunt blade will not bite, so the farmer forces it, loses control, and the blade slips onto a leg or a hand. The note withholds marks from an answer that only says 'it can cut you' - the reasoning is what earns them.",
 "Question 7(b) is the design task, and it is marked on two halves. Pupils must say something about PREPARING for the visit and something about what they would OBSERVE AND RECORD. An answer that covers only one half is capped at 3 of the 4 marks. Do not insist on a particular farm - the school farm, a nearby cocoa or maize farm, or a community animal farm all work.",
 "Question 1(b) asks for four tools OTHER than the one in Fig. 1. Several pupils will write 'hoe' because it is the first tool they think of, and that mark is withheld. Worth saying out loud before the mock.",
 "Question 6(a) is marked on the match, not on the rules alone. A pupil who lists four correct safety rules but attaches them to the wrong tools scores nothing. Tell them to write the tool and the rule together in one sentence.",
 "The two indicators under this content standard are 'explain the basic rules' (B7/JHS1.4.5.1.1) and 'apply the handling and maintenance in their community' (B7/JHS1.4.5.1.2). That is why the paper moves from naming tools, through meanings and rules, to a community visit and a report - the curriculum's own sequence, not mine.",
 "Topic weighting is 30 marks for 15.1, 25 for 15.2, 27 for 15.3 and 18 for 15.4. Tools and safety carry the most. If you spent longer on community work, move marks towards Question 7.",
 "Two cheap practicals that raise marks sharply: (1) bring a hoe, a cutlass and a rake to class and let pupils name the parts and pass them round safely, and (2) leave two nails, one oiled and one wet, overnight and look at them the next morning. The first teaches Questions 1 and 6, the second teaches Questions 3 and 4.",
 "If you can arrange it, the farm visit in Question 7(b) is worth doing for real. A single afternoon at a nearby farm fixes the whole sub-strand better than any number of notes, and it gives pupils something concrete to write about.",
 "Edit the school name, academic year and examination title on page 1 before printing.",
 "This is an original, teacher-made mock. It is not a reproduction of any WAEC or NaCCA examination paper.",
]:
    w("- " + n_)
w()

open("/home/user/Basic7_Integrated_Science_Mock_Strand4_AgriculturalTools.md", "w", encoding="utf-8").write("\n".join(L))
print("md written", len("\n".join(L)), "chars")
