# -*- coding: utf-8 -*-
"""Basic 7 Integrated Science mock - Strand 2 Sub-strand 1: EARTH SCIENCE. 100 marks.
Indicators sourced from the official NaCCA Science CCP curriculum (B7/JHS1-B9/JHS3, Sept 2020),
Strand 2: Cycles, Sub-strand 1: Earth Science, printed pages 7-8."""

SCHOOL = "[SCHOOL NAME]"
SUBJECT = "INTEGRATED SCIENCE (SCIENCE)"
EXAM = "END-OF-TERM MOCK EXAMINATION"
CLASS = "Basic 7 (JHS 1)"
TIME = "2 hours (Suggested: Section A - 40 min; Section B - 80 min)"
MARKS = "100"
YEAR = "2025/2026 Academic Year"

STRAND = "Cycles"
SUBSTRAND = "Earth Science"

TOPIC = {
    "3.1": "3.1 Natural Sources of Water",
    "3.2": "3.2 Stages of the Water Cycle: Evaporation, Condensation, Precipitation and Transpiration",
    "3.3": "3.3 Why the Water Cycle is a Repeated Pattern in Nature",
    "3.4": "3.4 Importance of the Water Cycle to the Environment",
    "3.5": "3.5 The Water Cycle and Weather Patterns",
}

CS = "B7/JHS1.2.1.1"
CS_TEXT = "Recognise that the water cycle is an example of repeated patterns of change in nature and " \
          "understand how it occurs"

IND = {
    "3.1": "B7/JHS1.2.1.1.1 (Ex. 1)",
    "3.2": "B7/JHS1.2.1.1.1 (Ex. 1, 2)",
    "3.3": "B7/JHS1.2.1.1.1 (Ex. 3)",
    "3.4": "B7/JHS1.2.1.1.2 (Ex. 2, 3)",
    "3.5": "B7/JHS1.2.1.1.2 (Ex. 2d)",
}
IND_TEXT = {
    "3.1": "Identify the natural sources of water.",
    "3.2": "List the stages of the water cycle - evaporation, condensation, precipitation and transpiration; "
           "draw a flow chart or diagram to show the order of the stages and how they are linked.",
    "3.3": "Explain why the water cycle is a repeated pattern in nature.",
    "3.4": "Describe the importance of the water cycle in terms of: energy source; carrier of nutrients; "
           "improving water table; regulating weather pattern; provision of clean water.",
    "3.5": "Describe the importance of the water cycle in regulating weather patterns.",
}
CC = {
    "3.1": "CP, DL, CI", "3.2": "CP, DL, CI", "3.3": "CP, DL, CI",
    "3.4": "CC, DL, CI, CP", "3.5": "CC, DL, CI, CP",
}

# ---------------------------------------------------------------- SECTION A
# (question, [A,B,C,D], answer, topic, cognitive, difficulty)
MCQ = [
 ("Which of the following is a natural source of water?",
  ["A water tank", "A spring", "A plastic bottle", "A dam"], "B", "3.1", "Understand", "Easy"),

 ("Water that is found beneath the surface of the earth is called",
  ["surface water", "rain water", "sea water", "ground water"], "D", "3.1", "Remember", "Easy"),

 ("Which of the following is an example of surface water?",
  ["A river", "Ground water", "A well", "A borehole"], "A", "3.1", "Understand", "Easy"),

 ("The main natural source from which all other sources of water on land are supplied is",
  ["a river", "a lake", "rain", "a spring"], "C", "3.1", "Understand", "Moderate"),

 ("Which of the following natural sources of water is salty?",
  ["A river", "A lake", "A spring", "The ocean"], "D", "3.1", "Remember", "Easy"),

 ("A stream that flows throughout the year in a forest is an example of",
  ["stored water", "a natural source of water", "a man-made source of water", "distilled water"],
  "B", "3.1", "Understand", "Easy"),

 ("Water that collects underground and can be reached by digging a well is called",
  ["rain water", "surface water", "ground water", "sea water"], "C", "3.1", "Remember", "Moderate"),

 ("Why is rainwater usually described as the purest natural water?",
  ["It has fallen directly from the clouds and has not picked up minerals from the ground.",
   "It is the only water that contains no oxygen.",
   "It is made inside the clouds.",
   "It is always safe to drink without boiling."], "A", "3.1", "Understand", "Moderate"),

 ("Which of the following shows water moving from a natural source into the air?",
  ["Rain falling on a roof", "A river flowing into the sea", "Water being stored in a tank",
   "Water disappearing from a puddle on a hot day"], "D", "3.1", "Apply", "Moderate"),

 ("The process by which water changes from a liquid into water vapour is called",
  ["condensation", "precipitation", "evaporation", "transpiration"], "C", "3.2", "Remember", "Easy"),

 ("The process by which water vapour changes back into liquid water is called",
  ["evaporation", "condensation", "precipitation", "filtration"], "B", "3.2", "Remember", "Easy"),

 ("Rain, snow and hail are all examples of",
  ["precipitation", "evaporation", "condensation", "transpiration"], "A", "3.2", "Understand", "Easy"),

 ("The loss of water vapour from the leaves of plants is called",
  ["precipitation", "condensation", "evaporation", "transpiration"], "D", "3.2", "Remember", "Easy"),

 ("Water vapour rises into the air, cools and forms",
  ["rain immediately", "clouds", "ice only", "ground water"], "B", "3.2", "Understand", "Moderate"),

 ("During which stage of the water cycle do clouds release water as rain?",
  ["evaporation", "transpiration", "precipitation", "condensation"], "C", "3.2", "Remember", "Easy"),

 ("Which of the following gives the correct order of the stages of the water cycle?",
  ["Evaporation, condensation, precipitation",
   "Condensation, evaporation, precipitation",
   "Precipitation, condensation, evaporation",
   "Evaporation, precipitation, condensation"], "A", "3.2", "Understand", "Moderate"),

 ("The main source of energy that drives the water cycle is",
  ["the moon", "the wind", "the ocean", "the sun"], "D", "3.2", "Remember", "Moderate"),

 ("Which of the following would most increase the rate of evaporation from a bowl of water?",
  ["Covering it with a lid", "Putting it in a refrigerator", "Placing it in bright sunshine",
   "Adding more cold water"], "C", "3.2", "Apply", "Moderate"),

 ("The water cycle is described as a repeated pattern because",
  ["the same stages happen over and over again in the same order",
   "it only happens in the rainy season",
   "it happens only once a year",
   "the amount of water increases each time"], "A", "3.3", "Understand", "Moderate"),

 ("The water cycle never stops because",
  ["new water is made every day",
   "the sun keeps providing energy and water keeps moving between the earth and the air",
   "people keep using water",
   "it rains only at night"], "B", "3.3", "Understand", "Moderate"),

 ("Even though people use water every day, the total amount of water on the earth does not run out because",
  ["new water is created by the oceans", "rain water is stored for ever",
   "water is made in factories", "water is recycled through the water cycle"],
  "D", "3.3", "Understand", "Moderate"),

 ("Which of the following best describes the water cycle?",
  ["A straight line", "A continuous (never-ending) cycle", "A one-way journey", "A random event"],
  "B", "3.3", "Understand", "Easy"),

 ("A drop of water that falls as rain today may later",
  ["disappear from the earth for ever", "be used up completely",
   "evaporate, form a cloud and fall again as rain", "turn into a new element"],
  "C", "3.3", "Understand", "Moderate"),

 ("After rain falls on the ground, most of the water finally reaches",
  ["rivers, lakes and the sea", "the moon", "the centre of the earth", "outer space"],
  "A", "3.3", "Understand", "Easy"),

 ("Which statement best shows that the water cycle is a pattern in nature?",
  ["It rains only in Ghana.",
   "Water is found only in rivers.",
   "The sun sets every evening.",
   "The same stages of evaporation, condensation and precipitation happen again and again in many places."],
  "D", "3.3", "Understand", "Moderate"),

 ("Which of these is NOT part of the repeated pattern of the water cycle?",
  ["Evaporation from the sea", "Water being boiled in a cooking pot", "Condensation forming clouds",
   "Rain falling on a farm"], "B", "3.3", "Analyse", "Challenging"),

 ("The water cycle is important to the environment mainly because it",
  ["makes the earth spin", "produces electricity",
   "supplies fresh water to plants, animals and people", "creates new land"],
  "C", "3.4", "Understand", "Easy"),

 ("Which of the following depends on the water cycle for survival?",
  ["All living things", "Only fish", "Only crops", "Only human beings"],
  "A", "3.4", "Understand", "Easy"),

 ("The water cycle helps to keep rivers and lakes from drying up by",
  ["freezing them", "making them salty", "filling them with sand",
   "returning water to them through rain"], "D", "3.4", "Understand", "Moderate"),

 ("If the water cycle stopped completely, which of the following would happen first?",
  ["The sun would stop shining.",
   "Rain would stop falling and plants would begin to dry up.",
   "The ocean would dry up in one day.",
   "New water would be created."], "B", "3.4", "Analyse", "Challenging"),

 ("Plants obtain most of the water they need from",
  ["the air only", "the sun", "water in the soil, which is replaced by rain", "melting ice"],
  "C", "3.4", "Understand", "Moderate"),

 ("Animals benefit from the water cycle because it",
  ["refills the rivers, ponds and streams they drink from", "makes them grow larger",
   "gives them energy directly", "protects them from the sun"], "A", "3.4", "Understand", "Moderate"),

 ("The water cycle helps to provide clean water for a community because rain water",
  ["contains no germs at all",
   "is made pure by the sun",
   "never mixes with dust",
   "has fallen from the clouds without dissolving minerals from the ground"],
  "D", "3.4", "Understand", "Challenging"),

 ("Which of the following is the best reason for protecting forests and water bodies?",
  ["They make the land look beautiful.",
   "They help to keep the water cycle working so that water is available for all living things.",
   "They stop the sun from shining.",
   "They are only useful for tourists."], "B", "3.4", "Evaluate", "Challenging"),

 ("Weather is mainly the day-to-day condition of",
  ["the soil", "the ocean floor", "the air - temperature, rain, wind and sunshine - in a place",
   "the plants in a place"], "C", "3.5", "Remember", "Moderate"),

 ("Heavy and frequent rain is most likely to occur when",
  ["there is a lot of evaporation and condensation taking place",
   "the air is very dry and no clouds form",
   "there is no wind at all",
   "the sun is hidden all day"], "A", "3.5", "Apply", "Moderate"),

 ("During the harmattan season in Ghana the weather is usually dry and dusty because",
  ["the sun stops heating the ocean", "it rains every day", "there are too many clouds",
   "the wind blows from the Sahara Desert and brings very little water vapour"],
  "D", "3.5", "Apply", "Challenging"),

 ("An area with many trees is likely to receive more rain than a bare area because",
  ["trees make the air colder", "trees add water vapour to the air through transpiration",
   "trees block the sun completely", "trees store all the rain water"],
  "B", "3.5", "Apply", "Challenging"),

 ("Cloudy weather is usually a sign that",
  ["no water vapour is present", "precipitation has stopped for ever",
   "condensation is taking place in the atmosphere", "evaporation has stopped"],
  "C", "3.5", "Understand", "Moderate"),

 ("A weather forecast says that rain is likely tomorrow. The most likely sign in the sky is",
  ["many dark, thick clouds", "a clear blue sky", "a bright, cloudless sun", "a full moon"],
  "A", "3.5", "Apply", "Easy"),
]

# --------------------------------------------------------- SECTION B DIAGRAM
WATER_CYCLE = [
    "                        2  CONDENSATION",
    "                 (water vapour cools and forms clouds)",
    "                    ^                             |",
    "                    |                             v",
    "                    |                  3  PRECIPITATION",
    "    1  EVAPORATION  |                    (water falls as rain)",
    " (the sun heats     |                             |",
    "  water and it      |                             v",
    "  rises as vapour)  |          RIVERS * LAKES * OCEANS * SOIL",
    "                    ^                             ^",
    "                    |                             |",
    "                    |                  4  TRANSPIRATION",
    "                    |           (water vapour lost from leaves)",
    "                    +--------------------------------+",
]

SECTION_B = [
 dict(
   num=1, total=10, topic="3.1",
   stem="Water is found in many natural sources in the environment.",
   parts=[
     ("(a)", "Name four natural sources of water.", 4, "Remember", "3.1", "Easy"),
     ("(b)", "State two differences between surface water and underground (ground) water.",
      2, "Understand", "3.1", "Moderate"),
     ("(c)", "Explain why rainwater is usually described as the purest natural water.",
      2, "Understand", "3.1", "Moderate"),
     ("(d)", "A classmate says that a borehole is a natural source of water because the water comes from "
             "the ground. Do you agree? Give a reason for your answer.",
      2, "Evaluate", "3.1", "Challenging"),
   ]),
 dict(
   num=2, total=9, topic="3.2",
   stem="The diagram below shows the stages of the water cycle. Study it and answer the questions that follow.",
   diagram=True,
   parts=[
     ("(a)", "Name the processes shown at 1, 2, 3 and 4.", 4, "Remember", "3.2", "Easy"),
     ("(b)", "Explain what happens during the process labelled 1.", 2, "Understand", "3.2", "Moderate"),
     ("(c)", "Explain what happens during the process labelled 2.", 2, "Understand", "3.2", "Moderate"),
     ("(d)", "Name the process by which plants lose water vapour.", 1, "Remember", "3.2", "Easy"),
   ]),
 dict(
   num=3, total=6, topic="3.2",
   stem="The four stages of the water cycle are linked to each other.",
   parts=[
     ("(a)", "State one difference between evaporation and transpiration.",
      2, "Understand", "3.2", "Moderate"),
     ("(b)", "Explain how clouds are formed.", 2, "Understand", "3.2", "Moderate"),
     ("(c)", "State two things that can happen to rain water after it falls on the ground.",
      2, "Understand", "3.2", "Moderate"),
   ]),
 dict(
   num=4, total=10, topic="3.3",
   stem="The water cycle is described as a repeated pattern of change in nature.",
   parts=[
     ("(a)", "Explain what is meant by the statement that the water cycle is a repeated pattern in nature.",
      3, "Understand", "3.3", "Moderate"),
     ("(b)", "State two reasons why the water cycle never stops.", 2, "Understand", "3.3", "Moderate"),
     ("(c)", "Explain why the total amount of water on the earth does not run out even though people use "
             "water every day.", 3, "Analyse", "3.3", "Challenging"),
     ("(d)", "Explain why the water cycle is described as a cycle and not as a straight line.",
      2, "Understand", "3.3", "Moderate"),
   ]),
 dict(
   num=5, total=10, topic="3.4",
   stem="The water cycle is important in nature in several ways.",
   parts=[
     ("(a)", "State three ways in which the water cycle is important in nature.",
      3, "Understand", "3.4", "Easy"),
     ("(b)", "Explain what is meant by the statement that the water cycle improves the water table.",
      3, "Understand", "3.4", "Moderate"),
     ("(c)", "Explain how the water cycle acts as a carrier of nutrients for plants.",
      4, "Apply", "3.4", "Challenging"),
   ]),
 dict(
   num=6, total=9, topic="3.5",
   stem="The water cycle also affects the weather of a place.",
   parts=[
     ("(a)", "State two ways in which the water cycle affects the weather.",
      2, "Understand", "3.5", "Moderate"),
     ("(b)", "Explain why an area with many trees is likely to receive more rain than a bare, dry area.",
      3, "Apply", "3.5", "Challenging"),
     ("(c)", "Explain why the harmattan season in Ghana is usually dry and dusty.",
      4, "Apply", "3.5", "Moderate"),
   ]),
 dict(
   num=7, total=6, topic="3.2",
   stem="A class wants to show one of the stages of the water cycle in the laboratory.",
   parts=[
     ("(a)", "Describe how you would show, using a glass, ice and water, that water vapour in the air "
             "condenses.", 3, "Create", "3.2", "Challenging"),
     ("(b)", "State what you would observe and the conclusion you would draw.",
      2, "Analyse", "3.2", "Moderate"),
     ("(c)", "Name the stage of the water cycle shown by the experiment.", 1, "Remember", "3.2", "Easy"),
   ]),
]

# ------------------------------------------------------- MARKING SCHEME
MARKING = {
 1: [
   ("(a)", ["Rain", "Rivers", "Streams", "Lakes", "Ponds", "Springs", "The ocean (sea)",
            "Ground water (underground water)"],
    "1 mark each for any FOUR correct natural sources (4 marks). Accept 'wells' only if the pupil makes "
    "clear that they reach ground water. Do NOT accept 'tap water', 'a dam', 'a water tank' or "
    "'sachet water'."),
   ("(b)", ["Surface water flows over the land (rivers, lakes, streams) while underground water is held "
            "in the soil and rocks below the surface.",
            "Surface water is easy to see and to reach while underground water has to be reached by "
            "digging a well or drilling a borehole.",
            "Surface water dries up quickly in a drought while underground water lasts longer."],
    "1 mark each for any TWO correct differences (2 marks). The difference must say something about BOTH "
    "types of water, not just one."),
   ("(c)", ["Rain water comes straight from the clouds.",
            "It has not flowed over or through the ground, so it has not dissolved minerals and salts "
            "from the soil and rocks."],
    "1 mark for stating that rain falls directly from the clouds. 1 mark for stating that it has not "
    "picked up dissolved minerals / salts from the ground. Do NOT award a mark for 'it is safe to "
    "drink' - rain water can still collect dust and germs from the air."),
   ("(d)", ["Disagree. A borehole is a hole that people drill to reach water; the natural source is the "
            "ground water itself, which the borehole taps.",
            "Accept 'partly agree' only if the pupil explains that the water is natural but the borehole "
            "itself is made by people."],
    "2 marks. Award 1 mark for a clear position (disagree / no) and 1 mark for a correct reason "
    "distinguishing the ground water from the hole that reaches it. A bare 'no' scores 0."),
 ],
 2: [
   ("(a)", ["1 = evaporation", "2 = condensation", "3 = precipitation", "4 = transpiration"],
    "1 mark each (4 marks). The number must be matched to the correct process. Accept 'rainfall' for 3. "
    "Do NOT award a mark if the label number is missing."),
   ("(b)", ["The sun heats water in rivers, lakes, oceans and the soil.",
            "The water changes into water vapour and rises into the air."],
    "1 mark for the sun heating the water. 1 mark for the water changing to water vapour and rising. "
    "Accept 'the water dries up and goes into the air' for 1 mark only."),
   ("(c)", ["The water vapour rises and cools as it goes higher.",
            "It changes back into tiny liquid droplets, which gather together to form clouds."],
    "1 mark for the vapour cooling. 1 mark for the formation of tiny droplets / clouds. Do NOT award a "
    "mark for 'it turns into rain' - that is precipitation, not condensation."),
   ("(d)", ["Transpiration."], "1 mark. Accept 'transpiration (loss of water vapour from leaves)'."),
 ],
 3: [
   ("(a)", ["Evaporation is the loss of water from surfaces such as rivers, lakes, oceans and wet soil, "
            "while transpiration is the loss of water vapour from the leaves of plants.",
            "Evaporation happens from any wet surface; transpiration happens only in plants."],
    "1 mark each for any TWO correct points (2 marks). The answer must make the difference clear. Do NOT "
    "award a mark for naming the two processes without a difference."),
   ("(b)", ["Water vapour rises into the air from evaporation and transpiration.",
            "As it rises it cools.",
            "The cooled vapour condenses into tiny droplets of water around small dust particles.",
            "Millions of these tiny droplets gather together to form a cloud."],
    "1 mark each for any TWO correct points (2 marks). Accept a clear two-step answer (vapour rises and "
    "cools, then condenses into droplets)."),
   ("(c)", ["It soaks into the ground to become ground water (it improves the water table).",
            "It runs over the surface into streams, rivers, lakes and the sea.",
            "It is taken up by the roots of plants.",
            "It evaporates back into the air."],
    "1 mark each for any TWO correct points (2 marks). Accept 'it is stored in a dam' as an additional "
    "correct point."),
 ],
 4: [
   ("(a)", ["The same stages - evaporation, condensation and precipitation - follow each other in the "
            "same order over and over again.",
            "Water keeps moving round and round between the earth and the air; it never stops or starts "
            "at one point.",
            "The pattern can be seen happening again and again in many different places."],
    "1 mark each for any THREE correct points (3 marks). Accept any answer that gives the idea of the "
    "same sequence happening repeatedly. Do NOT award three marks for the same point repeated."),
   ("(b)", ["The sun keeps supplying the energy needed for evaporation.",
            "Water keeps moving between the surface of the earth and the air.",
            "Gravity keeps pulling the water back down as precipitation."],
    "1 mark each for any TWO correct reasons (2 marks). Accept 'the sun never stops shining on the "
    "earth' with the link to evaporation."),
   ("(c)", ["Water is not used up - it only changes form and moves from one place to another.",
            "The water we use goes back into the environment (through washing, sweat, sewage and "
            "evaporation).",
            "The water cycle collects it, cleans it by evaporation and returns it as rain.",
            "So the same water is recycled over and over again."],
    "1 mark each for any THREE correct points (3 marks). The key idea is recycling rather than new water "
    "being made. Do NOT award a mark for 'because new water is created'."),
   ("(d)", ["A cycle returns to where it started, and the water cycle does exactly that: water leaves "
            "the surface, forms clouds and falls back to the surface.",
            "A straight line has a beginning and an end, but the water cycle has neither - it keeps "
            "going round and round."],
    "1 mark each for any TWO correct points (2 marks). Accept a clearly explained 'it comes back to the "
    "start'."),
 ],
 5: [
   ("(a)", ["It provides clean water for drinking, washing and farming.",
            "It carries nutrients to plants and animals.",
            "It improves the water table (replaces underground water).",
            "It regulates the weather pattern of a place.",
            "It releases energy that warms the environment."],
    "1 mark each for any THREE correct points (3 marks). All five points above are taken from the "
    "curriculum exemplar and are equally acceptable."),
   ("(b)", ["The water table is the level below which the ground is full of water.",
            "Rain soaks into the soil and rocks and refills the underground water store.",
            "So the water cycle keeps the water table from falling and keeps wells and boreholes "
            "supplied with water."],
    "1 mark each for any THREE correct points (3 marks). Award at least 1 mark for the idea that "
    "rainwater soaks into the ground and replaces underground water."),
   ("(c)", ["Rain water dissolves minerals in the soil as it soaks in.",
            "The water carries these dissolved minerals (nutrients) down to the roots of plants.",
            "Plants take up the nutrients with the water and use them to grow.",
            "Extra water also washes nutrients from decaying matter into the soil where roots can "
            "reach them."],
    "1 mark each for any FOUR correct points (4 marks). Award at least 1 mark for stating that water "
    "carries dissolved minerals to the roots of plants. Accept 'rivers carry fertile silt on to farm "
    "land' as one correct point."),
 ],
 6: [
   ("(a)", ["It determines how much rain falls in a place and when.",
            "It determines how cloudy or sunny the weather is.",
            "It affects how humid (how much water vapour is in the air) a place is.",
            "It affects temperature, because evaporation and condensation move heat around."],
    "1 mark each for any TWO correct points (2 marks). Accept 'it brings the rainy season and the dry "
    "season'."),
   ("(b)", ["Trees lose a lot of water vapour through transpiration.",
            "This adds extra water vapour to the air above the forest.",
            "More water vapour means more condensation, so more clouds form.",
            "With more clouds there is a greater chance of rain."],
    "1 mark each for any THREE correct points (3 marks). The chain must link transpiration, extra water "
    "vapour and increased cloud/rain formation. Do NOT award a mark for 'trees attract rain' on its own."),
   ("(c)", ["In the harmattan the wind blows from the Sahara Desert, across the dry lands to the north.",
            "That air contains very little water vapour.",
            "With little water vapour there is little condensation, so few clouds form and no rain falls.",
            "The same wind carries fine dust from the desert, which makes the air dusty and hazy."],
    "1 mark each for any FOUR correct points (4 marks). Award at least 1 mark for naming the wind from "
    "the Sahara and 1 mark for the link to very little water vapour."),
 ],
 7: [
   ("(a)", ["Dry the outside of a glass and fill it with cold water and some ice cubes.",
            "Leave the glass to stand in the room for a few minutes.",
            "Watch the outside of the glass (and feel it) to see what forms on it."],
    "1 mark for preparing the glass with cold water and ice (and drying the outside first). 1 mark for "
    "leaving it to stand. 1 mark for observing the outside surface of the glass. Accept any safe, "
    "workable method. Award method marks even if the conclusion is poorly worded."),
   ("(b)", ["Observation: droplets of water form on the outside of the cold glass.",
            "Conclusion: water vapour in the warm air touched the cold glass, cooled down and changed "
            "back into liquid water."],
    "1 mark for the observation (droplets on the outside of the glass). 1 mark for the conclusion that "
    "water vapour in the air cooled and turned back to liquid. Do NOT accept 'the water leaked through "
    "the glass'."),
   ("(c)", ["Condensation."], "1 mark."),
 ],
}


# --------------------------------------------- derive summary statistics
def topic_totals():
    m = {k: 0 for k in TOPIC}
    it = {k: 0 for k in TOPIC}
    for q in MCQ:
        m[q[3]] += 1
        it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk
            it[key] += 1
    return m, it

def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}
    b = {k: 0 for k in order}
    for q in MCQ:
        a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            b[cog] += mk
    return order, a, b

def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ:
        d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            d[diff] += mk
    return d
