# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "/home/user")
from build_energy import *

L = []
def w(s=""): L.append(s)

w(f"# {SCHOOL}"); w()
w(f"## {SUBJECT}"); w()
w(f"### {EXAM}"); w()
w(f"**Class:** {CLASS}  ")
w(f"**Time:** {TIME}  ")
w(f"**Total Marks:** {MARKS}  ")
w(f"**Academic Year:** {YEAR}"); w()
w("---"); w()
w("### INSTRUCTIONS"); w()
for i, t in enumerate([
    "Write your name and class clearly in the spaces provided on your answer sheet.",
    "This paper has TWO sections: Section A and Section B.",
    "Answer ALL the questions in both sections.",
    "Section A has 40 multiple-choice questions. Each question carries 1 mark. Choose the best answer (A, B, C or D) and record it on the answer sheet provided.",
    "Section B has 7 theory questions totalling 60 marks. Write your answers clearly and neatly in your answer booklet. Draw and label diagrams or tables where you are asked to.",
    "Read every question carefully before you answer it.",
    "Do not use correction fluid. Cancel any mistake neatly with a single line.",
    "Hand in your answer sheet and your answer booklet at the end of the examination.",
], start=1):
    w(f"{i}. {t}")
w(); w("---"); w()

w("## SECTION A: OBJECTIVE TEST (40 marks)"); w()
w("*Answer ALL questions. Each question carries 1 mark. Choose the BEST answer and write its letter "
  "(A, B, C or D) against the question number on your answer sheet.*"); w()
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"**{i}. {q}**"); w()
    for j, o in enumerate(opts): w(f"{'ABCD'[j]}. {o}")
    w()
w("---"); w()

w("## SECTION B: THEORY (60 marks)"); w()
w("*Answer ALL questions. Write your answers in your answer booklet. The marks for each question are shown "
  "in brackets.*"); w()
for qb in SECTION_B:
    w(f"### Question {qb['num']}  [{qb['total']} marks]"); w()
    w(qb["stem"]); w()
    if qb.get("table") == "energy":
        w("| " + " | ".join(EN_HEADERS) + " |")
        w("| " + " | ".join(["---"] * len(EN_HEADERS)) + " |")
        for r in EN_ROWS:
            w("| " + " | ".join(r) + " |")
        w()
        w("*Table 1: Forms of energy*"); w()
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        w(f"**{lab}** {text}  **[{mk} mark{'s' if mk > 1 else ''}]**"); w()
w("---"); w()

w("## ANSWER KEY"); w()
w("### Section A - Objective Test"); w()
w("| Question | Answer | Curriculum Area (Topic) | Cognitive Level |")
w("| -------- | ------ | ----------------------- | --------------- |")
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"| {i} | {ans} | {TOPIC[tp]} | {cog} |")
counts = {L2: sum(1 for q in MCQ if q[2] == L2) for L2 in "ABCD"}
w()
w("Correct-answer distribution: " + ", ".join(f"{L2} = {counts[L2]}" for L2 in "ABCD") + " (40 items).")
w()
w("### Section B - Theory (summary answers; full detail in the Marking Scheme)"); w()
w("| Question | Expected Answer | Curriculum Area | Cognitive Level |")
w("| -------- | --------------- | --------------- | --------------- |")
sba = [
 ("1 (a)", "Energy is the ability to do work. The SI unit of energy is the joule (J).", "11.1", "Understand"),
 ("1 (b)", "Any three of: lighting a room with a bulb (electrical); cooking food (heat); ringing the school bell (electrical/sound); moving a car or tro-tro (chemical in fuel); playing a radio (electrical); ironing a uniform (heat).", "11.1", "Remember"),
 ("1 (c)", "No - the water has potential energy because it is high above the ground, and if the tap were opened it would fall and could do work, so it could change into kinetic energy.", "11.1", "Evaluate"),
 ("2 (a)", "(i) the energy a body has because of its position or height, or because it is stretched; (ii) the energy a body has because it is moving; (iii) a charcoal pot or a pressing iron; (iv) the energy that travels through the air and makes our ears hear; (v) energy that comes from the sun; (vi) energy stored in food, in fuel and in dry cells and batteries.", "11.2", "Understand"),
 ("2 (b)", "Electrical energy and nuclear energy.", "11.2", "Remember"),
 ("2 (c)", "Electrical energy is used to light the home, to run a fridge or to power a radio. Nuclear energy is used in a nuclear power station to generate electricity, and in medicine such as X-rays.", "11.2", "Understand"),
 ("3 (a)", "Potential energy is the energy a body has because of its position or height, or because it is stretched; kinetic energy is the energy a body has because it is moving.", "11.3", "Understand"),
 ("3 (b)", "At the top the stone has its greatest potential energy and hardly any kinetic energy. As it falls the potential energy decreases and changes into kinetic energy, so the stone speeds up. Just before it hits the ground the kinetic energy is highest and the potential energy is almost zero.", "11.3", "Analyse"),
 ("3 (c)", "Mechanical energy is the total energy a body has because of its position and its motion. Mechanical Energy = Potential Energy + Kinetic Energy (ME = PE + KE).", "11.3", "Understand"),
 ("4 (a)", "PE = mgh = 40 x 10 x 2 = 800 J.", "11.4", "Apply"),
 ("4 (b)", "KE = 1/2 mv2 = 1/2 x 0.5 x 20 x 20 = 100 J.", "11.4", "Apply"),
 ("4 (c)", "(i) PE = mgh = 3 x 10 x 4 = 120 J. (ii) The kinetic energy just before it hits the ground is also 120 J, because all the potential energy at the top has changed into kinetic energy.", "11.4", "Apply"),
 ("5 (a)", "(i) a pressing iron - electrical energy; (ii) a radio - electrical energy; (iii) a solar calculator - solar energy; (iv) a kerosene lamp - chemical energy stored in the kerosene.", "11.5", "Understand"),
 ("5 (b)", "Heat energy is used at home to cook food, to boil water or to iron clothes. Sound energy is used at school when the bell is rung to end lessons, or when the teacher speaks and the pupils hear.", "11.5", "Understand"),
 ("5 (c)", "Solar energy (energy from the sun). One reason: it costs nothing, or it does not smoke the maize the way a fire does.", "11.5", "Understand"),
 ("6 (a)", "Conduction - heat passes through a solid from particle to particle. Convection - heat is carried through a liquid or a gas by the liquid or the gas itself moving. Radiation - heat travels as waves and needs no material at all.", "11.6", "Understand"),
 ("6 (b)", "Fix one end of a metal rod in a flame and stick drawing pins or wax along it. The far end becomes hot and the pins drop off one after another, starting from the hot end, which shows that heat has travelled along the metal.", "11.6", "Create"),
 ("6 (c)", "Radiation. The sun's heat crosses the air and the glass without heating the air much, the seats and glass absorb it, and the warm air is then trapped inside the closed car.", "11.6", "Analyse"),
 ("7 (a)", "Take three pieces of cardboard with a hole in each, stand them in a straight line and put a lit candle behind the first. The flame can be seen only when the three holes are in one straight line; move one card sideways and it disappears.", "11.7", "Apply"),
 ("7 (b)", "Reflection is the bouncing back of light when it falls on a shiny or polished surface such as a mirror. Refraction is the bending of light as it passes from one material into another, for example from air into water.", "11.7", "Understand"),
 ("7 (c)", "The process is dispersion. Sunlight is made of seven colours; when it enters a raindrop it is refracted and each colour bends by a different amount, so the colours separate and appear as a rainbow.", "11.7", "Understand"),
]
for r in sba: w(f"| {r[0]} | {r[1]} | {r[2]} | {r[3]} |")
w(); w("---"); w()

w("## MARKING SCHEME - SECTION B (60 marks)"); w()
w("*General rules: (1) Accept any other correct and relevant answer. (2) Award marks for correct points, not "
  "for repeating the question. (3) For procedures, award method marks. (4) Do not deduct marks for spelling "
  "unless the meaning is changed. (5) Where a candidate gives more answers than are asked for, mark only the "
  "first ones up to the number required.*"); w()
for qb in SECTION_B:
    n = qb["num"]
    w(f"### Question {n} ({qb['total']} marks)"); w()
    for (lab, points, note) in MARKING[n]:
        mkv = [p_[2] for p_ in qb["parts"] if p_[0] == lab]
        head = f"**{lab}**"
        if mkv: head += f" [{mkv[0]} mark{'s' if mkv[0] > 1 else ''}]"
        w(head); w()
        for pt in points: w(f"- {pt}")
        w(f"  - *Marking note: {note}*"); w()
w("---"); w()

w("## CURRICULUM ASSESSMENT BLUEPRINT"); w()
w(f"**Strand:** {STRAND} | **Sub-strand:** {SUBSTRAND} | **Class:** {CLASS}"); w()
w(f"**Content Standard:** {CS} - {CS_TEXT}"); w()
w("> Source: NaCCA Science Common Core Programme Curriculum (B7/JHS1-B9/JHS3), September 2020, "
  "Strand 4: Forces and Energy, Sub-strand 1: Energy, pp. 26-29. Indicators are quoted, not "
  "invented."); w()

w("### Section A"); w()
w("| Qn | Sub-strand | Content Standard | Indicator (NaCCA) - Indicator Text | Topic / Content | Cognitive Level | Marks |")
w("| -- | ---------- | ---------------- | ---------------------------------- | --------------- | --------------- | ----- |")
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"| A{i} | {SUBSTRAND} | {CS_BY_TOPIC[tp]} | {IND[tp]} - {IND_TEXT[tp]} | {TOPIC[tp]} | {cog} | 1 |")
w()
w("### Section B"); w()
w("| Qn | Sub-strand | Content Standard | Indicator (NaCCA) - Indicator Text | Topic / Content | Cognitive Level | Marks |")
w("| -- | ---------- | ---------------- | ---------------------------------- | --------------- | --------------- | ----- |")
for qb in SECTION_B:
    for (lab, text, mkv, cog, tp, diff) in qb["parts"]:
        key = tp if tp in TOPIC else tp.split(",")[0].strip()
        w(f"| B{qb['num']}{lab.strip('()')} | {SUBSTRAND} | {CS_BY_TOPIC[key]} | {IND[key]} - {IND_TEXT[key]} | {TOPIC[key]} | {cog} | {mkv} |")
w(); w("---"); w()

def topic_totals():
    m = {k: 0 for k in TOPIC}; it = {k: 0 for k in TOPIC}
    for q in MCQ: m[q[3]] += 1; it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk; it[key] += 1
    return m, it

def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}; b = {k: 0 for k in order}
    for q in MCQ: a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: b[cog] += mk
    return order, a, b

def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ: d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: d[diff] += mk
    return d

m, it = topic_totals(); diff_ = difficulty_totals(); order, ca, cb = cognitive_by_section()

w("### Summary 1 - Coverage by Curriculum Area (Topic)"); w()
w("| Topic / Content Area | No. of Items | Marks | % of Total Marks | Core Competencies |")
w("| -------------------- | ------------ | ----- | ---------------- | ----------------- |")
for k in TOPIC: w(f"| {TOPIC[k]} | {it[k]} | {m[k]} | {(m[k]/100)*100:.1f}% | {CC[k]} |")
w(f"| **TOTAL** | **{sum(it.values())}** | **{sum(m.values())}** | **100%** | - |")
w()
w("*CC = Communication and Collaboration; CP = Critical Thinking and Problem Solving; DL = Digital Literacy; "
  "CI = Creativity and Innovation.*"); w()
w("### Summary 2 - Cognitive-Level Distribution (Bloom's Taxonomy)"); w()
w("| Cognitive Level | Section A Marks | Section B Marks | Total Marks | % of Total |")
w("| --------------- | --------------- | --------------- | ----------- | ---------- |")
for lv in order:
    tot = ca[lv] + cb[lv]
    w(f"| {lv} | {ca[lv]} | {cb[lv]} | {tot} | {(tot/100)*100:.1f}% |")
w(f"| **TOTAL** | **{sum(ca.values())}** | **{sum(cb.values())}** | **{sum(ca.values())+sum(cb.values())}** | **100%** |")
w()
w("### Summary 3 - Difficulty Distribution"); w()
w("| Difficulty | Marks | % of Total Marks |")
w("| ---------- | ----- | ---------------- |")
for k, v in diff_.items(): w(f"| {k} | {v} | {(v/100)*100:.1f}% |")
w(f"| **TOTAL** | **{sum(diff_.values())}** | **100%** |")
w()
w("*Target in the master prompt: approximately 30% easy / 50% moderate / 20% challenging.*"); w()
w("### Summary 4 - Section Weighting"); w()
w("| Section | Question Type | Items | Marks | % of Total |")
w("| ------- | ------------- | ----- | ----- | ---------- |")
w("| A | Objective (multiple choice) | 40 | 40 | 40% |")
w("| B | Theory / constructed response | 21 | 60 | 60% |")
w("| **TOTAL** | - | **61** | **100** | **100%** |")
w(); w("---"); w()

w("## QUALITY-CONTROL SUMMARY")
w("")
w("| Check | Status |")
w("| --- | --- |")
for q_, a_ in [
 ("Every question within supplied curriculum scope",
  "Yes - all 61 items (40 objectives and 21 theory sub-questions) sit in topics 11.1-11.7 of Strand 4, Sub-Strand 1 (Energy), mapped to indicators B7/JHS1.4.1.1.1, B7/JHS1.4.1.1.2, B7/JHS1.4.1.2.1 and B7/JHS1.4.1.3.1"),
 ("Appropriate for the class",
  "Yes - B7 level; every calculation uses g = 10 m/s2 and round numbers, and no item needs algebra beyond substitution into a given formula. The conservation principle is left to Sub-strand 3 (B7/JHS1.4.3.1.1)"),
 ("Genuinely BECE-style",
  "Yes - 40 four-option objectives plus structured theory with printed mark allocations and a completion table"),
 ("Sufficient application and reasoning",
  "Yes - 32 of 100 marks (32%) at Apply level or above (Apply 20, Analyse 6, Evaluate 3, Create 3)"),
 ("Plausible MCQ distractors",
  "Yes - another form of energy, a quantity that is not a form of energy at all, a wrong unit, a wrong formula with the right letters, and the common arithmetic slips of forgetting to square the speed or of using the wrong factor"),
 ("Single best answer per MCQ",
  "Yes - reviewed item by item; special care with A9, where heat energy is not offered because heat from the sun is solar energy, and A23, where a kerosene lamp USES chemical energy even though it PRODUCES light"),
 ("Marks internally consistent",
  "Yes - Section A 40 x 1 = 40; Section B 8 + 10 + 9 + 9 + 8 + 8 + 8 = 60; sub-question marks match the marking scheme"),
 ("Total adds up correctly",
  "Yes - 40 + 60 = 100"),
 ("Answer key correct",
  "Yes - all 40 keys and all 21 Section B answers verified against the marking scheme; the three calculations were checked independently (800 J, 100 J, 120 J)"),
 ("Marking scheme matches questions",
  "Yes - expected answers plus marking notes covering partial credit, alternatives, common wrong answers and method marks; each calculation is split into a formula mark, a substitution mark and an answer mark"),
 ("Free from unnecessary ambiguity",
  "Yes - open items are anchored with 'name three' and 'state one' plus the mark allocation; Question 2(a) numbers every blank (i) to (vi), Question 4 states that g = 10 m/s2 and that working must be shown, and Question 6(a) asks for what moves in each method"),
 ("Ghanaian contexts natural and accurate",
  "Yes - water behind the Akosombo Dam, a tro-tro on the Accra-Kumasi road, a car parked in the sun at Madina, maize drying on a mat, a charcoal pot, a kerosene lantern, a solar panel on a house roof, a water tank on a two-storey building, and the school bell ending lessons"),
 ("No content beyond the curriculum",
  "No - the nine forms tested are exactly the nine named in exemplar 1 of B7/JHS1.4.1.1.1; no item asks about energy conversion chains, electricity generation or electronic components"),
 ("Questions sufficiently varied",
  "Yes - definition, listing, judging a claim, completing a comparison table, identifying the two missing forms, calculation with working, matching appliances to forms of energy, describing the three heat-transfer methods, planning two class activities, and explaining a rainbow"),
]:
    w("| " + q_ + " | " + a_ + " |")
w("")
w("### EXAMINER NOTES")
w("")
for n_ in [
 "Questions 6(b) and 7(a) are the two design tasks, and they come straight from the exemplars - 'carry out an activity to show how heat is transferred' and 'perform experiments to show that light travels in a straight line'. Award method marks generously: any workable plan that is clearly described deserves credit, even if the apparatus is not the one in the scheme.",
 "Question 4 is the calculation question, and it is marked in three steps - formula, substitution, answer - so a pupil who forgets to square the 20 in KE = 1/2 mv2 still earns the formula mark. Remind pupils to write the formula first and to show the substitution, because an answer alone loses two marks.",
 "The single most common error in this sub-strand is saying that potential energy 'finishes' or 'is used up' as a body falls. Question 3(b) is written to catch it, and the marking note allows at most 2 of 3 marks if the pupil says the energy disappears.",
 "Question 2(a) is the completion table. The six blanks are numbered (i) to (vi), so marking is quick and fair: 1 mark each, and the blank number must be matched to the answer.",
 "Watch for the pair of confusions in Question 5(a): a kerosene lamp USES chemical energy even though it PRODUCES light, and a solar calculator USES solar energy. The note tells you which answer to accept for each.",
 "Topic weightings are deliberately even here - every topic carries 14 or 15 marks - because the content standard covers three separate ideas (forms of energy, heat transfer, and light). If your scheme of work spent longer on one of them, move marks towards Questions 2 to 4, 6 or 7.",
 "B7 does not expect pupils to state the law of conservation of energy; that is Sub-strand 3 (B7/JHS1.4.3.1.1). Here they only need to say that PE changes into KE, which Question 3(b) and Question 4(c)(ii) both test.",
 "If your school has a science set, run the three-card activity and the drawing-pin-on-a-rod activity before the mock. Pupils who have done them write far better answers to Questions 6(b) and 7(a).",
 "Edit the school name, academic year and examination title on page 1 before printing.",
 "This is an original, teacher-made mock. It is not a reproduction of any WAEC or NaCCA examination paper.",
]:
    w("- " + n_)
w()

open("/home/user/Basic7_Integrated_Science_Mock_Strand4_Energy.md", "w", encoding="utf-8").write("\n".join(L))
print("md written", len("\n".join(L)), "chars")
