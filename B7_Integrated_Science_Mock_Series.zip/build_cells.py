# -*- coding: utf-8 -*-
"""Basic 7 Integrated Science mock - Strand 1 Sub-strand 2: LIVING CELLS. 100 marks.
Indicators sourced from the official NaCCA Science CCP curriculum (B7/JHS1-B9/JHS3, Sept 2020),
Strand 1: Diversity of Matter, Sub-strand 2: Living Cells, printed pages 5-6."""

SCHOOL = "[SCHOOL NAME]"
SUBJECT = "INTEGRATED SCIENCE (SCIENCE)"
EXAM = "END-OF-TERM MOCK EXAMINATION"
CLASS = "Basic 7 (JHS 1)"
TIME = "2 hours (Suggested: Section A - 40 min; Section B - 80 min)"
MARKS = "100"
YEAR = "2025/2026 Academic Year"

STRAND = "Diversity of Matter"
SUBSTRAND = "Living Cells"

TOPIC = {
    "2.1": "2.1 What is a Cell? Introduction to Living Cells",
    "2.2": "2.2 Structure and Functions of the Animal Cell",
    "2.3": "2.3 Organelles of the Animal Cell and Their Functions",
    "2.4": "2.4 Structure and Functions of the Plant Cell",
    "2.5": "2.5 Organelles of the Plant Cell and Their Functions",
    "2.6": "2.6 Differences and Similarities Between Plant and Animal Cells",
}

CS = "B7/JHS1.1.2.1"
CS_TEXT = "Demonstrate understanding of the structure of organisms and functions of cells in living systems"

IND = {
    "2.1": "B7/JHS1.1.2.1.1 / .1.2 (Ex. 3)",
    "2.2": "B7/JHS1.1.2.1.1 (Ex. 1, 4)",
    "2.3": "B7/JHS1.1.2.1.1 (Ex. 2, 5)",
    "2.4": "B7/JHS1.1.2.1.2 (Ex. 1, 4)",
    "2.5": "B7/JHS1.1.2.1.2 (Ex. 2)",
    "2.6": "B7/JHS1.1.2.1.1 + B7/JHS1.1.2.1.2 (comparison across both indicators)",
}

IND_TEXT = {
    "2.1": "Conclude, from observing cells with a microscope/magnifier, video or pictures, that animals and "
           "plants are made up of cells.",
    "2.2": "Identify and describe the structure of an animal cell; draw and label an animal cell.",
    "2.3": "State the function of each organelle in the animal cell; develop a model to represent an animal cell.",
    "2.4": "Identify and describe the structure of a plant cell; draw and label a plant cell.",
    "2.5": "State the functions of each organelle in a plant cell.",
    "2.6": "Compare the structures of plant and animal cells to identify their differences and similarities.",
}

CC = {
    "2.1": "CP, CC", "2.2": "CC, DL", "2.3": "CC, CI",
    "2.4": "CC, DL", "2.5": "CP, DL", "2.6": "CP, CC",
}

# ---------------------------------------------------------------- SECTION A
# (question, [A,B,C,D], answer, topic, cognitive, difficulty)
MCQ = [
 ("The basic unit of structure and function of all living things is the",
  ["tissue", "organ", "cell", "system"], "C", "2.1", "Remember", "Easy"),

 ("Which of the following statements about cells is correct?",
  ["All living things are made up of cells.",
   "All living things are made of only one cell.",
   "Only animals and plants are made of cells.",
   "Cells can be seen clearly with the naked eye."], "A", "2.1", "Understand", "Moderate"),

 ("A pupil wants to see the cells in a piece of onion skin. The most suitable instrument to use is a",
  ["telescope", "thermometer", "hand lens", "microscope"], "D", "2.1", "Remember", "Easy"),

 ("All of the following are made up of cells EXCEPT",
  ["a human being", "a maize plant", "a housefly", "a stone"], "D", "2.1", "Understand", "Moderate"),

 ("Kofi looks closely at a leaf with his naked eye but cannot see any cells. The best explanation is that",
  ["a leaf has no cells at all",
   "cells are very small and can only be seen with a microscope",
   "the cells in a leaf are too few to be seen",
   "the cells are hidden inside the leaf stalk"], "B", "2.1", "Understand", "Moderate"),

 ("Which part of a plant would be most suitable to place on a slide in order to see plant cells?",
  ["a thin piece of onion skin", "a whole leaf", "a thick woody stem", "a root covered with soil"],
  "A", "2.1", "Apply", "Moderate"),

 ("Ama cuts her finger. After some days, new cells grow and the cut heals. This shows that",
  ["the skin is not made of cells",
   "new cells can only be made inside a microscope",
   "living things grow and repair themselves by producing new cells",
   "cells are too small to be useful"], "C", "2.1", "Apply", "Moderate"),

 ("Which of the following is NOT part of an animal cell?",
  ["Cell membrane", "Cell wall", "Cytoplasm", "Nucleus"], "B", "2.2", "Understand", "Easy"),

 ("The cell membrane of an animal cell is",
  ["a rigid outer covering",
   "the control centre of the cell",
   "the store for water and salts",
   "a thin, flexible covering that surrounds the cytoplasm"], "D", "2.2", "Understand", "Moderate"),

 ("The part of an animal cell that holds the living material together and controls what enters and leaves "
  "the cell is the",
  ["nucleus", "vacuole", "cell membrane", "cytoplasm"], "C", "2.2", "Understand", "Moderate"),

 ("Which of the following correctly lists four parts of an animal cell?",
  ["Cell membrane, cytoplasm, nucleus and vacuole",
   "Cell wall, cytoplasm, nucleus and chloroplast",
   "Cell wall, cell membrane, chloroplast and vacuole",
   "Chloroplast, cytoplasm, nucleus and cell wall"], "A", "2.2", "Understand", "Moderate"),

 ("An animal cell has no cell wall. Because of this, an animal cell",
  ["is always rectangular in shape",
   "has no fixed shape and is usually round or irregular",
   "cannot take in food",
   "cannot reproduce"], "B", "2.2", "Understand", "Moderate"),

 ("The jelly-like substance in which the other parts of an animal cell are found is the",
  ["nucleus", "cell wall", "chloroplast", "cytoplasm"], "D", "2.2", "Remember", "Easy"),

 ("The part of a cell that controls all the activities of the cell is the",
  ["nucleus", "cytoplasm", "vacuole", "cell membrane"], "A", "2.3", "Remember", "Easy"),

 ("The nucleus is important to a cell because it",
  ["makes food for the cell",
   "controls the cell's activities and contains the hereditary material",
   "gives the cell a rigid shape",
   "stores water and salts only"], "B", "2.3", "Understand", "Moderate"),

 ("The cytoplasm is important because",
  ["it controls the cell",
   "it gives the cell a rigid shape",
   "it is where most of the cell's activities take place",
   "it stores the hereditary material"], "C", "2.3", "Understand", "Moderate"),

 ("Which part of an animal cell releases energy from food during respiration?",
  ["Vacuole", "Cytoplasm", "Cell membrane", "Mitochondrion"], "D", "2.3", "Understand", "Moderate"),

 ("Muscle cells need a lot of energy. Which organelle would you expect to find in large numbers in a "
  "muscle cell?",
  ["Vacuoles", "Chloroplasts", "Mitochondria", "Nuclei"], "C", "2.3", "Apply", "Challenging"),

 ("The cell membrane of a cell is badly damaged. The cell will most likely",
  ["become a plant cell",
   "lose useful substances and take in harmful ones, and may die",
   "grow a cell wall",
   "begin to make its own food"], "B", "2.3", "Apply", "Challenging"),

 ("A scientist carefully removes the nucleus from an animal cell. The most likely result is that the cell",
  ["stops working properly and dies because it has lost its control centre",
   "grows a new cell wall",
   "becomes a plant cell",
   "begins to make its own food"], "A", "2.3", "Analyse", "Challenging"),

 ("Which of the following structures is found in a plant cell but NOT in an animal cell?",
  ["Cell membrane", "Nucleus", "Cytoplasm", "Cell wall"], "D", "2.4", "Understand", "Easy"),

 ("The cell wall of a plant cell is important because it",
  ["makes food for the plant",
   "gives the cell a definite shape and supports the plant",
   "controls what enters and leaves the cell",
   "releases energy from food"], "B", "2.4", "Understand", "Moderate"),

 ("The outermost layer of a plant cell is the",
  ["nucleus", "cytoplasm", "cell wall", "vacuole"], "C", "2.4", "Remember", "Easy"),

 ("Which of the following gives the correct order of structures from the outside of a plant cell going inwards?",
  ["Cell wall, then cell membrane, then cytoplasm",
   "Cytoplasm, then cell membrane, then cell wall",
   "Nucleus, then cytoplasm, then cell wall",
   "Cell membrane, then cell wall, then nucleus"], "A", "2.4", "Understand", "Moderate"),

 ("The cell wall of a plant cell is made mainly of",
  ["starch", "protein", "sugar", "cellulose"], "D", "2.4", "Remember", "Moderate"),

 ("Plant cells usually have a regular, rectangular shape mainly because",
  ["they have a rigid cell wall",
   "they contain chloroplasts",
   "they have a very large nucleus",
   "they have no cytoplasm"], "A", "2.4", "Understand", "Moderate"),

 ("The green substance found in the chloroplasts of a plant cell is",
  ["iodine solution", "cellulose", "chlorophyll", "cytoplasm"], "C", "2.5", "Remember", "Easy"),

 ("The main function of the chloroplast is to",
  ["control the activities of the cell",
   "make food for the plant using sunlight",
   "store water, salts and waste",
   "release energy from food"], "B", "2.5", "Understand", "Moderate"),

 ("The large, permanent space in a plant cell that stores water, salts and some waste products is the",
  ["nucleus", "chloroplast", "cytoplasm", "vacuole"], "D", "2.5", "Understand", "Moderate"),

 ("Chloroplasts are found mostly in the leaves of a plant rather than in the roots because",
  ["leaves need more water than roots",
   "roots have no cells",
   "leaves are exposed to sunlight, which the chloroplasts need in order to make food",
   "roots are not living"], "C", "2.5", "Apply", "Challenging"),

 ("Which of the following correctly pairs a plant cell organelle with its function?",
  ["Cell wall - makes food for the plant",
   "Vacuole - stores water, salts and waste",
   "Chloroplast - controls the activities of the cell",
   "Nucleus - gives the cell a rigid shape"], "B", "2.5", "Analyse", "Challenging"),

 ("A green plant is kept in a dark cupboard for two weeks and its leaves turn yellow. The best explanation "
  "is that",
  ["the chloroplasts cannot make enough food without light",
   "the cell wall breaks down in the dark",
   "the vacuole loses all its water",
   "the nucleus stops working"], "A", "2.5", "Apply", "Challenging"),

 ("Which of the following structures is found in BOTH a plant cell and an animal cell?",
  ["Cell wall", "Chloroplast", "Large permanent vacuole", "Cell membrane"], "D", "2.6", "Understand", "Easy"),

 ("Which of the following is a difference between a plant cell and an animal cell?",
  ["Plant cells have a nucleus but animal cells do not.",
   "Plant cells have a cell wall but animal cells do not.",
   "Animal cells have cytoplasm but plant cells do not.",
   "Animal cells have a cell membrane but plant cells do not."], "B", "2.6", "Understand", "Moderate"),

 ("Which THREE structures are present in a plant cell but absent in an animal cell?",
  ["Nucleus, cytoplasm and cell membrane",
   "Chloroplast, nucleus and mitochondrion",
   "Cell wall, chloroplast and large permanent vacuole",
   "Cell wall, cytoplasm and cell membrane"], "C", "2.6", "Understand", "Moderate"),

 ("One similarity between a plant cell and an animal cell is that both have",
  ["a nucleus", "chloroplasts", "a cell wall", "a large permanent vacuole"], "A", "2.6", "Remember", "Easy"),

 ("A pupil observes a cell under a microscope. The cell has a regular rectangular shape and contains many "
  "small green structures. The pupil is most likely observing",
  ["a virus", "a bacterial cell", "an animal cell", "a plant cell"], "D", "2.6", "Apply", "Moderate"),

 ("A pupil draws an animal cell and then adds a cell wall and chloroplasts to the drawing. The pupil has drawn",
  ["a correct animal cell", "a bacterial cell", "a plant cell", "a virus"], "C", "2.6", "Understand", "Moderate"),

 ("A cell has a cell membrane, cytoplasm, a nucleus and mitochondria, but it has no cell wall and no "
  "chloroplasts. The cell is",
  ["an animal cell because it has no cell wall and no chloroplasts",
   "a plant cell because it has a nucleus",
   "a plant cell because it has mitochondria",
   "neither a plant cell nor an animal cell"], "A", "2.6", "Analyse", "Challenging"),

 ("Kwame says that a plant cell is better than an animal cell because a plant cell can make its own food. "
  "Which of the following is the best scientific response?",
  ["He is right, because animal cells have no nucleus.",
   "Each type of cell is suited to the way its organism lives; plant cells make their own food while "
   "animals obtain food from what they eat.",
   "He is right, because plant cells are the only living cells.",
   "He is wrong, because plant cells cannot make their own food."], "B", "2.6", "Evaluate", "Challenging"),
]

# --------------------------------------------------------- SECTION B DIAGRAMS
ANIMAL_CELL = [
    '              . - - - - - - - - - - - - - - - - - .',
    '            /   2  .  .  .  .  .  .  .  .  .  .  .  \\',
    '           /     .                                .   \\',
    '    1 --> |    .        ______________             .  |',
    '          |   .        /      3       \\             . |',
    '          |   .        \\______________/             . |',
    '          |    .                                   .  |',
    '          |    .       4   (    ~    )             .  |',
    '           \\    .  .  .  .  .  .  .  .  .  .  .  .  . /',
    "            ' - - - - - - - - - - - - - - - - - - - - '"
]

PLANT_CELL = [
    '     1 -> =========================================',
    '     2 -> -----------------------------------------',
    '          |  3  .  .  .  .  .  .  .  .  .  .  .   |',
    '          |  .         ____________               |',
    '          |  .     6  /            \\     4        |',
    '          |  .        \\____________/  _________   |',
    '          |  .                       |         |  |',
    '          |  .     5  ( o )   ( o )  |         |  |',
    '          |  .                       |_________|  |',
    '          |  .  .  .  .  .  .  .  .  .  .  .  .   |',
    '          -----------------------------------------',
    '          ========================================='
]

Q3_TABLE_HEAD = ["Organelle", "Function"]
Q3_TABLE_ROWS = [
    ["Nucleus", "(i)"],
    ["Cytoplasm", "(ii)"],
    ["Cell membrane", "(iii)"],
    ["Mitochondrion", "(iv)"],
]

Q6_TABLE_HEAD = ["Structure", "Plant cell", "Animal cell"]
Q6_TABLE_ROWS = [
    ["Cell wall", "(i)", "(ii)"],
    ["Chloroplast", "Yes", "(iii)"],
    ["Cell membrane", "(iv)", "Yes"],
    ["Nucleus", "Yes", "(v)"],
]

SECTION_B = [
 dict(
   num=1, total=8, topic="2.1",
   stem="Living things are made up of cells.",
   parts=[
     ("(a)", "What is a cell?", 1, "Remember", "2.1", "Easy"),
     ("(b)", "Explain why the cell is described as the basic unit of life.", 2, "Understand", "2.1", "Moderate"),
     ("(c)", "Describe briefly how you would use a microscope to show that a plant is made up of cells.",
      3, "Create", "2.1", "Challenging"),
     ("(d)", "Explain why cells cannot be seen with the naked eye.", 2, "Understand", "2.1", "Moderate"),
   ]),
 dict(
   num=2, total=9, topic="2.2, 2.3",
   stem="The diagram below shows an animal cell. Study it and answer the questions that follow.",
   diagram="animal",
   parts=[
     ("(a)", "Name the parts labelled 1, 2, 3 and 4.", 4, "Remember", "2.2", "Easy"),
     ("(b)", "State the function of the part labelled 1.", 1, "Understand", "2.3", "Moderate"),
     ("(c)", "State the function of the part labelled 3.", 1, "Understand", "2.3", "Moderate"),
     ("(d)", "Explain what would happen to the cell if the part labelled 1 were badly damaged.",
      2, "Analyse", "2.3", "Challenging"),
     ("(e)", "Explain why an animal cell has no fixed shape.", 1, "Understand", "2.2", "Moderate"),
   ]),
 dict(
   num=3, total=9, topic="2.3",
   stem="The table below shows four organelles found in an animal cell. Study it and answer the "
        "questions that follow.",
   table="organelles",
   parts=[
     ("(a)", "Complete the table.", 4, "Understand", "2.3", "Moderate"),
     ("(b)", "A pupil wants to make a model of an animal cell using local materials. Name one material she "
             "could use to represent the cytoplasm and give a reason for your choice.",
      1, "Create", "2.3", "Moderate"),
     ("(c)", "Explain why the mitochondrion is important to the cell.", 2, "Understand", "2.3", "Moderate"),
     ("(d)", "Explain what would happen to a cell whose nucleus has been removed.",
      2, "Analyse", "2.3", "Challenging"),
   ]),
 dict(
   num=4, total=11, topic="2.4, 2.5",
   stem="The diagram below shows a plant cell. Study it and answer the questions that follow.",
   diagram="plant",
   parts=[
     ("(a)", "Name the parts labelled 1, 2, 3, 4, 5 and 6.", 6, "Remember", "2.4", "Easy"),
     ("(b)", "Which TWO of the labelled parts are not found in an animal cell?", 2, "Analyse", "2.5", "Moderate"),
     ("(c)", "State one function of the part labelled 1.", 1, "Understand", "2.4", "Moderate"),
     ("(d)", "State one function of the part labelled 5.", 1, "Understand", "2.5", "Moderate"),
     ("(e)", "Explain why plant cells usually have a regular rectangular shape.",
      1, "Understand", "2.4", "Moderate"),
   ]),
 dict(
   num=5, total=8, topic="2.5",
   stem="Plant cells contain some organelles that animal cells do not have.",
   parts=[
     ("(a)", "Name the green substance found in the chloroplast and state why it is important to the plant.",
      2, "Understand", "2.5", "Easy"),
     ("(b)", "Explain what will happen to a green plant that is kept in a dark cupboard for many days, and "
             "give a reason for your answer.", 3, "Apply", "2.5", "Challenging"),
     ("(c)", "State two functions of the large vacuole in a plant cell.", 2, "Understand", "2.5", "Easy"),
     ("(d)", "State what the cell wall is made of.", 1, "Remember", "2.5", "Easy"),
   ]),
 dict(
   num=6, total=15, topic="2.6",
   stem="Plant cells and animal cells have both differences and similarities. The table below compares them.",
   table="compare",
   parts=[
     ("(a)", "State three differences between a plant cell and an animal cell.",
      3, "Understand", "2.6", "Moderate"),
     ("(b)", "State three structures that are found in BOTH a plant cell and an animal cell.",
      3, "Remember", "2.6", "Easy"),
     ("(c)", "A classmate says: \"A plant cell is just an animal cell with a cell wall added.\" Do you agree? "
             "Give two reasons for your answer.", 4, "Evaluate", "2.6", "Challenging"),
     ("(d)", "Copy and complete the table above by writing YES or NO in the spaces numbered (i) to (v).",
      5, "Understand", "2.6", "Moderate"),
   ]),
]

# ------------------------------------------------------- MARKING SCHEME
MARKING = {
 1: [
   ("(a)", ["A cell is the smallest (basic) unit of structure and function of a living thing.",
            "It is the smallest part of a living thing that can carry out all life processes."],
    "1 mark. Accept any answer that gives the idea of 'smallest / basic unit of a living thing'. Do NOT award "
    "a mark for 'a cell is a small thing' or for naming a cell organelle."),
   ("(b)", ["All living things are made up of cells, so the cell is the building block of every organism.",
            "The cell is the smallest part of an organism that can carry out all the life processes "
            "(feeding, growth, respiration, reproduction).",
            "Nothing smaller than a cell can live and work on its own."],
    "1 mark each for any TWO correct points (2 marks). Do NOT award a mark for simply repeating 'it is the "
    "basic unit of life' without explanation."),
   ("(c)", ["Peel a thin, transparent piece of skin from an onion leaf.",
            "Put it flat on a glass slide, add a drop of water (and a stain such as iodine solution), and "
            "cover it with a cover slip.",
            "Place the slide on the stage of the microscope and focus, first with the low-power lens and "
            "then with the high-power lens.",
            "Observe that the onion skin is made up of many small, box-like compartments, showing that the "
            "plant is made up of cells."],
    "1 mark for preparing a thin specimen on a slide. 1 mark for using the microscope correctly (slide on the "
    "stage, focus with the low-power lens first). 1 mark for stating the observation - many small box-like "
    "compartments - leading to the conclusion that the plant is made of cells. Award method marks even if the "
    "conclusion is poorly worded."),
   ("(d)", ["Cells are extremely small - thousands of them can fit on a pinhead.",
            "The human eye cannot magnify, so it cannot make objects that small large enough to be seen.",
            "A microscope magnifies the cells so that they become visible."],
    "1 mark each for any TWO correct points (2 marks). Accept 'they are too small' developed with the idea of "
    "magnification. Do NOT award both marks for the same point said twice."),
 ],
 2: [
   ("(a)", ["1 = cell membrane", "2 = cytoplasm", "3 = nucleus", "4 = vacuole"],
    "1 mark each (4 marks). The number must be matched to the correct part. Accept 'small vacuole' for 4. "
    "Do NOT award a mark if the label number is missing."),
   ("(b)", ["It holds the cell together (keeps the cytoplasm in).",
            "It controls the movement of substances into and out of the cell."],
    "1 mark. Accept either statement. 'It controls what enters and leaves the cell' is sufficient."),
   ("(c)", ["It controls all the activities of the cell.",
            "It contains the hereditary material (the instructions the cell needs to work and to reproduce)."],
    "1 mark. Accept either statement."),
   ("(d)", ["The cell would no longer be able to control what enters and leaves it.",
            "Useful substances would leak out and harmful substances could enter, so the cell would not work "
            "properly and might die."],
    "1 mark for the idea that the cell loses control over what enters and leaves it. 1 mark for the "
    "consequence (it stops working properly / may die). Do NOT award a mark for 'nothing will happen'."),
   ("(e)", ["An animal cell has no cell wall, so there is nothing rigid to hold it in a fixed shape.",
            "It is surrounded only by a thin, flexible cell membrane, so it is usually round or irregular."],
    "1 mark. The answer must refer to the absence of a cell wall. Do NOT award a mark for 'because it is "
    "soft' on its own."),
 ],
 3: [
   ("(a)", ["(i) It controls all the activities of the cell (and contains the hereditary material).",
            "(ii) It is the jelly-like substance in which the organelles are found and where most of the "
            "cell's activities take place.",
            "(iii) It holds the cell together and controls the movement of substances into and out of the cell.",
            "(iv) It releases energy from food during respiration."],
    "1 mark each (4 marks). Accept equivalent wording. Do NOT accept functions that belong to a different "
    "organelle (e.g. 'the nucleus makes food')."),
   ("(b)", ["e.g. Clear glue / jelly / corn dough - because cytoplasm is a jelly-like (semi-liquid) substance.",
            "e.g. Sand or fine gravel - because cytoplasm contains many small particles."],
    "1 mark for naming a suitable material WITH a matching reason. The reason must link the material to the "
    "fact that cytoplasm is jelly-like / fills the cell. No mark for a material without a reason."),
   ("(c)", ["It releases (sets free) the energy that the cell needs.",
            "The energy is released from the food the cell takes in, during respiration.",
            "Without it the cell would not have the energy to grow, move or repair itself."],
    "1 mark each for any TWO correct points (2 marks). Accept 'it gives the cell energy' once, developed. "
    "Do NOT award a mark for 'it makes food'."),
   ("(d)", ["The cell would lose its control centre.",
            "It would not be able to control its activities, grow or repair itself properly.",
            "It would stop working properly and would eventually die."],
    "1 mark each for any TWO correct points (2 marks). Accept a clear statement that the cell dies, provided "
    "a reason is given."),
 ],
 4: [
   ("(a)", ["1 = cell wall", "2 = cell membrane", "3 = cytoplasm", "4 = vacuole", "5 = chloroplast",
            "6 = nucleus"],
    "1 mark each (6 marks). The number must be matched to the correct part. Accept 'large vacuole' for 4."),
   ("(b)", ["1 (cell wall)", "5 (chloroplast)"],
    "1 mark each (2 marks). Both must be correct. Accept the names written instead of the numbers. Note: a "
    "vacuole (4) is found in animal cells as a small vacuole, so do NOT award a mark for choosing 4."),
   ("(c)", ["It gives the cell a definite (regular) shape.",
            "It supports and protects the plant.",
            "It is strong and rigid and helps the plant to stand upright."],
    "1 mark. Do NOT accept 'it makes food' or 'it controls what enters and leaves the cell'."),
   ("(d)", ["It contains chlorophyll, which traps light energy.",
            "It is where the plant makes its own food (photosynthesis)."],
    "1 mark. Accept either statement."),
   ("(e)", ["The rigid cell wall holds the cell in a fixed, regular shape.",
            "Unlike an animal cell, a plant cell has a cell wall outside its cell membrane."],
    "1 mark. The answer must refer to the cell wall."),
 ],
 5: [
   ("(a)", ["Chlorophyll.",
            "It traps (absorbs) light energy from the sun so that the plant can make its own food by "
            "photosynthesis."],
    "1 mark for naming chlorophyll. 1 mark for stating that it traps/absorbs light energy for making food. "
    "Accept 'it makes the plant green' only as part of a correct answer, not on its own."),
   ("(b)", ["The plant will not be able to make enough food.",
            "It will grow poorly, become weak and yellow, and may eventually die.",
            "Reason: chlorophyll needs light energy to make food, so photosynthesis cannot take place in "
            "the dark."],
    "1 mark for the effect on the plant. 1 mark for a developed effect (yellowing, weak growth, death). "
    "1 mark for the reason, which must refer to the need for light. Award the reason mark for 'there is no "
    "sunlight for photosynthesis'."),
   ("(c)", ["It stores water.",
            "It stores salts, sugars and some waste products.",
            "It helps to keep the cell firm (turgid) so that the plant stands upright."],
    "1 mark each for any TWO correct functions (2 marks). Accept 'it stores sap'."),
   ("(d)", ["Cellulose."], "1 mark. Accept 'cellulose (a carbohydrate)'. Do NOT accept starch."),
 ],
 6: [
   ("(a)", ["Plant cells have a cell wall; animal cells do not.",
            "Plant cells have chloroplasts; animal cells do not.",
            "Plant cells have a large permanent vacuole; animal cells have only small, temporary vacuoles.",
            "Plant cells usually have a regular rectangular shape; animal cells are usually round or "
            "irregular."],
    "1 mark each for any THREE correct differences (3 marks). The difference must state what is true of BOTH "
    "cell types, e.g. 'plant cells have a cell wall but animal cells do not' - not just 'plant cells have a "
    "cell wall'."),
   ("(b)", ["Cell membrane", "Cytoplasm", "Nucleus", "Mitochondria", "Vacuole (small in animal cells)"],
    "1 mark each for any THREE correct structures (3 marks). Accept 'vacuole' with the qualification. Do NOT "
    "accept cell wall, chloroplast or 'large permanent vacuole'."),
   ("(c)", ["Disagree. A plant cell also has chloroplasts, which an animal cell does not have.",
            "Disagree. A plant cell also has a large permanent vacuole, while an animal cell has only small, "
            "temporary vacuoles.",
            "Disagree. The two cell types also differ in shape and in the way they obtain food: plant cells "
            "make their own food while animal cells take in ready-made food."],
    "4 marks. Award 1 mark for a clear position (disagree), 1 mark for each of TWO correct reasons (2 marks), "
    "and 1 mark for the quality of the explanation. A bare 'no' scores 0. A position plus one reason scores 2."),
   ("(d)", ["(i) Yes", "(ii) No", "(iii) No", "(iv) Yes", "(v) Yes"],
    "1 mark each (5 marks). Accept 'YES'/'Y' and 'NO'/'N' written clearly. No mark for a blank or for "
    "'Yes/No'."),
 ],
}


# --------------------------------------------- derive summary statistics
def topic_totals():
    m = {k: 0 for k in TOPIC}
    it = {k: 0 for k in TOPIC}
    for q in MCQ:
        m[q[3]] += 1
        it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk
            it[key] += 1
    return m, it

def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}
    b = {k: 0 for k in order}
    for q in MCQ:
        a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            b[cog] += mk
    return order, a, b

def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ:
        d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            d[diff] += mk
    return d
