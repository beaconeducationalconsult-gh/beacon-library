# -*- coding: utf-8 -*-
"""Basic 7 Integrated Science mock - Strand 3 Sub-strand 2: THE SOLAR SYSTEM. 100 marks.
Indicators sourced from the official NaCCA Science CCP curriculum (B7/JHS1-B9/JHS3, Sept 2020),
Strand 3: Systems, Sub-strand 2: The Solar System, printed pages 19-20."""

SCHOOL = "[SCHOOL NAME]"
SUBJECT = "INTEGRATED SCIENCE (SCIENCE)"
EXAM = "END-OF-TERM MOCK EXAMINATION"
CLASS = "Basic 7 (JHS 1)"
TIME = "2 hours (Suggested: Section A - 40 min; Section B - 80 min)"
MARKS = "100"
YEAR = "2025/2026 Academic Year"

STRAND = "Systems"
SUBSTRAND = "The Solar System"

TOPIC = {
    "8.1": "8.1 What is the Solar System?",
    "8.2": "8.2 The Galaxy and the Milky Way",
    "8.3": "8.3 The Inner Planets: Mercury, Venus, Earth and Mars",
    "8.4": "8.4 Properties of the Inner Planets",
    "8.5": "8.5 Movement of Mercury and Venus Around the Sun",
    "8.6": "8.6 Elliptical Paths of the Planets",
}

CS = "B7/JHS1.3.2.1"
CS_BY_TOPIC = {k: "B7/JHS1.3.2.1" for k in ["8.1", "8.2", "8.3", "8.4", "8.5", "8.6"]}
CS_TEXT = "Demonstrate knowledge of the inner planets of the solar system and understand their movement " \
          "in the system"

IND = {
    "8.1": "B7/JHS1.3.2.1.1 (Ex. 1, 3)",
    "8.2": "B7/JHS1.3.2.1.1 (Ex. 2)",
    "8.3": "B7/JHS1.3.2.1.1 (Ex. 1)",
    "8.4": "B7/JHS1.3.2.1.2 (Ex. 1)",
    "8.5": "B7/JHS1.3.2.1.2 (Ex. 2)",
    "8.6": "B7/JHS1.3.2.1.1 (Ex. 2)",
}
IND_TEXT = {
    "8.1": "Identify and describe what constitutes the inner planets of the solar system using "
           "pictures, videos, etc.; design and construct a model of the solar system.",
    "8.2": "Describe the galaxy, the Milky Way, and the elliptical shape of the paths of movement of "
           "the inner planets.",
    "8.3": "Identify and describe what constitutes the inner planets of the solar system using "
           "pictures, videos, etc.",
    "8.4": "Outline the properties peculiar to each of the planets Mercury and Venus.",
    "8.5": "Describe the movement of the planets Mercury and Venus around the Sun.",
    "8.6": "Describe the galaxy, the Milky Way, and the elliptical shape of the paths of movement of "
           "the inner planets.",
}
CC = {k: "DL, CP, CC, CI" for k in ["8.1", "8.2", "8.3", "8.4", "8.5", "8.6"]}

# ---------------------------------------------------------------- SECTION A
# (question, [A,B,C,D], answer, topic, cognitive, difficulty)
MCQ = [
 ("The solar system is",
  ["the Sun on its own", "the Earth and the Moon",
   "the Sun and all the bodies that move around it", "all the stars we can see at night"],
  "C", "8.1", "Understand", "Easy"),
 ("The body at the centre of the solar system is the",
  ["Sun", "Earth", "Moon", "Jupiter"], "A", "8.1", "Remember", "Easy"),
 ("Which of these is NOT part of the solar system?",
  ["Mars", "an asteroid", "a comet", "a star in another galaxy"],
  "D", "8.1", "Understand", "Moderate"),
 ("The planets are held in their paths around the Sun by",
  ["the light of the Moon", "the pull of gravity from the Sun", "the wind from the sea",
   "the pull of the other stars"],
  "B", "8.1", "Understand", "Moderate"),
 ("How many planets are there in the solar system?",
  ["five", "nine", "eight", "twelve"], "C", "8.1", "Remember", "Easy"),
 ("Which of these gives the four planets nearest to the Sun in the correct order?",
  ["Mercury, Venus, Earth, Mars", "Venus, Mercury, Earth, Mars",
   "Earth, Venus, Mercury, Mars", "Mars, Earth, Venus, Mercury"],
  "A", "8.1", "Apply", "Moderate"),
 ("The Sun is described as a star because it",
  ["moves around the Earth", "is bigger than the Moon", "is the hottest planet",
   "gives out its own light and heat"],
  "D", "8.1", "Understand", "Moderate"),
 ("A galaxy is",
  ["a group of planets",
   "a very large group of stars, gas and dust held together by gravity",
   "the path a planet takes", "another name for the solar system"],
  "B", "8.2", "Understand", "Easy"),
 ("Our galaxy is called",
  ["the Solar System", "the Universe", "the Milky Way", "Andromeda"],
  "C", "8.2", "Remember", "Easy"),
 ("The Sun is",
  ["one star in the Milky Way", "the centre of the Milky Way", "outside the Milky Way",
   "bigger than the Milky Way"],
  "A", "8.2", "Understand", "Moderate"),
 ("The Milky Way is described as a",
  ["round ball", "flat plate", "cube", "spiral galaxy"],
  "D", "8.2", "Apply", "Moderate"),
 ("Compared with the solar system, a galaxy is",
  ["much smaller", "much bigger", "exactly the same size", "the same thing"],
  "B", "8.2", "Understand", "Moderate"),
 ("The Milky Way contains",
  ["only our Sun", "only the eight planets", "many millions of stars, including the Sun",
   "only the stars we can see at night"],
  "C", "8.2", "Understand", "Easy"),
 ("The inner planets are",
  ["Mercury, Venus, Earth and Mars", "Jupiter, Saturn, Uranus and Neptune",
   "the Sun, the Moon and the Earth", "all the planets that have rings"],
  "A", "8.3", "Understand", "Easy"),
 ("The inner planets are also called terrestrial planets because they",
  ["are the hottest planets", "have the most moons", "are the furthest from the Sun",
   "are small and have a solid, rocky surface"],
  "D", "8.3", "Understand", "Moderate"),
 ("Which of these is NOT one of the inner planets?",
  ["Venus", "Jupiter", "Earth", "Mars"], "B", "8.3", "Apply", "Moderate"),
 ("Compared with the outer planets, the inner planets are",
  ["larger and made of gas", "further from the Sun", "smaller, warmer and made of rock",
   "colder and have many moons"],
  "C", "8.3", "Understand", "Moderate"),
 ("The planet we live on is",
  ["Earth", "Mars", "Venus", "Mercury"], "A", "8.3", "Remember", "Easy"),
 ("The planet that is often called the red planet is",
  ["Venus", "Mercury", "Earth", "Mars"], "D", "8.3", "Remember", "Easy"),
 ("Which of the inner planets is known to support life?",
  ["Mars only", "Earth only", "Venus and Earth", "all four of them"],
  "B", "8.3", "Remember", "Easy"),
 ("The smallest planet in the solar system is",
  ["Earth", "Venus", "Mercury", "Mars"], "C", "8.4", "Understand", "Easy"),
 ("The hottest planet in the solar system is",
  ["Venus", "Mercury", "Mars", "Earth"], "A", "8.4", "Understand", "Moderate"),
 ("Venus is hotter than Mercury mainly because",
  ["it is nearer the Sun", "it is bigger than Mercury", "it has no moon",
   "its thick atmosphere traps the Sun's heat"],
  "D", "8.4", "Understand", "Challenging"),
 ("Venus is often called the morning star or the evening star because it",
  ["gives out its own light",
   "is the brightest object in the sky after the Sun and the Moon",
   "is the nearest planet to the Sun", "is the biggest planet"],
  "B", "8.4", "Understand", "Moderate"),
 ("A pupil says that all four inner planets have at least one moon. The best judgement is that",
  ["she is right", "she is wrong - none of them has a moon",
   "she is wrong - only Mercury and Venus have no moon",
   "she is wrong - only Mercury has no moon"],
  "C", "8.4", "Evaluate", "Moderate"),
 ("How many moons has the Earth?",
  ["one", "two", "three", "none"], "A", "8.4", "Remember", "Easy"),
 ("Mars has",
  ["no moon", "one moon", "four moons", "two moons"], "D", "8.4", "Remember", "Easy"),
 ("Venus is sometimes called the Earth's twin because it",
  ["has the same kind of air as the Earth", "is about the same size as the Earth",
   "has one moon, like the Earth", "has water on its surface, like the Earth"],
  "B", "8.4", "Understand", "Moderate"),
 ("The path a planet takes as it moves around the Sun is called its",
  ["axis", "galaxy", "orbit", "shadow"], "C", "8.5", "Remember", "Easy"),
 ("A planet's 'year' is the time it takes to",
  ["go once round the Sun", "spin once on its axis", "travel from the Sun to the Earth",
   "go once round the Moon"],
  "A", "8.5", "Understand", "Moderate"),
 ("Which planet takes the shortest time to go once round the Sun?",
  ["Earth", "Venus", "Mars", "Mercury"], "D", "8.5", "Understand", "Moderate"),
 ("Mercury moves faster along its orbit than Venus mainly because",
  ["it is the biggest planet",
   "it is nearer the Sun, so the Sun's pull on it is stronger and its path is shorter",
   "it has no moon", "it spins faster on its axis"],
  "B", "8.5", "Analyse", "Challenging"),
 ("Venus takes about 225 Earth days to go once round the Sun. This means that",
  ["a year on Venus is longer than a year on Earth",
   "a year on Venus is the same as a year on Earth",
   "a year on Venus is shorter than a year on Earth but longer than a year on Mercury",
   "Venus does not move at all"],
  "C", "8.5", "Understand", "Moderate"),
 ("Which statement about the movement of Mercury and Venus is correct?",
  ["both move around the Sun, and Mercury's year is the shorter of the two",
   "both move around the Earth", "both move around the Moon", "neither of them moves at all"],
  "A", "8.5", "Apply", "Moderate"),
 ("All the planets in the solar system",
  ["move in straight lines", "move around the Earth", "move at the same speed",
   "move around the Sun"],
  "D", "8.5", "Apply", "Easy"),
 ("A pupil draws the Earth's path round the Sun as a perfect circle. The best comment on the drawing "
  "is that it is",
  ["exactly right", "not quite right, because the path is an ellipse (an oval)",
   "right, because the path is a square", "right, because the Earth does not move"],
  "B", "8.6", "Evaluate", "Moderate"),
 ("An ellipse is a shape like a",
  ["triangle", "square", "flattened circle or oval", "straight line"],
  "C", "8.6", "Remember", "Easy"),
 ("A pupil says that because the Earth's path is an ellipse, the Earth is always the same distance "
  "from the Sun. Which of these is correct?",
  ["the pupil is wrong - the distance changes as the Earth moves along its path",
   "the pupil is right", "the pupil is wrong - the Earth does not move",
   "the pupil is wrong - the path is a square"],
  "A", "8.6", "Analyse", "Challenging"),
 ("Which statement best describes the path of a planet around the Sun?",
  ["a straight line", "a perfect circle with the Sun at the centre", "a spiral going outwards",
   "an ellipse with the Sun off to one side"],
  "D", "8.6", "Understand", "Moderate"),
 ("A pupil makes a model in which the Sun is placed exactly at the centre of an oval path. To make "
  "the model correct, the pupil should",
  ["leave it as it is", "move the Sun off the centre, towards one end of the oval",
   "move the Sun outside the oval", "remove the Sun altogether"],
  "B", "8.6", "Apply", "Challenging"),
]

# ------------------------------------------------- SECTION B DIAGRAM (Q3)
INNER_PLANETS = [
    "   +----------------------------------------------------------+",
    "   |         THE INNER PLANETS  (not drawn to scale)          |",
    "   |                                                          |",
    "   |   Sun                                                    |",
    "   |    *                                                     |",
    "   |    |                                                     |",
    "   |    |       1          2          3          4            |",
    "   |    +-------(o)--------(o)--------(o)--------(o)          |",
    "   |             |          |          |          |           |",
    "   |             |          |          |          |           |",
    "   |   Each planet moves round the Sun along its own          |",
    "   |   path. That path is called an orbit.                    |",
    "   |                                                          |",
    "   |   nearest the Sun  --------------------  furthest        |",
    "   +----------------------------------------------------------+"
]

# ---------------------------------------------------- SECTION B TABLE (Q4)
PROP_HEADERS = ["Inner planet", "Number of moons", "One other property"]
PROP_ROWS = [
 ["Mercury", "0", "(i)"],
 ["Venus", "0", "(ii)"],
 ["Earth", "(iii)", "the only planet known to support life"],
 ["Mars", "(iv)", "known as the red planet"],
]

# ---------------------------------------------------------------- SECTION B
SECTION_B = [
 dict(
   num=1, total=8, topic="8.1",
   stem="The Sun, the planets and everything else that moves around the Sun make up the solar system.",
   parts=[
     ("(a)", "What is meant by the solar system?", 3, "Understand", "8.1", "Easy"),
     ("(b)", "Name the four inner planets in order, starting with the one nearest the Sun.",
      3, "Remember", "8.1", "Easy"),
     ("(c)", "Explain why the Sun is the most important body in the solar system.",
      2, "Understand", "8.1", "Easy"),
   ]),
 dict(
   num=2, total=9, topic="8.2",
   stem="Our Sun is only one star among millions. It lies in a galaxy called the Milky Way.",
   parts=[
     ("(a)", "Explain what is meant by a galaxy, and name our own galaxy.",
      3, "Understand", "8.2", "Moderate"),
     ("(b)", "Describe the Milky Way.", 3, "Understand", "8.2", "Moderate"),
     ("(c)", "The Sun is only one star among millions in the galaxy. Explain why it is still the most "
             "important star to us.", 3, "Understand", "8.2", "Moderate"),
   ]),
 dict(
   num=3, total=10, topic="8.3",
   stem="The diagram below shows the four inner planets. Study it and answer the questions that follow.",
   diagram=True,
   parts=[
     ("(a)", "Name the planets labelled 1, 2, 3 and 4.", 4, "Remember", "8.3", "Easy"),
     ("(b)", "State three properties that the four inner planets have in common.",
      3, "Understand", "8.3", "Moderate"),
     ("(c)", "Jupiter and Saturn are much bigger than the planets in the diagram, yet they are not "
             "inner planets. Explain why not, and say which group they belong to.",
      3, "Apply", "8.3", "Challenging"),
   ]),
 dict(
   num=4, total=8, topic="8.4",
   stem="Each of the inner planets has properties that are peculiar to it. Study the incomplete table "
        "below and answer the questions that follow.",
   table="properties",
   parts=[
     ("(a)", "Copy and complete the table.", 4, "Understand", "8.4", "Moderate"),
     ("(b)", "Name the smallest inner planet and the largest inner planet.",
      2, "Remember", "8.4", "Moderate"),
     ("(c)", "Venus is hotter than Mercury, even though Mercury is nearer the Sun. Explain why.",
      2, "Analyse", "8.4", "Challenging"),
   ]),
 dict(
   num=5, total=9, topic="8.5",
   stem="Mercury and Venus are the two planets nearest the Sun, and both of them move around it.",
   parts=[
     ("(a)", "Describe the movement of Mercury around the Sun.", 3, "Understand", "8.5", "Moderate"),
     ("(b)", "Describe the movement of Venus around the Sun.", 3, "Understand", "8.5", "Moderate"),
     ("(c)", "Explain why Mercury moves faster along its path than Venus does.",
      3, "Analyse", "8.5", "Challenging"),
   ]),
 dict(
   num=6, total=9, topic="8.6",
   stem="The planets do not move in perfect circles around the Sun.",
   parts=[
     ("(a)", "What is meant by the orbit of a planet?", 2, "Understand", "8.6", "Easy"),
     ("(b)", "Explain what is meant by an elliptical path.", 3, "Understand", "8.6", "Moderate"),
     ("(c)", "Explain why a planet's distance from the Sun changes during one orbit, and say where "
             "the Sun lies in the orbit.", 4, "Analyse", "8.6", "Challenging"),
   ]),
 dict(
   num=7, total=7, topic="8.1",
   stem="Your class has been asked to design and construct a model of the solar system.",
   parts=[
     ("(a)", "Describe how your class would design and construct the model.",
      4, "Create", "8.1", "Challenging"),
     ("(b)", "Give two reasons why building a model helps the class to understand the solar system "
             "better than only reading about it, and state one thing the model must show.",
      3, "Evaluate", "8.6", "Moderate"),
   ]),
]

# ------------------------------------------------------- MARKING SCHEME
MARKING = {
 1: [
   ("(a)", ["The solar system is the Sun together with all the bodies that move around it.",
            "It is made up of the Sun, the eight planets and their moons, dwarf planets, asteroids, "
            "comets and meteoroids.",
            "It is the Sun's family: everything held in orbit by the Sun's gravity."],
    "1 mark each for any THREE correct points (3 marks). The Sun must be mentioned. Award 1 mark for "
    "'the Sun and the planets' if it is not developed further. Do NOT accept 'the universe' or 'the "
    "Milky Way' as the same thing as the solar system."),
   ("(b)", ["Mercury", "Venus", "Earth", "Mars"],
    "1 mark each for the four inner planets, and the order must be correct starting from the Sun "
    "(3 marks: award 3 for all four in the right order, 2 for three in the right order, 1 for two in "
    "the right order). Do NOT accept an outer planet in the list."),
   ("(c)", ["The Sun gives out the light and the heat that the planets receive.",
            "Its gravity holds all the planets and other bodies in their paths.",
            "Without the Sun there would be no solar system: the planets would drift away and life on "
            "Earth would not be possible."],
    "1 mark each for any TWO correct points (2 marks). One mark should be about light and heat and one "
    "about gravity, but accept any two sensible points."),
 ],
 2: [
   ("(a)", ["A galaxy is a very large group of stars, gas and dust held together by gravity.",
            "It contains many millions of stars.",
            "Our own galaxy is called the Milky Way."],
    "1 mark for a correct description of a galaxy and 1 mark for naming the Milky Way, plus 1 mark for "
    "any further correct point (3 marks). Award at least 1 mark for 'a huge group of stars'."),
   ("(b)", ["The Milky Way is the galaxy in which the Sun and the solar system are found.",
            "It is a spiral galaxy.",
            "It contains many millions of stars.",
            "When we look up on a clear, dark night, the band of light across the sky is part of the "
            "Milky Way.",
            "It is only one of many galaxies in the universe."],
    "1 mark each for any THREE correct points (3 marks). Do NOT accept 'the Milky Way is our solar "
    "system' - a galaxy is much bigger than a solar system."),
   ("(c)", ["The Sun is by far the nearest star to the Earth, so we get almost all our light and heat "
            "from it.",
            "The other stars are so far away that they look like tiny points of light and give us "
            "almost no heat.",
            "The Sun's gravity holds the Earth in its path, so it keeps the Earth at the right "
            "distance for life.",
            "Life on Earth depends on the Sun's energy."],
    "1 mark each for any THREE correct points (3 marks). The key idea is distance: the Sun is the "
    "nearest star. Award at least 1 mark for 'it is the nearest star'."),
 ],
 3: [
   ("(a)", ["1 = Mercury", "2 = Venus", "3 = Earth", "4 = Mars"],
    "1 mark each for all FOUR planets correctly named (4 marks). The number must be matched to the "
    "correct planet. Do NOT accept an outer planet in the list."),
   ("(b)", ["They are all small compared with the outer planets.",
            "They all have a solid, rocky surface (they are called the terrestrial planets).",
            "They are the four planets nearest the Sun, so they are warmer than the outer planets.",
            "They have few moons or none at all.",
            "They have no ring system round them.",
            "They all move around the Sun."],
    "1 mark each for any THREE correct points (3 marks). Accept 'they are made of rock' and 'they are "
    "near the Sun'."),
   ("(c)", ["Size alone does not decide whether a planet is an inner planet: what matters is how near "
            "the Sun it is.",
            "The inner planets are the four nearest the Sun; Jupiter and Saturn are much further out.",
            "Jupiter and Saturn belong to the outer planets (the gas giants).",
            "Unlike the inner planets, the outer planets are very large, made mostly of gas, cold, and "
            "have many moons and rings."],
    "1 mark each for any THREE correct points (3 marks). The answer must say that they belong to the "
    "OUTER planets to earn full marks; award at most 2 marks if the group is not named."),
 ],
 4: [
   ("(a)", ["(i) the smallest planet; the nearest planet to the Sun; has the shortest year (about 88 "
            "days); very hot in the day and very cold at night; has almost no air.",
            "(ii) the hottest planet; about the same size as the Earth (the Earth's twin); the "
            "brightest planet in the sky; has a thick atmosphere of carbon dioxide; spins in the "
            "opposite direction to most planets.",
            "(iii) 1",
            "(iv) 2"],
    "1 mark each for all FOUR blanks correctly filled (4 marks). The blank number must be matched to "
    "the correct answer. For (i) and (ii) accept any ONE correct property peculiar to that planet."),
   ("(b)", ["Smallest: Mercury.", "Largest: Earth."],
    "1 mark for naming Mercury as the smallest and 1 mark for naming Earth as the largest of the four "
    "inner planets (2 marks). Do NOT accept Venus as the largest - it is slightly smaller than the "
    "Earth."),
   ("(c)", ["Venus has a thick atmosphere of carbon dioxide, which traps the Sun's heat and will not "
            "let it escape.",
            "Mercury has almost no atmosphere, so the heat it receives escapes back into space, "
            "especially at night.",
            "So Venus stays hot all the time, while Mercury is scorching in the day and freezing at "
            "night."],
    "1 mark each for any TWO correct points (2 marks). The key idea is the thick atmosphere that traps "
    "heat. Award 1 mark for 'Venus has a thick atmosphere that traps heat' alone."),
 ],
 5: [
   ("(a)", ["Mercury moves round the Sun along its own path (orbit).",
            "It is the nearest planet to the Sun, so its path is the shortest.",
            "It travels faster than any other planet.",
            "It takes the shortest time to go once round the Sun - about 88 Earth days, which is the "
            "shortest year of any planet.",
            "It does not give out its own light; it shines because it reflects the light of the Sun."],
    "1 mark each for any THREE correct points (3 marks). The key ideas are: it moves round the Sun, "
    "nearest the Sun, and has the shortest year."),
   ("(b)", ["Venus moves round the Sun along its own path (orbit), outside the path of Mercury.",
            "It is the second planet from the Sun.",
            "It takes about 225 Earth days to go once round the Sun - longer than Mercury but shorter "
            "than the Earth.",
            "It also spins on its own axis, but very slowly, and in the opposite direction to most "
            "planets.",
            "It shines by reflecting the light of the Sun; it does not give out its own light."],
    "1 mark each for any THREE correct points (3 marks). The key ideas are: it moves round the Sun, "
    "second from the Sun, and takes about 225 days."),
   ("(c)", ["Mercury is nearer the Sun, so the Sun's pull of gravity on it is stronger.",
            "A stronger pull makes it move faster.",
            "Mercury's path is also shorter, so it has less distance to cover in one year.",
            "Venus is further away, so the pull on it is weaker, its path is longer, and it moves more "
            "slowly."],
    "1 mark each for any THREE correct points (3 marks). Award at least 1 mark for 'Mercury is nearer "
    "the Sun' and 1 mark for 'the Sun's pull is stronger' or 'its path is shorter'."),
 ],
 6: [
   ("(a)", ["The orbit of a planet is the path it follows as it moves around the Sun.",
            "It is the curved path the planet travels along, again and again."],
    "1 mark each for any TWO correct points (2 marks). Accept 'the path a planet takes round the Sun'."),
   ("(b)", ["An elliptical path is an oval path - a flattened circle, not a perfect circle.",
            "It has two 'centres' (foci) instead of one.",
            "The Sun is not at the centre of the ellipse, but off to one side.",
            "A planet's orbit is an ellipse."],
    "1 mark each for any THREE correct points (3 marks). Accept 'an oval' for an ellipse. Award at "
    "least 1 mark for 'it is an oval, not a perfect circle'."),
   ("(c)", ["Because the path is an ellipse and the Sun is off to one side of it, the planet is nearer "
            "the Sun at one part of the path and further away at another.",
            "So the distance between the planet and the Sun changes as the planet moves along its "
            "orbit.",
            "The planet is closest to the Sun at one end of the ellipse and furthest at the other.",
            "The Sun lies at one of the two foci of the ellipse, not at its centre.",
            "If the orbit were a perfect circle with the Sun at the centre, the distance would never "
            "change."],
    "1 mark each for any FOUR correct points (4 marks). The key ideas are: the Sun is off-centre, so "
    "the distance changes, and the Sun lies at a focus rather than at the centre. Award at least 2 "
    "marks for 'the Sun is not at the centre, so the distance changes'."),
 ],
 7: [
   ("(a)", ["Decide what the model will show: the Sun at the centre and the eight planets in their "
            "correct order.",
            "Choose the materials, e.g. balls of different sizes of paper, clay, foam or plasticine, "
            "string, wire, cardboard and paint.",
            "Make the Sun the biggest ball and paint it yellow; make the planets smaller, with Mercury "
            "the smallest and Jupiter the biggest.",
            "Paint or label each planet with its name and, where possible, its colour (Mars red, "
            "Earth blue and green).",
            "Arrange the planets in the correct order from the Sun: Mercury, Venus, Earth, Mars, "
            "Jupiter, Saturn, Uranus, Neptune.",
            "Hang them from a wooden frame or a cardboard base with string, or fix them on sticks.",
            "Show the path of each planet with string, wire or a drawn ellipse, not a perfect circle.",
            "Add the Moon beside the Earth, and add rings to Saturn.",
            "Write a title and a key, and let each group member take a task."],
    "1 mark each for any FOUR correct points (4 marks). This is a design task: award method marks for "
    "any sensible step. The three things to look for first are: the correct ORDER of the planets, the "
    "Sun at the centre, and materials a real class could find."),
   ("(b)", ["A model shows the order of the planets and their relative sizes in a way a drawing "
            "cannot.",
            "The class can handle it, walk round it and point, so the idea stays in the memory.",
            "Building it together makes pupils discuss and explain the solar system to one another.",
            "It shows the distances and the shapes of the paths (the orbits), which a flat drawing "
            "often gets wrong.",
            "One thing it must show: the planets in the correct order from the Sun (or: the paths as "
            "ellipses, not perfect circles; or: the Sun at the centre)."],
    "1 mark each for any TWO sensible reasons and 1 mark for a correct thing the model must show "
    "(3 marks). Accept any reason that shows the model adds something a book cannot. Do NOT accept "
    "'it is fun' on its own."),
 ],
}


# --------------------------------------------- derive summary statistics
def topic_totals():
    m = {k: 0 for k in TOPIC}
    it = {k: 0 for k in TOPIC}
    for q in MCQ:
        m[q[3]] += 1
        it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk
            it[key] += 1
    return m, it


def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}
    b = {k: 0 for k in order}
    for q in MCQ:
        a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            b[cog] += mk
    return order, a, b


def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ:
        d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            d[diff] += mk
    return d
