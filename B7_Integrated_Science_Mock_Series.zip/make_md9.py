# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "/home/user")
from build_eco import *

L = []
def w(s=""): L.append(s)

w(f"# {SCHOOL}"); w()
w(f"## {SUBJECT}"); w()
w(f"### {EXAM}"); w()
w(f"**Class:** {CLASS}  ")
w(f"**Time:** {TIME}  ")
w(f"**Total Marks:** {MARKS}  ")
w(f"**Academic Year:** {YEAR}"); w()
w("---"); w()
w("### INSTRUCTIONS"); w()
for i, t in enumerate([
    "Write your name and class clearly in the spaces provided on your answer sheet.",
    "This paper has TWO sections: Section A and Section B.",
    "Answer ALL the questions in both sections.",
    "Section A has 40 multiple-choice questions. Each question carries 1 mark. Choose the best answer (A, B, C or D) and record it on the answer sheet provided.",
    "Section B has 7 theory questions totalling 60 marks. Write your answers clearly and neatly in your answer booklet. Draw and label diagrams or tables where you are asked to.",
    "Read every question carefully before you answer it.",
    "Do not use correction fluid. Cancel any mistake neatly with a single line.",
    "Hand in your answer sheet and your answer booklet at the end of the examination.",
], start=1):
    w(f"{i}. {t}")
w(); w("---"); w()

w("## SECTION A: OBJECTIVE TEST (40 marks)"); w()
w("*Answer ALL questions. Each question carries 1 mark. Choose the BEST answer and write its letter "
  "(A, B, C or D) against the question number on your answer sheet.*"); w()
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"**{i}. {q}**"); w()
    for j, o in enumerate(opts): w(f"{'ABCD'[j]}. {o}")
    w()
w("---"); w()

w("## SECTION B: THEORY (60 marks)"); w()
w("*Answer ALL questions. Write your answers in your answer booklet. The marks for each question are shown "
  "in brackets.*"); w()
for qb in SECTION_B:
    w(f"### Question {qb['num']}  [{qb['total']} marks]"); w()
    w(qb["stem"]); w()
    if qb.get("table") == "pond":
        w("| " + " | ".join(POND_HEADERS) + " |")
        w("| " + " | ".join(["---"] * len(POND_HEADERS)) + " |")
        for r in POND_ROWS:
            w("| " + " | ".join(r) + " |")
        w()
        w("*Table 1: Components of a pond ecosystem*"); w()
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        w(f"**{lab}** {text}  **[{mk} mark{'s' if mk > 1 else ''}]**"); w()
w("---"); w()

w("## ANSWER KEY"); w()
w("### Section A - Objective Test"); w()
w("| Question | Answer | Curriculum Area (Topic) | Cognitive Level |")
w("| -------- | ------ | ----------------------- | --------------- |")
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"| {i} | {ans} | {TOPIC[tp]} | {cog} |")
counts = {L2: sum(1 for q in MCQ if q[2] == L2) for L2 in "ABCD"}
w()
w("Correct-answer distribution: " + ", ".join(f"{L2} = {counts[L2]}" for L2 in "ABCD") + " (40 items).")
w()
w("### Section B - Theory (summary answers; full detail in the Marking Scheme)"); w()
w("| Question | Expected Answer | Curriculum Area | Cognitive Level |")
w("| -------- | --------------- | --------------- | --------------- |")
sba = [
 ("1 (a)", "A self-sustaining unit in which living things and their non-living surroundings interact; a community of organisms together with the soil, water, air and sunlight around them.", "9.1", "Understand"),
 ("1 (b)", "Any two of: a pond; a forest; a river or stream; a lake; a mangrove swamp; a grassland or savanna; a farm or school garden; the branches of a large tree.", "9.1", "Remember"),
 ("1 (c)", "The parts supply what each other needs; green plants trap the Sun's energy and make the food; waste and dead remains are broken down so nutrients go round again; so the unit can keep itself going.", "9.1", "Understand"),
 ("2 (a)", "Terrestrial, aquatic and arboreal.", "9.2", "Remember"),
 ("2 (b)", "Terrestrial - a forest, a grassland, a farm. Aquatic - a pond, a river, a lake, a mangrove swamp. Arboreal - the community of organisms living in the branches of one large tree.", "9.2", "Understand"),
 ("2 (c)", "An arboreal ecosystem is found up in the branches and on the trunk of trees, while a terrestrial ecosystem is found on the land surface; an arboreal ecosystem is really the part of a terrestrial one that lives in the trees.", "9.2", "Understand"),
 ("3 (a)", "(i) abiotic; (ii) biotic; (iii) abiotic; (iv) biotic; (v) abiotic; (vi) biotic.", "9.3", "Understand"),
 ("3 (b)", "Any two not already in the table: the temperature of the water; the depth of the water; the mud at the bottom; rainfall; mineral salts; the amount of light; the wind.", "9.3", "Remember"),
 ("3 (c)", "Biotic components are the living parts - the plants, animals and decay organisms; abiotic components are the non-living parts - water, air, sunlight, temperature, soil and mineral salts.", "9.3", "Understand"),
 ("4 (a)", "Any three of: feeding on one another; carrying pollen from flower to flower; carrying seeds to new places; providing shelter; breaking down dead remains; competing for food, water, light and space.", "9.4", "Understand"),
 ("4 (b)", "Sunlight lets the water plants make food; the temperature affects how much oxygen dissolves in the water; the fish breathe the oxygen dissolved in the water; mineral salts feed the plants; in the dry season the water level falls and there is less room and less oxygen.", "9.4", "Apply"),
 ("4 (c)", "Plants take in carbon dioxide and give out oxygen; dead remains add humus to the soil; tree roots break up rocks, hold the soil together and stop it being washed away; plants shade the ground so the soil stays cooler and moister.", "9.4", "Understand"),
 ("5 (a)", "The organisms depend on one another to stay alive: each needs something another provides - food, shelter, pollination or seed dispersal - so what happens to one affects the others.", "9.5", "Understand"),
 ("5 (b)", "Animals depend on plants for food and oxygen; plants depend on animals for carbon dioxide and for pollination and seed dispersal; animals depend on plants for shelter.", "9.5", "Understand"),
 ("5 (c)", "Any sensible chain starting with a green plant, e.g. maize -> grasshopper -> lizard -> hawk. Removing a link means the animals that feed on it lose their food and their numbers fall, while what it used to eat may increase, so the balance of the whole ecosystem is disturbed.", "9.5", "Analyse"),
 ("6 (a)", "Any three of: the lizards, birds and frogs that eat insects lose their food; flowers are not pollinated and produce fewer seeds and fruits; pest insects may return in larger numbers; the yield may fall; the chemical may wash into the soil and water; animals that eat poisoned insects may be poisoned.", "9.5", "Analyse"),
 ("6 (b)", "The organisms are interdependent, so whatever happens to the insects passes along the food chain to the animals that eat them and then to those that eat those, and the plants lose their pollinators too.", "9.5", "Analyse"),
 ("6 (c)", "Any two of: mixed cropping or crop rotation; a mild local method such as neem extract or wood ash; leaving a strip uncultivated for useful insects and birds; spraying only in the evening; spraying only the affected part; hand-picking pests; adding compost or manure.", "9.5", "Create"),
 ("7 (a)", "Choose one ecosystem near the school; visit it more than once and observe quietly; note the abiotic components and list the biotic ones; record where each organism was found; draw or photograph it; record everything in a two-column table; note any interaction seen; work in groups and write a short report.", "9.3", "Create"),
 ("7 (b)", "Any two of: it shows that the living and non-living parts really do interact; it makes the class notice how the organisms depend on one another; it shows what happens when people damage an ecosystem; group work lets everyone join in. Precaution: do not pick flowers or break branches, put back any stone or log turned over, do not take animals home, leave no litter, keep to the paths.", "9.4", "Evaluate"),
]
for r in sba: w(f"| {r[0]} | {r[1]} | {r[2]} | {r[3]} |")
w(); w("---"); w()

w("## MARKING SCHEME - SECTION B (60 marks)"); w()
w("*General rules: (1) Accept any other correct and relevant answer. (2) Award marks for correct points, not "
  "for repeating the question. (3) For procedures, award method marks. (4) Do not deduct marks for spelling "
  "unless the meaning is changed. (5) Where a candidate gives more answers than are asked for, mark only the "
  "first ones up to the number required.*"); w()
for qb in SECTION_B:
    n = qb["num"]
    w(f"### Question {n} ({qb['total']} marks)"); w()
    for (lab, points, note) in MARKING[n]:
        mkv = [p_[2] for p_ in qb["parts"] if p_[0] == lab]
        head = f"**{lab}**"
        if mkv: head += f" [{mkv[0]} mark{'s' if mkv[0] > 1 else ''}]"
        w(head); w()
        for pt in points: w(f"- {pt}")
        w(f"  - *Marking note: {note}*"); w()
w("---"); w()

w("## CURRICULUM ASSESSMENT BLUEPRINT"); w()
w(f"**Strand:** {STRAND} | **Sub-strand:** {SUBSTRAND} | **Class:** {CLASS}"); w()
w(f"**Content Standard:** {CS} - {CS_TEXT}"); w()
w("> Source: NaCCA Science Common Core Programme Curriculum (B7/JHS1-B9/JHS3), September 2020, "
  "Strand 3: Systems, Sub-strand 3: Ecosystem, pp. 21-22. Indicators are quoted, not "
  "invented."); w()

w("### Section A"); w()
w("| Qn | Sub-strand | Content Standard | Indicator (NaCCA) - Indicator Text | Topic / Content | Cognitive Level | Marks |")
w("| -- | ---------- | ---------------- | ---------------------------------- | --------------- | --------------- | ----- |")
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"| A{i} | {SUBSTRAND} | {CS_BY_TOPIC[tp]} | {IND[tp]} - {IND_TEXT[tp]} | {TOPIC[tp]} | {cog} | 1 |")
w()
w("### Section B"); w()
w("| Qn | Sub-strand | Content Standard | Indicator (NaCCA) - Indicator Text | Topic / Content | Cognitive Level | Marks |")
w("| -- | ---------- | ---------------- | ---------------------------------- | --------------- | --------------- | ----- |")
for qb in SECTION_B:
    for (lab, text, mkv, cog, tp, diff) in qb["parts"]:
        key = tp if tp in TOPIC else tp.split(",")[0].strip()
        w(f"| B{qb['num']}{lab.strip('()')} | {SUBSTRAND} | {CS_BY_TOPIC[key]} | {IND[key]} - {IND_TEXT[key]} | {TOPIC[key]} | {cog} | {mkv} |")
w(); w("---"); w()

def topic_totals():
    m = {k: 0 for k in TOPIC}; it = {k: 0 for k in TOPIC}
    for q in MCQ: m[q[3]] += 1; it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk; it[key] += 1
    return m, it

def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}; b = {k: 0 for k in order}
    for q in MCQ: a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: b[cog] += mk
    return order, a, b

def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ: d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: d[diff] += mk
    return d

m, it = topic_totals(); diff_ = difficulty_totals(); order, ca, cb = cognitive_by_section()

w("### Summary 1 - Coverage by Curriculum Area (Topic)"); w()
w("| Topic / Content Area | No. of Items | Marks | % of Total Marks | Core Competencies |")
w("| -------------------- | ------------ | ----- | ---------------- | ----------------- |")
for k in TOPIC: w(f"| {TOPIC[k]} | {it[k]} | {m[k]} | {(m[k]/100)*100:.1f}% | {CC[k]} |")
w(f"| **TOTAL** | **{sum(it.values())}** | **{sum(m.values())}** | **100%** | - |")
w()
w("*CC = Communication and Collaboration; CP = Critical Thinking and Problem Solving; DL = Digital Literacy; "
  "CI = Creativity and Innovation.*"); w()
w("### Summary 2 - Cognitive-Level Distribution (Bloom's Taxonomy)"); w()
w("| Cognitive Level | Section A Marks | Section B Marks | Total Marks | % of Total |")
w("| --------------- | --------------- | --------------- | ----------- | ---------- |")
for lv in order:
    tot = ca[lv] + cb[lv]
    w(f"| {lv} | {ca[lv]} | {cb[lv]} | {tot} | {(tot/100)*100:.1f}% |")
w(f"| **TOTAL** | **{sum(ca.values())}** | **{sum(cb.values())}** | **{sum(ca.values())+sum(cb.values())}** | **100%** |")
w()
w("### Summary 3 - Difficulty Distribution"); w()
w("| Difficulty | Marks | % of Total Marks |")
w("| ---------- | ----- | ---------------- |")
for k, v in diff_.items(): w(f"| {k} | {v} | {(v/100)*100:.1f}% |")
w(f"| **TOTAL** | **{sum(diff_.values())}** | **100%** |")
w()
w("*Target in the master prompt: approximately 30% easy / 50% moderate / 20% challenging.*"); w()
w("### Summary 4 - Section Weighting"); w()
w("| Section | Question Type | Items | Marks | % of Total |")
w("| ------- | ------------- | ----- | ----- | ---------- |")
w("| A | Objective (multiple choice) | 40 | 40 | 40% |")
w("| B | Theory / constructed response | 20 | 60 | 60% |")
w("| **TOTAL** | - | **60** | **100** | **100%** |")
w(); w("---"); w()

w("## QUALITY-CONTROL SUMMARY")
w("")
w("| Check | Status |")
w("| --- | --- |")
for q_, a_ in [
 ("Every question within supplied curriculum scope",
  "Yes - topics 9.1-9.5 of Strand 3, Sub-Strand 3 (Ecosystem), mapped to indicator B7/JHS1.3.3.1.1 and its five exemplars"),
 ("Appropriate for the class",
  "Yes - B7 level; no energy pyramid, no chemical cycling detail and no quantitative population study, all of which sit outside the B7 indicator"),
 ("Genuinely BECE-style",
  "Yes - 40 four-option objectives plus structured theory with printed mark allocations and a completion table"),
 ("Sufficient application and reasoning",
  "Yes - 28 of 100 marks (28%) at Apply level or above (Apply 7, Analyse 11, Evaluate 4, Create 6)"),
 ("Plausible MCQ distractors",
  "Yes - drawn from the same content family as the key: examples offered as if they were categories, the wrong category for a named ecosystem, the wrong classification of a component, and an interaction of the wrong kind"),
 ("Single best answer per MCQ",
  "Yes - reviewed item by item; special care with A14, where the stem asks for the three categories and not for examples"),
 ("Marks internally consistent",
  "Yes - Section A 40 x 1 = 40; Section B 9 + 9 + 10 + 9 + 8 + 8 + 7 = 60; sub-question marks match the marking scheme"),
 ("Total adds up correctly",
  "Yes - 40 + 60 = 100"),
 ("Answer key correct",
  "Yes - all 40 keys and all 20 Section B answers verified against the marking scheme"),
 ("Marking scheme matches questions",
  "Yes - expected answers plus marking notes covering partial credit, alternatives, common wrong answers and method marks; the completion table, the food-chain item and both design tasks have explicit marking grids"),
 ("Free from unnecessary ambiguity",
  "Yes - open items are anchored with 'state three', 'name two' and the mark allocation; Question 3(a) numbers every blank (i) to (vi), Question 4 names the direction of interaction required in each part, and Question 7(b) asks for two reasons plus one precaution"),
 ("Ghanaian contexts natural and accurate",
  "Yes - a village pond, a silk-cotton tree, the Volta Lake, coastal mangrove swamp, a maize farm with grasshoppers, lizards and hawks, savanna grassland, the dry season, neem extract and wood ash, and a class studying an ecosystem beside its own school"),
 ("No content beyond the curriculum",
  "No - Question 1 uses exemplar 1; Questions 2 and 3 use exemplars 2, 3 and 4; Questions 4 and 6 use exemplar 5, the interactions; Question 5 uses the interdependence named in the content standard itself"),
 ("Questions sufficiently varied",
  "Yes - definition, giving examples, explaining a key phrase, naming and exemplifying three categories, classifying components, stating interactions in a required direction, writing a food chain, predicting the result of removing a link, suggesting safer farming, and designing a field study"),
]:
    w("| " + q_ + " | " + a_ + " |")
w("")
w("### EXAMINER NOTES")
w("")
for n_ in [
 "This sub-strand has ONE indicator with FIVE exemplars, so the blueprint shows the same indicator code throughout and varies only the exemplar number. That is correct and expected here - do not read it as a mapping error.",
 "Question 3 is exemplar 3, 'identify and list the components'. The six blanks are numbered (i) to (vi), so marking is quick and fair: 1 mark each, and the blank number must be matched to the answer. Accept 'living' for biotic and 'non-living' for abiotic.",
 "Questions 4 and 6 are exemplar 5, 'explain how the components affect one another'. The hardest part for pupils is the DIRECTION of the effect. Question 4(a) wants living-on-living, 4(b) non-living-on-living, and 4(c) living-on-non-living - mark each against its own direction and do not accept an answer given in the wrong one.",
 "Question 5(c) expects a food chain, not a food web. The chain must start with a green plant and the arrows must point the way the food passes. Do NOT expect the words producer, consumer, trophic level or a pyramid of numbers - all of that is beyond B7.",
 "Question 6 is the insecticide scenario. It is the best single test of interdependence in the paper: many pupils will answer 'the maize grows better', which is exactly the misconception the question is written to expose.",
 "Topic 9.5 carries 24 of 100 marks, the highest weighting, because interdependence is named in the content standard itself, not only in the exemplars. If you want a flatter spread, move marks from Questions 5 and 6 to Questions 1 and 2.",
 "Question 7 is designed as a real activity. If your school is near a pond, a stream, a patch of bush or one large tree, run it before the mock and accept what the pupils actually did as evidence. The safety rule is simple: observe, record, and put back anything that is moved.",
 "Edit the school name, academic year and examination title on page 1 before printing.",
 "This is an original, teacher-made mock. It is not a reproduction of any WAEC or NaCCA examination paper.",
]:
    w("- " + n_)
w()

open("/home/user/Basic7_Integrated_Science_Mock_Strand3_Ecosystem.md", "w", encoding="utf-8").write("\n".join(L))
print("md written", len("\n".join(L)), "chars")
