# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "/home/user")
from build_fly import *

from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT

doc = Document()
sec = doc.sections[0]
sec.left_margin = Inches(0.7); sec.right_margin = Inches(0.7)
sec.top_margin = Inches(0.7); sec.bottom_margin = Inches(0.6)

st = doc.styles["Normal"]; st.font.name = "Calibri"; st.font.size = Pt(11)


def set_font(run, size=11, bold=False, italic=False, mono=False, color=None):
    run.font.size = Pt(size); run.bold = bold; run.italic = italic
    run.font.name = "Consolas" if mono else "Calibri"
    if color: run.font.color.rgb = color
    return run


def para(text="", size=11, bold=False, italic=False, align=None, mono=False,
         space_before=0, space_after=4, color=None):
    p = doc.add_paragraph()
    if align == "c": p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    elif align == "j": p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p.paragraph_format.space_before = Pt(space_before)
    p.paragraph_format.space_after = Pt(space_after)
    if text: set_font(p.add_run(text), size, bold, italic, mono, color)
    return p


def rule():
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(6); p.paragraph_format.space_before = Pt(2)
    set_font(p.add_run("_" * 78), 9, color=RGBColor(0x99, 0x99, 0x99))


def add_table(headers, rows, widths=None, size=9, head_size=9):
    t = doc.add_table(rows=1, cols=len(headers)); t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, h in enumerate(headers):
        c = t.rows[0].cells[i]; c.text = ""
        p = c.paragraphs[0]; p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_font(p.add_run(str(h)), head_size, bold=True)
    for row in rows:
        cells = t.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = ""
            p = cells[i].paragraphs[0]; p.paragraph_format.space_after = Pt(1)
            set_font(p.add_run(str(v)), size)
    if widths:
        for r_ in t.rows:
            for i, w in enumerate(widths): r_.cells[i].width = Inches(w)
    return t


def draw_diagram(lines, caption):
    t = doc.add_table(rows=2, cols=1); t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = t.rows[0].cells[0]
    for k, line in enumerate(lines):
        p = cell.paragraphs[0] if k == 0 else cell.add_paragraph()
        p.paragraph_format.space_after = Pt(0); p.paragraph_format.space_before = Pt(0)
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_font(p.add_run(line), 10, mono=True)
    c2 = t.rows[1].cells[0].paragraphs[0]
    c2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_font(c2.add_run(caption), 9, italic=True)
    t.rows[0].cells[0].width = Inches(6.6)
    t.rows[1].cells[0].width = Inches(6.6)


# ============================================================= TITLE BLOCK
para(SCHOOL, size=15, bold=True, align="c", space_after=2)
para(SUBJECT, size=13, bold=True, align="c", space_after=2)
para(EXAM, size=12, bold=True, align="c", space_after=2)
para(YEAR, size=10, italic=True, align="c", space_after=8)

info = doc.add_table(rows=1, cols=3); info.style = "Table Grid"
info.alignment = WD_TABLE_ALIGNMENT.CENTER
for i, v in enumerate([f"Class: {CLASS}", f"Time: {TIME}", f"Total Marks: {MARKS}"]):
    c = info.rows[0].cells[i]; c.text = ""
    set_font(c.paragraphs[0].add_run(v), 10, bold=True)
para("", space_after=6)

para("INSTRUCTIONS", size=11, bold=True, space_after=3)
for txt in [
    "1. Write your name and class clearly in the spaces provided on your answer sheet.",
    "2. This paper has TWO sections: Section A and Section B.",
    "3. Answer ALL the questions in both sections.",
    "4. Section A has 40 multiple-choice questions. Each question carries 1 mark. Choose the best answer "
    "(A, B, C or D) and record it on the answer sheet provided.",
    "5. Section B has 7 theory questions totalling 60 marks. Write your answers clearly and neatly in your "
    "answer booklet. Draw and label diagrams where you are asked to.",
    "6. Read every question carefully before you answer it.",
    "7. Do not use correction fluid. Cancel any mistake neatly with a single line.",
    "8. Hand in your answer sheet and your answer booklet at the end of the examination.",
]:
    para(txt, size=10.5, space_after=2)
rule()

# =============================================================== SECTION A
para("SECTION A - OBJECTIVE TEST (40 marks)", size=12, bold=True, align="c", space_after=2)
para("Answer ALL questions. Each question carries 1 mark. Choose the BEST answer and write its letter "
     "(A, B, C or D) against the question number on your answer sheet.",
     size=10, italic=True, align="c", space_after=8)

for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(1); p.paragraph_format.space_before = Pt(4)
    set_font(p.add_run(f"{i}. {q}"), 10.5)
    for j, o in enumerate(opts):
        p2 = doc.add_paragraph()
        p2.paragraph_format.left_indent = Inches(0.28)
        p2.paragraph_format.space_after = Pt(0); p2.paragraph_format.space_before = Pt(0)
        set_font(p2.add_run(f"{'ABCD'[j]}. {o}"), 10.5)

doc.add_page_break()

# =============================================================== SECTION B
para("SECTION B - THEORY (60 marks)", size=12, bold=True, align="c", space_after=2)
para("Answer ALL questions. Write your answers in your answer booklet. The marks for each question are "
     "shown in brackets.", size=10, italic=True, align="c", space_after=8)

for qb in SECTION_B:
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(8); p.paragraph_format.space_after = Pt(2)
    set_font(p.add_run(f"Question {qb['num']}"), 11, bold=True)
    set_font(p.add_run(f"  [{qb['total']} marks]"), 10, bold=True, italic=True)
    para(qb["stem"], size=10.5, space_after=4)
    if qb.get("diagram"):
        draw_diagram(LIFE_CYCLE, "Fig. 1: The life cycle of the housefly (not drawn to scale)")
        para("", space_after=2)
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Inches(0.25)
        p.paragraph_format.space_after = Pt(3); p.paragraph_format.space_before = Pt(2)
        set_font(p.add_run(f"{lab} {text}  "), 10.5)
        set_font(p.add_run(f"[{mk} mark{'s' if mk > 1 else ''}]"), 10, bold=True)

doc.add_page_break()

# ============================================================== ANSWER KEY
para("ANSWER KEY", size=13, bold=True, align="c", space_after=6)
para("SECTION A - OBJECTIVE TEST", size=11, bold=True, space_after=4)
rows = [[i, ans, TOPIC[tp], cog] for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1)]
add_table(["Question", "Answer", "Curriculum Area (Topic)", "Cognitive Level"],
          rows, widths=[0.8, 0.7, 3.6, 1.5], size=9)
counts = {L: sum(1 for q in MCQ if q[2] == L) for L in "ABCD"}
para("", space_after=4)
para("Correct-answer distribution: " + ", ".join(f"{L} = {counts[L]}" for L in "ABCD") + " (30 items).",
     size=9, italic=True)

para("", space_after=8)
para("SECTION B - THEORY (summary answers; see the Marking Scheme for full detail)",
     size=11, bold=True, space_after=4)
sba = [
 ("1 (a)", "The series of changes a living thing goes through from the start of its life to the time it "
  "produces young ones of its own.", "4.1", "Understand"),
 ("1 (b)", "Any three of: so the kind of organism does not die out; to replace those that die; to increase "
  "in number; to spread to new places.", "4.1", "Understand"),
 ("1 (c)", "The adult produces the egg again, so the series comes back to where it started; it has no real "
  "beginning or end, unlike a straight line.", "4.1", "Understand"),
 ("2 (a)", "1 = egg; 2 = larva (maggot); 3 = pupa; 4 = adult", "4.2", "Remember"),
 ("2 (b)", "Any two of: soft, whitish, legless and worm-like; hatches from the egg; feeds continuously and "
  "grows; has no wings.", "4.2", "Understand"),
 ("2 (c)", "The larva stops feeding and becomes inactive, forms a brown case, and inside it the body changes "
  "completely into the adult, which then breaks out.", "4.2", "Understand"),
 ("3 (a)", "On moist, decaying matter such as refuse, rotten food and animal droppings - because the larvae "
  "have food to eat as soon as they hatch.", "4.2", "Understand"),
 ("3 (b)", "egg \u2192 larva \u2192 pupa \u2192 adult", "4.2", "Remember"),
 ("3 (c)", "Many of the eggs and larvae are destroyed by heat, rain, animals and people, so laying many "
  "makes it likely that some will survive.", "4.2", "Understand"),
 ("4 (a)", "Any three of: dead animals; rotten food; animal droppings (manure); solid waste (refuse); liquid "
  "waste; faeces; human food.", "4.3", "Remember"),
 ("4 (b)", "It has no teeth and cannot chew; its mouthparts can only suck up liquid, so it must turn solid "
  "food into liquid first.", "4.3", "Understand"),
 ("4 (c)", "It feeds on filthy matter and then lands on human food, carrying disease organisms on its legs "
  "and body hairs and leaving them in its droppings and vomit.", "4.3", "Analyse"),
 ("5 (a)", "Any three of: transfers disease organisms to food; causes food poisoning; contaminates food; is "
  "a nuisance in the environment.", "4.4", "Understand"),
 ("5 (b)", "Any two of: dysentery; cholera; typhoid fever; diarrhoea.", "4.5", "Remember"),
 ("5 (c)", "It feeds on faeces, organisms stick to the hairs on its legs and body, then it walks over "
  "uncovered food and leaves droppings and vomit carrying the organisms.", "4.5", "Apply"),
 ("5 (d)", "Illness caused by eating food containing harmful organisms or their poisons; the fly carries "
  "these from faeces and refuse on to the food, causing stomach pain, vomiting and diarrhoea.",
  "4.4", "Understand"),
 ("6 (a)", "Any three of: cover all food and water; covered refuse bins and proper disposal; regular "
  "cleaning; screen windows and doors; wash hands with soap; keep droppings away from homes.",
  "4.6", "Understand"),
 ("6 (b)", "Covering food stops flies landing on and contaminating it; covering refuse bins stops them "
  "reaching the decaying matter where they feed and lay eggs.", "4.6", "Understand"),
 ("6 (c)", "Any six of: identified problem; practical intervention; who carries it out; when and where; how "
  "the community is educated; how it will be checked. Must be safe and workable.", "4.6", "Create"),
 ("7 (a)", "Make a card or small model for each of the four stages, arrange them egg \u2192 larva \u2192 "
  "pupa \u2192 adult, join them with arrows, and draw an arrow from the adult back to the egg.",
  "4.2", "Create"),
 ("7 (b)", "Any two of: makes the order of the stages clear; pupils can see and handle the stages so they "
  "remember them; safer and cleaner than keeping live flies.", "4.2", "Evaluate"),
]
add_table(["Question", "Expected Answer", "Curriculum Area", "Cognitive Level"],
          [list(r) for r in sba], widths=[0.8, 4.2, 1.2, 1.2], size=9)

doc.add_page_break()

# =========================================================== MARKING SCHEME
para("MARKING SCHEME - SECTION B (60 marks)", size=13, bold=True, align="c", space_after=4)
para("General rules: (1) Accept any other correct and relevant answer. (2) Award marks for correct points, "
     "not for repeating the question. (3) For procedures, award method marks. (4) Do not deduct marks for "
     "spelling unless the meaning is changed. (5) Where a candidate gives more answers than are asked for, "
     "mark only the first ones up to the number required.",
     size=9.5, italic=True, space_after=8)

for qb in SECTION_B:
    n = qb["num"]
    para(f"Question {n}  ({qb['total']} marks)", size=11, bold=True, space_before=8, space_after=3)
    for (lab, points, note) in MARKING[n]:
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(2)
        set_font(p.add_run(f"{lab} "), 10.5, bold=True)
        mkv = [p_[2] for p_ in qb["parts"] if p_[0] == lab]
        if mkv: set_font(p.add_run(f"[{mkv[0]} mark{'s' if mkv[0] > 1 else ''}]"), 10, bold=True)
        for pt in points:
            pp = doc.add_paragraph()
            pp.paragraph_format.left_indent = Inches(0.35); pp.paragraph_format.space_after = Pt(1)
            set_font(pp.add_run("- " + pt), 10.5)
        pp = doc.add_paragraph()
        pp.paragraph_format.left_indent = Inches(0.35); pp.paragraph_format.space_after = Pt(6)
        set_font(pp.add_run("Marking note: " + note), 9.5, italic=True)

doc.add_page_break()

# ================================================================ BLUEPRINT
para("CURRICULUM ASSESSMENT BLUEPRINT", size=13, bold=True, align="c", space_after=3)
para(f"Strand: {STRAND}   |   Sub-strand: {SUBSTRAND}   |   Class: {CLASS}",
     size=10, italic=True, align="c", space_after=3)
para(f"Content Standard: {CS} - {CS_TEXT}", size=9, italic=True, align="c", space_after=3)
para("Source: NaCCA Science Common Core Programme Curriculum (B7/JHS1-B9/JHS3), September 2020, "
     "Strand 2: Cycles, Sub-strand 2: Life Cycle of Organisms, pp. 9-10. Indicators are quoted, not "
     "invented.",
     size=9, italic=True, space_after=8)

hdr = ["Qn", "Sub-strand", "Content Standard", "Indicator (NaCCA) - Indicator Text", "Topic / Content",
       "Cognitive Level", "Marks"]

rows = [[f"A{i}", SUBSTRAND, CS, f"{IND[tp]} - {IND_TEXT[tp]}", TOPIC[tp], cog, 1]
        for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1)]
add_table(hdr, rows, widths=[0.35, 0.75, 0.75, 1.75, 1.4, 0.8, 0.35], size=7, head_size=7.5)

para("", space_after=8)
rows = []
for qb in SECTION_B:
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        key = tp if tp in TOPIC else tp.split(",")[0].strip()
        rows.append([f"B{qb['num']}{lab.strip('()')}", SUBSTRAND, CS,
                     f"{IND[key]} - {IND_TEXT[key]}", TOPIC[key], cog, mk])
add_table(hdr, rows, widths=[0.35, 0.75, 0.75, 1.75, 1.4, 0.8, 0.35], size=7, head_size=7.5)

doc.add_page_break()

# ----------------------------------------------------------------- helpers
def topic_totals():
    m = {k: 0 for k in TOPIC}; it = {k: 0 for k in TOPIC}
    for q in MCQ:
        m[q[3]] += 1; it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk; it[key] += 1
    return m, it

def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}; b = {k: 0 for k in order}
    for q in MCQ: a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: b[cog] += mk
    return order, a, b

def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ: d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: d[diff] += mk
    return d

m, it = topic_totals(); diff = difficulty_totals(); order, ca, cb = cognitive_by_section()

para("SUMMARY 1 - COVERAGE BY CURRICULUM AREA (TOPIC)", size=12, bold=True, space_after=4)
rows = [[TOPIC[k], it[k], m[k], f"{(m[k]/100)*100:.1f}%", CC[k]] for k in TOPIC]
rows.append(["TOTAL", sum(it.values()), sum(m.values()), "100%", "-"])
add_table(["Topic / Content Area", "No. of Items", "Marks", "% of Total Marks", "Core Competencies"],
          rows, widths=[2.7, 0.8, 0.6, 1.0, 1.1], size=8.5)
para("CC = Communication and Collaboration; CP = Critical Thinking and Problem Solving; "
     "DL = Digital Literacy; CI = Creativity and Innovation.", size=8.5, italic=True, space_after=2)

para("", space_after=8)
para("SUMMARY 2 - COGNITIVE-LEVEL DISTRIBUTION (Bloom's Taxonomy)", size=12, bold=True, space_after=4)
rows = []
for lv in order:
    tot = ca[lv] + cb[lv]
    rows.append([lv, ca[lv], cb[lv], tot, f"{(tot/100)*100:.1f}%"])
rows.append(["TOTAL", sum(ca.values()), sum(cb.values()), sum(ca.values()) + sum(cb.values()), "100%"])
add_table(["Cognitive Level", "Section A Marks", "Section B Marks", "Total Marks", "% of Total"],
          rows, widths=[1.6, 1.3, 1.3, 1.1, 1.1], size=9.5)

para("", space_after=8)
para("SUMMARY 3 - DIFFICULTY DISTRIBUTION", size=12, bold=True, space_after=4)
rows = [[k, v, f"{(v/100)*100:.1f}%"] for k, v in diff.items()]
rows.append(["TOTAL", sum(diff.values()), "100%"])
add_table(["Difficulty", "Marks", "% of Total Marks"], rows, widths=[2.0, 1.2, 1.5], size=9.5)
para("Target in the master prompt: approximately 30% easy / 50% moderate / 20% challenging.",
     size=9, italic=True, space_after=2)

para("", space_after=8)
para("SUMMARY 4 - SECTION WEIGHTING", size=12, bold=True, space_after=4)
add_table(["Section", "Question Type", "Items", "Marks", "% of Total"],
          [["A", "Objective (multiple choice)", 40, 40, "40%"],
           ["B", "Theory / constructed response", 21, 60, "60%"],
           ["TOTAL", "-", 61, 100, "100%"]],
          widths=[0.9, 2.4, 0.8, 0.8, 1.0], size=9.5)

doc.add_page_break()

# ===================================================== QUALITY-CONTROL
para("QUALITY-CONTROL SUMMARY", size=13, bold=True, align="c", space_after=4)
para("Carried out against the 14-point validation list in the master prompt before the examination was "
     "finalised.", size=9.5, italic=True, space_after=8)

qc = [
 ("Does every question belong to the supplied curriculum scope?",
  "Yes. All 46 items trace to Strand 2 (Cycles), Sub-Strand 2 (Life Cycle of Organisms), topics 4.1-4.6, and "
  "to the two official B7 indicators (B7/JHS1.2.2.1.1 and B7/JHS1.2.2.1.2). Malaria, measles and rabies "
  "appear only as distractors, never as diseases to be attributed to the housefly."),
 ("Is the examination appropriate for the stated class?",
  "Yes. The B7 curriculum requires learners to identify and describe the four stages in order, describe the "
  "feeding habit, discuss the effects on humans, and design an intervention. No other insect's life cycle, no "
  "genetics and no insect-anatomy detail are tested, as these fall outside the B7 indicators."),
 ("Are the questions genuinely BECE-style?",
  "Yes: Section A is 40 four-option objectives worth 1 mark each, and Section B is structured theory with "
  "sub-questions carrying printed mark allocations. A labelled life-cycle diagram is included, matching the "
  "BECE science convention and the indicator's own exemplar 3, which asks learners to draw and link the stages."),
 ("Are there enough application and reasoning questions?",
  "Yes. 26 of 100 marks (26%) are at Apply level or above (Apply 8, Analyse 5, Evaluate 4, Create 9). "
  "Create is unusually well represented because indicator B7/JHS1.2.2.1.2 exemplar 3 explicitly requires "
  "learners to design an intervention - Question 6(c) carries 6 marks for that task."),
 ("Are the MCQ distractors plausible?",
  "Yes. Distractors are drawn from the same content family as the key: other life-cycle stages, stages in the "
  "wrong order (A9), and diseases that are real but not spread by houseflies (A28, A33)."),
 ("Is there only one best answer for each MCQ?",
  "Yes. Every item was reviewed for a single defensible key. Special care was taken with A18, where several "
  "listed items are plausible feeding matter, so the keyed option (covered fresh bread) is the only one a "
  "housefly cannot normally reach."),
 ("Are the marks internally consistent?",
  "Yes. Section A = 40 items x 1 mark = 40. Section B = 8 + 9 + 6 + 9 + 11 + 12 + 5 = 60. "
  "Each Section B sub-question's printed marks match its marking-scheme allocation."),
 ("Does the total add up correctly?",
  "Yes: 40 + 60 = 100 marks, matching the stated total on the front page."),
 ("Are the answers in the answer key correct?",
  "Yes. All 40 objective keys and all 21 Section B answers were verified against the marking scheme."),
 ("Does the marking scheme match the questions?",
  "Yes. Every Section B sub-question has an expected-answer list and a marking note covering partial credit, "
  "acceptable alternatives, common wrong answers and method marks. The 6-mark design task has a six-point "
  "marking grid so it can be marked consistently across a class."),
 ("Are the questions free from unnecessary ambiguity?",
  "Yes. Open items are anchored with 'state three', 'name two' and the mark allocation. The life-cycle diagram "
  "was checked so that each number points to exactly one stage and no stage is named at more than one number."),
 ("Are Ghanaian contexts used naturally and accurately?",
  "Yes: refuse dumps and open compound refuse, uncovered food at chop bars and in markets, covered bins, "
  "wire-mesh screening, a pupil in Bolgatanga, and community education through churches, mosques and market "
  "women. The intervention question deliberately asks pupils to act on their own community."),
 ("Has any content outside the supplied curriculum been introduced?",
  "No. Every item sits inside topics 4.1-4.6. Question 5 is built around the three areas named in the "
  "curriculum exemplar - transfer of diseases, food poisoning and nuisance in the environment - and the "
  "feeding list in Question 4(a) is taken directly from the exemplar's own list."),
 ("Are the questions sufficiently varied?",
  "Yes. Item types include definition, sequencing, diagram labelling, diagram description, explanation of "
  "mechanism, application to a scenario, evaluation of control methods, and design of an intervention."),
]
for i, (q, a) in enumerate(qc, start=1):
    p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(2)
    set_font(p.add_run(f"{i}. {q}"), 10.5, bold=True)
    p2 = doc.add_paragraph()
    p2.paragraph_format.left_indent = Inches(0.3); p2.paragraph_format.space_after = Pt(6)
    set_font(p2.add_run(a), 10)

para("", space_after=8)
para("EXAMINER NOTES (for the teacher, not for candidates)", size=11, bold=True, space_after=4)
for n in [
 "The curriculum exemplar for indicator B7/JHS1.2.2.1.2 names three effects: transfer of diseases, food "
 "poisoning, and nuisance in the environment. Question 5 is built on exactly those three, and the feeding "
 "list in Question 4(a) is taken from the exemplar's own list (dead animals, rotten food, manure, solid and "
 "liquid waste).",
 "Question 6(c) is the curriculum's 'design an intervention' task and carries 6 marks. It is marked against "
 "a six-point grid (problem, intervention, who, when/where, community education, checking). Because it is "
 "open, two markers should agree on the grid before marking a whole class.",
 "Apply is the thinnest strand in this paper (8 of 100 marks) because most of the higher-order demand sits "
 "in Create (9 marks, the intervention), Evaluate (4 marks) and Analyse (5 marks). That balance follows the "
 "indicator, which asks pupils to design and to discuss rather than to calculate or predict.",
 "Topic 4.2 carries 29 of 100 marks (29%), the highest weighting, because describing the four stages in "
 "order is the core of indicator B7/JHS1.2.2.1.1. If you want a flatter spread, move marks from Questions "
 "2, 3 and 7 to Questions 4 and 5.",
 "The life-cycle diagram is drawn with text characters inside a Word table. Enlarge the font, replace the "
 "characters with real boxes and arrows, or paste in a hand-drawn figure - the numbering (1-4) is what the "
 "questions depend on.",
 "Question 7 deliberately asks pupils to model the cycle rather than to breed houseflies. Do not set any "
 "task that requires keeping live flies in the classroom.",
 "Edit the school name, academic year and examination title on page 1 before printing.",
 "This is an original, teacher-made mock. It is not a reproduction of any WAEC or NaCCA examination paper.",
]:
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Inches(0.3); p.paragraph_format.space_after = Pt(3)
    set_font(p.add_run("- " + n), 10)

doc.save("/home/user/Basic7_Integrated_Science_Mock_Strand2_LifeCycleOfOrganisms.docx")
print("docx written")

print("Section A:", len(MCQ), "items")
print("Section B total:", sum(q["total"] for q in SECTION_B))
print("Topic marks:", m, "sum", sum(m.values()))
print("Difficulty:", diff, "sum", sum(diff.values()))
print("Cognitive A:", ca)
print("Cognitive B:", cb)
print("Answer counts:", counts)
print("Totals:", sum(m.values()), sum(diff.values()),
      sum(ca.values()) + sum(cb.values()))
