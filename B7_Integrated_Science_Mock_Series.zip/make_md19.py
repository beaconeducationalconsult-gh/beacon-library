# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "/home/user")
from build_virus import *

L = []
def w(s=""): L.append(s)

w(f"# {SCHOOL}"); w()
w(f"## {SUBJECT}"); w()
w(f"### {EXAM}"); w()
w(f"**Class:** {CLASS}  ")
w(f"**Time:** {TIME}  ")
w(f"**Total Marks:** {MARKS}  ")
w(f"**Academic Year:** {YEAR}"); w()
w("---"); w()
w("### INSTRUCTIONS"); w()
for i, t in enumerate([
    "Write your name and class clearly in the spaces provided on your answer sheet.",
    "This paper has TWO sections: Section A and Section B.",
    "Answer ALL the questions in both sections.",
    "Section A has 40 multiple-choice questions. Each question carries 1 mark. Choose the best answer (A, B, C or D) and record it on the answer sheet provided.",
    "Section B has 7 theory questions totalling 60 marks. Write your answers clearly and neatly in your answer booklet. Draw and label diagrams or tables where you are asked to.",
    "Read every question carefully before you answer it.",
    "Do not use correction fluid. Cancel any mistake neatly with a single line.",
    "Hand in your answer sheet and your answer booklet at the end of the examination.",
], start=1):
    w(f"{i}. {t}")
w(); w("---"); w()

w("## SECTION A: OBJECTIVE TEST (40 marks)"); w()
w("*Answer ALL questions. Each question carries 1 mark. Choose the BEST answer and write its letter "
  "(A, B, C or D) against the question number on your answer sheet.*"); w()
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"**{i}. {q}**"); w()
    for j, o in enumerate(opts): w(f"{'ABCD'[j]}. {o}")
    w()
w("---"); w()

w("## SECTION B: THEORY (60 marks)"); w()
w("*Answer ALL questions. Write your answers in your answer booklet. The marks for each question are shown "
  "in brackets.*"); w()
for qb in SECTION_B:
    w(f"### Question {qb['num']}  [{qb['total']} marks]"); w()
    w(qb["stem"]); w()
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        w(f"**{lab}** {text}  **[{mk} mark{'s' if mk > 1 else ''}]**"); w()
w("---"); w()

w("## ANSWER KEY"); w()
w("### Section A - Objective Test"); w()
w("| Question | Answer | Curriculum Area (Topic) | Cognitive Level |")
w("| -------- | ------ | ----------------------- | --------------- |")
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"| {i} | {ans} | {TOPIC[tp]} | {cog} |")
counts = {L2: sum(1 for q in MCQ if q[2] == L2) for L2 in "ABCD"}
w()
w("Correct-answer distribution: " + ", ".join(f"{L2} = {counts[L2]}" for L2 in "ABCD") + " (40 items).")
w()
w("### Section B - Theory (summary answers; full detail in the Marking Scheme)"); w()
w("| Question | Expected Answer | Curriculum Area | Cognitive Level |")
w("| -------- | --------------- | --------------- | --------------- |")
sba = [
 ("1 (a)", "A viral disease is an illness caused by a virus. It is infectious, so it can spread from one person to another, and the virus enters the body and multiplies inside the body's living cells. Examples are COVID-19, Ebola, H1N1 influenza, measles and chicken pox.", "17.4", "Understand"),
 ("1 (b)", "Any three: a virus is much smaller than a bacterium; a virus can only multiply inside a living cell while many bacteria can multiply outside cells; antibiotics kill bacteria but have no effect on viruses; bacteria are living cells while a virus is not a complete cell; viral diseases can often be prevented by vaccination.", "17.4", "Understand"),
 ("1 (c)", "Antibiotics are medicines that kill bacteria or stop them multiplying. A virus is not a bacterium and does not have the parts that antibiotics attack, and because a virus multiplies inside the body's own cells a medicine that attacked it would also harm the body's cells. Taking antibiotics when they are not needed can also make bacteria resistant to them later.", "17.4", "Understand"),
 ("2 (a)", "Any three: through droplets released into the air when an infected person coughs, sneezes or talks; by touching surfaces or objects that have the virus on them and then touching the mouth, nose or eyes; by close contact such as shaking hands, hugging or sharing cups and plates; through body fluids, as with Ebola.", "17.4", "Understand"),
 ("2 (b)", "An infected person travels by tro-tro, bus, taxi or plane to another town or country while still infectious. People move from place to place for markets, funerals, school and work, carrying the virus with them. In the new place the person passes the virus to others, who pass it on again, and because travel is now fast a virus can reach many countries within days.", "17.4", "Understand"),
 ("2 (c)", "Any two: people are close together so droplets reach others easily; many people touch the same surfaces such as door handles, rails and money; there is less fresh air and less room to keep a distance; one infectious person can pass the virus to many people in a short time.", "17.4", "Understand"),
 ("3 (a)", "The germ is the corona virus, often written SARS-CoV-2. Any three symptoms: a high temperature or fever; a dry, persistent cough; difficulty in breathing or shortness of breath; loss of taste or smell; tiredness and body aches; a sore throat or headache.", "17.5", "Remember"),
 ("3 (b)", "It spreads mainly through droplets released when an infected person coughs, sneezes, talks or sings. A person nearby breathes in those droplets, or they land on the mouth, nose or eyes, and a person can also pick up the virus by touching a surface that has droplets on it and then touching the face. It spreads most easily indoors and in crowded places.", "17.5", "Understand"),
 ("3 (c)", "Any two: schools were closed for a long time and pupils lost lessons; markets, churches and funerals were restricted or stopped; people were asked to wear face masks and keep a distance; travel between towns and into the country was restricted; many people lost work or income; hospitals were put under great strain.", "17.5", "Understand"),
 ("4 (a)", "Any four: wash the hands often with soap under running water, or use an alcohol hand sanitiser; wear a face mask properly in crowded or enclosed places; keep a distance from other people and avoid crowds; cover the mouth and nose with a bent elbow or tissue when coughing or sneezing; stay at home and report to a health facility when unwell; get vaccinated when the vaccine is offered; clean surfaces that are touched often.", "17.5", "Understand"),
 ("4 (b)", "Either side, with reasons. For: closing schools kept large numbers of children and teachers apart so the virus could not spread easily among them, it protected pupils, teachers and the older people they live with, and it gave the health service time to prepare. Against: pupils lost a lot of learning and some children went hungry without school meals.", "17.5", "Evaluate"),
 ("5 (a)", "Any three: fever and severe headache; body aches, weakness and tiredness; bleeding from the gums, nose, eyes or other body openings; vomiting and diarrhoea; stomach pain.", "17.6", "Remember"),
 ("5 (b)", "Through direct contact with the blood, saliva, sweat, urine, stool or other body fluids of an infected person; by touching or caring for a sick person without gloves and other protection; by washing or touching the body of someone who has died of Ebola during burial preparations; or by touching clothes, bedding or instruments soiled with body fluids. It does not spread through the air over a long distance like flu.", "17.6", "Understand"),
 ("5 (c)", "Ebola spreads very easily through contact with body fluids, so everyone near the person is at risk, and the disease is severe and kills many of those it infects. The person needs skilled treatment at a health facility that the community cannot give, and leaving them at home means carers and family are infected and carry it to others. There is no cure the family can give at home, so delay costs lives.", "17.6", "Apply"),
 ("6 (a)", "H1N1 is a viral disease, a kind of influenza or flu that affects people, first called swine flu because the virus is related to flu viruses found in pigs. Any two symptoms: fever and chills; a cough and sore throat; a running or blocked nose; body aches, headache and tiredness; vomiting or diarrhoea.", "17.6", "Understand"),
 ("6 (b)", "Any two similarities: both are caused by a virus and both can be declared a pandemic; both spread through droplets from coughing and sneezing; both cause fever, cough and tiredness and can make breathing difficult; both are prevented by handwashing, masks, distance and avoiding crowds. Any one difference: Ebola spreads through body fluids rather than mainly through the air and causes bleeding, or Ebola kills a far larger share of the people it infects, or H1N1 is a flu that most people recover from while Ebola is much more severe.", "17.6", "Analyse"),
 ("6 (c)", "Any two: wash the hands often with soap and water; cover the mouth and nose when coughing or sneezing; keep away from crowds and keep a distance from anyone coughing; get the seasonal flu vaccine where it is available; stay at home and rest when unwell; clean surfaces that are touched often and keep rooms well aired.", "17.6", "Apply"),
 ("7 (a)", "The individual should wash hands regularly, wear a mask in crowded places, report sickness early and follow the health rules. The community should report cases early, support families who are isolating, and stop spreading false information. The government should provide testing, treatment and isolation centres, give clear health education, and supply protective equipment to health workers.", "17.7", "Understand"),
 ("7 (b)", "A short clear message such as 'Wash your hands, wear your mask, keep your distance'; pictures showing hands being washed, a mask being worn and someone covering a cough; the signs of the disease and what to do about them; a phone number or place to report to. Use very few words and large letters, pictures and symbols rather than long sentences because some people cannot read, the local language as well as English, bright colours, and put the message at the top.", "17.7", "Create"),
 ("7 (c)", "Any two with a reason: at the market, because many people pass there every day; at the clinic or health centre, where people already come for health matters; at the school, so pupils and parents both see it; at the church or mosque, where the community gathers; at the lorry station, where travellers pass through.", "17.7", "Apply"),
]
for r in sba: w(f"| {r[0]} | {r[1]} | {r[2]} | {r[3]} |")
w(); w("---"); w()

w("## MARKING SCHEME - SECTION B (60 marks)"); w()
w("*General rules: (1) Accept any other correct and relevant answer. (2) Award marks for correct points, not "
  "for repeating the question. (3) For procedures, award method marks. (4) Do not deduct marks for spelling "
  "unless the meaning is changed. (5) Where a candidate gives more answers than are asked for, mark only the "
  "first ones up to the number required.*"); w()
for qb in SECTION_B:
    n = qb["num"]
    w(f"### Question {n} ({qb['total']} marks)"); w()
    for (lab, points, note) in MARKING[n]:
        mkv = [p_[2] for p_ in qb["parts"] if p_[0] == lab]
        head = f"**{lab}**"
        if mkv: head += f" [{mkv[0]} mark{'s' if mkv[0] > 1 else ''}]"
        w(head); w()
        for pt in points: w(f"- {pt}")
        w(f"  - *Marking note: {note}*"); w()
w("---"); w()

w("## CURRICULUM ASSESSMENT BLUEPRINT"); w()
w(f"**Strand:** {STRAND} | **Sub-strand:** {SUBSTRAND} | **Class:** {CLASS}"); w()
w(f"**Content Standard:** {CS} - {CS_TEXT}"); w()
w("> Source: NaCCA Science Common Core Programme Curriculum (B7/JHS1-B9/JHS3), September 2020, "
  "Strand 5: Humans and the Environment, Sub-strand 2: Human Health "
  "(topics 17.4-17.7), p. 46. Indicators are quoted, not invented."); w()

w("### Section A"); w()
w("| Qn | Sub-strand | Content Standard | Indicator (NaCCA) - Indicator Text | Topic / Content | Cognitive Level | Marks |")
w("| -- | ---------- | ---------------- | ---------------------------------- | --------------- | --------------- | ----- |")
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"| A{i} | {SUBSTRAND} | {CS_BY_TOPIC[tp]} | {IND[tp]} - {IND_TEXT[tp]} | {TOPIC[tp]} | {cog} | 1 |")
w()
w("### Section B"); w()
w("| Qn | Sub-strand | Content Standard | Indicator (NaCCA) - Indicator Text | Topic / Content | Cognitive Level | Marks |")
w("| -- | ---------- | ---------------- | ---------------------------------- | --------------- | --------------- | ----- |")
for qb in SECTION_B:
    for (lab, text, mkv, cog, tp, diff) in qb["parts"]:
        key = tp if tp in TOPIC else tp.split(",")[0].strip()
        w(f"| B{qb['num']}{lab.strip('()')} | {SUBSTRAND} | {CS_BY_TOPIC[key]} | {IND[key]} - {IND_TEXT[key]} | {TOPIC[key]} | {cog} | {mkv} |")
w(); w("---"); w()

def topic_totals():
    m = {k: 0 for k in TOPIC}; it = {k: 0 for k in TOPIC}
    for q in MCQ: m[q[3]] += 1; it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk; it[key] += 1
    return m, it

def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}; b = {k: 0 for k in order}
    for q in MCQ: a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: b[cog] += mk
    return order, a, b

def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ: d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: d[diff] += mk
    return d

m, it = topic_totals(); diff_ = difficulty_totals(); order, ca, cb = cognitive_by_section()

w("### Summary 1 - Coverage by Curriculum Area (Topic)"); w()
w("| Topic / Content Area | No. of Items | Marks | % of Total Marks | Core Competencies |")
w("| -------------------- | ------------ | ----- | ---------------- | ----------------- |")
for k in TOPIC: w(f"| {TOPIC[k]} | {it[k]} | {m[k]} | {(m[k]/100)*100:.1f}% | {CC[k]} |")
w(f"| **TOTAL** | **{sum(it.values())}** | **{sum(m.values())}** | **100%** | - |")
w()
w("*CC = Communication and Collaboration; CP = Critical Thinking and Problem Solving; DL = Digital Literacy; "
  "CI = Creativity and Innovation.*"); w()
w("### Summary 2 - Cognitive-Level Distribution (Bloom's Taxonomy)"); w()
w("| Cognitive Level | Section A Marks | Section B Marks | Total Marks | % of Total |")
w("| --------------- | --------------- | --------------- | ----------- | ---------- |")
for lv in order:
    tot = ca[lv] + cb[lv]
    w(f"| {lv} | {ca[lv]} | {cb[lv]} | {tot} | {(tot/100)*100:.1f}% |")
w(f"| **TOTAL** | **{sum(ca.values())}** | **{sum(cb.values())}** | **{sum(ca.values())+sum(cb.values())}** | **100%** |")
w()
w("### Summary 3 - Difficulty Distribution"); w()
w("| Difficulty | Marks | % of Total Marks |")
w("| ---------- | ----- | ---------------- |")
for k, v in diff_.items(): w(f"| {k} | {v} | {(v/100)*100:.1f}% |")
w(f"| **TOTAL** | **{sum(diff_.values())}** | **100%** |")
w()
w("*Target in the master prompt: approximately 30% easy / 50% moderate / 20% challenging.*"); w()
w("### Summary 4 - Section Weighting"); w()
w("| Section | Question Type | Items | Marks | % of Total |")
w("| ------- | ------------- | ----- | ----- | ---------- |")
w("| A | Objective (multiple choice) | 40 | 40 | 40% |")
w("| B | Theory / constructed response | 20 | 60 | 60% |")
w("| **TOTAL** | - | **60** | **100** | **100%** |")
w(); w("---"); w()

w("## QUALITY-CONTROL SUMMARY")
w("")
w("| Check | Status |")
w("| --- | --- |")
for q_, a_ in [
 ("Every question within supplied curriculum scope",
  "Yes - all 60 items (40 objectives and 20 theory sub-questions) sit in topics 17.4-17.7 of Strand 5, Sub-Strand 2 (Human Health), under content standard B7/JHS1.5.2.2, mapped to indicator B7/JHS1.5.2.2.1. Deficiency diseases and food nutrients are excluded; they belong to the companion paper on B7/JHS1.5.2.1"),
 ("Appropriate for the class",
  "Yes - B7 level; no deficiency diseases, no food nutrients, and no virus biology beyond 'a virus multiplies only inside a living cell' and 'antibiotics act on bacteria, not viruses'"),
 ("Genuinely BECE-style",
  "Yes - 40 four-option objectives plus structured theory with printed mark allocations, 'state', 'name', 'describe' and 'explain' items, an argument task, a comparison task and a poster-design task"),
 ("Sufficient application and reasoning",
  "Yes - 34 of 100 marks (34%) at Apply level or above (Apply 22, Analyse 4, Evaluate 4, Create 4)"),
 ("Plausible MCQ distractors",
  "Yes - a real disease caused by something other than a virus, a symptom belonging to a different disease, a genuine activity that is not protective, a real statement about the wrong group, and a genuine poster item that is simply the least useful"),
 ("Single best answer per MCQ",
  "Yes - reviewed item by item and each option list was checked so that the declared key sits on the correct answer; malaria, cholera and typhoid are all diseases but none is viral in A3, malaria, cholera and kwashiorkor are all real diseases but only the common flu matches how H1N1 spreads in A24, and three of the four options in A40 are genuinely useful on a poster"),
 ("Marks internally consistent",
  "Yes - Section A 40 x 1 = 40; Section B 9 + 8 + 9 + 8 + 9 + 8 + 9 = 60; sub-question marks match the marking scheme"),
 ("Total adds up correctly",
  "Yes - 40 + 60 = 100"),
 ("Answer key correct",
  "Yes - all 40 keys and all 20 Section B answers verified against the marking scheme; the three transmission routes checked apart (COVID-19 and H1N1 through droplets, Ebola through contact with body fluids and not through the air over a distance)"),
 ("Marking scheme matches questions",
  "Yes - expected answers plus marking notes covering partial credit, alternatives, common wrong answers and method marks; Question 2(b) caps the answer at 2 if it describes only person-to-person spread, Question 5(b) caps it at 2 if it says Ebola spreads through the air, and Question 7(b) requires both what the poster shows and how it is made clear to someone who cannot read"),
 ("Free from unnecessary ambiguity",
  "Yes - open items are anchored with 'state three', 'state four' and 'state two' plus the mark allocation; Question 7(a) asks for one role each of three named groups and the note withholds the mark when a correct action is attached to the wrong group, Question 6(b) asks for two similarities and one difference, Question 3(a) asks for the germ and three symptoms, and Question 1(c) asks why antibiotics do not work rather than whether they do"),
 ("Ghanaian contexts natural and accurate",
  "Yes - tro-tros, buses and taxis between towns, markets, churches, mosques and funerals, the lorry station, the chief's palace, the clinic and health centre, school closures and lost lessons, travel restrictions, and posters in the local language as well as English"),
 ("No content beyond the curriculum",
  "No - every item sits inside topics 17.4-17.7; deficiency diseases and food nutrients are not required anywhere, and no virus is named beyond the corona virus, Ebola and H1N1"),
 ("Questions sufficiently varied",
  "Yes - defining a viral disease, contrasting a virus with a bacterium, explaining why antibiotics fail, describing three routes of spread, explaining spread between communities and countries, explaining why crowds are risky, naming the cause and symptoms of COVID-19, explaining droplet spread, listing effects on Ghana, listing four preventive measures, arguing about school closures, listing Ebola symptoms, explaining Ebola's transmission, justifying removal of a suspected case, explaining H1N1, comparing it with another viral disease, preventing flu, giving the roles of individual, community and government, designing a poster, and choosing where to put it up"),
]:
    w("| " + q_ + " | " + a_ + " |")
w("")
w("### EXAMINER NOTES")
w("")
for n_ in [
 "Question 1(c) is the item that separates understanding from rote learning. Pupils who have only memorised a list will say 'antibiotics do not work'. The marks are on why: antibiotics attack bacteria, a virus has none of the parts they attack, and a virus hides inside the body's own cells. Worth teaching the reason, not just the rule.",
 "Questions 5(b) and 3(b) sit next to each other on purpose, because pupils merge the two routes. COVID-19 and H1N1 travel in droplets from the breath; Ebola travels in body fluids and NOT through the air over a distance. Both notes cap the answer at 2 if the route is given for the wrong disease, so drill the pair together.",
 "Question 7(b) is the design task, and it is marked on two halves: what the poster SHOWS or SAYS, and how it is made clear to someone who cannot read. Many pupils will produce a good slogan and forget the second half. The note caps them at 3 of 4 for that.",
 "Question 4(b) is deliberately open. Pupils who lived through the school closures have real views about it, and the note credits either side provided the reasons support the position. Do not mark down a pupil who argues that closing schools was wrong, if the reasons are good.",
 "Question 6(b) asks for two similarities and one difference, and pupils may compare H1N1 with either COVID-19 or Ebola. Both are accepted. The one answer to watch for is a 'difference' that is really a similarity written twice.",
 "Topic weighting is 26 marks for 17.4, 28 for 17.5, 24 for 17.6 and 22 for 17.7. If you spent longer on community roles than on the nature of viruses, move marks towards Question 7.",
 "Two cheap activities that raise marks sharply: (1) put glitter or flour on one pupil's hands and let the class see how far it travels by touch in five minutes, and (2) have the class design a real poster and then read it to a pupil from a lower class to test whether the message lands. The first teaches Question 2, the second teaches Question 7.",
 "The companion paper covers topics 17.1 to 17.3 - food nutrients, deficiency diseases, and night blindness, rickets, scurvy, kwashiorkor and anaemia - under content standard B7/JHS1.5.2.1. Use the two papers together for a full end-of-term examination on this sub-strand, or separately as two class tests.",
 "Edit the school name, academic year and examination title on page 1 before printing.",
 "This is an original, teacher-made mock. It is not a reproduction of any WAEC or NaCCA examination paper.",
]:
    w("- " + n_)
w()

open("/home/user/Basic7_Integrated_Science_Mock_Strand5_HumanHealth2.md", "w", encoding="utf-8").write("\n".join(L))
print("md written", len("\n".join(L)), "chars")
