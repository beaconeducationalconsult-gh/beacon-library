# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "/home/user")
from build_animal import *

from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT

doc = Document()
sec = doc.sections[0]
sec.left_margin = Inches(0.7); sec.right_margin = Inches(0.7)
sec.top_margin = Inches(0.7); sec.bottom_margin = Inches(0.6)

st = doc.styles["Normal"]; st.font.name = "Calibri"; st.font.size = Pt(11)


def set_font(run, size=11, bold=False, italic=False, mono=False, color=None):
    run.font.size = Pt(size); run.bold = bold; run.italic = italic
    run.font.name = "Consolas" if mono else "Calibri"
    if color: run.font.color.rgb = color
    return run


def para(text="", size=11, bold=False, italic=False, align=None, mono=False,
         space_before=0, space_after=4, color=None):
    p = doc.add_paragraph()
    if align == "c": p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    elif align == "j": p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p.paragraph_format.space_before = Pt(space_before)
    p.paragraph_format.space_after = Pt(space_after)
    if text: set_font(p.add_run(text), size, bold, italic, mono, color)
    return p


def rule():
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(6); p.paragraph_format.space_before = Pt(2)
    set_font(p.add_run("_" * 78), 9, color=RGBColor(0x99, 0x99, 0x99))


def add_table(headers, rows, widths=None, size=9, head_size=9):
    t = doc.add_table(rows=1, cols=len(headers)); t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, h in enumerate(headers):
        c = t.rows[0].cells[i]; c.text = ""
        p = c.paragraphs[0]; p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_font(p.add_run(str(h)), head_size, bold=True)
    for row in rows:
        cells = t.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = ""
            p = cells[i].paragraphs[0]; p.paragraph_format.space_after = Pt(1)
            set_font(p.add_run(str(v)), size)
    if widths:
        for r_ in t.rows:
            for i, w in enumerate(widths): r_.cells[i].width = Inches(w)
    return t


def draw_diagram(lines, caption):
    t = doc.add_table(rows=2, cols=1); t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = t.rows[0].cells[0]
    for k, line in enumerate(lines):
        p = cell.paragraphs[0] if k == 0 else cell.add_paragraph()
        p.paragraph_format.space_after = Pt(0); p.paragraph_format.space_before = Pt(0)
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_font(p.add_run(line), 10, mono=True)
    c2 = t.rows[1].cells[0].paragraphs[0]
    c2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_font(c2.add_run(caption), 9, italic=True)
    t.rows[0].cells[0].width = Inches(6.6)
    t.rows[1].cells[0].width = Inches(6.6)


# ============================================================= TITLE BLOCK
para(SCHOOL, size=15, bold=True, align="c", space_after=2)
para(SUBJECT, size=13, bold=True, align="c", space_after=2)
para(EXAM, size=12, bold=True, align="c", space_after=2)
para(YEAR, size=10, italic=True, align="c", space_after=8)

info = doc.add_table(rows=1, cols=3); info.style = "Table Grid"
info.alignment = WD_TABLE_ALIGNMENT.CENTER
for i, v in enumerate([f"Class: {CLASS}", f"Time: {TIME}", f"Total Marks: {MARKS}"]):
    c = info.rows[0].cells[i]; c.text = ""
    set_font(c.paragraphs[0].add_run(v), 10, bold=True)
para("", space_after=6)

para("INSTRUCTIONS", size=11, bold=True, space_after=3)
for txt in [
    "1. Write your name and class clearly in the spaces provided on your answer sheet.",
    "2. This paper has TWO sections: Section A and Section B.",
    "3. Answer ALL the questions in both sections.",
    "4. Section A has 40 multiple-choice questions. Each question carries 1 mark. Choose the best answer "
    "(A, B, C or D) and record it on the answer sheet provided.",
    "5. Section B has 7 theory questions totalling 60 marks. Write your answers clearly and neatly in your "
    "answer booklet. Draw and label diagrams or tables where you are asked to.",
    "6. Read every question carefully before you answer it.",
    "7. Do not use correction fluid. Cancel any mistake neatly with a single line.",
    "8. Hand in your answer sheet and your answer booklet at the end of the examination.",
]:
    para(txt, size=10.5, space_after=2)
rule()

# =============================================================== SECTION A
para("SECTION A - OBJECTIVE TEST (40 marks)", size=12, bold=True, align="c", space_after=2)
para("Answer ALL questions. Each question carries 1 mark. Choose the BEST answer and write its letter "
     "(A, B, C or D) against the question number on your answer sheet.",
     size=10, italic=True, align="c", space_after=8)

for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(1); p.paragraph_format.space_before = Pt(4)
    set_font(p.add_run(f"{i}. {q}"), 10.5)
    for j, o in enumerate(opts):
        p2 = doc.add_paragraph()
        p2.paragraph_format.left_indent = Inches(0.28)
        p2.paragraph_format.space_after = Pt(0); p2.paragraph_format.space_before = Pt(0)
        set_font(p2.add_run(f"{'ABCD'[j]}. {o}"), 10.5)

doc.add_page_break()

# =============================================================== SECTION B
para("SECTION B - THEORY (60 marks)", size=12, bold=True, align="c", space_after=2)
para("Answer ALL questions. Write your answers in your answer booklet. The marks for each question are "
     "shown in brackets.", size=10, italic=True, align="c", space_after=8)

for qb in SECTION_B:
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(8); p.paragraph_format.space_after = Pt(2)
    set_font(p.add_run(f"Question {qb['num']}"), 11, bold=True)
    set_font(p.add_run(f"  [{qb['total']} marks]"), 10, bold=True, italic=True)
    para(qb["stem"], size=10.5, space_after=4)
    if qb.get("table") == "classify":
        add_table(CLASSIFY_HEADERS, CLASSIFY_ROWS, widths=[1.5, 1.5, 1.9, 1.9], size=8.5, head_size=8.5)
        para(CLASSIFY_CAPTION, size=9, italic=True, align="c", space_after=6)
        para("", space_after=2)
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Inches(0.25)
        p.paragraph_format.space_after = Pt(3); p.paragraph_format.space_before = Pt(2)
        set_font(p.add_run(f"{lab} {text}  "), 10.5)
        set_font(p.add_run(f"[{mk} mark{'s' if mk > 1 else ''}]"), 10, bold=True)

doc.add_page_break()

# ============================================================== ANSWER KEY
para("ANSWER KEY", size=13, bold=True, align="c", space_after=6)
para("SECTION A - OBJECTIVE TEST", size=11, bold=True, space_after=4)
rows = [[i, ans, TOPIC[tp], cog] for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1)]
add_table(["Question", "Answer", "Curriculum Area (Topic)", "Cognitive Level"],
          rows, widths=[0.8, 0.7, 3.6, 1.5], size=9)
counts = {L: sum(1 for q in MCQ if q[2] == L) for L in "ABCD"}
para("", space_after=4)
para("Correct-answer distribution: " + ", ".join(f"{L} = {counts[L]}" for L in "ABCD") + " (30 items).",
     size=9, italic=True)

para("", space_after=8)
para("SECTION B - THEORY (summary answers; see the Marking Scheme for full detail)",
     size=11, bold=True, space_after=4)
sba = [
 ("1 (a)", "An animal that people have tamed and keep for their own use; it depends on people for food, "
  "water and shelter and is not wild.", "6.1", "Understand"),
 ("1 (b)", "Any four of: cattle; goat; sheep; pig; fowl; duck; guinea fowl; turkey; rabbit; pigeon; "
  "donkey; dog; cat.", "6.1", "Remember"),
 ("1 (c)", "Cattle: N'Dama, Sanga or Zebu. Goat: West African Dwarf or Sahelian.", "6.1", "Remember"),
 ("2 (a)", "Ruminant: an animal with a four-chambered stomach that chews the cud. Monogastric: an animal "
  "with a simple, single-chambered stomach. Poultry: birds kept by people, such as fowl, duck, guinea "
  "fowl, turkey and pigeon.", "6.2", "Understand"),
 ("2 (b)", "Ruminant - cattle, goat or sheep. Monogastric - pig or rabbit. Poultry - fowl, duck, guinea "
  "fowl, turkey or pigeon.", "6.2", "Remember"),
 ("2 (c)", "Watch them resting: the goat brings food back up and chews it again (chews the cud) and "
  "thrives on grass, while the pig does not and needs grains and kitchen waste. The goat is the "
  "ruminant.", "6.2", "Apply"),
 ("3 (a)", "(i) simple, one chamber; (ii) no; (iii) feathers; (iv) born alive; (v) grass and other "
  "fibrous plant material (forage, hay, leaves); (vi) no upper front teeth - a hard dental pad.", "6.3",
  "Understand"),
 ("3 (b)", "Any two of: all are kept by people; all need food, water, shelter and care; all are kept "
  "for food (meat, milk or eggs); all reproduce; all produce waste used as manure; all have a backbone; "
  "all need protection from disease and heat.", "6.3", "Understand"),
 ("3 (c)", "The goat is a ruminant: micro-organisms in its four-chambered stomach break down the fibre "
  "in grass. The pig has a simple stomach and cannot break down much fibre, so it needs grains, kitchen "
  "waste and concentrates.", "6.3", "Analyse"),
 ("4 (a)", "Using animals to meet the needs of the family or household - the animal or what it gives is "
  "used at home rather than sold.", "6.4", "Understand"),
 ("4 (b)", "Keeping animals in order to sell them or what they produce, in order to earn money.", "6.4",
  "Understand"),
 ("4 (c)", "Any four of: selling meat; selling eggs; selling milk; selling live animals; selling hides "
  "and skins; selling feathers, bones or blood meal; selling manure; ploughing other people's fields or "
  "carrying goods for money.", "6.4", "Understand"),
 ("5 (a)", "Any three of: milk, meat or eggs for the family; dung for cooking fuel or the family "
  "garden; ploughing or carrying loads; a dog to guard the house; animals for dowry, festivals or "
  "ceremonies; company or pets; feathers, wool or hides used at home.", "6.4", "Understand"),
 ("5 (b)", "The family eats what it needs and sells the extra, which gives money for school fees, food "
  "and medicine; keeping animals is also a way of saving, because one can be sold when cash is needed.",
  "6.4", "Analyse"),
 ("5 (c)", "Any three of: a clear picture of each animal; its name and the group it belongs to; what it "
  "is kept for (domestic uses); what it eats and how it is housed; its by-products and their uses; "
  "short clear sentences under each picture; a title and the class name.", "6.4", "Create"),
 ("6 (a)", "A useful material obtained from an animal apart from the main product - something useful "
  "that is left after the meat, milk or eggs have been taken.", "6.5", "Understand"),
 ("6 (b)", "Any five correctly named with an importance: dung - manure; bones - bone meal for feed and "
  "fertilizer; hides and skins - leather; feathers - pillows and cushions; blood - blood meal for "
  "feed; horns and hooves - glue, buttons and combs; fat - soap and candles; wool and hair - cloth and "
  "blankets; urine - compost; eggshells - feed or compost.", "6.5", "Understand"),
 ("6 (c)", "Dung adds plant nutrients, improves the soil structure and helps the soil hold water, and "
  "it saves money on fertilizer. It should be heaped and left to rot (composted) for some weeks, then "
  "spread on the bed and worked lightly into the soil; fresh dung can scorch young plants.", "6.5",
  "Apply"),
 ("7 (a)", "Decide the questions; walk round the community and observe the animals; write down each "
  "animal and what it is kept for; ask the owners a few set questions; record everything in a table; "
  "bring the results together and write a short report.", "6.5", "Create"),
 ("7 (b)", "Any two of: shows which animals are really kept and what they are used for; makes class "
  "work real instead of only reading; shows which animals earn money for families; practises observing, "
  "recording and group work; the class could advise families on better animal care.", "6.5", "Evaluate"),
]
add_table(["Question", "Expected Answer", "Curriculum Area", "Cognitive Level"],
          [list(r) for r in sba], widths=[0.8, 4.2, 1.2, 1.2], size=9)

doc.add_page_break()

# =========================================================== MARKING SCHEME
para("MARKING SCHEME - SECTION B (60 marks)", size=13, bold=True, align="c", space_after=4)
para("General rules: (1) Accept any other correct and relevant answer. (2) Award marks for correct points, "
     "not for repeating the question. (3) For procedures, award method marks. (4) Do not deduct marks for "
     "spelling unless the meaning is changed. (5) Where a candidate gives more answers than are asked for, "
     "mark only the first ones up to the number required.",
     size=9.5, italic=True, space_after=8)

for qb in SECTION_B:
    n = qb["num"]
    para(f"Question {n}  ({qb['total']} marks)", size=11, bold=True, space_before=8, space_after=3)
    for (lab, points, note) in MARKING[n]:
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(2)
        set_font(p.add_run(f"{lab} "), 10.5, bold=True)
        mkv = [p_[2] for p_ in qb["parts"] if p_[0] == lab]
        if mkv: set_font(p.add_run(f"[{mkv[0]} mark{'s' if mkv[0] > 1 else ''}]"), 10, bold=True)
        for pt in points:
            pp = doc.add_paragraph()
            pp.paragraph_format.left_indent = Inches(0.35); pp.paragraph_format.space_after = Pt(1)
            set_font(pp.add_run("- " + pt), 10.5)
        pp = doc.add_paragraph()
        pp.paragraph_format.left_indent = Inches(0.35); pp.paragraph_format.space_after = Pt(6)
        set_font(pp.add_run("Marking note: " + note), 9.5, italic=True)

doc.add_page_break()

# ================================================================ BLUEPRINT
para("CURRICULUM ASSESSMENT BLUEPRINT", size=13, bold=True, align="c", space_after=3)
para(f"Strand: {STRAND}   |   Sub-strand: {SUBSTRAND}   |   Class: {CLASS}",
     size=10, italic=True, align="c", space_after=3)
para(f"Content Standard: {CS} - {CS_TEXT}", size=9, italic=True, align="c", space_after=3)
para("Source: NaCCA Science Common Core Programme Curriculum (B7/JHS1-B9/JHS3), September 2020, "
     "Strand 2: Cycles, Sub-strand 4: Animal Production, pp. 12-15. Indicators are quoted, not "
     "invented.",
     size=9, italic=True, space_after=8)

hdr = ["Qn", "Sub-strand", "Content Standard", "Indicator (NaCCA) - Indicator Text", "Topic / Content",
       "Cognitive Level", "Marks"]

rows = [[f"A{i}", SUBSTRAND, CS_BY_TOPIC[tp], f"{IND[tp]} - {IND_TEXT[tp]}", TOPIC[tp], cog, 1]
        for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1)]
add_table(hdr, rows, widths=[0.35, 0.75, 0.75, 1.75, 1.4, 0.8, 0.35], size=7, head_size=7.5)

para("", space_after=8)
rows = []
for qb in SECTION_B:
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        key = tp if tp in TOPIC else tp.split(",")[0].strip()
        rows.append([f"B{qb['num']}{lab.strip('()')}", SUBSTRAND, CS_BY_TOPIC[key],
                     f"{IND[key]} - {IND_TEXT[key]}", TOPIC[key], cog, mk])
add_table(hdr, rows, widths=[0.35, 0.75, 0.75, 1.75, 1.4, 0.8, 0.35], size=7, head_size=7.5)

doc.add_page_break()

# ----------------------------------------------------------------- helpers
def topic_totals():
    m = {k: 0 for k in TOPIC}; it = {k: 0 for k in TOPIC}
    for q in MCQ:
        m[q[3]] += 1; it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk; it[key] += 1
    return m, it

def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}; b = {k: 0 for k in order}
    for q in MCQ: a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: b[cog] += mk
    return order, a, b

def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ: d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: d[diff] += mk
    return d

m, it = topic_totals(); diff = difficulty_totals(); order, ca, cb = cognitive_by_section()

para("SUMMARY 1 - COVERAGE BY CURRICULUM AREA (TOPIC)", size=12, bold=True, space_after=4)
rows = [[TOPIC[k], it[k], m[k], f"{(m[k]/100)*100:.1f}%", CC[k]] for k in TOPIC]
rows.append(["TOTAL", sum(it.values()), sum(m.values()), "100%", "-"])
add_table(["Topic / Content Area", "No. of Items", "Marks", "% of Total Marks", "Core Competencies"],
          rows, widths=[2.7, 0.8, 0.6, 1.0, 1.1], size=8.5)
para("CC = Communication and Collaboration; CP = Critical Thinking and Problem Solving; "
     "DL = Digital Literacy; CI = Creativity and Innovation.", size=8.5, italic=True, space_after=2)

para("", space_after=8)
para("SUMMARY 2 - COGNITIVE-LEVEL DISTRIBUTION (Bloom's Taxonomy)", size=12, bold=True, space_after=4)
rows = []
for lv in order:
    tot = ca[lv] + cb[lv]
    rows.append([lv, ca[lv], cb[lv], tot, f"{(tot/100)*100:.1f}%"])
rows.append(["TOTAL", sum(ca.values()), sum(cb.values()), sum(ca.values()) + sum(cb.values()), "100%"])
add_table(["Cognitive Level", "Section A Marks", "Section B Marks", "Total Marks", "% of Total"],
          rows, widths=[1.6, 1.3, 1.3, 1.1, 1.1], size=9.5)

para("", space_after=8)
para("SUMMARY 3 - DIFFICULTY DISTRIBUTION", size=12, bold=True, space_after=4)
rows = [[k, v, f"{(v/100)*100:.1f}%"] for k, v in diff.items()]
rows.append(["TOTAL", sum(diff.values()), "100%"])
add_table(["Difficulty", "Marks", "% of Total Marks"], rows, widths=[2.0, 1.2, 1.5], size=9.5)
para("Target in the master prompt: approximately 30% easy / 50% moderate / 20% challenging.",
     size=9, italic=True, space_after=2)

para("", space_after=8)
para("SUMMARY 4 - SECTION WEIGHTING", size=12, bold=True, space_after=4)
add_table(["Section", "Question Type", "Items", "Marks", "% of Total"],
          [["A", "Objective (multiple choice)", 40, 40, "40%"],
           ["B", "Theory / constructed response", 20, 60, "60%"],
           ["TOTAL", "-", 60, 100, "100%"]],
          widths=[0.9, 2.4, 0.8, 0.8, 1.0], size=9.5)

doc.add_page_break()

# ===================================================== QUALITY-CONTROL
para("QUALITY-CONTROL SUMMARY", size=13, bold=True, align="c", space_after=4)
para("Carried out against the 14-point validation list in the master prompt before the examination was "
     "finalised.", size=9.5, italic=True, space_after=8)

qc = [
 ("Does every question belong to the supplied curriculum scope?",
  "Yes. All 46 items trace to Strand 2 (Cycles), Sub-Strand 4 (Animal Production), topics 6.1-6.5, and "
  "to the four official B7 indicators (B7/JHS1.2.4.1.1, B7/JHS1.2.4.1.2, B7/JHS1.2.4.2.1 and "
  "B7/JHS1.2.4.2.2). Anatomy, digestion chemistry, disease, housing design and breeding appear only as "
  "distractors, never as things pupils must answer on."),
 ("Is the examination appropriate for the stated class?",
  "Yes. The B7 curriculum requires learners to list community animals and their breeds, classify them "
  "into ruminants, monogastrics and poultry, write their differences and similarities, explain domestic "
  "and commercial use, and match animals to their commercial uses including by-products. No stomach "
  "anatomy beyond 'four chambers' versus 'simple', no nutrient chemistry and no farm economics are "
  "tested, as these fall outside the B7 indicators."),
 ("Are the questions genuinely BECE-style?",
  "Yes: Section A is 40 four-option objectives worth 1 mark each, and Section B is structured theory "
  "with sub-questions carrying printed mark allocations. Question 3 uses a table for pupils to "
  "complete, matching the BECE science convention and the indicator's own exemplar 3, which asks "
  "learners to discuss and write the differences among the three groups."),
 ("Are there enough application and reasoning questions?",
  "Yes. 29 of 100 marks (29%) are at Apply level or above (Apply 13, Analyse 7, Evaluate 3, Create 6). "
  "Create is well represented because the exemplars ask pupils to design a poster, carry out a "
  "community study, and complete a comparison table."),
 ("Are the MCQ distractors plausible?",
  "Yes. Distractors are drawn from the same content family as the key: the other animal group (A8-A16), "
  "a feature of a different group (A18, A22), real but wrong breeds (A7), and plausible but wrong "
  "uses (A27, A28)."),
 ("Is there only one best answer for each MCQ?",
  "Yes. Every item was reviewed for a single defensible key. Special care was taken with A29, where "
  "hide could be argued either way, so the stem asks specifically for a DIRECT product and not a "
  "by-product."),
 ("Are the marks internally consistent?",
  "Yes. Section A = 40 items x 1 mark = 40. Section B = 9 + 9 + 10 + 8 + 8 + 11 + 5 = 60. "
  "Each Section B sub-question's printed marks match its marking-scheme allocation."),
 ("Does the total add up correctly?",
  "Yes: 40 + 60 = 100 marks, matching the stated total on the front page."),
 ("Are the answers in the answer key correct?",
  "Yes. All 40 objective keys and all 20 Section B answers were verified against the marking scheme."),
 ("Does the marking scheme match the questions?",
  "Yes. Every Section B sub-question has an expected-answer list and a marking note covering partial "
  "credit, acceptable alternatives, common wrong answers and method marks. The two design tasks "
  "(Question 5(c), 3 marks, and Question 7(a), 3 marks) have opening marking grids so they can be "
  "marked consistently across a class."),
 ("Are the questions free from unnecessary ambiguity?",
  "Yes. Open items are anchored with 'state three', 'name four' and the mark allocation. Question 3(a) "
  "numbers every blank (i) to (vi), so there is no doubt which answer belongs where, and Question 6(b) "
  "states that both the by-product and its importance must be given."),
 ("Are Ghanaian contexts used naturally and accurately?",
  "Yes: cattle, goats, sheep, pigs, fowl, ducks and guinea fowl; the breeds N'Dama, Sanga and Zebu, "
  "West African Dwarf and Sahelian goats and Djallonke sheep; chevon, mutton and beef at the market; "
  "kraals and coops, the harmattan, school fees, tanners and hides, and a community study of compounds "
  "and the market."),
 ("Has any content outside the supplied curriculum been introduced?",
  "No. Every item sits inside topics 6.1-6.5. Question 3 is built on exemplars 3 and 4 of "
  "B7/JHS1.2.4.1.2 (differences and similarities); Question 5(c) is the poster of exemplar 2 of "
  "B7/JHS1.2.4.2.1; Question 7 is the community study of exemplar 1 of B7/JHS1.2.4.2.2; Question 6 is "
  "the by-product matching of exemplar 2."),
 ("Are the questions sufficiently varied?",
  "Yes. Item types include definition, listing and breed matching, classification, completing a "
  "comparison table, stating differences and similarities, explaining a mechanism, distinguishing "
  "domestic from commercial use, designing a poster, and designing a community study."),
]
for i, (q, a) in enumerate(qc, start=1):
    p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(2)
    set_font(p.add_run(f"{i}. {q}"), 10.5, bold=True)
    p2 = doc.add_paragraph()
    p2.paragraph_format.left_indent = Inches(0.3); p2.paragraph_format.space_after = Pt(6)
    set_font(p2.add_run(a), 10)

para("", space_after=8)
para("EXAMINER NOTES (for the teacher, not for candidates)", size=11, bold=True, space_after=4)
for n in [
 "This sub-strand has TWO content standards, so the blueprint carries both: B7/JHS1.2.4.1 for topics "
 "6.1-6.3 (differences among domestic animals) and B7/JHS1.2.4.2 for topics 6.4-6.5 (usefulness for "
 "domestic and commercial purposes). Each blueprint row shows the standard that applies to it.",
 "Follow the curriculum's wording on the three groups: a ruminant has a FOUR-CHAMBERED stomach and "
 "chews the cud; a monogastric animal has a SIMPLE, single-chambered stomach; and poultry are birds "
 "described as monogastric herbivores, because they have a simple stomach and feed mainly on plant "
 "material such as grain (A14).",
 "Question 3(a) turns 'discuss and write the differences' into a completion table with six numbered "
 "blanks, (i) to (vi), so marking is quick and fair: 1 mark each, and the blank number must be matched "
 "to the answer.",
 "Question 5(c) is the poster exemplar (B7/JHS1.2.4.2.1, Ex. 2) and Question 7 is the community-study "
 "exemplar (B7/JHS1.2.4.2.2, Ex. 1). Both are design tasks, so award method marks: any sensible feature "
 "or step earns credit. If your class actually makes the poster or does the study, accept what they did "
 "as evidence.",
 "Topic 6.1 asks pupils to match animals with their breeds. Keep breeds gentle: N'Dama, Sanga and Zebu "
 "for cattle, West African Dwarf and Sahelian for goats, Djallonke for sheep. Accept local names.",
 "Topics 6.4 and 6.5 carry 24 marks each, the highest weightings, because the second content standard "
 "is entirely about uses and by-products. If you want a flatter spread, move marks from Questions 4, 5 "
 "and 6 to Questions 1 and 2.",
 "A20 and A23 ask why a ruminant can use grass. The expected level is 'micro-organisms in the "
 "ruminant stomach break down the fibre' - do not expect any detail about rumen anatomy or about "
 "microbial protein.",
 "Edit the school name, academic year and examination title on page 1 before printing.",
 "This is an original, teacher-made mock. It is not a reproduction of any WAEC or NaCCA examination "
 "paper.",
]:
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Inches(0.3); p.paragraph_format.space_after = Pt(3)
    set_font(p.add_run("- " + n), 10)

doc.save("/home/user/Basic7_Integrated_Science_Mock_Strand2_AnimalProduction.docx")
print("docx written")

print("Section A:", len(MCQ), "items")
print("Section B total:", sum(q["total"] for q in SECTION_B))
print("Topic marks:", m, "sum", sum(m.values()))
print("Difficulty:", diff, "sum", sum(diff.values()))
print("Cognitive A:", ca)
print("Cognitive B:", cb)
print("Answer counts:", counts)
print("Totals:", sum(m.values()), sum(diff.values()),
      sum(ca.values()) + sum(cb.values()))
