# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "/home/user")
from build_climate import *

L = []
def w(s=""): L.append(s)

w(f"# {SCHOOL}"); w()
w(f"## {SUBJECT}"); w()
w(f"### {EXAM}"); w()
w(f"**Class:** {CLASS}  ")
w(f"**Time:** {TIME}  ")
w(f"**Total Marks:** {MARKS}  ")
w(f"**Academic Year:** {YEAR}"); w()
w("---"); w()
w("### INSTRUCTIONS"); w()
for i, t in enumerate([
    "Write your name and class clearly in the spaces provided on your answer sheet.",
    "This paper has TWO sections: Section A and Section B.",
    "Answer ALL the questions in both sections.",
    "Section A has 40 multiple-choice questions. Each question carries 1 mark. Choose the best answer (A, B, C or D) and record it on the answer sheet provided.",
    "Section B has 7 theory questions totalling 60 marks. Write your answers clearly and neatly in your answer booklet. Draw and label diagrams or tables where you are asked to.",
    "Read every question carefully before you answer it.",
    "Do not use correction fluid. Cancel any mistake neatly with a single line.",
    "Hand in your answer sheet and your answer booklet at the end of the examination.",
], start=1):
    w(f"{i}. {t}")
w(); w("---"); w()

w("## SECTION A: OBJECTIVE TEST (40 marks)"); w()
w("*Answer ALL questions. Each question carries 1 mark. Choose the BEST answer and write its letter "
  "(A, B, C or D) against the question number on your answer sheet.*"); w()
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"**{i}. {q}**"); w()
    for j, o in enumerate(opts): w(f"{'ABCD'[j]}. {o}")
    w()
w("---"); w()

w("## SECTION B: THEORY (60 marks)"); w()
w("*Answer ALL questions. Write your answers in your answer booklet. The marks for each question are shown "
  "in brackets.*"); w()
for qb in SECTION_B:
    w(f"### Question {qb['num']}  [{qb['total']} marks]"); w()
    w(qb["stem"]); w()
    if qb.get("table") == "green":
        w("| " + " | ".join(GREEN_HEADERS) + " |")
        w("| " + " | ".join(["---"] * len(GREEN_HEADERS)) + " |")
        for r in GREEN_ROWS:
            w("| " + " | ".join(r) + " |")
        w()
        w("*Table 1: Human activities that add greenhouse gases to the air*"); w()
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        w(f"**{lab}** {text}  **[{mk} mark{'s' if mk > 1 else ''}]**"); w()
w("---"); w()

w("## ANSWER KEY"); w()
w("### Section A - Objective Test"); w()
w("| Question | Answer | Curriculum Area (Topic) | Cognitive Level |")
w("| -------- | ------ | ----------------------- | --------------- |")
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"| {i} | {ans} | {TOPIC[tp]} | {cog} |")
counts = {L2: sum(1 for q in MCQ if q[2] == L2) for L2 in "ABCD"}
w()
w("Correct-answer distribution: " + ", ".join(f"{L2} = {counts[L2]}" for L2 in "ABCD") + " (40 items).")
w()
w("### Section B - Theory (summary answers; full detail in the Marking Scheme)"); w()
w("| Question | Expected Answer | Curriculum Area | Cognitive Level |")
w("| -------- | --------------- | --------------- | --------------- |")
sba = [
 ("1 (a)", "Any four: the sun or solar energy; the wind; moving water or water behind a dam; biogas from animal dung and food waste; crops and crop waste grown again each season; the heat inside the earth.", "19.1", "Remember"),
 ("1 (b)", "A renewable source is one that is replaced naturally as fast as people use it, so it never runs out. It is also a source that can go on being used without spoiling the air, the land or the climate for people in the future.", "19.1", "Understand"),
 ("1 (c)", "Any two: fewer trees are cut down, so the woodland around the village is saved; the goat waste is used instead of being left to rot; the gas burns without smoke, so the kitchen and the family's lungs stay cleaner; the slurry left over is a good manure for the farm; the family spends less on charcoal or firewood; the gas is free once the digester is built.", "19.1", "Understand"),
 ("2 (a)", "Any two: it is made from trees, and trees take many years to grow back; making it destroys the forest around the village; the wood is being used faster than it can be replaced; burning it gives out smoke and carbon dioxide.", "19.1", "Understand"),
 ("2 (b)", "Any three: the sun, using a solar cooker or solar panels; biogas from the goat pen and the kitchen waste; LPG; an improved cookstove, which cuts the wood used very sharply; wind or water power if the village has them.", "19.1", "Understand"),
 ("2 (c)", "Accept any one real difficulty, explained. The digester or the cooker costs money to buy or build. A biogas digester needs dung and water every day, and a family with no animals has none. A solar cooker works only when the sun is out, so it cannot cook the evening meal or work in the rainy season. LPG cylinders must be refilled, and the dealer may be far away. Nobody in the family may know how to look after the new equipment.", "19.1", "Apply"),
 ("3 (a)", "Any two: carbon dioxide, methane, nitrous oxide, water vapour.", "19.2", "Remember"),
 ("3 (b)", "Heat from the sun reaches the earth and warms the ground. The warm ground gives the heat back out again as infrared radiation. Greenhouse gases in the air let the sun's heat pass down but they absorb much of the heat going back up, and send some of it back towards the ground instead of letting it escape into space. So the heat is held near the surface, and the air near the ground stays warmer than it would otherwise be.", "19.2", "Understand"),
 ("3 (c)", "HELPFUL: without any greenhouse gases the earth would be far too cold for living things, so the natural greenhouse effect keeps the planet warm enough to live on. HARMFUL: people are now adding far more of these gases - by burning fuel, cutting down the forest and keeping cattle - so too much heat is being trapped and the earth is warming too fast. That extra warming brings floods at the coast, unreliable rain, crop failure and hunger.", "19.2", "Understand"),
 ("4 (i)", "Carbon dioxide.", "19.2", "Understand"),
 ("4 (ii)", "Cutting down and burning the forest. Also accept bush burning, or clearing land for farming by burning.", "19.2", "Understand"),
 ("4 (iii)", "Methane.", "19.2", "Understand"),
 ("4 (iv)", "Walk, ride a bicycle, use a tro-tro, or share transport instead of driving alone. Also accept: use the generator less, keep the engine serviced, or switch to solar power instead of a generator.", "19.2", "Understand"),
 ("5 (a)", "Any three: fit solar panels on the roof; use a solar water heater; cook with an improved cookstove or LPG instead of firewood; install a biogas digester for the dining-hall waste; use LED bulbs instead of filament bulbs; use a wind pump to draw water; switch off lights, fans and computers when they are not needed; insulate the roof; plant trees round the compound for shade.", "19.3", "Remember"),
 ("5 (b)", "Accept any two correctly explained. Solar panels: materials in the panel take in light energy from the sun and change it straight into electrical energy, with nothing burnt and no smoke. Improved cookstove: a wall round the fire keeps the heat in and sends it up to the pot, and the controlled air lets the wood burn more completely. LED bulb: it gives out light without first getting hot, so far less electricity is wasted as heat. Biogas digester: bacteria rot the waste without air and give off methane, which burns as a fuel.", "19.3", "Understand"),
 ("5 (c)", "Accept any sensible check: read the electricity meter before and after and compare the bills; count how many bags of firewood the kitchen buys each term and compare with last term; keep a daily record of how long the lights are on; check that the LED bulbs are still working after a term.", "19.3", "Apply"),
 ("6 (a)", "A solar dryer is a closed box or cabinet, often with a clear cover, that lets the sun's heat in and keeps it there, so the air inside gets hotter than the air outside and the water in the fish evaporates faster. Because the fish is inside a covered box, it is protected from dust, flies and sudden rain, so much less of it is spoiled. The fish dries evenly and more quickly, keeps its quality, and so fetches a better price at the market.", "19.3", "Apply"),
 ("6 (b)", "The whole community benefits, not only she does. Less fish is spoiled, so more food reaches the market and families nearby have fish to buy; good dried fish travels further, so it can be sold in other towns and brings money into the town; because the fish keeps, it can be eaten in the lean season when the catch is poor; and less spoiled fish is thrown away, so there is less waste and fewer flies breeding near the market.", "19.3", "Evaluate"),
 ("7 (a)", "Any three: what the clinic actually needs the energy for - light at night, a refrigerator for vaccines, or power for a small machine; how much sunshine, wind or flowing water the village has; what materials can be found nearby and what must be bought; how much money is available; whether anyone in the village can repair the equipment; where the project would be safe from damage and theft.", "19.4", "Understand"),
 ("7 (b)", "Accept any sensible project. For example, a solar system for the clinic: mount solar panels on the clinic roof facing the sun where no tree shades them; fix a frame, a charge controller, a battery and wiring; connect LED lamps inside and a small refrigerator for vaccines; test each lamp and the refrigerator; label the switches. MATERIALS: solar panels, a battery, a charge controller, cable, switches, LED lamps, a frame and fixings. STEPS: survey the roof, collect the parts, fit the frame, mount the panels, wire the controller and battery, run the cable inside, fit the lamps, test, and hand over with instructions.", "19.4", "Create"),
 ("7 (c)", "KNOWING IT WORKS: check that the clinic has light at night and that the refrigerator keeps vaccines cold; read a meter or keep a daily record for a few weeks; compare the clinic's bills or its kerosene use with what it was before. KEEPING IT RUNNING: name a person at the clinic and one pupil or teacher to check it; clean the panels; keep a few spare parts and the number of someone who can repair it; fix a card of instructions near the switch; show the next class how it works.", "19.4", "Apply"),
]
for r in sba: w(f"| {r[0]} | {r[1]} | {r[2]} | {r[3]} |")
w(); w("---"); w()

w("## MARKING SCHEME - SECTION B (60 marks)"); w()
w("*General rules: (1) Accept any other correct and relevant answer. (2) Award marks for correct points, not "
  "for repeating the question. (3) For procedures, award method marks. (4) Do not deduct marks for spelling "
  "unless the meaning is changed. (5) Where a candidate gives more answers than are asked for, mark only the "
  "first ones up to the number required.*"); w()
for qb in SECTION_B:
    n = qb["num"]
    w(f"### Question {n} ({qb['total']} marks)"); w()
    for (lab, points, note) in MARKING[n]:
        mkv = [p_[2] for p_ in qb["parts"] if p_[0] == lab]
        head = f"**{lab}**"
        if mkv: head += f" [{mkv[0]} mark{'s' if mkv[0] > 1 else ''}]"
        w(head); w()
        for pt in points: w(f"- {pt}")
        w(f"  - *Marking note: {note}*"); w()
w("---"); w()

w("## CURRICULUM ASSESSMENT BLUEPRINT"); w()
w(f"**Strand:** {STRAND} | **Sub-strand:** {SUBSTRAND} | **Class:** {CLASS}"); w()
w(f"**Content Standard:** {CS} - {CS_TEXT}"); w()
w("> Source: NaCCA Science Common Core Programme Curriculum (B7/JHS1-B9/JHS3), September 2020, "
  "Strand 5: Humans and the Environment, Sub-strand 4: Climate Change and Green "
  "Economy (topics 19.1-19.4), p. 48. Indicators are quoted, not invented."); w()

w("### Section A"); w()
w("| Qn | Sub-strand | Content Standard | Indicator (NaCCA) - Indicator Text | Topic / Content | Cognitive Level | Marks |")
w("| -- | ---------- | ---------------- | ---------------------------------- | --------------- | --------------- | ----- |")
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"| A{i} | {SUBSTRAND} | {CS_BY_TOPIC[tp]} | {IND[tp]} - {IND_TEXT[tp]} | {TOPIC[tp]} | {cog} | 1 |")
w()
w("### Section B"); w()
w("| Qn | Sub-strand | Content Standard | Indicator (NaCCA) - Indicator Text | Topic / Content | Cognitive Level | Marks |")
w("| -- | ---------- | ---------------- | ---------------------------------- | --------------- | --------------- | ----- |")
for qb in SECTION_B:
    for (lab, text, mkv, cog, tp, diff) in qb["parts"]:
        key = tp if tp in TOPIC else tp.split(",")[0].strip()
        w(f"| B{qb['num']}{lab.strip('()')} | {SUBSTRAND} | {CS_BY_TOPIC[key]} | {IND[key]} - {IND_TEXT[key]} | {TOPIC[key]} | {cog} | {mkv} |")
w(); w("---"); w()

def topic_totals():
    m = {k: 0 for k in TOPIC}; it = {k: 0 for k in TOPIC}
    for q in MCQ: m[q[3]] += 1; it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk; it[key] += 1
    return m, it

def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}; b = {k: 0 for k in order}
    for q in MCQ: a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: b[cog] += mk
    return order, a, b

def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ: d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: d[diff] += mk
    return d

m, it = topic_totals(); diff_ = difficulty_totals(); order, ca, cb = cognitive_by_section()

w("### Summary 1 - Coverage by Curriculum Area (Topic)"); w()
w("| Topic / Content Area | No. of Items | Marks | % of Total Marks | Core Competencies |")
w("| -------------------- | ------------ | ----- | ---------------- | ----------------- |")
for k in TOPIC: w(f"| {TOPIC[k]} | {it[k]} | {m[k]} | {(m[k]/100)*100:.1f}% | {CC[k]} |")
w(f"| **TOTAL** | **{sum(it.values())}** | **{sum(m.values())}** | **100%** | - |")
w()
w("*CC = Communication and Collaboration; CP = Critical Thinking and Problem Solving; DL = Digital Literacy; "
  "CI = Creativity and Innovation.*"); w()
w("### Summary 2 - Cognitive-Level Distribution (Bloom's Taxonomy)"); w()
w("| Cognitive Level | Section A Marks | Section B Marks | Total Marks | % of Total |")
w("| --------------- | --------------- | --------------- | ----------- | ---------- |")
for lv in order:
    tot = ca[lv] + cb[lv]
    w(f"| {lv} | {ca[lv]} | {cb[lv]} | {tot} | {(tot/100)*100:.1f}% |")
w(f"| **TOTAL** | **{sum(ca.values())}** | **{sum(cb.values())}** | **{sum(ca.values())+sum(cb.values())}** | **100%** |")
w()
w("### Summary 3 - Difficulty Distribution"); w()
w("| Difficulty | Marks | % of Total Marks |")
w("| ---------- | ----- | ---------------- |")
for k, v in diff_.items(): w(f"| {k} | {v} | {(v/100)*100:.1f}% |")
w(f"| **TOTAL** | **{sum(diff_.values())}** | **100%** |")
w()
w("*Target in the master prompt: approximately 30% easy / 50% moderate / 20% challenging.*"); w()
w("### Summary 4 - Section Weighting"); w()
w("| Section | Question Type | Items | Marks | % of Total |")
w("| ------- | ------------- | ----- | ----- | ---------- |")
w("| A | Objective (multiple choice) | 40 | 40 | 40% |")
w("| B | Theory / constructed response | 21 | 60 | 60% |")
w("| **TOTAL** | - | **61** | **100** | **100%** |")
w(); w("---"); w()

w("## QUALITY-CONTROL SUMMARY")
w("")
w("| Check | Status |")
w("| --- | --- |")
for q_, a_ in [
 ("Every question within supplied curriculum scope",
  "Yes - all 61 items (40 objectives and 21 theory sub-questions) sit in topics 19.1-19.4 of Strand 5, Sub-Strand 4 (Climate Change and Green Economy), under content standard B7/JHS1.5.4.1, mapped to indicator B7/JHS1.5.4.1.1. The three exemplars map to the topics: describing sustainable energy choices and scientific ideas, analysing the greenhouse effect and how to minimise it, and designing a local energy project"),
 ("Appropriate for the class",
  "Yes - the B7 curriculum asks learners to search for information on ways sustainable energy choices and scientific ideas are used to protect the environment; to describe how people use them; to analyse greenhouse effects and show how they can be minimised; and to design a project showing how energy can be locally sustained through scientific processes. Nothing beyond that is tested"),
 ("Genuinely BECE-style",
  "Yes - 40 four-option objectives plus structured theory with printed mark allocations, a three-column completion table, 'name', 'state' and 'explain' items, and open tasks requiring application, analysis, evaluation and design"),
 ("Sufficient application and reasoning",
  "Yes - 34 of 100 marks (34%) at Apply level or above (Apply 22, Analyse 4, Evaluate 5, Create 3)"),
 ("Plausible MCQ distractors",
  "Yes - a real source of energy that is not renewable, a real gas in the air that is not a greenhouse gas, a real description that explains the wrong thing, a genuine activity that would not help, and a real project step that is not the first or the best one"),
 ("Single best answer per MCQ",
  "Yes - reviewed item by item and each option list was checked so that the declared key sits on the correct answer; three options in A15 are things that happen when a forest is cleared but only one explains the rise in carbon dioxide, three in A25 are true of drying cassava but only one follows from using a solar dryer, and three in A39 are things a group might really do but only one shows the project works"),
 ("Marks internally consistent",
  "Yes - Section A 40 x 1 = 40; Section B 9 + 8 + 9 + 8 + 9 + 8 + 9 = 60; sub-question marks match the marking scheme"),
 ("Total adds up correctly",
  "Yes - 40 + 60 = 100"),
 ("Answer key correct",
  "Yes - all 40 keys and all 21 Section B answers verified against the marking scheme; the science was checked item by item - biogas is made when waste rots WITHOUT air, rotting waste and cattle give out methane rather than carbon dioxide, a dark surface takes in heat rather than reflecting it, and a solar dryer uses the sun's heat directly while a solar panel changes light into electricity"),
 ("Marking scheme matches questions",
  "Yes - expected answers plus marking notes covering partial credit, alternatives, common wrong answers and method marks; Question 3(c) gives at most 1 to a pupil who says only that the greenhouse effect is bad, Question 4(iii) does not accept carbon dioxide where the clue points to methane, Question 5(c) gives 0 for 'we will see if it works' with no measurement, Question 6(b) gives 1 for a position but no more unless the benefit to others is argued, and Question 7(b) gives 0 for any project that burns charcoal, firewood or diesel"),
 ("Free from unnecessary ambiguity",
  "Yes - open items are anchored with 'name four', 'state two', 'name three', 'give two' and 'explain one' plus the mark allocation; Question 1(a) asks for sources that will not run out and the note excludes bare 'electricity', Question 5(b) must be answered on the choices named in 5(a), Question 2(c) asks for a difficulty the family would really face, and Question 7(b) requires the project, the materials and the steps"),
 ("Ghanaian contexts natural and accurate",
  "Yes - a village where one family cooks with firewood and another with gas from a goat pen, charcoal and the forest around the village, tro-tros and shared transport, a lakeside fishmonger drying fish on the ground, cassava dried for market, bush burning to clear farmland, flooding at a coastal town, a clinic with a vaccine refrigerator, and the lean season when the catch is poor"),
 ("No content beyond the curriculum",
  "No - every item sits inside topics 19.1-19.4; no detailed chemistry of combustion or photosynthesis is required, no calculations are set, and no climate policy beyond what a Basic 7 pupil can observe is tested"),
 ("Questions sufficiently varied",
  "Yes - naming sources that will not run out, explaining renewability, giving reasons to switch to biogas, explaining why charcoal is not sustainable, naming alternatives, explaining a real difficulty of switching, naming greenhouse gases, explaining how they warm the earth, explaining why the effect is both helpful and harmful, completing a four-blank greenhouse-gas table, naming school energy choices, explaining the science behind two of them, planning a check that measures a saving, explaining how a solar dryer helps a fishmonger, evaluating who benefits from it, deciding what to find out before designing, and designing, testing and maintaining a clinic energy project"),
]:
    w("| " + q_ + " | " + a_ + " |")
w("")
w("### EXAMINER NOTES")
w("")
for n_ in [
 "Question 3(c) is the most important item on this paper, because it is where pupils show whether they have understood the idea at all. Most will have learned that carbon dioxide is 'bad' and will say the greenhouse effect is harmful, which earns 1 of 3. The full answer is that the effect keeps the earth warm enough to live on and the problem is the EXTRA gas we are adding. Teach both halves every time.",
 "Question 4(iii) is the blank that catches pupils out. Rotting waste and cattle give out METHANE, not carbon dioxide, and the table gives them the clue in the 'activity' column. The note does not accept carbon dioxide there. Drill the two gases separately: burning fuel and clearing forest give carbon dioxide; rotting waste and cattle give methane.",
 "Question 1(b) and Question 2(a) both press the same point from different sides - what makes a source renewable, and why charcoal is not one. Pupils will answer 'charcoal is expensive' or 'charcoal makes smoke', which the note does not accept, because the question is about the source running out. Push them to 'trees take years to grow back'.",
 "Question 6(b) is deliberately open. The strongest answers say the whole community benefits - more food reaches the market, less is wasted, fish can be eaten in the lean season, money comes into the town - while adding that the fishmonger herself gains most directly. A pupil who argues that only she benefits earns 1 for the position but no more unless the argument is genuinely developed.",
 "Question 7 is the design task from Exemplar 3, and pupils find it easy to NAME a project and hard to list materials and give the steps in order. The note caps them at 1 of 3 if the materials and steps are missing, and gives 0 for anything that burns charcoal, firewood or diesel - which is a common answer and worth warning them about before the examination.",
 "Question 5(c) asks pupils to CHECK that a change has saved energy, and the mark is on the comparison - a meter reading or a firewood count before and after. 'We will see if it works' earns 0. This is the same skill Question 7(c) needs, so the two reinforce each other.",
 "Topic weighting is 27 marks each for 19.1, 19.2 and 19.3, and 19 marks for 19.4. The design task carries the least in Section B, where it appears only once. If you spent longer on the project work, move marks towards Question 7.",
 "Three cheap activities that raise marks sharply: (1) put two thermometers in the sun, one under a clear bowl and one in the open, and read them after ten minutes, which makes the greenhouse effect visible; (2) leave two equal slices of fish or cassava out, one covered and one open to the flies and dust, which teaches Question 6; and (3) have each group cost out one clinic energy project on a single page, which teaches Question 7.",
 "This sub-strand has one content standard and one indicator, so it is a single paper and not split. The companion papers cover Sub-strand 2 (Human Health) in two parts, Sub-strand 3 (Science and Industry), and Sub-strand 5 (Understanding the Environment).",
 "This version is a full rebuild. Every question is new, and none is repeated from the earlier version of this paper, so you can use either as a mock and the other as a second sitting without pupils seeing the same items twice.",
 "Edit the school name, academic year and examination title on page 1 before printing.",
 "This is an original, teacher-made mock. It is not a reproduction of any WAEC or NaCCA examination paper.",
]:
    w("- " + n_)
w()

open("/home/user/Basic7_Integrated_Science_Mock_Strand5_ClimateChange.md", "w", encoding="utf-8").write("\n".join(L))
print("md written", len("\n".join(L)), "chars")
