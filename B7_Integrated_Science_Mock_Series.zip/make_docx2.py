# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "/home/user")
from build_cells import *

from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT

doc = Document()
sec = doc.sections[0]
sec.left_margin = Inches(0.7); sec.right_margin = Inches(0.7)
sec.top_margin = Inches(0.7); sec.bottom_margin = Inches(0.6)

st = doc.styles["Normal"]; st.font.name = "Calibri"; st.font.size = Pt(11)


def set_font(run, size=11, bold=False, italic=False, mono=False, color=None):
    run.font.size = Pt(size); run.bold = bold; run.italic = italic
    run.font.name = "Consolas" if mono else "Calibri"
    if color: run.font.color.rgb = color
    return run


def para(text="", size=11, bold=False, italic=False, align=None, mono=False,
         space_before=0, space_after=4, color=None):
    p = doc.add_paragraph()
    if align == "c": p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    elif align == "j": p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p.paragraph_format.space_before = Pt(space_before)
    p.paragraph_format.space_after = Pt(space_after)
    if text: set_font(p.add_run(text), size, bold, italic, mono, color)
    return p


def rule():
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(6); p.paragraph_format.space_before = Pt(2)
    set_font(p.add_run("_" * 78), 9, color=RGBColor(0x99, 0x99, 0x99))


def add_table(headers, rows, widths=None, size=9, head_size=9):
    t = doc.add_table(rows=1, cols=len(headers)); t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, h in enumerate(headers):
        c = t.rows[0].cells[i]; c.text = ""
        p = c.paragraphs[0]; p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_font(p.add_run(str(h)), head_size, bold=True)
    for row in rows:
        cells = t.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = ""
            p = cells[i].paragraphs[0]; p.paragraph_format.space_after = Pt(1)
            set_font(p.add_run(str(v)), size)
    if widths:
        for r_ in t.rows:
            for i, w in enumerate(widths): r_.cells[i].width = Inches(w)
    return t


def draw_diagram(lines, caption):
    t = doc.add_table(rows=2, cols=1); t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = t.rows[0].cells[0]
    for k, line in enumerate(lines):
        p = cell.paragraphs[0] if k == 0 else cell.add_paragraph()
        p.paragraph_format.space_after = Pt(0); p.paragraph_format.space_before = Pt(0)
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_font(p.add_run(line), 10, mono=True)
    c2 = t.rows[1].cells[0].paragraphs[0]
    c2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_font(c2.add_run(caption), 9, italic=True)
    t.rows[0].cells[0].width = Inches(6.6)
    t.rows[1].cells[0].width = Inches(6.6)


# ============================================================= TITLE BLOCK
para(SCHOOL, size=15, bold=True, align="c", space_after=2)
para(SUBJECT, size=13, bold=True, align="c", space_after=2)
para(EXAM, size=12, bold=True, align="c", space_after=2)
para(YEAR, size=10, italic=True, align="c", space_after=8)

info = doc.add_table(rows=1, cols=3); info.style = "Table Grid"
info.alignment = WD_TABLE_ALIGNMENT.CENTER
for i, v in enumerate([f"Class: {CLASS}", f"Time: {TIME}", f"Total Marks: {MARKS}"]):
    c = info.rows[0].cells[i]; c.text = ""
    set_font(c.paragraphs[0].add_run(v), 10, bold=True)
para("", space_after=6)

para("INSTRUCTIONS", size=11, bold=True, space_after=3)
for txt in [
    "1. Write your name and class clearly in the spaces provided on your answer sheet.",
    "2. This paper has TWO sections: Section A and Section B.",
    "3. Answer ALL the questions in both sections.",
    "4. Section A has 40 multiple-choice questions. Each question carries 1 mark. Choose the best answer "
    "(A, B, C or D) and record it on the answer sheet provided.",
    "5. Section B has 7 theory questions totalling 60 marks. Write your answers clearly and neatly in your "
    "answer booklet. Draw and label diagrams where you are asked to.",
    "6. Read every question carefully before you answer it.",
    "7. Do not use correction fluid. Cancel any mistake neatly with a single line.",
    "8. Hand in your answer sheet and your answer booklet at the end of the examination.",
]:
    para(txt, size=10.5, space_after=2)
rule()

# =============================================================== SECTION A
para("SECTION A - OBJECTIVE TEST (40 marks)", size=12, bold=True, align="c", space_after=2)
para("Answer ALL questions. Each question carries 1 mark. Choose the BEST answer and write its letter "
     "(A, B, C or D) against the question number on your answer sheet.",
     size=10, italic=True, align="c", space_after=8)

for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(1); p.paragraph_format.space_before = Pt(4)
    set_font(p.add_run(f"{i}. {q}"), 10.5)
    for j, o in enumerate(opts):
        p2 = doc.add_paragraph()
        p2.paragraph_format.left_indent = Inches(0.28)
        p2.paragraph_format.space_after = Pt(0); p2.paragraph_format.space_before = Pt(0)
        set_font(p2.add_run(f"{'ABCD'[j]}. {o}"), 10.5)

doc.add_page_break()

# =============================================================== SECTION B
para("SECTION B - THEORY (60 marks)", size=12, bold=True, align="c", space_after=2)
para("Answer ALL questions. Write your answers in your answer booklet. The marks for each question are "
     "shown in brackets.", size=10, italic=True, align="c", space_after=8)

for qb in SECTION_B:
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(8); p.paragraph_format.space_after = Pt(2)
    set_font(p.add_run(f"Question {qb['num']}"), 11, bold=True)
    set_font(p.add_run(f"  [{qb['total']} marks]"), 10, bold=True, italic=True)
    para(qb["stem"], size=10.5, space_after=4)
    if qb.get("diagram") == "animal":
        draw_diagram(ANIMAL_CELL, "Fig. 1: An animal cell (not drawn to scale)")
        para("", space_after=2)
    if qb.get("diagram") == "plant":
        draw_diagram(PLANT_CELL, "Fig. 2: A plant cell (not drawn to scale)")
        para("", space_after=2)
    if qb.get("table") == "organelles":
        add_table(Q3_TABLE_HEAD, Q3_TABLE_ROWS, widths=[1.8, 4.8], size=10, head_size=10)
        para("", space_after=2)
    if qb.get("table") == "compare":
        add_table(Q6_TABLE_HEAD, Q6_TABLE_ROWS, widths=[2.2, 2.2, 2.2], size=10, head_size=10)
        para("", space_after=2)
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Inches(0.25)
        p.paragraph_format.space_after = Pt(3); p.paragraph_format.space_before = Pt(2)
        set_font(p.add_run(f"{lab} {text}  "), 10.5)
        set_font(p.add_run(f"[{mk} mark{'s' if mk > 1 else ''}]"), 10, bold=True)

doc.add_page_break()

# ============================================================== ANSWER KEY
para("ANSWER KEY", size=13, bold=True, align="c", space_after=6)
para("SECTION A - OBJECTIVE TEST", size=11, bold=True, space_after=4)
rows = [[i, ans, TOPIC[tp], cog] for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1)]
add_table(["Question", "Answer", "Curriculum Area (Topic)", "Cognitive Level"],
          rows, widths=[0.8, 0.7, 3.6, 1.5], size=9)
counts = {L: sum(1 for q in MCQ if q[2] == L) for L in "ABCD"}
para("", space_after=4)
para("Correct-answer distribution: " + ", ".join(f"{L} = {counts[L]}" for L in "ABCD") + " (30 items).",
     size=9, italic=True)

para("", space_after=8)
para("SECTION B - THEORY (summary answers; see the Marking Scheme for full detail)",
     size=11, bold=True, space_after=4)
sba = [
 ("1 (a)", "The smallest (basic) unit of structure and function of a living thing.", "2.1", "Remember"),
 ("1 (b)", "All living things are made of cells; the cell is the smallest part that can carry out all life "
  "processes; nothing smaller than a cell can live on its own.", "2.1", "Understand"),
 ("1 (c)", "Peel a thin piece of onion skin, mount it in a drop of water on a slide with a cover slip, place it "
  "on the microscope stage and focus (low power, then high power). Many small box-like compartments (cells) are "
  "seen.", "2.1", "Create"),
 ("1 (d)", "Cells are extremely small and the naked eye cannot magnify them; a microscope is needed to make them "
  "large enough to see.", "2.1", "Understand"),
 ("2 (a)", "1 = cell membrane; 2 = cytoplasm; 3 = nucleus; 4 = vacuole", "2.2", "Remember"),
 ("2 (b)", "It holds the cell together and controls the movement of substances into and out of the cell.",
  "2.3", "Understand"),
 ("2 (c)", "It controls all the activities of the cell and contains the hereditary material.",
  "2.3", "Understand"),
 ("2 (d)", "The cell would lose control of what enters and leaves; useful substances leak out, harmful ones "
  "enter, and the cell may die.", "2.3", "Analyse"),
 ("2 (e)", "An animal cell has no rigid cell wall, only a thin flexible cell membrane, so it has no fixed shape.",
  "2.2", "Understand"),
 ("3 (a)", "(i) Controls all the activities of the cell. (ii) Jelly-like substance where the organelles are found "
  "and where most activities take place. (iii) Holds the cell together and controls what enters and leaves. "
  "(iv) Releases energy from food during respiration.", "2.3", "Understand"),
 ("3 (b)", "Any suitable material with a matching reason, e.g. clear glue or jelly - because cytoplasm is a "
  "jelly-like substance.", "2.3", "Create"),
 ("3 (c)", "It releases the energy the cell needs, from the food the cell takes in during respiration.",
  "2.3", "Understand"),
 ("3 (d)", "The cell loses its control centre, cannot control its activities or repair itself, and eventually "
  "dies.", "2.3", "Analyse"),
 ("4 (a)", "1 = cell wall; 2 = cell membrane; 3 = cytoplasm; 4 = vacuole; 5 = chloroplast; 6 = nucleus",
  "2.4", "Remember"),
 ("4 (b)", "1 (cell wall) and 5 (chloroplast)", "2.5", "Analyse"),
 ("4 (c)", "It gives the cell a definite shape and supports and protects the plant.", "2.4", "Understand"),
 ("4 (d)", "It contains chlorophyll and is where the plant makes its own food by photosynthesis.",
  "2.5", "Understand"),
 ("4 (e)", "The rigid cell wall holds the cell in a fixed, regular shape.", "2.4", "Understand"),
 ("5 (a)", "Chlorophyll - it traps light energy so the plant can make its own food by photosynthesis.",
  "2.5", "Understand"),
 ("5 (b)", "The plant cannot make enough food, so it becomes weak and yellow and may die, because chlorophyll "
  "needs light for photosynthesis.", "2.5", "Apply"),
 ("5 (c)", "Any two of: stores water; stores salts, sugars and waste; keeps the cell firm.", "2.5", "Understand"),
 ("5 (d)", "Cellulose.", "2.5", "Remember"),
 ("6 (a)", "Any three of: cell wall present in plants only; chloroplasts present in plants only; large permanent "
  "vacuole in plants, small temporary vacuoles in animals; regular shape in plants, irregular in animals.",
  "2.6", "Understand"),
 ("6 (b)", "Any three of: cell membrane, cytoplasm, nucleus, mitochondria, vacuole.", "2.6", "Remember"),
 ("6 (c)", "Disagree - a plant cell also has chloroplasts and a large permanent vacuole, which an animal cell "
  "does not have, and the two cell types obtain food differently.", "2.6", "Evaluate"),
 ("6 (d)", "(i) Yes   (ii) No   (iii) No   (iv) Yes   (v) Yes", "2.6", "Understand"),
]
add_table(["Question", "Expected Answer", "Curriculum Area", "Cognitive Level"],
          [list(r) for r in sba], widths=[0.8, 4.2, 1.2, 1.2], size=9)

doc.add_page_break()

# =========================================================== MARKING SCHEME
para("MARKING SCHEME - SECTION B (60 marks)", size=13, bold=True, align="c", space_after=4)
para("General rules: (1) Accept any other correct and relevant answer. (2) Award marks for correct points, "
     "not for repeating the question. (3) For procedures, award method marks. (4) Do not deduct marks for "
     "spelling unless the meaning is changed. (5) Where a candidate gives more answers than are asked for, "
     "mark only the first ones up to the number required.",
     size=9.5, italic=True, space_after=8)

for qb in SECTION_B:
    n = qb["num"]
    para(f"Question {n}  ({qb['total']} marks)", size=11, bold=True, space_before=8, space_after=3)
    for (lab, points, note) in MARKING[n]:
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(2)
        set_font(p.add_run(f"{lab} "), 10.5, bold=True)
        mkv = [p_[2] for p_ in qb["parts"] if p_[0] == lab]
        if mkv: set_font(p.add_run(f"[{mkv[0]} mark{'s' if mkv[0] > 1 else ''}]"), 10, bold=True)
        for pt in points:
            pp = doc.add_paragraph()
            pp.paragraph_format.left_indent = Inches(0.35); pp.paragraph_format.space_after = Pt(1)
            set_font(pp.add_run("- " + pt), 10.5)
        pp = doc.add_paragraph()
        pp.paragraph_format.left_indent = Inches(0.35); pp.paragraph_format.space_after = Pt(6)
        set_font(pp.add_run("Marking note: " + note), 9.5, italic=True)

doc.add_page_break()

# ================================================================ BLUEPRINT
para("CURRICULUM ASSESSMENT BLUEPRINT", size=13, bold=True, align="c", space_after=3)
para(f"Strand: {STRAND}   |   Sub-strand: {SUBSTRAND}   |   Class: {CLASS}",
     size=10, italic=True, align="c", space_after=3)
para(f"Content Standard: {CS} - {CS_TEXT}", size=9, italic=True, align="c", space_after=3)
para("Source: NaCCA Science Common Core Programme Curriculum (B7/JHS1-B9/JHS3), September 2020, "
     "Strand 1: Diversity of Matter, Sub-strand 2: Living Cells, pp. 5-6. Indicators are quoted, not invented.",
     size=9, italic=True, space_after=8)

hdr = ["Qn", "Sub-strand", "Content Standard", "Indicator (NaCCA) - Indicator Text", "Topic / Content",
       "Cognitive Level", "Marks"]

rows = [[f"A{i}", SUBSTRAND, CS, f"{IND[tp]} - {IND_TEXT[tp]}", TOPIC[tp], cog, 1]
        for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1)]
add_table(hdr, rows, widths=[0.35, 0.75, 0.75, 1.75, 1.4, 0.8, 0.35], size=7, head_size=7.5)

para("", space_after=8)
rows = []
for qb in SECTION_B:
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        key = tp if tp in TOPIC else tp.split(",")[0].strip()
        rows.append([f"B{qb['num']}{lab.strip('()')}", SUBSTRAND, CS,
                     f"{IND[key]} - {IND_TEXT[key]}", TOPIC[key], cog, mk])
add_table(hdr, rows, widths=[0.35, 0.75, 0.75, 1.75, 1.4, 0.8, 0.35], size=7, head_size=7.5)

doc.add_page_break()

# ----------------------------------------------------------------- helpers
def topic_totals():
    m = {k: 0 for k in TOPIC}; it = {k: 0 for k in TOPIC}
    for q in MCQ:
        m[q[3]] += 1; it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk; it[key] += 1
    return m, it

def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}; b = {k: 0 for k in order}
    for q in MCQ: a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: b[cog] += mk
    return order, a, b

def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ: d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: d[diff] += mk
    return d

m, it = topic_totals(); diff = difficulty_totals(); order, ca, cb = cognitive_by_section()

para("SUMMARY 1 - COVERAGE BY CURRICULUM AREA (TOPIC)", size=12, bold=True, space_after=4)
rows = [[TOPIC[k], it[k], m[k], f"{(m[k]/100)*100:.1f}%", CC[k]] for k in TOPIC]
rows.append(["TOTAL", sum(it.values()), sum(m.values()), "100%", "-"])
add_table(["Topic / Content Area", "No. of Items", "Marks", "% of Total Marks", "Core Competencies"],
          rows, widths=[2.7, 0.8, 0.6, 1.0, 1.1], size=8.5)
para("CC = Communication and Collaboration; CP = Critical Thinking and Problem Solving; "
     "DL = Digital Literacy; CI = Creativity and Innovation.", size=8.5, italic=True, space_after=2)

para("", space_after=8)
para("SUMMARY 2 - COGNITIVE-LEVEL DISTRIBUTION (Bloom's Taxonomy)", size=12, bold=True, space_after=4)
rows = []
for lv in order:
    tot = ca[lv] + cb[lv]
    rows.append([lv, ca[lv], cb[lv], tot, f"{(tot/100)*100:.1f}%"])
rows.append(["TOTAL", sum(ca.values()), sum(cb.values()), sum(ca.values()) + sum(cb.values()), "100%"])
add_table(["Cognitive Level", "Section A Marks", "Section B Marks", "Total Marks", "% of Total"],
          rows, widths=[1.6, 1.3, 1.3, 1.1, 1.1], size=9.5)

para("", space_after=8)
para("SUMMARY 3 - DIFFICULTY DISTRIBUTION", size=12, bold=True, space_after=4)
rows = [[k, v, f"{(v/100)*100:.1f}%"] for k, v in diff.items()]
rows.append(["TOTAL", sum(diff.values()), "100%"])
add_table(["Difficulty", "Marks", "% of Total Marks"], rows, widths=[2.0, 1.2, 1.5], size=9.5)
para("Target in the master prompt: approximately 30% easy / 50% moderate / 20% challenging.",
     size=9, italic=True, space_after=2)

para("", space_after=8)
para("SUMMARY 4 - SECTION WEIGHTING", size=12, bold=True, space_after=4)
add_table(["Section", "Question Type", "Items", "Marks", "% of Total"],
          [["A", "Objective (multiple choice)", 40, 40, "40%"],
           ["B", "Theory / constructed response", 26, 60, "60%"],
           ["TOTAL", "-", 66, 100, "100%"]],
          widths=[0.9, 2.4, 0.8, 0.8, 1.0], size=9.5)

doc.add_page_break()

# ===================================================== QUALITY-CONTROL
para("QUALITY-CONTROL SUMMARY", size=13, bold=True, align="c", space_after=4)
para("Carried out against the 14-point validation list in the master prompt before the examination was "
     "finalised.", size=9.5, italic=True, space_after=8)

qc = [
 ("Does every question belong to the supplied curriculum scope?",
  "Yes. All 46 items trace to Strand 1 (Diversity of Matter), Sub-Strand 2 (Living Cells), topics 2.1-2.6, and "
  "to the two official B7 indicators (B7/JHS1.1.2.1.1 and B7/JHS1.1.2.1.2). Viruses (A28) and bacteria (A28) "
  "appear only as distractors, never as content to be taught."),
 ("Is the examination appropriate for the stated class?",
  "Yes. The B7 curriculum introduces cells at identification-and-description level, so organelles are limited to "
  "cell membrane, cytoplasm, nucleus, vacuole, mitochondrion, cell wall and chloroplast. No meiosis, mitosis, "
  "DNA structure, osmosis or tissue/organ-system hierarchy is tested, as these fall outside the B7 indicators."),
 ("Are the questions genuinely BECE-style?",
  "Yes: Section A is 30 four-option objectives worth 1 mark each, and Section B is structured theory with "
  "sub-questions carrying printed mark allocations. Two labelled diagrams are included, matching the BECE "
  "science convention."),
 ("Are there enough application and reasoning questions?",
  "Yes. 28 of 100 marks (28%) are at Apply level or above (Apply 10, Analyse 9, Evaluate 5, Create 4), including "
  "diagram analysis, a damage-to-the-cell consequence item, an experimental procedure, model design and "
  "a claim to evaluate."),
 ("Are the MCQ distractors plausible?",
  "Yes. Distractors are drawn from the same content family as the key: other organelles, functions swapped "
  "between organelles (A23), and structures wrongly assigned to the wrong cell type (A26)."),
 ("Is there only one best answer for each MCQ?",
  "Yes. Every item was reviewed for a single defensible key. Special care was taken with A21 (vacuole), where "
  "'cytoplasm' and 'nucleus' are plausible to a weak candidate but only 'vacuole' stores water, salts and waste."),
 ("Are the marks internally consistent?",
  "Yes. Section A = 40 items x 1 mark = 40. Section B = 8 + 9 + 9 + 11 + 8 + 15 = 60. Every Section B "
  "sub-question's printed marks match its marking-scheme allocation."),
 ("Does the total add up correctly?",
  "Yes: 40 + 60 = 100 marks, matching the stated total on the front page."),
 ("Are the answers in the answer key correct?",
  "Yes. All 40 objective keys and all 26 Section B answers were verified against the marking scheme and "
  "checked for internal consistency (e.g. B2(a) labels feed B2(b) and B2(c))."),
 ("Does the marking scheme match the questions?",
  "Yes. Every Section B sub-question has an expected-answer list and a marking note covering partial credit, "
  "acceptable alternatives, common wrong answers and method marks."),
 ("Are the questions free from unnecessary ambiguity?",
  "Yes. Open items are anchored with 'state two', 'name the green substance' and the mark allocation. The two "
  "diagram questions were checked so that each label points to exactly one structure and no organelle is named "
  "in the artwork itself (which would give away the answer)."),
 ("Are Ghanaian contexts used naturally and accurately?",
  "Yes: Kwame, Ama, Kofi and Akosua; onion skin; a dark cupboard; local materials for modelling a cell "
  "(corn dough, clear glue, sand). Contexts support the science rather than decorating it."),
 ("Has any content outside the supplied curriculum been introduced?",
  "No. Every item sits inside topics 2.1-2.6. 'Mitochondrion' (A13, A29) is required by indicator "
  "B7/JHS1.1.2.1.1 exemplar 2, which asks for the function of each organelle in the animal cell. No chemical "
  "formulae, equations or biochemistry were introduced."),
 ("Are the questions sufficiently varied?",
  "Yes. Item types include definition, identification, function matching, diagram labelling, diagram analysis, "
  "table completion, experimental procedure, model design, application to a novel situation and evaluation of "
  "a claim."),
]
for i, (q, a) in enumerate(qc, start=1):
    p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(2)
    set_font(p.add_run(f"{i}. {q}"), 10.5, bold=True)
    p2 = doc.add_paragraph()
    p2.paragraph_format.left_indent = Inches(0.3); p2.paragraph_format.space_after = Pt(6)
    set_font(p2.add_run(a), 10)

para("", space_after=8)
para("EXAMINER NOTES (for the teacher, not for candidates)", size=11, bold=True, space_after=4)
for n in [
 "Cognitive demand and the indicators: the action verbs in the two official B7 indicators are 'describe' "
 "(B7/JHS1.1.2.1.1) and 'state' (B7/JHS1.1.2.1.2), which sit at Understand level. That sets the floor for this "
 "sub-strand. The Apply, Analyse, Evaluate and Create items in this paper are deliberate extensions beyond the "
 "minimum - standard practice for a mock examination, and directly supported by the indicators' own exemplars, "
 "which ask learners to 'draw and label a cell' and to 'develop a model to represent a cell' (Create). If you "
 "want a paper that sits exactly at the indicator level, drop Questions 1(c), 2(c), 3(b), 5(b) and 6(c).",
 "Topic 2.6 carries 23 of 100 marks (23%), the highest weighting, because comparing the two cell types is the "
 "natural synthesis of the sub-strand and is heavily examined at this level.",
 "Question 3(b) and Question 1(c) are the two items most likely to separate strong candidates from weak ones. "
 "Both are marked generously for method and reasoning, so partial credit is common.",
 "The two diagrams are drawn with text characters inside Word tables. Enlarge the font, replace the characters "
 "with real shapes, or paste in a hand-drawn figure - the numbering (1-4 and 1-6) is what the questions depend on.",
 "Edit the school name, academic year and examination title on page 1 before printing.",
 "This is an original, teacher-made mock. It is not a reproduction of any WAEC or NaCCA examination paper.",
]:
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Inches(0.3); p.paragraph_format.space_after = Pt(3)
    set_font(p.add_run("- " + n), 10)

doc.save("/home/user/Basic7_Integrated_Science_Mock_Strand1_LivingCells.docx")
print("docx written")

print("Section A:", len(MCQ), "items")
print("Section B total:", sum(q["total"] for q in SECTION_B))
print("Topic marks:", m, "sum", sum(m.values()))
print("Difficulty:", diff, "sum", sum(diff.values()))
print("Cognitive A:", ca)
print("Cognitive B:", cb)
print("Answer counts:", counts)
print("Totals:", sum(m.values()), sum(diff.values()),
      sum(ca.values()) + sum(cb.values()))
