# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "/home/user")
from build_crop import *

L = []
def w(s=""): L.append(s)

w(f"# {SCHOOL}"); w()
w(f"## {SUBJECT}"); w()
w(f"### {EXAM}"); w()
w(f"**Class:** {CLASS}  ")
w(f"**Time:** {TIME}  ")
w(f"**Total Marks:** {MARKS}  ")
w(f"**Academic Year:** {YEAR}"); w()
w("---"); w()
w("### INSTRUCTIONS"); w()
for i, t in enumerate([
    "Write your name and class clearly in the spaces provided on your answer sheet.",
    "This paper has TWO sections: Section A and Section B.",
    "Answer ALL the questions in both sections.",
    "Section A has 40 multiple-choice questions. Each question carries 1 mark. Choose the best answer (A, B, C or D) and record it on the answer sheet provided.",
    "Section B has 7 theory questions totalling 60 marks. Write your answers clearly and neatly in your answer booklet. Draw and label diagrams or tables where you are asked to.",
    "Read every question carefully before you answer it.",
    "Do not use correction fluid. Cancel any mistake neatly with a single line.",
    "Hand in your answer sheet and your answer booklet at the end of the examination.",
], start=1):
    w(f"{i}. {t}")
w(); w("---"); w()

w("## SECTION A: OBJECTIVE TEST (40 marks)"); w()
w("*Answer ALL questions. Each question carries 1 mark. Choose the BEST answer and write its letter "
  "(A, B, C or D) against the question number on your answer sheet.*"); w()
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"**{i}. {q}**"); w()
    for j, o in enumerate(opts): w(f"{'ABCD'[j]}. {o}")
    w()
w("---"); w()

w("## SECTION B: THEORY (60 marks)"); w()
w("*Answer ALL questions. Write your answers in your answer booklet. The marks for each question are shown "
  "in brackets.*"); w()
for qb in SECTION_B:
    w(f"### Question {qb['num']}  [{qb['total']} marks]"); w()
    w(qb["stem"]); w()
    if qb.get("table") == "compare":
        w("| " + " | ".join(COMPARE_HEADERS) + " |")
        w("| " + " | ".join(["---"] * len(COMPARE_HEADERS)) + " |")
        for r in COMPARE_ROWS:
            w("| " + " | ".join(r) + " |")
        w()
        w("*Table 1: Differences between organic and inorganic plant nutrients*"); w()
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        w(f"**{lab}** {text}  **[{mk} mark{'s' if mk > 1 else ''}]**"); w()
w("---"); w()

w("## ANSWER KEY"); w()
w("### Section A - Objective Test"); w()
w("| Question | Answer | Curriculum Area (Topic) | Cognitive Level |")
w("| -------- | ------ | ----------------------- | --------------- |")
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"| {i} | {ans} | {TOPIC[tp]} | {cog} |")
counts = {L2: sum(1 for q in MCQ if q[2] == L2) for L2 in "ABCD"}
w()
w("Correct-answer distribution: " + ", ".join(f"{L2} = {counts[L2]}" for L2 in "ABCD") + " (40 items).")
w()
w("### Section B - Theory (summary answers; full detail in the Marking Scheme)"); w()
w("| Question | Expected Answer | Curriculum Area | Cognitive Level |")
w("| -------- | --------------- | --------------- | --------------- |")
sba = [
 ("1 (a)", "Any substance that a plant takes in and uses for its growth and development; it is the plant's food, taken mainly from the soil, air and water.", "5.1", "Understand"),
 ("1 (b)", "Any three of: to grow tall and produce leaves and stems; to produce a good root system; to produce flowers, fruits and seeds; to stay healthy and resist disease and drought; to give a dark green leaf colour.", "5.1", "Understand"),
 ("1 (c)", "Each harvest carries nutrients away in the grain, leaves and stalks, so the soil store gets smaller; rain also washes nutrients away; they must be replaced or the yield falls.", "5.1", "Analyse"),
 ("2 (a)", "Any three of: poultry manure; cow dung; goat or sheep droppings; compost; green manure; crop residue; kitchen refuse; wood ash; fish waste; decayed leaves.", "5.2", "Remember"),
 ("2 (b)", "Any three of: NPK 15-15-15; urea; sulphate of ammonia; muriate of potash; single superphosphate.", "5.2", "Remember"),
 ("2 (c)", "Decide where the material comes from: from the remains of plants and animals = organic; manufactured or mined = inorganic. Organic material is bulky, dark and rots; inorganic material is usually dry, clean granules or crystals with the nutrient content printed on the bag.", "5.2", "Understand"),
 ("3 (a)", "(i) manufactured from mineral deposits or chemicals; (ii) low, and it varies from heap to heap; (iii) slow, because soil organisms must break it down first; (iv) little or no humus is added and long use can make the soil hard; (v) large; (vi) very low - it rarely burns the plant.", "5.3", "Understand"),
 ("3 (b)", "NPK is concentrated: each kilogram contains far more nutrient than a kilogram of manure, so a small volume supplies as much nutrient as a very large volume of poultry manure.", "5.3", "Apply"),
 ("3 (c)", "Organic nutrient source (compost or manure), because it adds humus which binds sandy particles together and helps the soil hold water, and it improves the soil year after year.", "5.3", "Evaluate"),
 ("4 (a)", "Any three of: dry; granules, crystals or powder; small uniform particles; often coloured; packed in labelled bags; little smell of decay; dissolves readily in water; heavy for its size.", "5.4", "Remember"),
 ("4 (b)", "Any three of: dark brown or black; crumbly or powdery; moist; smells of decay; bulky; contains visible straw, husks or fibre; particles of many sizes; light for its size.", "5.4", "Remember"),
 ("4 (c)", "NPK is dry and flows freely, so it can be measured with a tin and placed in a ring or band beside each plant; because it dissolves quickly it must be covered with soil or rain will wash it away. Compost is bulky and coarse, so it is spread over the whole bed and mixed into the topsoil, or used as a mulch.", "5.4", "Apply"),
 ("5 (a)", "Wait until the soil is moist; measure the amount needed; place it in a ring or band about 5-10 cm from the base of each maize plant; cover it with soil; apply it in two or three split doses during the season.", "5.5", "Understand"),
 ("5 (b)", "Spread it evenly over the whole bed, work it lightly into the topsoil with a hoe or rake before planting (or round established plants without touching the stem), then water the plot.", "5.5", "Understand"),
 ("5 (c)", "Fertilizer against the stem can draw water out of the young tissues and burn the plant; placing it a few centimetres away puts the nutrient where the feeding roots are; covering it with soil stops rain and wind from carrying it away before the roots take it up.", "5.5", "Understand"),
 ("6 (a)", "Any three of: hoe or hand fork; rake; bucket or basin; measuring tin or cup; watering can; string and pegs; gloves; nose mask; boots; notebook and pencil.", "5.6", "Remember"),
 ("6 (b)", "Clear and loosen the bed; mark out the planting positions; measure the compost so every part gets the same amount; spread it evenly; work it lightly into the topsoil; plant and water well; record the date and the amount.", "5.6", "Apply"),
 ("6 (c)", "Any four of: date; bed or plot name; what was applied and how much; plant height measured at regular intervals; number of leaves or leaf colour; yield (number or mass harvested); other observations; a comparison bed with no compost; space for comments.", "5.6", "Create"),
 ("7 (a)", "Use beds of the same size, soil and place; plant the same crop at the same spacing on the same day; give the same water, weeding and care; change only the type of nutrient; keep one bed with no nutrient as a control.", "5.6", "Create"),
 ("7 (b)", "Any two of: plant height measured at the same time; leaf colour; number of leaves; how quickly plants flower or fruit; number or mass of the crop harvested.", "5.6", "Evaluate"),
]
for r in sba: w(f"| {r[0]} | {r[1]} | {r[2]} | {r[3]} |")
w(); w("---"); w()

w("## MARKING SCHEME - SECTION B (60 marks)"); w()
w("*General rules: (1) Accept any other correct and relevant answer. (2) Award marks for correct points, not "
  "for repeating the question. (3) For procedures, award method marks. (4) Do not deduct marks for spelling "
  "unless the meaning is changed. (5) Where a candidate gives more answers than are asked for, mark only the "
  "first ones up to the number required.*"); w()
for qb in SECTION_B:
    n = qb["num"]
    w(f"### Question {n} ({qb['total']} marks)"); w()
    for (lab, points, note) in MARKING[n]:
        mkv = [p_[2] for p_ in qb["parts"] if p_[0] == lab]
        head = f"**{lab}**"
        if mkv: head += f" [{mkv[0]} mark{'s' if mkv[0] > 1 else ''}]"
        w(head); w()
        for pt in points: w(f"- {pt}")
        w(f"  - *Marking note: {note}*"); w()
w("---"); w()

w("## CURRICULUM ASSESSMENT BLUEPRINT"); w()
w(f"**Strand:** {STRAND} | **Sub-strand:** {SUBSTRAND} | **Class:** {CLASS}"); w()
w(f"**Content Standard:** {CS} - {CS_TEXT}"); w()
w("> Source: NaCCA Science Common Core Programme Curriculum (B7/JHS1-B9/JHS3), September 2020, "
  "Strand 2: Cycles, Sub-strand 3: Crop Production, p. 11. Indicators are quoted, not invented."); w()

w("### Section A"); w()
w("| Qn | Sub-strand | Content Standard | Indicator (NaCCA) - Indicator Text | Topic / Content | Cognitive Level | Marks |")
w("| -- | ---------- | ---------------- | ---------------------------------- | --------------- | --------------- | ----- |")
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"| A{i} | {SUBSTRAND} | {CS} | {IND[tp]} - {IND_TEXT[tp]} | {TOPIC[tp]} | {cog} | 1 |")
w()
w("### Section B"); w()
w("| Qn | Sub-strand | Content Standard | Indicator (NaCCA) - Indicator Text | Topic / Content | Cognitive Level | Marks |")
w("| -- | ---------- | ---------------- | ---------------------------------- | --------------- | --------------- | ----- |")
for qb in SECTION_B:
    for (lab, text, mkv, cog, tp, diff) in qb["parts"]:
        key = tp if tp in TOPIC else tp.split(",")[0].strip()
        w(f"| B{qb['num']}{lab.strip('()')} | {SUBSTRAND} | {CS} | {IND[key]} - {IND_TEXT[key]} | {TOPIC[key]} | {cog} | {mkv} |")
w(); w("---"); w()

def topic_totals():
    m = {k: 0 for k in TOPIC}; it = {k: 0 for k in TOPIC}
    for q in MCQ: m[q[3]] += 1; it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk; it[key] += 1
    return m, it

def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}; b = {k: 0 for k in order}
    for q in MCQ: a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: b[cog] += mk
    return order, a, b

def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ: d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: d[diff] += mk
    return d

m, it = topic_totals(); diff_ = difficulty_totals(); order, ca, cb = cognitive_by_section()

w("### Summary 1 - Coverage by Curriculum Area (Topic)"); w()
w("| Topic / Content Area | No. of Items | Marks | % of Total Marks | Core Competencies |")
w("| -------------------- | ------------ | ----- | ---------------- | ----------------- |")
for k in TOPIC: w(f"| {TOPIC[k]} | {it[k]} | {m[k]} | {(m[k]/100)*100:.1f}% | {CC[k]} |")
w(f"| **TOTAL** | **{sum(it.values())}** | **{sum(m.values())}** | **100%** | - |")
w()
w("*CC = Communication and Collaboration; CP = Critical Thinking and Problem Solving; DL = Digital Literacy; "
  "CI = Creativity and Innovation.*"); w()
w("### Summary 2 - Cognitive-Level Distribution (Bloom's Taxonomy)"); w()
w("| Cognitive Level | Section A Marks | Section B Marks | Total Marks | % of Total |")
w("| --------------- | --------------- | --------------- | ----------- | ---------- |")
for lv in order:
    tot = ca[lv] + cb[lv]
    w(f"| {lv} | {ca[lv]} | {cb[lv]} | {tot} | {(tot/100)*100:.1f}% |")
w(f"| **TOTAL** | **{sum(ca.values())}** | **{sum(cb.values())}** | **{sum(ca.values())+sum(cb.values())}** | **100%** |")
w()
w("### Summary 3 - Difficulty Distribution"); w()
w("| Difficulty | Marks | % of Total Marks |")
w("| ---------- | ----- | ---------------- |")
for k, v in diff_.items(): w(f"| {k} | {v} | {(v/100)*100:.1f}% |")
w(f"| **TOTAL** | **{sum(diff_.values())}** | **100%** |")
w()
w("*Target in the master prompt: approximately 30% easy / 50% moderate / 20% challenging.*"); w()
w("### Summary 4 - Section Weighting"); w()
w("| Section | Question Type | Items | Marks | % of Total |")
w("| ------- | ------------- | ----- | ----- | ---------- |")
w("| A | Objective (multiple choice) | 40 | 40 | 40% |")
w("| B | Theory / constructed response | 20 | 60 | 60% |")
w("| **TOTAL** | - | **60** | **100** | **100%** |")
w(); w("---"); w()

w("## QUALITY-CONTROL SUMMARY")
w("")
w("| Check | Status |")
w("| --- | --- |")
for q_, a_ in [
 ("Every question within supplied curriculum scope",
  "Yes - topics 5.1-5.6 of Strand 2, Sub-Strand 3 (Crop Production), mapped to indicators B7/JHS1.2.3.1.1 and B7/JHS1.2.3.1.2"),
 ("Appropriate for the class",
  "Yes - B7 level; no micronutrient chemistry, no fertilizer-formula calculation and no NPK ratio arithmetic, all of which sit outside the B7 indicator"),
 ("Genuinely BECE-style",
  "Yes - 40 four-option objectives plus structured theory with printed mark allocations and a table for pupils to complete"),
 ("Sufficient application and reasoning",
  "Yes - 30 of 100 marks (30%) at Apply level or above (Apply 14, Analyse 5, Evaluate 4, Create 7)"),
 ("Plausible MCQ distractors",
  "Yes - drawn from the same content family as the key: the other nutrient category, the wrong nutrient element, the wrong application method, and plausible but wrong timings"),
 ("Single best answer per MCQ",
  "Yes - reviewed item by item; special care with A2, where the stem asks specifically for the three elements most often supplied in fertilizers"),
 ("Marks internally consistent",
  "Yes - Section A 40 x 1 = 40; Section B 8 + 9 + 10 + 9 + 9 + 10 + 5 = 60; sub-question marks match the marking scheme"),
 ("Total adds up correctly",
  "Yes - 40 + 60 = 100"),
 ("Answer key correct",
  "Yes - all 40 keys and all 20 Section B answers verified against the marking scheme"),
 ("Marking scheme matches questions",
  "Yes - expected answers plus marking notes covering partial credit, alternatives, common wrong answers and method marks; the two design tasks have opening marking grids"),
 ("Free from unnecessary ambiguity",
  "Yes - open items are anchored with 'state three', 'name two' and the mark allocation; Question 3(a) numbers every blank (i) to (vi)"),
 ("Ghanaian contexts natural and accurate",
  "Yes - maize, garden eggs, pepper, cocoa husks, poultry manure, NPK 15-15-15 and sulphate of ammonia under its local trade name, market fish waste, the harmattan, and a school garden bed marked out with string and pegs"),
 ("No content beyond the curriculum",
  "No - Question 3 uses the tabular comparison of exemplar 1 and the volume comparison of exemplar 2; Question 7 repeats it as a practical fair test; Question 6 is exemplar 3, the practical application itself"),
 ("Questions sufficiently varied",
  "Yes - definition, listing and classification, completing a comparison table, explaining concentration and volume, describing physical characteristics, linking form to method of application, describing field method, designing a record sheet, and designing a fair test"),
]:
    w("| " + q_ + " | " + a_ + " |")
w("")
w("### EXAMINER NOTES")
w("")
for n_ in [
 "Question 3(a) is the 'create a table' exemplar (B7/JHS1.2.3.1.1, Ex. 1) turned into a completion task. The six blanks are numbered (i) to (vi) so marking is quick and fair: 1 mark each, and the blank number must be matched to the answer.",
 "Question 7 is the volume-comparison exemplar (B7/JHS1.2.3.1.1, Ex. 2) set up as a fair test. The thing to look for is the principle that only the type of nutrient changes - same bed size, same crop, same spacing, same water and a control bed.",
 "Question 6 is the practical-application exemplar (B7/JHS1.2.3.1.2, Ex. 3). If your school has a garden, run Questions 6 and 7 as real activities before the mock, and accept what pupils actually did as evidence in the answers.",
 "Topic 5.6 carries 21 of 100 marks (21%), the highest weighting, because the indicator ends in practical application. If you want a flatter spread, move marks from Questions 6 and 7 to Questions 1 and 2.",
 "A6 and A20 deliberately avoid any calculation. The figures on an NPK bag (A24) are tested as labels to read, not as numbers to work with - that is the B7 limit.",
 "If you supply real samples of compost, manure and NPK during revision, pupils handle A21 to A27 far better, since those items are about what the material looks and feels like.",
 "Safety note for any practical follow-up: gloves, hand washing, no eating in the garden, and no handling of fertilizer dust without supervision. Do not let pupils taste or smell fertilizers.",
 "Edit the school name, academic year and examination title on page 1 before printing.",
 "This is an original, teacher-made mock. It is not a reproduction of any WAEC or NaCCA examination paper.",
]:
    w("- " + n_)
w()

open("/home/user/Basic7_Integrated_Science_Mock_Strand2_CropProduction.md", "w", encoding="utf-8").write("\n".join(L))
print("md written", len("\n".join(L)), "chars")
