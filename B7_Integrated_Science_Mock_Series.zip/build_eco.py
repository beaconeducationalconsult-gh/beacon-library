# -*- coding: utf-8 -*-
"""Basic 7 Integrated Science mock - Strand 3 Sub-strand 3: ECOSYSTEM. 100 marks.
Indicators sourced from the official NaCCA Science CCP curriculum (B7/JHS1-B9/JHS3, Sept 2020),
Strand 3: Systems, Sub-strand 3: Ecosystem, printed pages 21-22."""

SCHOOL = "[SCHOOL NAME]"
SUBJECT = "INTEGRATED SCIENCE (SCIENCE)"
EXAM = "END-OF-TERM MOCK EXAMINATION"
CLASS = "Basic 7 (JHS 1)"
TIME = "2 hours (Suggested: Section A - 40 min; Section B - 80 min)"
MARKS = "100"
YEAR = "2025/2026 Academic Year"

STRAND = "Systems"
SUBSTRAND = "Ecosystem"

TOPIC = {
    "9.1": "9.1 What is an Ecosystem?",
    "9.2": "9.2 Types of Ecosystems: Terrestrial, Aquatic and Arboreal",
    "9.3": "9.3 Components of an Ecosystem: Biotic and Abiotic Factors",
    "9.4": "9.4 How Components of an Ecosystem Interact",
    "9.5": "9.5 Interdependence of Organisms in an Ecosystem",
}

CS = "B7/JHS1.3.3.1"
CS_BY_TOPIC = {k: "B7/JHS1.3.3.1" for k in ["9.1", "9.2", "9.3", "9.4", "9.5"]}
CS_TEXT = "Recognise the components of and interdependences in an ecosystem, and appreciate their " \
          "interactions"

IND = {
    "9.1": "B7/JHS1.3.3.1.1 (Ex. 1)",
    "9.2": "B7/JHS1.3.3.1.1 (Ex. 2, 4)",
    "9.3": "B7/JHS1.3.3.1.1 (Ex. 3)",
    "9.4": "B7/JHS1.3.3.1.1 (Ex. 5)",
    "9.5": "B7/JHS1.3.3.1.1 (Ex. 4, 5)",
}
IND_TEXT = {
    "9.1": "Describe an ecosystem as a self-sustaining unit in which components interact, e.g. a pond, "
           "a forest and many others.",
    "9.2": "Group ecosystems into terrestrial, aquatic and arboreal categories; differentiate among "
           "organisms in the different ecosystems.",
    "9.3": "Identify and list the components, such as biotic and abiotic, of each category of "
           "ecosystem.",
    "9.4": "Explain how the components of the different ecosystems affect one another.",
    "9.5": "Differentiate among organisms in the different ecosystems; explain how the components of "
           "the different ecosystems affect one another (interdependence).",
}
CC = {k: "DL, CP, CC, CI" for k in ["9.1", "9.2", "9.3", "9.4", "9.5"]}

# ---------------------------------------------------------------- SECTION A
# (question, [A,B,C,D], answer, topic, cognitive, difficulty)
MCQ = [
 ("An ecosystem is",
  ["a place where only plants grow", "all the animals in the world",
   "a self-sustaining unit in which living things and their non-living surroundings interact",
   "a collection of rocks and soil"],
  "C", "9.1", "Understand", "Easy"),
 ("Which of these is an example of an ecosystem?",
  ["a pond", "a stone", "a bucket of dry sand", "a single leaf"],
  "A", "9.1", "Understand", "Easy"),
 ("The living and the non-living parts of an ecosystem are called its",
  ["planets", "nutrients", "organs", "components"],
  "D", "9.1", "Remember", "Easy"),
 ("An ecosystem is described as self-sustaining because",
  ["it never changes at all",
   "it can keep itself going, because its parts supply what the others need",
   "people look after it every day", "it has no animals in it"],
  "B", "9.1", "Understand", "Moderate"),
 ("Which of these is the smallest ecosystem?",
  ["the ocean", "the Sahara desert", "a small pond behind a house", "the Amazon forest"],
  "C", "9.1", "Understand", "Easy"),
 ("Two important parts of every ecosystem are",
  ["the living things and the non-living surroundings", "the Sun and the Moon",
   "the soil and the air only", "the plants and the soil only"],
  "A", "9.1", "Understand", "Easy"),
 ("A forest is an ecosystem because",
  ["it has many trees", "it is very large", "nobody lives in it",
   "the trees, animals, soil, water and air in it all interact and keep the forest going"],
  "D", "9.1", "Understand", "Moderate"),
 ("Which of these would NOT be described as an ecosystem?",
  ["a pond", "a pile of dry stones in a compound", "a forest", "a stretch of mangrove swamp"],
  "B", "9.1", "Understand", "Easy"),
 ("An ecosystem found in water is called",
  ["terrestrial", "arboreal", "aquatic", "desert"],
  "C", "9.2", "Remember", "Easy"),
 ("A forest or a grassland is an example of a",
  ["terrestrial ecosystem", "aquatic ecosystem", "arboreal ecosystem", "marine ecosystem"],
  "A", "9.2", "Remember", "Easy"),
 ("An arboreal ecosystem is one that is found",
  ["under the ground", "in the sea", "on open grassland", "in trees"],
  "D", "9.2", "Remember", "Easy"),
 ("A pond, a river and a lake are all examples of",
  ["terrestrial ecosystems", "aquatic ecosystems", "arboreal ecosystems", "desert ecosystems"],
  "B", "9.2", "Remember", "Easy"),
 ("Which of these is an arboreal ecosystem?",
  ["a rice field", "the Volta Lake",
   "the community of plants and animals living in the branches of a big silk-cotton tree",
   "a cattle ranch"],
  "C", "9.2", "Understand", "Moderate"),
 ("Which of the following correctly names the three categories of ecosystem?",
  ["terrestrial, aquatic and arboreal", "forest, farm and town",
   "hot, cold and wet", "plant, animal and soil"],
  "A", "9.2", "Remember", "Easy"),
 ("A mangrove swamp along the coast is best described as",
  ["terrestrial only", "arboreal only", "neither aquatic nor terrestrial",
   "an ecosystem with both aquatic and terrestrial features"],
  "D", "9.2", "Understand", "Moderate"),
 ("Birds, insects, lizards and mosses living in the branches of one large tree are mainly part of",
  ["an aquatic ecosystem", "an arboreal ecosystem", "a desert ecosystem", "a marine ecosystem"],
  "B", "9.2", "Apply", "Moderate"),
 ("The living components of an ecosystem are called the",
  ["abiotic components", "habitats", "biotic components", "nutrients"],
  "C", "9.3", "Remember", "Easy"),
 ("Which of these is an abiotic component of a pond?",
  ["the temperature of the water", "the fish", "the water lily", "the frog"],
  "A", "9.3", "Remember", "Easy"),
 ("Which of these is a biotic component of a forest?",
  ["rainfall", "the soil", "sunlight", "the trees"],
  "D", "9.3", "Remember", "Easy"),
 ("Which of the following lists contains ONLY abiotic components?",
  ["fish, water, sunlight", "sunlight, water, temperature, soil",
   "grass, goat, soil", "trees, birds, air"],
  "B", "9.3", "Understand", "Moderate"),
 ("Which pair is correctly matched?",
  ["frog - abiotic", "water - biotic", "water lily - biotic", "sunlight - biotic"],
  "C", "9.3", "Understand", "Moderate"),
 ("Which of these is a biotic component of an arboreal ecosystem?",
  ["a squirrel living in the branches", "the bark of the tree", "the rain falling on the leaves",
   "the wind moving the branches"],
  "A", "9.3", "Understand", "Easy"),
 ("In a pond ecosystem, the oxygen dissolved in the water is",
  ["a biotic component", "a plant", "an animal", "an abiotic component"],
  "D", "9.3", "Remember", "Easy"),
 ("Which abiotic component supplies the energy that almost all ecosystems depend on?",
  ["the soil", "sunlight", "the wind", "the rocks"],
  "B", "9.3", "Understand", "Easy"),
 ("Green plants are important in an ecosystem mainly because they",
  ["provide shade only", "hold the soil together only",
   "make their own food using sunlight, and so provide food for the other living things",
   "keep the wind away"],
  "C", "9.4", "Understand", "Moderate"),
 ("Which of these is an example of one living thing affecting another in an ecosystem?",
  ["bees carrying pollen from flower to flower", "rain falling on the soil",
   "the Sun warming the water", "the wind shaking the leaves"],
  "A", "9.4", "Understand", "Moderate"),
 ("When a plant dies in a forest, its remains",
  ["disappear at once", "turn into stone", "stay the same for ever",
   "are broken down by decay organisms, which return nutrients to the soil"],
  "D", "9.4", "Understand", "Moderate"),
 ("During the day, the green plants in a pond give out",
  ["carbon dioxide only", "oxygen", "nitrogen", "nothing at all"],
  "B", "9.4", "Understand", "Moderate"),
 ("Animals in an ecosystem depend on plants for",
  ["shelter only", "water only", "food and oxygen", "sunlight"],
  "C", "9.4", "Remember", "Easy"),
 ("Which of these shows a non-living component affecting a living one?",
  ["a long dry season making the grass turn brown", "a goat eating the grass",
   "a hawk catching a chick", "a bee visiting a flower"],
  "A", "9.4", "Apply", "Challenging"),
 ("Which of these shows living things affecting a non-living component?",
  ["rain filling the pond", "the Sun drying the soil", "the wind bending the grass",
   "tree roots breaking up the rocks and adding humus to the soil"],
  "D", "9.4", "Apply", "Challenging"),
 ("Plants depend on animals in an ecosystem mainly for",
  ["sunlight", "carbon dioxide for making food, and help with pollination", "water", "soil"],
  "B", "9.4", "Understand", "Moderate"),
 ("Interdependence in an ecosystem means that",
  ["all the organisms are the same", "the organisms never meet one another",
   "the organisms depend on one another for food, shelter, pollination and other needs",
   "only the plants are important"],
  "C", "9.5", "Understand", "Moderate"),
 ("A food chain on a Ghanaian farm could be",
  ["maize -> grasshopper -> lizard -> hawk", "hawk -> lizard -> grasshopper -> maize",
   "maize -> hawk -> lizard -> grasshopper", "lizard -> maize -> hawk -> grasshopper"],
  "A", "9.5", "Understand", "Moderate"),
 ("If all the grasshoppers were removed from the farm, the most likely result would be that",
  ["the maize would grow much better", "nothing would change at all",
   "the hawks would start eating maize",
   "the lizards and the hawks would lose a source of food and their numbers would fall"],
  "D", "9.5", "Apply", "Moderate"),
 ("A farmer sprays a strong insecticide and kills most of the insects on his farm. Which of these is "
  "most likely to follow?",
  ["the crops grow better at once",
   "the animals that feed on the insects lose their food, and the flowers that needed the insects "
   "are not pollinated",
   "the soil becomes richer", "nothing at all changes"],
  "B", "9.5", "Analyse", "Challenging"),
 ("Decay organisms such as bacteria and fungi are important in an ecosystem because they",
  ["cause disease only", "make the soil hard",
   "break down dead plants and animals and return nutrients to the soil", "eat the living plants"],
  "C", "9.5", "Understand", "Moderate"),
 ("Which statement best describes a balanced ecosystem?",
  ["the numbers of the different organisms stay roughly the same over time, because each depends on "
   "the others", "there are no animals at all",
   "one kind of organism is far more numerous than all the others",
   "the ecosystem never changes in any way"],
  "A", "9.5", "Understand", "Moderate"),
 ("Cutting down all the trees on a hillside is likely to",
  ["have no effect on the ecosystem", "make the soil richer at once", "bring more rain",
   "remove food and shelter for many organisms and allow the soil to be washed away"],
  "D", "9.5", "Analyse", "Moderate"),
 ("Which of these is the best reason for protecting an ecosystem?",
  ["so that nobody can ever use it",
   "because the living and the non-living parts depend on one another, so damaging one part harms "
   "the whole", "because tourists like to look at it", "because the soil is valuable"],
  "B", "9.5", "Evaluate", "Moderate"),
]

# ---------------------------------------------------- SECTION B TABLE (Q3)
POND_HEADERS = ["Component of the pond ecosystem", "Biotic or abiotic"]
POND_ROWS = [
 ["Water", "(i)"],
 ["Water lily", "(ii)"],
 ["Sunlight", "(iii)"],
 ["Tilapia (a fish)", "(iv)"],
 ["Oxygen dissolved in the water", "(v)"],
 ["Frog", "(vi)"],
]

# ---------------------------------------------------------------- SECTION B
SECTION_B = [
 dict(
   num=1, total=9, topic="9.1",
   stem="A pond behind a village, a forest reserve and the branches of one big silk-cotton tree can all "
        "be studied in the same way.",
   parts=[
     ("(a)", "Explain what is meant by an ecosystem.", 3, "Understand", "9.1", "Easy"),
     ("(b)", "Give two examples of an ecosystem found in Ghana.", 2, "Remember", "9.1", "Easy"),
     ("(c)", "Explain why an ecosystem is described as a self-sustaining unit.",
      4, "Understand", "9.1", "Challenging"),
   ]),
 dict(
   num=2, total=9, topic="9.2",
   stem="Ecosystems are grouped into three categories.",
   parts=[
     ("(a)", "Name the three categories into which ecosystems are grouped.",
      3, "Remember", "9.2", "Easy"),
     ("(b)", "Give one example of each of the three categories.", 3, "Understand", "9.2", "Easy"),
     ("(c)", "Explain what is meant by an arboreal ecosystem, and say how it differs from a "
             "terrestrial one.", 3, "Understand", "9.2", "Moderate"),
   ]),
 dict(
   num=3, total=10, topic="9.3",
   stem="The class studied a pond near the school and listed some of its components. Study the "
        "incomplete table below and answer the questions that follow.",
   table="pond",
   parts=[
     ("(a)", "Copy and complete the table.", 6, "Understand", "9.3", "Moderate"),
     ("(b)", "Name two other abiotic components of a pond ecosystem that are not in the table.",
      2, "Remember", "9.3", "Easy"),
     ("(c)", "Explain the difference between a biotic component and an abiotic component.",
      2, "Understand", "9.3", "Moderate"),
   ]),
 dict(
   num=4, total=9, topic="9.4",
   stem="The components of an ecosystem affect one another all the time.",
   parts=[
     ("(a)", "State three ways in which the living components of an ecosystem affect one another.",
      3, "Understand", "9.4", "Moderate"),
     ("(b)", "Explain how the abiotic components affect the living things in a pond.",
      3, "Apply", "9.4", "Moderate"),
     ("(c)", "Explain how the living things in an ecosystem affect the abiotic components.",
      3, "Understand", "9.4", "Challenging"),
   ]),
 dict(
   num=5, total=8, topic="9.5",
   stem="The organisms in an ecosystem depend on one another.",
   parts=[
     ("(a)", "Explain what is meant by the interdependence of organisms in an ecosystem.",
      3, "Understand", "9.5", "Moderate"),
     ("(b)", "State two ways in which plants and animals depend on each other in an ecosystem.",
      2, "Understand", "9.5", "Moderate"),
     ("(c)", "Write down a simple food chain for a Ghanaian farm or forest, and explain what would "
             "happen if one of the links were removed.", 3, "Analyse", "9.5", "Challenging"),
   ]),
 dict(
   num=6, total=8, topic="9.5",
   stem="A farmer sprays a strong insecticide on his maize farm and most of the insects die.",
   parts=[
     ("(a)", "State three effects this could have on the other organisms on the farm.",
      3, "Analyse", "9.5", "Moderate"),
     ("(b)", "Explain why the effect does not stop with the insects.", 3, "Analyse", "9.5",
      "Moderate"),
     ("(c)", "Suggest two things the farmer could do to farm without destroying the ecosystem.",
      2, "Create", "9.5", "Challenging"),
   ]),
 dict(
   num=7, total=7, topic="9.3",
   stem="Your class has been asked to study an ecosystem in your own community.",
   parts=[
     ("(a)", "Describe how your class would carry out the study, and say what you would record.",
      4, "Create", "9.3", "Challenging"),
     ("(b)", "Give two reasons why such a study helps the class to appreciate the ecosystem, and "
             "state one thing the class should do to avoid harming the ecosystem it studies.",
      3, "Evaluate", "9.4", "Moderate"),
   ]),
]

# ------------------------------------------------------- MARKING SCHEME
MARKING = {
 1: [
   ("(a)", ["An ecosystem is a self-sustaining unit in which living things and their non-living "
            "surroundings interact.",
            "It is a community of living things together with the soil, water, air and sunlight around "
            "them.",
            "It is any natural unit, such as a pond or a forest, in which the living and non-living "
            "parts interact."],
    "1 mark each for any THREE correct points (3 marks). Accept 'a place where living things and their "
    "surroundings interact'. Do NOT accept 'a habitat' alone - a habitat is the home of ONE kind of "
    "organism, while an ecosystem is the whole interacting unit."),
   ("(b)", ["A pond", "A forest", "A river or a stream", "A lake (e.g. the Volta Lake)",
            "A mangrove swamp", "A grassland or savanna", "A farm or a school garden",
            "The branches of a large tree"],
    "1 mark each for any TWO correct examples (2 marks). Accept any real ecosystem found in Ghana. Do "
    "NOT accept 'a zoo' or 'a garden in a pot' without the surroundings."),
   ("(c)", ["The living parts supply what the other living parts need: plants make the food, animals "
            "spread pollen and seeds, and decay organisms return nutrients to the soil.",
            "The non-living parts - sunlight, water, air and soil - provide what the living parts "
            "need.",
            "Green plants trap the Sun's energy and make food, so the ecosystem has its own source of "
            "energy.",
            "Waste and dead remains are broken down and used again, so the nutrients go round and "
            "round instead of being lost.",
            "Because of these links the unit can keep itself going without people having to supply "
            "anything from outside."],
    "1 mark each for any FOUR correct points (4 marks). The key ideas are: the parts supply each "
    "other's needs, energy enters through green plants, and nutrients are recycled. Award at least "
    "1 mark for 'the parts depend on each other so it can keep going'."),
 ],
 2: [
   ("(a)", ["Terrestrial", "Aquatic", "Arboreal"],
    "1 mark each for all THREE categories correctly named (3 marks). Accept the local spelling if it "
    "is recognisable. Do NOT accept 'forest', 'farm' or 'desert' - those are examples, not "
    "categories."),
   ("(b)", ["Terrestrial: a forest, a grassland (savanna), a farm, a school garden, the scrub round "
            "the compound.",
            "Aquatic: a pond, a stream, a river, a lake, a mangrove swamp, the sea.",
            "Arboreal: the community of organisms living in the branches of one large tree, such as a "
            "silk-cotton tree or a mango tree."],
    "1 mark for each category matched to a correct example (3 marks). The example must belong to the "
    "category named."),
   ("(c)", ["An arboreal ecosystem is the community of organisms that lives in the branches and on the "
            "trunk of trees.",
            "It is found up in the trees, not on the open ground.",
            "A terrestrial ecosystem is found on the land surface - on the ground, as in a forest or a "
            "grassland.",
            "An arboreal ecosystem is really a special part of a terrestrial one: the same trees, but "
            "the community being studied is the one living up in them."],
    "1 mark each for any THREE correct points (3 marks). The key idea is that an arboreal ecosystem is "
    "found IN TREES. Award at least 1 mark for 'it is found in trees'."),
 ],
 3: [
   ("(a)", ["(i) abiotic", "(ii) biotic", "(iii) abiotic", "(iv) biotic", "(v) abiotic",
            "(vi) biotic"],
    "1 mark each for all SIX blanks correctly filled (6 marks). The blank number must be matched to "
    "the correct answer. Accept 'living' for biotic and 'non-living' for abiotic."),
   ("(b)", ["The temperature of the water", "The depth of the water", "The soil or mud at the bottom",
            "Rainfall", "Mineral salts dissolved in the water", "The pH of the water",
            "The amount of light reaching the water", "The wind"],
    "1 mark each for any TWO correct abiotic components not already listed in the table (2 marks). Do "
    "NOT accept 'water', 'sunlight' or 'oxygen', because those are already in the table."),
   ("(c)", ["A biotic component is a living component: the plants, the animals and the decay "
            "organisms.",
            "An abiotic component is a non-living component: the water, air, sunlight, temperature, "
            "soil and mineral salts.",
            "The biotic components are the living things; the abiotic components are the physical and "
            "chemical surroundings they live in."],
    "1 mark each for any TWO correct points (2 marks). Award 1 mark for 'biotic = living, abiotic = "
    "non-living' if it is not developed further."),
 ],
 4: [
   ("(a)", ["One living thing feeds on another (feeding), e.g. a goat eating grass.",
            "Animals carry pollen from flower to flower, so the plants can make seeds.",
            "Animals carry seeds to new places and spread them in their droppings.",
            "Animals provide shelter for one another, e.g. birds nesting in trees.",
            "Decay organisms break down dead plants and animals and return nutrients to the soil.",
            "Large animals trample or browse plants and so change what grows where.",
            "Living things compete with one another for food, water, light and space."],
    "1 mark each for any THREE correct points (3 marks). Each point must say how one LIVING thing "
    "affects another. Do NOT accept 'the rain waters the plants' here - that is abiotic affecting "
    "biotic."),
   ("(b)", ["Sunlight allows the water plants to make their food, and warms the water.",
            "The temperature of the water affects how much oxygen dissolves in it and how fast the "
            "organisms grow.",
            "Oxygen dissolved in the water is what the fish and other water animals breathe.",
            "The water itself is the home and the support of the organisms in the pond.",
            "Mineral salts in the water and in the mud feed the water plants.",
            "In the dry season the water level falls, so the organisms are crowded into less space "
            "and there is less oxygen."],
    "1 mark each for any THREE correct points (3 marks). The answer must link a named ABIOTIC "
    "component to its effect on a living thing."),
   ("(c)", ["Plants take in carbon dioxide and give out oxygen, so they change the air around them.",
            "Plants and animals add humus to the soil when they die and decay.",
            "Tree roots break up rocks, hold the soil together and stop it being washed away.",
            "Plants slow down the wind and shade the ground, so the soil stays cooler and moister.",
            "Plants take water from the soil and give it out through their leaves, which adds "
            "moisture to the air.",
            "Animals tread on the soil and their droppings add nutrients to it."],
    "1 mark each for any THREE correct points (3 marks). The answer must show a LIVING thing changing "
    "a NON-LIVING part. Award at least 1 mark for an example such as 'plants give out oxygen' or "
    "'roots hold the soil'."),
 ],
 5: [
   ("(a)", ["Interdependence means that the organisms in an ecosystem depend on one another to stay "
            "alive.",
            "Each organism needs something that another organism provides: food, shelter, pollination "
            "or seed dispersal.",
            "It also means that what happens to one organism affects the others.",
            "Because of interdependence, the removal of one kind of organism can harm many others."],
    "1 mark each for any THREE correct points (3 marks). The key word is DEPEND. Accept 'they rely on "
    "each other'."),
   ("(b)", ["Animals depend on plants for food and for the oxygen they breathe.",
            "Plants depend on animals for the carbon dioxide they use to make food.",
            "Many plants depend on insects and other animals to carry pollen so they can make seeds.",
            "Many plants depend on animals to carry their seeds to new places.",
            "Animals depend on plants for shelter and for places to build nests.",
            "Plants depend on decay organisms, helped by animals, to return nutrients to the soil."],
    "1 mark each for any TWO correct points (2 marks). Each point must show dependence in BOTH "
    "directions, or at least be clearly about plants and animals depending on each other."),
   ("(c)", ["Any sensible Ghanaian food chain, e.g. maize -> grasshopper -> lizard -> hawk; or grass "
            "-> goat -> human; or leaves -> caterpillar -> hen -> human.",
            "The chain must start with a green plant (the producer) and the arrows must point in the "
            "direction the food passes.",
            "If one link is removed, the organisms that feed on it lose their food and their numbers "
            "fall.",
            "The organisms that the removed link used to feed on may increase in number because "
            "nothing is eating them.",
            "So the balance of the whole ecosystem is disturbed, not just one link."],
    "1 mark for a correct food chain and 1 mark each for any TWO correct effects of removing a link "
    "(3 marks). The chain must begin with a plant. Award at least 1 mark for 'the animals that eat it "
    "lose their food'."),
 ],
 6: [
   ("(a)", ["The animals that feed on the insects, such as lizards, birds and frogs, lose their food "
            "and may move away or become fewer.",
            "The flowers that needed the insects for pollination are not pollinated, so they produce "
            "fewer seeds and fruits.",
            "With fewer insects to eat the pests, the pest insects may come back in larger numbers "
            "later.",
            "The maize may at first look better, but the yield may fall because there is less "
            "pollination.",
            "The insecticide may also wash into the soil and the water and harm other organisms.",
            "The birds and other animals that eat the poisoned insects may be poisoned too."],
    "1 mark each for any THREE correct points (3 marks). Accept any sensible consequence. Do NOT "
    "accept 'the maize grows better' on its own."),
   ("(b)", ["Because the organisms in an ecosystem are interdependent: each one depends on the others "
            "for food, pollination and other needs.",
            "So whatever happens to the insects passes along the food chain to the animals that eat "
            "them, and then to the animals that eat those.",
            "It also affects the plants, because many of them need insects for pollination.",
            "Nothing in an ecosystem lives on its own, so no effect stops with the organism it "
            "started with."],
    "1 mark each for any THREE correct points (3 marks). The key word is INTERDEPENDENCE, or the idea "
    "of a chain reaction along the food chain. Award at least 1 mark for 'everything depends on "
    "everything else'."),
   ("(c)", ["Plant different crops together or in rotation, so that no one pest builds up.",
            "Use a mild, local method such as neem extract or wood ash instead of a strong chemical.",
            "Leave a strip of the farm uncultivated so that useful insects and birds have somewhere "
            "to live.",
            "Spray only in the evening, when the bees and other useful insects are not flying.",
            "Spray only when it is necessary, and only the part of the farm that is affected.",
            "Hand-pick the pests, or encourage birds and lizards that eat them.",
            "Add compost or manure so that the crops are strong enough to resist attack."],
    "1 mark each for any TWO sensible suggestions (2 marks). Award method marks: any suggestion that "
    "would really reduce the harm earns credit. Do NOT accept 'stop farming'."),
 ],
 7: [
   ("(a)", ["Choose one ecosystem near the school, e.g. a pond, a stream, a patch of bush or one large "
            "tree.",
            "Visit it more than once, at the same time of day, and observe quietly.",
            "Note the ABIOTIC components: the soil, the water, the temperature, the light, the "
            "rainfall.",
            "List the BIOTIC components: the plants, the animals and any decay organisms seen.",
            "Record where each organism was found and, where possible, what it was doing.",
            "Draw or photograph the ecosystem and label what is in it.",
            "Record the information in a table with two columns, biotic and abiotic.",
            "Note any sign of interaction, e.g. a bee on a flower, a caterpillar eating a leaf, a bird "
            "in a branch.",
            "Work in groups, compare notes afterwards and write a short report."],
    "1 mark each for any FOUR correct points (4 marks). This is a design task: award method marks for "
    "any sensible step. The three things to look for first are: choosing and visiting a real "
    "ecosystem, recording both biotic and abiotic components, and noting interactions."),
   ("(b)", ["It shows the class that the living and non-living parts really do interact, not just in "
            "a book.",
            "It makes the class notice how the organisms depend on one another.",
            "It helps the class to see what happens when people damage an ecosystem.",
            "Working together on it helps everyone in the group to join in.",
            "To avoid harm: do not pick the flowers or break the branches.",
            "To avoid harm: put back any stone, log or leaf that is turned over.",
            "To avoid harm: do not take animals home and do not leave litter behind.",
            "To avoid harm: keep to the paths and do not trample the plants or pollute the water."],
    "1 mark each for any TWO sensible reasons and 1 mark for a sensible precaution (3 marks). Accept "
    "any reason that shows the study added something a book cannot. Do NOT accept 'it is fun' on its "
    "own."),
 ],
}


# --------------------------------------------- derive summary statistics
def topic_totals():
    m = {k: 0 for k in TOPIC}
    it = {k: 0 for k in TOPIC}
    for q in MCQ:
        m[q[3]] += 1
        it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk
            it[key] += 1
    return m, it


def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}
    b = {k: 0 for k in order}
    for q in MCQ:
        a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            b[cog] += mk
    return order, a, b


def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ:
        d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            d[diff] += mk
    return d
