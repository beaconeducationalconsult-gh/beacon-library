# -*- coding: utf-8 -*-
"""Basic 7 Integrated Science mock - Strand 4 Sub-strand 1: ENERGY. 100 marks.
Indicators sourced from the official NaCCA Science CCP curriculum (B7/JHS1-B9/JHS3, Sept 2020),
Strand 4: Forces and Energy, Sub-strand 1: Energy, printed pages 26-29."""

SCHOOL = "[SCHOOL NAME]"
SUBJECT = "INTEGRATED SCIENCE (SCIENCE)"
EXAM = "END-OF-TERM MOCK EXAMINATION"
CLASS = "Basic 7 (JHS 1)"
TIME = "2 hours (Suggested: Section A - 40 min; Section B - 80 min)"
MARKS = "100"
YEAR = "2025/2026 Academic Year"

STRAND = "Forces and Energy"
SUBSTRAND = "Energy"

TOPIC = {
    "11.1": "11.1 What is Energy?",
    "11.2": "11.2 Forms of Energy",
    "11.3": "11.3 Potential and Kinetic Energy",
    "11.4": "11.4 Calculating PE and KE",
    "11.5": "11.5 Daily Applications of Energy",
    "11.6": "11.6 Heat Transfer",
    "11.7": "11.7 Characteristics of Light",
}

CS = "B7/JHS1.4.1.1 / B7/JHS1.4.1.2 / B7/JHS1.4.1.3"
CS_BY_TOPIC = {
    "11.1": "B7/JHS1.4.1.1", "11.2": "B7/JHS1.4.1.1", "11.3": "B7/JHS1.4.1.1",
    "11.4": "B7/JHS1.4.1.1", "11.5": "B7/JHS1.4.1.1",
    "11.6": "B7/JHS1.4.1.2", "11.7": "B7/JHS1.4.1.3",
}
CS_TEXT = ("Demonstrate an understanding of forms of energy and their daily applications; "
           "demonstrate an understanding of the concept of heat transfer and its applications in "
           "life; demonstrate understanding of characteristics of light, such as travelling in a "
           "straight line, reflection, refraction and dispersion")

IND = {
    "11.1": "B7/JHS1.4.1.1.1 (Ex. 1)",
    "11.2": "B7/JHS1.4.1.1.1 (Ex. 1)",
    "11.3": "B7/JHS1.4.1.1.1 (Ex. 2)",
    "11.4": "B7/JHS1.4.1.1.2 (Ex. 4)",
    "11.5": "B7/JHS1.4.1.1.2 (Ex. 1, 2, 3)",
    "11.6": "B7/JHS1.4.1.2.1 (Ex. 1, 2)",
    "11.7": "B7/JHS1.4.1.3.1 (Ex. 1, 2)",
}
IND_TEXT = {
    "11.1": "Identify the various forms of energy and show how they are related. Ex. 1: List forms "
            "of energy in terms of Potential, Kinetic, Heat, Sound, Solar, Electrical, Nuclear, "
            "Chemical and Light.",
    "11.2": "Identify the various forms of energy and show how they are related. Ex. 1: List forms "
            "of energy in terms of Potential, Kinetic, Heat, Sound, Solar, Electrical, Nuclear, "
            "Chemical and Light.",
    "11.3": "Identify the various forms of energy and show how they are related. Ex. 2: Demonstrate "
            "and show by diagrams how Potential Energy (PE) is related to Kinetic Energy (KE); "
            "Mechanical Energy = PE + KE.",
    "11.4": "Explain daily applications of forms of energy. Ex. 4: Use mathematical expressions for "
            "both Potential energy (PE = mgh) and Kinetic energy (KE = 1/2 mv2) and use the "
            "expressions to solve problems involving mechanical energy.",
    "11.5": "Explain daily applications of forms of energy. Ex. 1-3: Discuss how forms of energy "
            "are used in daily life; match forms of energy to appliances used daily at school, in "
            "the home and community; explain factors that affect Potential and Kinetic energy in "
            "their application in daily life.",
    "11.6": "Explain and demonstrate how heat is transferred in various media. Ex. 1, 2: Explain how "
            "heat is transferred through different media (gas, plastic, metal, liquid); carry out an "
            "activity to show how heat is transferred through different media.",
    "11.7": "Demonstrate how light travels in a straight line. Ex. 1, 2: Perform experiments to show "
            "that light travels in a straight line and can be reflected and refracted; perform an "
            "experiment to show dispersion of light into colours.",
}
CC = {
    "11.1": "DL, CC, CG", "11.2": "DL, CC, CG", "11.3": "DL, CC, CG",
    "11.4": "DL, CC, CG, CI", "11.5": "DL, CC, CG, CI",
    "11.6": "DL, CC, CI", "11.7": "DL, CC, CP, CI",
}

# ---------------------------------------------------------------- SECTION A
# (question, [A,B,C,D], answer, topic, cognitive, difficulty)
MCQ = [
 ("Energy may be defined as",
  ["the ability to do work", "the force that pulls things down to the ground",
   "the size of an object", "the speed of a moving body"],
  "A", "11.1", "Understand", "Easy"),
 ("The SI unit of energy is the",
  ["watt", "newton", "joule", "metre"], "C", "11.1", "Remember", "Easy"),
 ("A boy holds a bag of maize above his head without moving. The bag has",
  ["kinetic energy", "potential energy", "no energy at all", "sound energy"],
  "B", "11.1", "Understand", "Easy"),
 ("Which of these is NOT a form of energy?",
  ["heat", "light", "force", "sound"], "C", "11.1", "Understand", "Moderate"),
 ("Energy is measured in",
  ["joules", "newtons", "kilograms", "metres per second"], "A", "11.1", "Remember", "Moderate"),
 ("An object that is standing still can still have energy because",
  ["it is very heavy", "it may have stored energy waiting to be used", "it is resting on the ground",
   "it was made in a factory"],
  "B", "11.1", "Understand", "Challenging"),

 ("Which of these is NOT one of the forms of energy listed in the Basic 7 curriculum?",
  ["nuclear energy", "chemical energy", "magnetic energy", "solar energy"],
  "C", "11.2", "Remember", "Moderate"),
 ("The energy stored in food, in fuel and in a dry cell is",
  ["chemical energy", "solar energy", "nuclear energy", "light energy"],
  "A", "11.2", "Remember", "Easy"),
 ("The form of energy that comes from the sun is called",
  ["heat energy", "nuclear energy", "chemical energy", "solar energy"],
  "D", "11.2", "Remember", "Moderate"),
 ("A rubber band that has been stretched and is waiting to be released has",
  ["sound energy", "potential energy", "heat energy", "electrical energy"],
  "B", "11.2", "Understand", "Moderate"),
 ("The form of energy that enables us to see is",
  ["heat energy", "sound energy", "light energy", "nuclear energy"],
  "C", "11.2", "Remember", "Easy"),

 ("As a stone falls from a height towards the ground, its potential energy",
  ["increases", "decreases and changes into kinetic energy", "stays the same",
   "disappears completely"],
  "B", "11.3", "Understand", "Moderate"),
 ("Mechanical energy is equal to",
  ["PE + KE", "PE - KE", "PE x KE", "KE divided by PE"], "A", "11.3", "Remember", "Easy"),
 ("A ball is thrown straight up into the air. At the very top of its flight",
  ["its kinetic energy is greatest and its potential energy is zero",
   "both its potential energy and its kinetic energy are zero",
   "its potential energy is greatest and its kinetic energy is least",
   "both its potential energy and its kinetic energy are greatest"],
  "C", "11.3", "Analyse", "Challenging"),
 ("A boy is swinging. At the lowest point of the swing his energy is mostly",
  ["potential energy", "chemical energy", "nuclear energy", "kinetic energy"],
  "D", "11.3", "Understand", "Easy"),
 ("Water is stored behind the Akosombo Dam. Before the water is released it has mainly",
  ["potential energy", "kinetic energy", "sound energy", "electrical energy"],
  "A", "11.3", "Apply", "Challenging"),

 ("The expression used to calculate potential energy is",
  ["PE = 1/2 mv2", "PE = mg divided by h", "PE = mgh", "PE = m2gh"],
  "C", "11.4", "Remember", "Moderate"),
 ("The expression used to calculate kinetic energy is",
  ["KE = mgh", "KE = 1/2 mv2", "KE = mv2", "KE = 1/2 mgh"], "B", "11.4", "Remember", "Moderate"),
 ("A boy of mass 40 kg stands on top of a table 2 m high. Taking g as 10 m/s2, his potential "
  "energy is",
  ["80 J", "400 J", "800 J", "1600 J"], "C", "11.4", "Apply", "Moderate"),
 ("A ball of mass 2 kg moves at 4 m/s. Its kinetic energy is",
  ["8 J", "4 J", "32 J", "16 J"], "D", "11.4", "Apply", "Challenging"),
 ("In the expression PE = mgh, the letter g stands for",
  ["the acceleration due to gravity", "the mass of the object", "the height of the object",
   "the energy of the object"],
  "A", "11.4", "Understand", "Challenging"),

 ("A pressing iron works mainly by using",
  ["electrical energy", "solar energy", "nuclear energy", "chemical energy"],
  "A", "11.5", "Understand", "Easy"),
 ("A kerosene lantern gives light. The energy that is stored in the kerosene is",
  ["heat energy", "electrical energy", "chemical energy", "light energy"],
  "C", "11.5", "Understand", "Moderate"),
 ("A solar calculator uses",
  ["chemical energy", "nuclear energy", "sound energy", "solar energy"],
  "D", "11.5", "Remember", "Moderate"),
 ("A woman cooks soup on a charcoal pot. The energy used comes from",
  ["the sun", "the chemical energy stored in the charcoal", "the air around the pot",
   "the water in the soup"],
  "B", "11.5", "Understand", "Moderate"),
 ("Two identical bags of rice are in the same room, one on the floor and one on a high shelf. The "
  "bag with the greater potential energy is the one",
  ["on the floor", "neither, because they are the same size", "on the high shelf",
   "whichever bag is heavier"],
  "C", "11.5", "Apply", "Moderate"),
 ("A tro-tro and a bicycle are moving along the same road at the same speed. Which has more "
  "kinetic energy?",
  ["the bicycle, because it is lighter", "the tro-tro, because it has a bigger mass",
   "both have the same kinetic energy", "neither, because neither one is falling"],
  "B", "11.5", "Apply", "Challenging"),
 ("A radio changes electrical energy mainly into",
  ["light energy", "chemical energy", "heat energy", "sound energy"],
  "D", "11.5", "Understand", "Moderate"),

 ("Heat travelling along a metal rod from the hot end to the cold end is",
  ["conduction", "convection", "radiation", "dispersion"], "A", "11.6", "Remember", "Easy"),
 ("Heat carried through a liquid or a gas by the movement of the liquid or gas itself is",
  ["conduction", "convection", "radiation", "reflection"], "B", "11.6", "Remember", "Moderate"),
 ("Heat from the sun reaches the earth by",
  ["radiation", "conduction only", "convection only", "dispersion"],
  "A", "11.6", "Remember", "Easy"),
 ("Which of these is the best conductor of heat?",
  ["a wooden spoon", "a plastic cup", "a piece of cloth", "an aluminium cooking pot"],
  "D", "11.6", "Understand", "Moderate"),
 ("The handle of a cooking pot is often made of plastic or wood because these materials",
  ["are good conductors of heat", "are poor conductors of heat, so they do not burn the hand",
   "make the pot much lighter", "are the cheapest materials to buy"],
  "B", "11.6", "Understand", "Moderate"),
 ("Warm air in a room rises above cooler air because the warm air",
  ["is heavier than the cold air", "is pushed down by the ceiling", "contains more dust",
   "expands, becomes less dense and is pushed up by the cooler, denser air"],
  "D", "11.6", "Understand", "Challenging"),

 ("Light travels",
  ["in straight lines", "in curved lines", "in circles", "only through air"],
  "A", "11.7", "Remember", "Easy"),
 ("The bouncing back of light from a shiny surface is called",
  ["refraction", "dispersion", "reflection", "conduction"], "C", "11.7", "Remember", "Moderate"),
 ("The bending of light as it passes from air into water is called",
  ["dispersion", "reflection", "radiation", "refraction"], "D", "11.7", "Remember", "Moderate"),
 ("A pencil standing in a glass of water looks broken at the water surface. This happens because "
  "the light is",
  ["reflected", "dispersed", "absorbed", "refracted"], "D", "11.7", "Apply", "Moderate"),
 ("The splitting of white light into seven colours is called",
  ["reflection", "refraction", "radiation", "dispersion"], "D", "11.7", "Apply", "Challenging"),
 ("A pupil sees her own face in a clean mirror. This happens because light is",
  ["refracted by the mirror", "reflected by the mirror", "absorbed by the mirror",
   "dispersed by the mirror"],
  "B", "11.7", "Apply", "Challenging"),
]

# ---------------------------------------------------- SECTION B TABLE (Q2)
EN_HEADERS = ["Form of energy", "What it is / where it is found", "One example in daily life"]
EN_ROWS = [
 ["Potential", "(i)", "water stored in a tank on top of a storey building"],
 ["Kinetic", "(ii)", "a tro-tro moving along the Accra-Kumasi road"],
 ["Heat", "the energy that makes things warm or hot", "(iii)"],
 ["Sound", "(iv)", "a bell ringing to end lessons"],
 ["Solar", "(v)", "a solar panel on the roof of a house"],
 ["Chemical", "(vi)", "the kerosene in a lantern"],
 ["Light", "the energy that enables us to see", "a torch shining at night"],
]

# ---------------------------------------------------------------- SECTION B
SECTION_B = [
 dict(
   num=1, total=8, topic="11.1",
   stem="Your class has been asked to explain what energy is and to give examples of things that "
        "cannot happen without it.",
   parts=[
     ("(a)", "Explain what is meant by energy and state its SI unit.",
      2, "Understand", "11.1", "Easy"),
     ("(b)", "Name three things in your school or home that cannot happen without energy.",
      3, "Remember", "11.1", "Easy"),
     ("(c)", "A classmate says that the water in a tank on top of a two-storey building has no "
             "energy because the water is not moving. Do you agree? Give two reasons for your "
             "answer.", 3, "Evaluate", "11.1", "Moderate"),
   ]),
 dict(
   num=2, total=10, topic="11.2",
   stem="The Basic 7 curriculum lists nine forms of energy. Study the incomplete table below and "
        "answer the questions that follow.",
   table="energy",
   parts=[
     ("(a)", "Copy and complete the table.", 6, "Understand", "11.2", "Moderate"),
     ("(b)", "Name the two forms of energy from the Basic 7 list that are NOT shown in the table.",
      2, "Remember", "11.2", "Moderate"),
     ("(c)", "State one use of each of those two forms of energy in daily life.",
      2, "Understand", "11.2", "Easy"),
   ]),
 dict(
   num=3, total=9, topic="11.3",
   stem="A stone is held at the top of a two-storey building and then released.",
   parts=[
     ("(a)", "Explain what is meant by potential energy and by kinetic energy.",
      3, "Understand", "11.3", "Easy"),
     ("(b)", "Describe what happens to the potential energy and to the kinetic energy of the stone "
             "as it falls from the top of the building to the ground.",
      3, "Analyse", "11.3", "Moderate"),
     ("(c)", "State what is meant by mechanical energy and write the relationship between "
             "mechanical energy, potential energy and kinetic energy.",
      3, "Understand", "11.3", "Moderate"),
   ]),
 dict(
   num=4, total=9, topic="11.4",
   stem="Work out the following. Take g as 10 m/s2. Show your working in your answer booklet.",
   parts=[
     ("(a)", "A boy of mass 40 kg stands on top of a table 2 m high. Calculate his potential "
             "energy.", 3, "Apply", "11.4", "Moderate"),
     ("(b)", "A ball of mass 0.5 kg moves at 20 m/s. Calculate its kinetic energy.",
      3, "Apply", "11.4", "Moderate"),
     ("(c)", "A stone of mass 3 kg is lifted to a height of 4 m and then released. "
             "(i) Calculate its potential energy at the top. "
             "(ii) State its kinetic energy just before it hits the ground, and give a reason for "
             "your answer.", 3, "Apply", "11.4", "Challenging"),
   ]),
 dict(
   num=5, total=8, topic="11.5",
   stem="Forms of energy are used every day at school, in the home and in the community.",
   parts=[
     ("(a)", "Name the form of energy each of the following uses to work: "
             "(i) a pressing iron; (ii) a radio; (iii) a solar calculator; (iv) a kerosene lamp.",
      4, "Understand", "11.5", "Moderate"),
     ("(b)", "State one way in which heat energy is useful in the home and one way in which sound "
             "energy is useful at school.", 2, "Understand", "11.5", "Easy"),
     ("(c)", "A farmer spreads maize on a mat to dry in the sun. Name the form of energy being "
             "used and give one reason why this method is better than drying the maize over a "
             "fire.", 2, "Understand", "11.5", "Easy"),
   ]),
 dict(
   num=6, total=8, topic="11.6",
   stem="Heat can be transferred from one place to another in three different ways.",
   parts=[
     ("(a)", "Name the three ways in which heat is transferred and say what moves in each one.",
      3, "Understand", "11.6", "Easy"),
     ("(b)", "Plan an activity your class could carry out to show that heat travels along a metal "
             "rod by conduction. Say what you would use and what you would see.",
      3, "Create", "11.6", "Challenging"),
     ("(c)", "A car parked in the sun at Madina becomes very hot inside. Name the method by which "
             "the sun's heat reaches the car, and explain why the inside of the car gets hotter "
             "than the air outside.", 2, "Analyse", "11.6", "Challenging"),
   ]),
 dict(
   num=7, total=8, topic="11.7",
   stem="Your class is studying the characteristics of light.",
   parts=[
     ("(a)", "Describe an activity you would carry out to show that light travels in a straight "
             "line.", 3, "Apply", "11.7", "Moderate"),
     ("(b)", "Explain what is meant by reflection of light and by refraction of light.",
      2, "Understand", "11.7", "Easy"),
     ("(c)", "Explain how the seven colours of the rainbow are formed, naming the process "
             "involved.", 3, "Understand", "11.7", "Challenging"),
   ]),
]

# ------------------------------------------------------- MARKING SCHEME
MARKING = {
 1: [
   ("(a)", ["Energy is the ability to do work.",
            "Energy is what makes it possible for things to move, to heat up or to change.",
            "The SI unit of energy is the joule (J)."],
    "1 mark for a correct explanation of energy and 1 mark for the unit, the joule (2 marks). "
    "Accept 'the ability to do work' or any correct statement that energy makes things happen. Do "
    "NOT accept 'energy is power'. Accept 'J' or 'joule', but NOT 'watt' or 'newton'."),
   ("(b)", ["Lighting a classroom or a room with a bulb needs electrical energy.",
            "Cooking food needs heat energy from fire, gas or electricity.",
            "A bell ringing to end lessons needs electrical and sound energy.",
            "A car or a tro-tro moving needs chemical energy from fuel.",
            "A radio or a television playing needs electrical energy.",
            "Ironing a school uniform needs heat energy.",
            "Playing football or walking needs energy from the food eaten.",
            "Charging a phone needs electrical energy."],
    "1 mark each for any THREE correct things that need energy (3 marks). The pupil must name the "
    "thing AND the energy it needs. Do NOT accept 'sleeping' or 'sitting'."),
   ("(c)", ["No, I do not agree - the water has energy.",
            "The water has potential energy because it is high above the ground.",
            "Height gives an object potential energy; it does not have to be moving.",
            "If the tap were opened, the stored energy would change into kinetic energy as the "
            "water fell.",
            "The water could do work - it could push a turbine round or push water out of a tap - "
            "so it has energy."],
    "1 mark for a clear 'no' / disagreeing, and 1 mark each for any TWO correct reasons (3 marks). "
    "The key ideas are: it is high up, so it has stored (potential) energy; and it could do work "
    "if it were allowed to fall. Award 1 mark only if the pupil says 'it has energy' with no "
    "reason."),
 ],
 2: [
   ("(a)", ["(i) the energy a body has because of its position or height, or because it is "
            "stretched - it is stored energy",
            "(ii) the energy a body has because it is moving - movement energy",
            "(iii) a charcoal pot; a pressing iron; a hot pressing comb; fire burning",
            "(iv) the energy that travels through the air and makes our ears hear; the energy of "
            "vibrations we can hear",
            "(v) energy that comes from the sun",
            "(vi) energy stored in food, in fuel such as kerosene or charcoal, and in dry cells "
            "and batteries"],
    "1 mark each for any SIX correct entries (6 marks). The blank number must be matched to the "
    "answer. For (i) the key word is 'stored' or 'position'; for (ii) the key word is 'moving'. "
    "For (iii) accept any correct daily example of heat energy. For (iv) accept 'energy that makes "
    "us hear'. For (v) the key word is 'sun'. For (vi) the key words are 'stored in food, fuel or "
    "cells'."),
   ("(b)", ["Electrical energy", "Nuclear energy"],
    "1 mark each for BOTH correct forms (2 marks). No marks for one alone. Do NOT accept 'magnetic "
    "energy', 'wind energy' or 'wind' - those are not on the Basic 7 list."),
   ("(c)", ["Electrical energy is used to light the home, to run a fridge, to iron clothes or to "
            "power a radio.",
            "Nuclear energy is used in a nuclear power station to generate electricity.",
            "Nuclear energy is used in medicine, for example in X-rays or in treating some "
            "illnesses."],
    "1 mark each for one correct daily use of EACH form (2 marks). One of the two must be a use of "
    "nuclear energy to earn the second mark. Accept any sensible use."),
 ],
 3: [
   ("(a)", ["Potential energy is the energy a body has because of its position or height, or "
            "because it is stretched.",
            "Kinetic energy is the energy a body has because it is moving.",
            "Potential energy is stored energy; kinetic energy is movement energy."],
    "1 mark each for any THREE correct points (3 marks). At least ONE point must define POTENTIAL "
    "energy and at least ONE must define KINETIC energy; award at most 2 marks if the pupil only "
    "describes one of the two."),
   ("(b)", ["At the top the stone has its greatest potential energy and hardly any kinetic energy, "
            "because it is not yet moving.",
            "As it falls, the potential energy decreases because the height is decreasing.",
            "The potential energy is not lost - it changes into kinetic energy as the stone "
            "speeds up.",
            "Just before it hits the ground the potential energy is almost zero and the kinetic "
            "energy is at its greatest.",
            "The total (mechanical) energy stays the same all the way down."],
    "1 mark each for any THREE correct points (3 marks). The essential idea is that PE is "
    "CONVERTED into KE, not lost. Award at most 2 marks if the pupil says the PE 'disappears' or "
    "'finishes'."),
   ("(c)", ["Mechanical energy is the total energy a body has because of its position and its "
            "motion.",
            "Mechanical Energy = Potential Energy + Kinetic Energy.",
            "ME = PE + KE."],
    "1 mark each for any THREE correct points (3 marks). The formula ME = PE + KE must be given "
    "for full marks. Accept 'mechanical energy is the sum of the potential and the kinetic "
    "energy'."),
 ],
 4: [
   ("(a)", ["PE = mgh", "PE = 40 x 10 x 2", "PE = 800 J"],
    "1 mark for writing the formula PE = mgh, 1 mark for the correct substitution "
    "(40 x 10 x 2) and 1 mark for the answer 800 J (3 marks). Award the substitution and answer "
    "marks even if the formula is not written, provided the working is shown. Allow the method "
    "mark if the arithmetic is wrong but the substitution is right."),
   ("(b)", ["KE = 1/2 mv2", "KE = 1/2 x 0.5 x 20 x 20", "KE = 1/2 x 0.5 x 400", "KE = 100 J"],
    "1 mark for writing the formula KE = 1/2 mv2, 1 mark for the correct substitution "
    "(1/2 x 0.5 x 20 x 20 or 1/2 x 0.5 x 400) and 1 mark for the answer 100 J (3 marks). The "
    "commonest error is forgetting to square the 20 - award the formula mark only in that case."),
   ("(c)", ["(i) PE = mgh = 3 x 10 x 4 = 120 J",
            "(ii) The kinetic energy just before it hits the ground is also 120 J.",
            "This is because all the potential energy at the top changes into kinetic energy as "
            "the stone falls, so no energy is lost."],
    "2 marks for the correct calculation PE = 3 x 10 x 4 = 120 J (1 mark for the method, 1 mark "
    "for the answer) and 1 mark for stating that the KE is also 120 J with the reason that all "
    "the PE has changed into KE (3 marks). Accept 'the same as the PE at the top'."),
 ],
 5: [
   ("(a)", ["(i) a pressing iron - electrical energy", "(ii) a radio - electrical energy",
            "(iii) a solar calculator - solar (light) energy from the sun",
            "(iv) a kerosene lamp - chemical energy stored in the kerosene"],
    "1 mark each for all FOUR correct forms of energy (4 marks). For (iii) accept 'solar energy' "
    "or 'light energy'. For (iv) accept 'chemical energy'; do NOT accept 'light energy' alone, "
    "because the question asks for the form of energy the lamp USES."),
   ("(b)", ["Heat energy is used at home to cook food, to iron clothes, to boil water or to warm "
            "bath water.",
            "Sound energy is used at school when the bell is rung to end lessons, or when the "
            "teacher speaks and the pupils hear.",
            "Sound energy is used at school in a public address system or in an assembly."],
    "1 mark each for one correct use of HEAT energy in the home and one correct use of SOUND "
    "energy at school (2 marks). One mark is for heat and one for sound; if both answers are about "
    "the same form, award only 1 mark."),
   ("(c)", ["The form of energy used is solar energy (energy from the sun).",
            "It costs nothing, because the sun is free.",
            "It does not smoke the maize or give it a smoky taste the way a fire does.",
            "It is safer, because there is no open flame that could start a fire.",
            "A large amount of maize can be dried at one time on the mat."],
    "1 mark for naming solar energy and 1 mark for any ONE correct reason (2 marks). Accept 'heat "
    "energy from the sun'. Do NOT accept 'it is faster'."),
 ],
 6: [
   ("(a)", ["Conduction - heat passes through a solid from particle to particle; the particles "
            "vibrate but do not move from place to place.",
            "Convection - heat is carried through a liquid or a gas by the liquid or the gas "
            "itself moving.",
            "Radiation - heat travels as waves and needs no material at all; it can cross empty "
            "space."],
    "1 mark each for all THREE correct methods (3 marks). One mark is for naming each method; "
    "if the pupil names the methods correctly but does not say what moves, award 2 marks in all."),
   ("(b)", ["Fix one end of a metal rod (or a long iron nail / a metal spoon) in a flame or put it "
            "in hot water and hold the other end.",
            "Stick drawing pins or candle wax / margarine along the rod at equal distances.",
            "Watch the far end of the rod - after a short time it also becomes hot and the pins "
            "drop off one after another, starting from the hot end.",
            "The heat has travelled along the metal from the hot end to the cold end, which shows "
            "conduction.",
            "Repeat with a wooden stick or a plastic rod as a control - the far end stays cool."],
    "1 mark for a sensible set-up, 1 mark for what would be seen / measured and 1 mark for the "
    "conclusion that heat travels along the metal (3 marks). This is a design task: award method "
    "marks for any workable plan that is clearly described."),
   ("(c)", ["The method is radiation.",
            "The sun's heat reaches the car as radiation, crossing the air and the glass without "
            "heating the air much on the way.",
            "The glass and the seats absorb the radiation and become hot, and they then warm the "
            "air inside.",
            "The warm air cannot escape from the closed car, so the heat is trapped and the inside "
            "gets hotter and hotter."],
    "1 mark for naming radiation and 1 mark for any ONE correct reason (2 marks). The key point is "
    "that radiation needs no material and that the heat is then trapped inside the car."),
 ],
 7: [
   ("(a)", ["Take three pieces of cardboard and make a small hole in the middle of each one.",
            "Stand the three cards in a straight line so that the three holes are in line with one "
            "another.",
            "Put a lit candle or a torch behind the first card and look through the third hole.",
            "The flame can be seen only when all three holes are in one straight line.",
            "Move one card sideways and the flame can no longer be seen - this shows that light "
            "cannot bend round the corner, so it travels in a straight line."],
    "1 mark for a sensible set-up, 1 mark for what would be seen and 1 mark for the conclusion "
    "(3 marks). Accept any correct straight-line demonstration, for example looking along the edge "
    "of a ruler or using a long straight pipe. Award method marks for a workable plan."),
   ("(b)", ["Reflection is the bouncing back of light when it falls on a shiny or polished "
            "surface, such as a mirror.",
            "Refraction is the bending of light as it passes from one material into another, for "
            "example from air into water or from air into glass."],
    "1 mark each for a correct explanation of reflection and of refraction (2 marks). The key word "
    "for reflection is 'bouncing back' and for refraction is 'bending'. Do NOT accept the two "
    "definitions swapped."),
   ("(c)", ["The process is called dispersion.",
            "Sunlight (white light) is made up of seven colours mixed together.",
            "When white light passes into a raindrop it is refracted (bent) and each colour bends "
            "by a different amount.",
            "The colours therefore separate out and come out of the drop travelling in slightly "
            "different directions.",
            "The seven colours - red, orange, yellow, green, blue, indigo and violet - appear as a "
            "rainbow."],
    "1 mark for naming dispersion and 1 mark each for any TWO correct points (3 marks). The idea to "
    "look for is that white light is a mixture of colours which are separated. Accept the "
    "explanation in terms of a glass prism instead of raindrops."),
 ],
}


# --------------------------------------------- derive summary statistics
def topic_totals():
    m = {k: 0 for k in TOPIC}
    it = {k: 0 for k in TOPIC}
    for q in MCQ:
        m[q[3]] += 1
        it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk
            it[key] += 1
    return m, it


def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}
    b = {k: 0 for k in order}
    for q in MCQ:
        a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            b[cog] += mk
    return order, a, b


def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ:
        d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            d[diff] += mk
    return d
