# -*- coding: utf-8 -*-
"""Basic 7 Integrated Science mock - Strand 5 Sub-strand 2: HUMAN HEALTH, part 2 of 2.
Covers topics 17.4 to 17.7 (the nature of viral diseases; COVID-19; Ebola and H1N1; and the
roles of individuals, communities and government in managing viral diseases). 100 marks.
Indicators sourced from the official NaCCA Science CCP curriculum (B7/JHS1-B9/JHS3, Sept 2020),
Strand 5: Humans and the Environment, Sub-strand 2: Human Health, printed page 46.
Content standard: B7/JHS1.5.2.2. Deficiency diseases (B7/JHS1.5.2.1) are in the companion
paper."""

SCHOOL = "[SCHOOL NAME]"
SUBJECT = "INTEGRATED SCIENCE (SCIENCE)"
EXAM = "END-OF-TERM MOCK EXAMINATION"
CLASS = "Basic 7 (JHS 1)"
TIME = "2 hours (Suggested: Section A - 40 min; Section B - 80 min)"
MARKS = "100"
YEAR = "2025/2026 Academic Year"

STRAND = "Humans and the Environment"
SUBSTRAND = "Human Health (Part 2: Viral Diseases)"

TOPIC = {
    "17.4": "17.4 Nature of Viral Diseases",
    "17.5": "17.5 COVID-19: Causes, Symptoms, Transmission and Prevention",
    "17.6": "17.6 Ebola and H1N1 Diseases",
    "17.7": "17.7 Role of Individuals, Communities and Government",
}

CS = "B7/JHS1.5.2.2"
CS_BY_TOPIC = {k: "B7/JHS1.5.2.2" for k in ["17.4", "17.5", "17.6", "17.7"]}
CS_TEXT = ("Demonstrate knowledge of the nature of selected viral diseases of humans, their "
           "causes, symptoms, effects and management")

IND = {
    "17.4": "B7/JHS1.5.2.2.1 (Ex. 1)",
    "17.5": "B7/JHS1.5.2.2.1 (Ex. 2, 3)",
    "17.6": "B7/JHS1.5.2.2.1 (Ex. 2, 3)",
    "17.7": "B7/JHS1.5.2.2.1 (Ex. 4, 5)",
}
IND_TEXT = {
    "17.4": "Explain the nature of viral diseases with special emphasis on corona virus "
            "(COVID-19) / Ebola / H1N1 disease, its causes, symptoms, effects on humans and its "
            "prevention. Ex. 1: Discuss the nature of viral diseases.",
    "17.5": "Explain the nature of viral diseases with special emphasis on corona virus "
            "(COVID-19) / Ebola / H1N1 disease, its causes, symptoms, effects on humans and its "
            "prevention. Ex. 2, 3: Search for information and make presentations on the corona "
            "virus disease (COVID-19), Ebola, and H1N1 diseases and their mode of transmission "
            "from person to person, community to community and from country to country; "
            "describe the symptoms, effects and prevention of COVID-19, Ebola, and H1N1 "
            "diseases and why they are declared pandemic.",
    "17.6": "Explain the nature of viral diseases with special emphasis on corona virus "
            "(COVID-19) / Ebola / H1N1 disease, its causes, symptoms, effects on humans and its "
            "prevention. Ex. 2, 3: Search for information and make presentations on the corona "
            "virus disease (COVID-19), Ebola, and H1N1 diseases and their mode of transmission; "
            "describe the symptoms, effects and prevention of COVID-19, Ebola, and H1N1 "
            "diseases and why they are declared pandemic.",
    "17.7": "Explain the nature of viral diseases with special emphasis on corona virus "
            "(COVID-19) / Ebola / H1N1 disease, its causes, symptoms, effects on humans and its "
            "prevention. Ex. 4, 5: Describe the role of individuals, community members and "
            "government in managing COVID-19, Ebola, and H1N1 diseases; design and produce a "
            "poster to educate their community members on the incidence and control of named "
            "viral diseases: COVID-19, Ebola, and H1N1.",
}
CC = {"17.4": "CP, DL, CC, CI", "17.5": "CP, DL, CC, CI",
      "17.6": "CP, DL, CC, CI", "17.7": "CP, DL, CC, CI"}

# ---------------------------------------------------------------- SECTION A
# (question, [A,B,C,D], answer, topic, cognitive, difficulty)
MCQ = [
 ("A virus is",
  ["a large animal", "a type of bacterium",
   "a very tiny germ that can only multiply inside a living cell", "a kind of fungus"],
  "C", "17.4", "Remember", "Easy"),
 ("Viral diseases are different from bacterial diseases because",
  ["they are caused by viruses, and antibiotics do not cure them", "they are caused by worms",
   "they are caused by dirty water only", "they cannot be caught from another person"],
  "A", "17.4", "Understand", "Challenging"),
 ("Which of these is a viral disease?",
  ["malaria", "cholera", "typhoid", "Ebola"],
  "D", "17.4", "Apply", "Moderate"),
 ("A virus multiplies",
  ["in the air", "only inside the living cells of a plant, animal or person",
   "in stagnant water", "in the soil"],
  "B", "17.4", "Understand", "Moderate"),
 ("Which of these is NOT a viral disease?",
  ["malaria", "COVID-19", "Ebola", "H1N1 flu"],
  "A", "17.4", "Apply", "Easy"),
 ("A disease that spreads from one person to another is said to be",
  ["infectious or communicable", "deficient", "hereditary", "seasonal"],
  "A", "17.4", "Remember", "Easy"),
 ("One way viral diseases spread is through",
  ["drinking clean water", "eating balanced meals", "sleeping early",
   "droplets from coughing and sneezing"],
  "D", "17.4", "Apply", "Easy"),
 ("Handwashing with soap helps to prevent viral diseases because it",
  ["makes the hands soft", "removes or destroys the virus on the hands", "changes the blood",
   "stops hunger"],
  "B", "17.4", "Apply", "Easy"),
 ("A pandemic is",
  ["a disease that affects only one person", "a disease that cannot be treated",
   "a disease that spreads over many countries or the whole world",
   "a disease that only animals get"],
  "C", "17.4", "Understand", "Moderate"),

 ("COVID-19 is caused by",
  ["a corona virus", "a bacterium", "a fungus", "a worm"],
  "A", "17.5", "Remember", "Easy"),
 ("One common symptom of COVID-19 is",
  ["bow legs", "bleeding gums", "night blindness", "a dry cough and fever"],
  "D", "17.5", "Understand", "Easy"),
 ("COVID-19 spreads mainly through",
  ["eating stale food",
   "droplets released when an infected person coughs, sneezes or talks",
   "drinking borehole water", "sitting in the sun"],
  "B", "17.5", "Understand", "Moderate"),
 ("Which of these helps to prevent COVID-19?",
  ["shaking hands with everybody", "crowding into a small room",
   "wearing a face mask in crowded places", "sharing cups and plates"],
  "C", "17.5", "Apply", "Easy"),
 ("A person who has COVID-19 should",
  ["stay away from others and report to a health facility", "go to the market",
   "attend a funeral", "travel to another town"],
  "A", "17.5", "Apply", "Easy"),
 ("COVID-19 was declared a pandemic because it",
  ["was very mild", "affected only one village", "was caused by a new virus",
   "spread quickly to many countries all over the world"],
  "D", "17.5", "Understand", "Moderate"),
 ("Vaccination against COVID-19 helps by",
  ["curing the disease at once", "helping the body to build defence against the virus",
   "replacing all other medicine", "making the virus grow"],
  "B", "17.5", "Understand", "Moderate"),
 ("One effect COVID-19 had on the country was that",
  ["farming increased", "schools and markets were closed for a time", "roads were built",
   "rainfall increased"],
  "B", "17.5", "Understand", "Moderate"),
 ("Which of these is NOT a symptom of COVID-19?",
  ["bow legs", "fever", "loss of taste or smell", "difficulty in breathing"],
  "A", "17.5", "Apply", "Easy"),
 ("Washing the hands with soap under running water for at least twenty seconds",
  ["is only necessary for doctors", "makes no difference at all",
   "is only needed after eating", "helps to destroy the virus that may be on the hands"],
  "D", "17.5", "Apply", "Easy"),
 ("During the COVID-19 outbreak people were advised to",
  ["travel as much as possible", "keep a distance from one another in public places",
   "stop washing their hands", "share face masks with friends"],
  "B", "17.5", "Apply", "Easy"),

 ("Ebola spreads mainly through",
  ["the air over a long distance", "mosquito bites",
   "contact with the body fluids of an infected person", "drinking rain water"],
  "C", "17.6", "Understand", "Moderate"),
 ("One symptom of Ebola is",
  ["bleeding from the gums, nose or other openings", "night blindness", "bow legs",
   "reddish hair"],
  "A", "17.6", "Remember", "Moderate"),
 ("H1N1 is a disease that",
  ["affects only cattle", "affects only fish", "affects only crops",
   "affects people, and is a kind of influenza or flu"],
  "D", "17.6", "Understand", "Moderate"),
 ("H1N1 spreads in a way most similar to",
  ["malaria", "the common flu, through droplets from coughing and sneezing", "cholera",
   "kwashiorkor"],
  "B", "17.6", "Understand", "Moderate"),
 ("Which of these diseases is caused by a virus?",
  ["cholera", "malaria", "H1N1 influenza", "dysentery"],
  "C", "17.6", "Apply", "Moderate"),
 ("A person suspected of having Ebola should be",
  ["taken to a health facility at once and kept away from others",
   "left in the community to recover", "given antibiotics at home", "sent to the market"],
  "A", "17.6", "Apply", "Moderate"),
 ("Both Ebola and H1N1",
  ["are caused by bacteria", "cannot be prevented", "affect only animals",
   "are viral diseases that can spread from person to person"],
  "D", "17.6", "Understand", "Challenging"),

 ("One way an INDIVIDUAL can help to control a viral disease is to",
  ["hide the illness", "wash hands regularly and report any sickness early",
   "travel to other towns", "attend large gatherings"],
  "B", "17.7", "Apply", "Easy"),
 ("One way the COMMUNITY can help is to",
  ["ignore the sick", "close all schools for ever",
   "report cases early and support families who are isolating", "stop farming"],
  "C", "17.7", "Understand", "Moderate"),
 ("The GOVERNMENT can help to manage a viral disease by",
  ["providing testing, treatment and health education", "building more markets",
   "selling medicine from door to door", "closing all churches permanently"],
  "A", "17.7", "Understand", "Moderate"),
 ("Health workers such as doctors and nurses",
  ["spread the disease", "are not needed", "should be avoided",
   "treat the sick and help to stop the spread"],
  "D", "17.7", "Remember", "Moderate"),
 ("A poster meant to educate the community about a viral disease should",
  ["be full of long writing", "have a clear message, simple words and pictures",
   "use only difficult English terms", "be kept locked in a cupboard"],
  "B", "17.7", "Understand", "Easy"),
 ("Which of these would be the best title for a poster about viral diseases?",
  ["The History of Farming", "How to Cook Banku", "Stop the Spread: Wash Your Hands",
   "Types of Soil in Ghana"],
  "C", "17.7", "Apply", "Easy"),
 ("During an outbreak, spreading false information",
  ["can make the disease spread further and should be avoided", "is helpful",
   "is the government's job", "cures the disease"],
  "A", "17.7", "Understand", "Moderate"),
 ("Keeping a sick person away from others, called isolation, helps because it",
  ["punishes the person", "makes the person well at once", "saves money",
   "keeps the virus from reaching other people"],
  "D", "17.7", "Understand", "Moderate"),
 ("A community that buries a person who died of Ebola without any protection",
  ["is following the right rule", "risks spreading the disease to many more people",
   "will not be affected", "will end the outbreak at once"],
  "B", "17.7", "Understand", "Challenging"),
 ("The best way for a pupil to help during an outbreak is to",
  ["stay away from school for ever", "ignore the rules",
   "follow the health rules and tell others what has been taught", "treat the sick at home"],
  "C", "17.7", "Apply", "Moderate"),
 ("Wearing a face mask in a crowded place mainly",
  ["makes a person look important", "keeps the face warm",
   "helps to stop droplets carrying the virus from reaching other people", "stops hunger"],
  "C", "17.7", "Apply", "Easy"),
 ("Government health education on radio and television helps because it",
  ["costs nothing to produce", "is only for adults",
   "reaches many people at once with the same correct message", "replaces hospitals"],
  "C", "17.7", "Understand", "Moderate"),
 ("Which of these is the least useful thing to put on a health poster?",
  ["a picture of someone washing their hands", "a short slogan in simple language",
   "the signs of the disease", "a long list of chemists and their prices"],
  "D", "17.7", "Analyse", "Challenging"),
]

# ---------------------------------------------------------------- SECTION B
SECTION_B = [
 dict(
   num=1, total=9, topic="17.4",
   stem="Some illnesses are caused by bacteria and others are caused by viruses, and the two "
        "are not treated in the same way.",
   parts=[
     ("(a)", "Explain what is meant by a viral disease.", 3, "Understand", "17.4", "Easy"),
     ("(b)", "State three ways in which a virus is different from a bacterium.",
      3, "Understand", "17.4", "Moderate"),
     ("(c)", "Explain why antibiotics do not cure viral diseases.",
      3, "Understand", "17.4", "Challenging"),
   ]),
 dict(
   num=2, total=8, topic="17.4",
   stem="A viral disease can start with one person and end up in many countries.",
   parts=[
     ("(a)", "Describe three ways in which viral diseases spread from one person to another.",
      3, "Understand", "17.4", "Moderate"),
     ("(b)", "Explain how a viral disease can spread from one community to another and from one "
             "country to another.", 3, "Understand", "17.4", "Challenging"),
     ("(c)", "State two reasons why viral diseases spread quickly in crowded places.",
      2, "Understand", "17.4", "Moderate"),
   ]),
 dict(
   num=3, total=9, topic="17.5",
   stem="COVID-19 spread round the world in 2020 and changed life everywhere, including Ghana.",
   parts=[
     ("(a)", "Name the germ that causes COVID-19 and state three symptoms of the disease.",
      4, "Remember", "17.5", "Easy"),
     ("(b)", "Explain how COVID-19 spreads from one person to another.",
      3, "Understand", "17.5", "Moderate"),
     ("(c)", "State two effects COVID-19 had on life in Ghana.",
      2, "Understand", "17.5", "Moderate"),
   ]),
 dict(
   num=4, total=8, topic="17.5",
   stem="Governments everywhere had to decide how to slow the spread of COVID-19.",
   parts=[
     ("(a)", "State four ways of preventing the spread of COVID-19.",
      4, "Understand", "17.5", "Moderate"),
     ("(b)", "During the COVID-19 outbreak, schools in Ghana were closed for a long time. Do "
             "you think that was the right thing to do? Give two reasons for your answer.",
      4, "Evaluate", "17.5", "Moderate"),
   ]),
 dict(
   num=5, total=9, topic="17.6",
   stem="Ebola is a viral disease that has caused serious outbreaks in parts of Africa.",
   parts=[
     ("(a)", "State three symptoms of Ebola.", 3, "Remember", "17.6", "Easy"),
     ("(b)", "Explain how Ebola spreads from one person to another.",
      3, "Understand", "17.6", "Moderate"),
     ("(c)", "Explain why a person suspected of having Ebola must not be left in the "
             "community.", 3, "Apply", "17.6", "Challenging"),
   ]),
 dict(
   num=6, total=8, topic="17.6",
   stem="H1N1 is another viral disease that spread round the world.",
   parts=[
     ("(a)", "Explain what H1N1 is and state two of its symptoms.",
      3, "Understand", "17.6", "Moderate"),
     ("(b)", "State two ways in which H1N1 is similar to COVID-19 and one way in which it is "
             "different.", 3, "Analyse", "17.6", "Challenging"),
     ("(c)", "State two ways of preventing the spread of influenza such as H1N1.",
      2, "Apply", "17.6", "Easy"),
   ]),
 dict(
   num=7, total=9, topic="17.7",
   stem="Managing a viral disease is not the job of one person alone.",
   parts=[
     ("(a)", "State one role each of the individual, the community and the government in "
             "managing a viral disease.", 3, "Understand", "17.7", "Moderate"),
     ("(b)", "Your class has been asked to design a poster to educate the community about "
             "COVID-19. Describe what you would put on it, what the message would be, and how "
             "you would make it clear to people who cannot read well.",
      4, "Create", "17.7", "Challenging"),
     ("(c)", "State two places in the community where the poster should be put up, and give a "
             "reason for each.", 2, "Apply", "17.7", "Easy"),
   ]),
]

# ------------------------------------------------------- MARKING SCHEME
MARKING = {
 1: [
   ("(a)", ["A viral disease is an illness caused by a virus.",
            "It is an infectious disease, so it can spread from one person to another.",
            "Examples are COVID-19, Ebola, H1N1 influenza, measles and chicken pox.",
            "The virus enters the body and multiplies inside the body's living cells."],
    "1 mark each for any THREE correct points (3 marks). The key idea is that the cause is a "
    "VIRUS. Do NOT accept 'a disease caused by bacteria' or 'a disease caused by a lack of "
    "food'."),
   ("(b)", ["A virus is much smaller than a bacterium; it cannot be seen with an ordinary "
            "school microscope.",
            "A virus can only multiply INSIDE a living cell, while many bacteria can multiply "
            "outside cells.",
            "Antibiotics kill bacteria but have no effect on viruses.",
            "Bacteria are living cells; a virus is not a complete cell.",
            "Viral diseases can often be prevented by vaccination; fewer bacterial diseases "
            "are."],
    "1 mark each for any THREE correct differences (3 marks). Accept any genuine difference. Do "
    "NOT accept 'viruses are bad and bacteria are good' or any answer that treats all bacteria "
    "as harmless."),
   ("(c)", ["Antibiotics are medicines that kill BACTERIA or stop them from multiplying.",
            "A virus is not a bacterium and does not have the parts that antibiotics attack.",
            "Because a virus multiplies inside the body's own cells, a medicine that attacked "
            "it would also harm the body's cells.",
            "So antibiotics cannot destroy the virus and will not cure the illness.",
            "Taking antibiotics when they are not needed can also cause harm later, because "
            "bacteria become resistant to them."],
    "1 mark each for any THREE correct points (3 marks). The key idea is that antibiotics act "
    "on bacteria and not on viruses. Award at most 1 mark for an answer that only says 'they "
    "do not work'."),
 ],
 2: [
   ("(a)", ["Through droplets released into the air when an infected person coughs, sneezes or "
            "talks.", "By touching surfaces or objects that have the virus on them and then "
            "touching the mouth, nose or eyes.",
            "By close contact such as shaking hands, hugging or sharing cups and plates.",
            "Through body fluids, as with Ebola.",
            "By touching or handling a sick person or, in the case of Ebola, a person who has "
            "died of the disease."],
    "1 mark each for any THREE correct ways (3 marks). Accept any genuine route of spread. Do "
    "NOT accept routes belonging to other diseases, such as 'mosquito bites' for malaria."),
   ("(b)", ["An infected person travels by tro-tro, bus, taxi or plane to another town or "
            "country while still infectious.",
            "People move from place to place for markets, funerals, school and work, carrying "
            "the virus with them.",
            "In the new place the person passes the virus to others, who pass it on again.",
            "Because travel is now fast, a virus can reach many countries within days.",
            "Large gatherings such as markets, churches and funerals help it to spread once it "
            "arrives."],
    "1 mark each for any THREE correct points (3 marks). The key idea is the MOVEMENT OF "
    "PEOPLE from one place to another. Award at most 2 marks if the answer only describes "
    "person-to-person spread without explaining how it moves between places."),
   ("(c)", ["People are close together, so droplets from a cough or sneeze reach others "
            "easily.", "Many people touch the same surfaces, such as door handles, rails and "
            "money.", "There is less fresh air and less room to keep a distance from others.",
            "One infectious person can pass the virus to many people in a short time."],
    "1 mark each for any TWO correct points (2 marks). Accept any sensible reason."),
 ],
 3: [
   ("(a)", ["The germ is the corona virus, often written SARS-CoV-2.",
            "A high temperature or fever.", "A dry, persistent cough.",
            "Difficulty in breathing or shortness of breath.",
            "Loss of taste or loss of smell.", "Tiredness and body aches.",
            "A sore throat or a headache."],
    "1 mark for naming the corona virus and 1 mark each for any THREE correct symptoms "
    "(4 marks). Award at most 3 marks if the germ is named wrongly. Do NOT accept symptoms of "
    "other diseases such as bow legs or bleeding gums."),
   ("(b)", ["It spreads mainly through droplets released when an infected person coughs, "
            "sneezes, talks or sings.",
            "A person nearby breathes in those droplets, or they land on the mouth, nose or "
            "eyes.",
            "A person can also pick up the virus by touching a surface that has droplets on it "
            "and then touching the face.",
            "It spreads most easily indoors and in crowded places where people are close "
            "together.",
            "A person can spread it before they know they are ill, or even if they never feel "
            "ill."],
    "1 mark each for any THREE correct points (3 marks). The key idea is DROPLETS from the "
    "breath of an infected person."),
   ("(c)", ["Schools were closed for a long time and pupils lost lessons.",
            "Markets, churches and funerals were restricted or stopped.",
            "People were asked to wear face masks and to keep a distance from one another.",
            "Travel between towns and into the country was restricted.",
            "Many people lost work or income, and some businesses closed.",
            "Hospitals and health centres were put under great strain.",
            "Families lost relatives and had to bury them under special rules."],
    "1 mark each for any TWO correct effects (2 marks). Accept any sensible effect on life in "
    "Ghana."),
 ],
 4: [
   ("(a)", ["Wash the hands often with soap under running water, or use an alcohol hand "
            "sanitiser.", "Wear a face mask properly in crowded or enclosed places.",
            "Keep a distance from other people and avoid crowds.",
            "Cover the mouth and nose with a bent elbow or tissue when coughing or sneezing.",
            "Stay at home and report to a health facility when feeling unwell.",
            "Get vaccinated when the vaccine is offered.",
            "Clean and disinfect surfaces that are touched often, such as door handles.",
            "Avoid sharing cups, plates, towels and other personal items."],
    "1 mark each for any FOUR correct ways (4 marks). Accept any sensible preventive measure."),
   ("(b)", ["Closing the schools was the right thing to do.",
            "It kept large numbers of children and teachers apart, so the virus could not "
            "spread easily among them.",
            "It protected pupils, teachers and the older people they live with.",
            "It gave the health service time to prepare and to treat the sick.",
            "Against that: pupils lost a lot of learning and some children went hungry without "
            "school meals.",
            "Accept either side of the argument, provided the reasons genuinely support the "
            "position taken."],
    "1 mark for a clear position and 1 mark each for any THREE good reasons (4 marks). Credit "
    "either 'yes' or 'no'. An answer that gives a position with no reason scores at most 1."),
 ],
 5: [
   ("(a)", ["Fever and severe headache.", "Body aches, weakness and tiredness.",
            "Bleeding from the gums, nose, eyes or other body openings.",
            "Vomiting and diarrhoea.", "Stomach pain.", "A rash or sores in some cases."],
    "1 mark each for any THREE correct symptoms (3 marks). Do NOT accept symptoms that belong "
    "to deficiency diseases, such as bow legs or night blindness."),
   ("(b)", ["Through direct contact with the blood, saliva, sweat, urine, stool or other body "
            "fluids of an infected person.",
            "By touching or caring for a sick person without gloves and other protection.",
            "By washing or touching the body of someone who has died of Ebola during burial "
            "preparations.",
            "By touching clothes, bedding or instruments soiled with the body fluids of a sick "
            "person.",
            "It does NOT spread through the air over a long distance like flu."],
    "1 mark each for any THREE correct points (3 marks). The key idea is contact with BODY "
    "FLUIDS. Award at most 2 marks if the answer says it spreads through the air."),
   ("(c)", ["Ebola spreads very easily through contact with body fluids, so everyone near the "
            "person is at risk.",
            "The disease is severe and kills many of the people it infects.",
            "The person needs skilled treatment at a health facility, which the community "
            "cannot give.",
            "Leaving the person at home means carers and family members are infected, and they "
            "carry it to others.",
            "Taking the person to a health facility protects the family and helps the health "
            "workers stop the outbreak.",
            "There is no cure that the family can give at home, so delay costs lives."],
    "1 mark each for any THREE correct points (3 marks). The key ideas are that the person is "
    "highly infectious, that they need skilled care, and that leaving them in the community "
    "spreads the disease."),
 ],
 6: [
   ("(a)", ["H1N1 is a viral disease; it is a kind of influenza or flu that affects people.",
            "It was first called swine flu because the virus is related to flu viruses found "
            "in pigs.", "Symptoms include fever and chills.",
            "A cough and a sore throat.", "A running nose or a blocked nose.",
            "Body aches, headache and tiredness.", "Some people vomit or have diarrhoea."],
    "1 mark for explaining that H1N1 is a viral flu and 1 mark each for any TWO correct "
    "symptoms (3 marks). Award at most 2 marks if the explanation is missing."),
   ("(b)", ["SIMILAR: both are caused by a virus and both can be declared a pandemic.",
            "SIMILAR: both spread through droplets from coughing and sneezing.",
            "SIMILAR: both cause fever, cough and tiredness, and both can make breathing "
            "difficult.",
            "SIMILAR: both are prevented by handwashing, masks, distance and avoiding crowds.",
            "DIFFERENT: Ebola spreads through body fluids rather than mainly through the air, "
            "and it causes bleeding.",
            "DIFFERENT: Ebola kills a far larger share of the people it infects.",
            "DIFFERENT: H1N1 is a flu that most people recover from, while Ebola is much more "
            "severe."],
    "1 mark for each of TWO correct similarities and 1 mark for one correct difference "
    "(3 marks). Accept comparisons with either COVID-19 or Ebola, provided the point is "
    "accurate."),
   ("(c)", ["Wash the hands often with soap and water.",
            "Cover the mouth and nose when coughing or sneezing.",
            "Keep away from crowds and keep a distance from anyone who is coughing.",
            "Get the seasonal flu vaccine where it is available.",
            "Stay at home and rest when feeling unwell, and do not go to school or work.",
            "Clean surfaces that are touched often and keep rooms well aired."],
    "1 mark each for any TWO correct ways (2 marks). Accept any sensible preventive measure."),
 ],
 7: [
   ("(a)", ["THE INDIVIDUAL: wash hands regularly, wear a mask in crowded places, report "
            "sickness early and follow the health rules.",
            "THE COMMUNITY: report cases early, support families who are isolating, and stop "
            "spreading false information about the disease.",
            "THE GOVERNMENT: provide testing, treatment and isolation centres, give clear "
            "health education, and supply protective equipment to health workers.",
            "Health workers treat the sick and trace the people they have been in contact "
            "with."],
    "1 mark for each of the three roles (3 marks). The role must be matched to the right "
    "person or group; award no mark for a correct action attached to the wrong one."),
   ("(b)", ["A short, clear message such as 'Wash your hands, wear your mask, keep your "
            "distance'.",
            "Pictures showing the right actions - hands being washed, a mask being worn, "
            "someone covering a cough.",
            "The signs of the disease, and what to do if someone has them.",
            "A phone number or place to report to, such as the clinic or the health centre.",
            "Very few words and large letters, so it can be read from a distance.",
            "Use pictures and symbols rather than long sentences, because some people cannot "
            "read.",
            "Use the local language as well as English, and bright colours to catch the eye.",
            "Put the message at the top where it is seen first."],
    "1 mark each for any FOUR correct points (4 marks). This is a design task: award method "
    "marks for any sensible poster. At least ONE mark must come from what the poster SHOWS or "
    "SAYS and at least ONE from how it is made clear to someone who cannot read; award at most "
    "3 marks if the answer covers only one of the two."),
   ("(c)", ["At the market, because many people pass there every day.",
            "At the clinic or health centre, where people already come for health matters.",
            "At the school, so pupils and parents both see it.",
            "At the church or mosque, where the community gathers.",
            "At the lorry station or bus stop, where travellers pass through.",
            "At the chief's palace or the community centre, where people come for meetings."],
    "1 mark for each of TWO correct places with a reason (2 marks). Accept any sensible public "
    "place in the community; the reason must explain why people would see it there."),
 ],
}


# --------------------------------------------- derive summary statistics
def topic_totals():
    m = {k: 0 for k in TOPIC}
    it = {k: 0 for k in TOPIC}
    for q in MCQ:
        m[q[3]] += 1
        it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk
            it[key] += 1
    return m, it


def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}
    b = {k: 0 for k in order}
    for q in MCQ:
        a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            b[cog] += mk
    return order, a, b


def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ:
        d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            d[diff] += mk
    return d
