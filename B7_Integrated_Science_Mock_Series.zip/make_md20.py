# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "/home/user")
from build_career import *

L = []
def w(s=""): L.append(s)

w(f"# {SCHOOL}"); w()
w(f"## {SUBJECT}"); w()
w(f"### {EXAM}"); w()
w(f"**Class:** {CLASS}  ")
w(f"**Time:** {TIME}  ")
w(f"**Total Marks:** {MARKS}  ")
w(f"**Academic Year:** {YEAR}"); w()
w("---"); w()
w("### INSTRUCTIONS"); w()
for i, t in enumerate([
    "Write your name and class clearly in the spaces provided on your answer sheet.",
    "This paper has TWO sections: Section A and Section B.",
    "Answer ALL the questions in both sections.",
    "Section A has 40 multiple-choice questions. Each question carries 1 mark. Choose the best answer (A, B, C or D) and record it on the answer sheet provided.",
    "Section B has 7 theory questions totalling 60 marks. Write your answers clearly and neatly in your answer booklet. Draw and label diagrams or tables where you are asked to.",
    "Read every question carefully before you answer it.",
    "Do not use correction fluid. Cancel any mistake neatly with a single line.",
    "Hand in your answer sheet and your answer booklet at the end of the examination.",
], start=1):
    w(f"{i}. {t}")
w(); w("---"); w()

w("## SECTION A: OBJECTIVE TEST (40 marks)"); w()
w("*Answer ALL questions. Each question carries 1 mark. Choose the BEST answer and write its letter "
  "(A, B, C or D) against the question number on your answer sheet.*"); w()
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"**{i}. {q}**"); w()
    for j, o in enumerate(opts): w(f"{'ABCD'[j]}. {o}")
    w()
w("---"); w()

w("## SECTION B: THEORY (60 marks)"); w()
w("*Answer ALL questions. Write your answers in your answer booklet. The marks for each question are shown "
  "in brackets.*"); w()
for qb in SECTION_B:
    w(f"### Question {qb['num']}  [{qb['total']} marks]"); w()
    w(qb["stem"]); w()
    if qb.get("table") == "scientist":
        w("| " + " | ".join(SCIENTIST_HEADERS) + " |")
        w("| " + " | ".join(["---"] * len(SCIENTIST_HEADERS)) + " |")
        for r in SCIENTIST_ROWS:
            w("| " + " | ".join(r) + " |")
        w()
        w("*Table 1: Some Ghanaian scientists and science educators and their work*"); w()
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        w(f"**{lab}** {text}  **[{mk} mark{'s' if mk > 1 else ''}]**"); w()
w("---"); w()

w("## ANSWER KEY"); w()
w("### Section A - Objective Test"); w()
w("| Question | Answer | Curriculum Area (Topic) | Cognitive Level |")
w("| -------- | ------ | ----------------------- | --------------- |")
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"| {i} | {ans} | {TOPIC[tp]} | {cog} |")
counts = {L2: sum(1 for q in MCQ if q[2] == L2) for L2 in "ABCD"}
w()
w("Correct-answer distribution: " + ", ".join(f"{L2} = {counts[L2]}" for L2 in "ABCD") + " (40 items).")
w()
w("### Section B - Theory (summary answers; full detail in the Marking Scheme)"); w()
w("| Question | Expected Answer | Curriculum Area | Cognitive Level |")
w("| -------- | --------------- | --------------- | --------------- |")
sba = [
 ("1 (a)", "Any three careers in science that are not medicine: agricultural scientist or food technologist, engineer, geologist, meteorologist, environmental health officer, science teacher, laboratory technician, veterinary doctor, computer or ICT specialist, soil scientist, water quality officer, solar technician, medical researcher.", "18.1", "Remember"),
 ("1 (b)", "Accept a correct description of the work for any two of the careers named in (a), for example: a soil scientist takes samples of the soil, tests them and tells the farmer what crop to plant and what fertiliser to use; an environmental health officer inspects houses, drains and water sources and advises the community on how to stop disease spreading; a solar technician fixes panels on a roof, wires them up and returns to clean and check them.", "18.1", "Understand"),
 ("1 (c)", "A veterinary doctor keeps farm animals healthy, so families keep the milk, meat and eggs they depend on and do not lose the animals that plough their fields. Healthy animals also mean more food in the market and a better income for the farmer. Some animal diseases can pass to people, so treating the animals protects the people who live with them.", "18.1", "Understand"),
 ("2 (a)", "Accept any two sensible careers with a reason that fits Adjoa: agricultural scientist or soil scientist - she wants to help her community grow more food and likes working outdoors; agricultural engineer - the work is outdoors and uses mathematics; environmental scientist - she likes the outdoors and wants to help her community; mathematics or science teacher - she is good at mathematics and could pass it on.", "18.1", "Apply"),
 ("2 (b)", "Any two: work hard at mathematics and science and pass them well; ask her science teacher about the careers and what subjects they need; read books and look for information about science; join the science club or enter a science competition; go on to a university or a training college that teaches the subject.", "18.1", "Understand"),
 ("2 (c)", "Any two: scientists solve the country's own problems in food, health, water and energy; a country that trains its own scientists does not have to buy every solution from abroad; science and technology create jobs and income; the problems Ghana faces - floods, crop failure, disease - need people who understand them.", "18.1", "Understand"),
 ("3 (a)", "A science educator is someone who teaches science and works to improve the way it is taught - training science teachers and designing what is taught and how, rather than doing research in a laboratory themselves.", "18.2", "Understand"),
 ("3 (b)", "Accept any two correctly named Ghanaian science educators. Prof. Jophus Anamuah-Mensah - a science educator who has worked to improve science teaching in Ghana, led a university and helped shape education policy. Prof. Theophilus Ossei-Anto and Prof. Christian Anthony-Krueger - science educators at the University of Cape Coast who train science teachers. Also accept Prof. Ewurama Addy, who worked to popularise science and directed the Science Education Programme for Africa.", "18.2", "Understand"),
 ("3 (c)", "Any three: teachers produce the next generation of scientists, so without them there would be no scientists at all; a researcher may discover something, but teachers make sure the discovery is understood and used; a country needs many good teachers but only a few researchers, so teachers reach far more people; teachers find and encourage the pupils who will become the scientists of the future; good teaching makes sure a discovery does not stay locked inside one laboratory.", "18.2", "Understand"),
 ("4 (i)", "Mathematical physics. Also accept physics.", "18.2", "Understand"),
 ("4 (ii)", "She reduces post-harvest losses and adds value to Ghanaian foods, so less of the harvest is wasted after it is picked. Also accept: her work on fortified sweetpotato products helps to reduce vitamin A deficiency.", "18.2", "Understand"),
 ("4 (iii)", "Prof. Ewurama Addy. Also accept Marian Ewurama Addy, or Prof. Addy.", "18.2", "Understand"),
 ("4 (iv)", "Science education. Also accept science education, or the training of science teachers.", "18.2", "Understand"),
 ("5 (a)", "Any two: scientific knowledge belongs to the whole world, so we use discoveries made in other countries every day; the medicines, machines and crops developed abroad are used in Ghana; their stories show pupils what patience, curiosity and hard work can achieve; learning about them gives pupils ideas they can apply to Ghana's own problems.", "18.3", "Understand"),
 ("5 (b)", "Accept any one correctly matched. Albert Einstein - physics; the theory of relativity and E = mc squared. Alexander Fleming - medicine and microbiology; the discovery of penicillin. Charles Darwin - biology and natural history; the theory of evolution by natural selection. Stephen Hawking - physics and cosmology; his work on black holes. Marie Curie - physics and chemistry; radioactivity. Isaac Newton - physics and mathematics; gravity and the laws of motion. Louis Pasteur - microbiology; showing that germs cause disease and developing vaccines.", "18.3", "Understand"),
 ("5 (c)", "Accept any accurate account of how the work named in (b) still matters. Fleming's penicillin began the age of antibiotics, and antibiotics are still the treatment for bacterial infections in every Ghanaian hospital today. Pasteur's idea that germs cause disease is why water is treated, wounds are cleaned and children are vaccinated. Einstein's work on energy and matter underlies the physics used in medical scanners, satellites and the generation of electricity.", "18.3", "Analyse"),
 ("6 (a)", "Any two: scientists publish their results so others can build on them; problems such as disease, climate and food do not stop at borders; a discovery made in one country can save lives in another; sharing saves each country from repeating work already done; journals, conferences and the internet let results travel quickly.", "18.3", "Understand"),
 ("6 (b)", "Either position, with reasons. For training our own scientists: they understand Ghana's own problems; the knowledge stays in the country and trains the next generation; it is cheaper in the long run; a country that cannot make or repair anything is always dependent. For buying from abroad: it is quicker; some technology already exists and is expensive to develop. A strong answer says Ghana needs both - to buy what exists and to train the people who will maintain, repair and adapt it.", "18.3", "Evaluate"),
 ("7 (a)", "Any three: electric light lets children read after dark; a refrigerator keeps food and fish from spoiling; a mobile phone lets families keep in touch and lets traders check prices; mobile money lets people pay without carrying cash; a borehole gives clean water close to home; a grinding mill saves hours of pounding; gas or electric cookers have replaced some firewood.", "18.4", "Understand"),
 ("7 (b)", "HOME: a page listing the technologies used at home, each with a picture and a note of what the family did before. SCHOOL: a page on computers, a projector, calculators, the science laboratory, treated water or a borehole, and what they have changed about lessons. COMMUNITY: a page on solar panels, a borehole, a mobile money agent, a grinding mill, a clinic or a tractor, with a note on who uses each one. Plus a title page, a contents list and a short conclusion.", "18.4", "Create"),
 ("7 (c)", "CHECKING: ask a parent, a teacher or an older person whether what you wrote is true; compare what you found with a book or a trusted website; check an internet fact against a second source; ask someone who uses the technology, such as the miller or the nurse. PRESENTING: pin the pages on the wall and walk the class round them; give a short talk to another class; demonstrate one of the technologies; show the album to parents on an open day; act out before and after.", "18.4", "Apply"),
]
for r in sba: w(f"| {r[0]} | {r[1]} | {r[2]} | {r[3]} |")
w(); w("---"); w()

w("## MARKING SCHEME - SECTION B (60 marks)"); w()
w("*General rules: (1) Accept any other correct and relevant answer. (2) Award marks for correct points, not "
  "for repeating the question. (3) For procedures, award method marks. (4) Do not deduct marks for spelling "
  "unless the meaning is changed. (5) Where a candidate gives more answers than are asked for, mark only the "
  "first ones up to the number required.*"); w()
for qb in SECTION_B:
    n = qb["num"]
    w(f"### Question {n} ({qb['total']} marks)"); w()
    for (lab, points, note) in MARKING[n]:
        mkv = [p_[2] for p_ in qb["parts"] if p_[0] == lab]
        head = f"**{lab}**"
        if mkv: head += f" [{mkv[0]} mark{'s' if mkv[0] > 1 else ''}]"
        w(head); w()
        for pt in points: w(f"- {pt}")
        w(f"  - *Marking note: {note}*"); w()
w("---"); w()

w("## CURRICULUM ASSESSMENT BLUEPRINT"); w()
w(f"**Strand:** {STRAND} | **Sub-strand:** {SUBSTRAND} | **Class:** {CLASS}"); w()
w(f"**Content Standard:** {CS} - {CS_TEXT}"); w()
w("> Source: NaCCA Science Common Core Programme Curriculum (B7/JHS1-B9/JHS3), September 2020, "
  "Strand 5: Humans and the Environment, Sub-strand 3: Science and Industry "
  "(topics 18.1-18.4), p. 47. Indicators are quoted, not invented."); w()

w("### Section A"); w()
w("| Qn | Sub-strand | Content Standard | Indicator (NaCCA) - Indicator Text | Topic / Content | Cognitive Level | Marks |")
w("| -- | ---------- | ---------------- | ---------------------------------- | --------------- | --------------- | ----- |")
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"| A{i} | {SUBSTRAND} | {CS_BY_TOPIC[tp]} | {IND[tp]} - {IND_TEXT[tp]} | {TOPIC[tp]} | {cog} | 1 |")
w()
w("### Section B"); w()
w("| Qn | Sub-strand | Content Standard | Indicator (NaCCA) - Indicator Text | Topic / Content | Cognitive Level | Marks |")
w("| -- | ---------- | ---------------- | ---------------------------------- | --------------- | --------------- | ----- |")
for qb in SECTION_B:
    for (lab, text, mkv, cog, tp, diff) in qb["parts"]:
        key = tp if tp in TOPIC else tp.split(",")[0].strip()
        w(f"| B{qb['num']}{lab.strip('()')} | {SUBSTRAND} | {CS_BY_TOPIC[key]} | {IND[key]} - {IND_TEXT[key]} | {TOPIC[key]} | {cog} | {mkv} |")
w(); w("---"); w()

def topic_totals():
    m = {k: 0 for k in TOPIC}; it = {k: 0 for k in TOPIC}
    for q in MCQ: m[q[3]] += 1; it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk; it[key] += 1
    return m, it

def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}; b = {k: 0 for k in order}
    for q in MCQ: a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: b[cog] += mk
    return order, a, b

def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ: d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: d[diff] += mk
    return d

m, it = topic_totals(); diff_ = difficulty_totals(); order, ca, cb = cognitive_by_section()

w("### Summary 1 - Coverage by Curriculum Area (Topic)"); w()
w("| Topic / Content Area | No. of Items | Marks | % of Total Marks | Core Competencies |")
w("| -------------------- | ------------ | ----- | ---------------- | ----------------- |")
for k in TOPIC: w(f"| {TOPIC[k]} | {it[k]} | {m[k]} | {(m[k]/100)*100:.1f}% | {CC[k]} |")
w(f"| **TOTAL** | **{sum(it.values())}** | **{sum(m.values())}** | **100%** | - |")
w()
w("*CC = Communication and Collaboration; CP = Critical Thinking and Problem Solving; DL = Digital Literacy; "
  "CI = Creativity and Innovation.*"); w()
w("### Summary 2 - Cognitive-Level Distribution (Bloom's Taxonomy)"); w()
w("| Cognitive Level | Section A Marks | Section B Marks | Total Marks | % of Total |")
w("| --------------- | --------------- | --------------- | ----------- | ---------- |")
for lv in order:
    tot = ca[lv] + cb[lv]
    w(f"| {lv} | {ca[lv]} | {cb[lv]} | {tot} | {(tot/100)*100:.1f}% |")
w(f"| **TOTAL** | **{sum(ca.values())}** | **{sum(cb.values())}** | **{sum(ca.values())+sum(cb.values())}** | **100%** |")
w()
w("### Summary 3 - Difficulty Distribution"); w()
w("| Difficulty | Marks | % of Total Marks |")
w("| ---------- | ----- | ---------------- |")
for k, v in diff_.items(): w(f"| {k} | {v} | {(v/100)*100:.1f}% |")
w(f"| **TOTAL** | **{sum(diff_.values())}** | **100%** |")
w()
w("*Target in the master prompt: approximately 30% easy / 50% moderate / 20% challenging.*"); w()
w("### Summary 4 - Section Weighting"); w()
w("| Section | Question Type | Items | Marks | % of Total |")
w("| ------- | ------------- | ----- | ----- | ---------- |")
w("| A | Objective (multiple choice) | 40 | 40 | 40% |")
w("| B | Theory / constructed response | 21 | 60 | 60% |")
w("| **TOTAL** | - | **61** | **100** | **100%** |")
w(); w("---"); w()

w("## QUALITY-CONTROL SUMMARY")
w("")
w("| Check | Status |")
w("| --- | --- |")
for q_, a_ in [
 ("Every question within supplied curriculum scope",
  "Yes - all 61 items (40 objectives and 21 theory sub-questions) sit in topics 18.1-18.4 of Strand 5, Sub-Strand 3 (Science and Industry), under content standard B7/JHS1.5.3.1, mapped to indicator B7/JHS1.5.3.1.1. Every Ghanaian scientist named is one the curriculum itself names in Exemplar 1"),
 ("Appropriate for the class",
  "Yes - the B7 curriculum asks learners to discover and explain how careers in science improve human conditions and relate them to great national and international scientists and science educators; to research and build a portfolio on the impact of science, technology and innovation in homes, schools, communities and the universe; and to identify the careers Ghana must focus on and give reasons. The four exemplars map to the four topics in order"),
 ("Genuinely BECE-style",
  "Yes - 40 four-option objectives plus structured theory with printed mark allocations, a three-column completion table, 'name' and 'state' items, and open tasks requiring explanation, analysis, evaluation and design"),
 ("Sufficient application and reasoning",
  "Yes - 38 of 100 marks (38%) at Apply level or above (Apply 25, Analyse 4, Evaluate 5, Create 4)"),
 ("Plausible MCQ distractors",
  "Yes - a real job that is not based on science, a real university that is not the one the scientist worked at, a real scientist whose work belongs to a different field, and a real but weaker way of judging or doing something"),
 ("Single best answer per MCQ",
  "Yes - reviewed item by item and each option list was checked so that the declared key sits on the correct answer; three pairs in A21 are real Ghanaian scientists but only Anamuah-Mensah and Ossei-Anto share a field, three of the four scientists in A30 do reach a hospital but only Fleming's work is used there every day, and three options in A40 are things a group might do but only one tests the oven"),
 ("Marks internally consistent",
  "Yes - Section A 40 x 1 = 40; Section B 9 + 8 + 9 + 8 + 9 + 6 + 11 = 60; sub-question marks match the marking scheme"),
 ("Total adds up correctly",
  "Yes - 40 + 60 = 100"),
 ("Answer key correct",
  "Yes - all 40 keys and all 21 Section B answers verified against the marking scheme; the facts about each named Ghanaian scientist were checked against published sources - Prof. Oduro at KNUST and her work on post-harvest losses and vitamin A, Prof. Allotey as the first Ghanaian full professor of mathematics and his work in computing education, and Prof. Addy at the University of Ghana as the first Ghanaian woman to reach a full professorship in natural science"),
 ("Marking scheme matches questions",
  "Yes - expected answers plus marking notes covering partial credit, alternatives, common wrong answers and method marks; Question 1(a) withholds the mark for any medical career because the question excludes medicine, Question 1(c) gives 0 for 'he treats animals' with no link to people, Question 3(b) does not accept a research scientist where a science educator is asked for, Question 4(i) caps the answer at 1 for 'mathematics' alone, and Question 7(b) caps it at 1 if only one or two of home, school and community are covered"),
 ("Free from unnecessary ambiguity",
  "Yes - open items are anchored with 'name three', 'state two', 'give two', 'give three' and 'suggest two' plus the mark allocation; Question 1(b) must be answered on the careers named in 1(a), Question 2(a) says the reason must fit what the stem tells us about Adjoa, Question 5(c) asks about the scientist named in 5(b), and Question 7(c) asks for two ways of checking AND two ways of presenting"),
 ("Ghanaian contexts natural and accurate",
  "Yes - KNUST in Kumasi, the University of Ghana at Legon, UEW in Winneba and UCC in Cape Coast, fishmongers and grinding mills, maize sold at market prices checked on a mobile phone, mobile money agents, boreholes and hand pumps, a village far from the national grid, kerosene lanterns, and charcoal and firewood as the comparison for a solar oven"),
 ("No content beyond the curriculum",
  "No - every item sits inside topics 18.1-18.4; Marie Curie, Isaac Newton, Louis Pasteur and Jane Goodall are offered only as accepted alternatives in the marking scheme since the curriculum's own list ends with 'etc.', and no question depends on knowing them; no detailed chemistry, physics or biology is required"),
 ("Questions sufficiently varied",
  "Yes - naming non-medical careers, describing what two of them do, explaining a veterinary doctor's benefit to people, matching careers to a pupil's interests, planning how to prepare for a science career, defining a science educator, naming Ghanaian science educators and their work, arguing why teachers matter, completing a four-blank table, justifying the study of international scientists, describing a contribution, tracing it to the present day, explaining why knowledge is shared, weighing local training against imported technology, listing changes in homes and communities, designing a portfolio, and planning how to check and present it"),
]:
    w("| " + q_ + " | " + a_ + " |")
w("")
w("### EXAMINER NOTES")
w("")
for n_ in [
 "The curriculum names 'Paul Ratnei' among the international scientists in Exemplar 2. That name could not be found in any reference source and is very likely a typographical error in the curriculum document. No question here tests a contribution by him; he is accepted as a name in Question 5(b) and nowhere else, and the note says no contribution can be credited. If you know who was intended, teach the right name and accept it.",
 "Question 3 is the one that is easiest to mark wrongly. It asks for SCIENCE EDUCATORS, not research scientists, so Prof. Allotey and Prof. Oduro do not fit here even though they are the names pupils remember best. The science educators are Prof. Anamuah-Mensah, Prof. Ossei-Anto and Prof. Anthony-Krueger. Keep Question 3 and Question 4 apart when you teach them.",
 "Question 4(i) is the paper's most reliable discriminator. Prof. Allotey is MATHEMATICAL PHYSICS, not mathematics - the Allotey Formalism came from his work on soft X-ray spectroscopy, and he was the first Ghanaian full professor of mathematics but a physicist by research. The note gives 2 marks for mathematical physics and only 1 for 'physics' or 'mathematics' alone.",
 "Question 1(c) looks easy and is not. Pupils write 'a veterinary doctor treats animals' and earn 0, because the question asks how that improves HUMAN life. The two marks are for the link - food, income, ploughing, or protection from diseases that pass from animals to people. Teach the link, not the job.",
 "Question 6(b) is deliberately open, and the strongest answers say Ghana needs BOTH - to buy technology that already exists and to train Ghanaians who can run it, repair it and eventually make their own. Credit any position that is argued, and do not mark down a pupil who disagrees with you.",
 "Question 5(c) is the Analyse item and it is harder than it looks. Pupils tend to repeat the contribution from 5(b) instead of tracing it to today. The note caps them at 1 for that. Push them to a concrete present-day example - antibiotics in a Ghanaian hospital, clean water and vaccination from Pasteur's germ theory.",
 "Topic weighting is 28 marks for 18.1, 27 for 18.2, 24 for 18.3 and 21 for 18.4. If you spent longer on science, technology and innovation than on careers, move marks towards Question 7.",
 "Three cheap activities that raise marks sharply: (1) give each group one Ghanaian scientist to research for ten minutes and let them present to the class, which teaches Questions 3 and 4 and satisfies the 'presentations' in the exemplars; (2) hand out a page of job advertisements cut from a newspaper and ask pupils which ones need science and why, which teaches Question 1; and (3) walk round the school listing every piece of technology and asking what people did before it existed, which teaches Question 7(a).",
 "This sub-strand has one content standard and one indicator, so it is a single paper and not split. The companion papers cover Sub-strand 2 (Human Health) in two parts and Sub-strands 4 and 5 in one paper each.",
 "This version is a full rebuild. Every question is new, and none is repeated from the earlier version of this paper, so you can use either as a mock and the other as a second sitting without pupils seeing the same items twice.",
 "Edit the school name, academic year and examination title on page 1 before printing.",
 "This is an original, teacher-made mock. It is not a reproduction of any WAEC or NaCCA examination paper.",
]:
    w("- " + n_)
w()

open("/home/user/Basic7_Integrated_Science_Mock_Strand5_ScienceAndIndustry.md", "w", encoding="utf-8").write("\n".join(L))
print("md written", len("\n".join(L)), "chars")
