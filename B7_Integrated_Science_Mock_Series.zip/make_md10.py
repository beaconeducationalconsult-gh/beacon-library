# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "/home/user")
from build_farm import *

L = []
def w(s=""): L.append(s)

w(f"# {SCHOOL}"); w()
w(f"## {SUBJECT}"); w()
w(f"### {EXAM}"); w()
w(f"**Class:** {CLASS}  ")
w(f"**Time:** {TIME}  ")
w(f"**Total Marks:** {MARKS}  ")
w(f"**Academic Year:** {YEAR}"); w()
w("---"); w()
w("### INSTRUCTIONS"); w()
for i, t in enumerate([
    "Write your name and class clearly in the spaces provided on your answer sheet.",
    "This paper has TWO sections: Section A and Section B.",
    "Answer ALL the questions in both sections.",
    "Section A has 40 multiple-choice questions. Each question carries 1 mark. Choose the best answer (A, B, C or D) and record it on the answer sheet provided.",
    "Section B has 7 theory questions totalling 60 marks. Write your answers clearly and neatly in your answer booklet. Draw and label diagrams or tables where you are asked to.",
    "Read every question carefully before you answer it.",
    "Do not use correction fluid. Cancel any mistake neatly with a single line.",
    "Hand in your answer sheet and your answer booklet at the end of the examination.",
], start=1):
    w(f"{i}. {t}")
w(); w("---"); w()

w("## SECTION A: OBJECTIVE TEST (40 marks)"); w()
w("*Answer ALL questions. Each question carries 1 mark. Choose the BEST answer and write its letter "
  "(A, B, C or D) against the question number on your answer sheet.*"); w()
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"**{i}. {q}**"); w()
    for j, o in enumerate(opts): w(f"{'ABCD'[j]}. {o}")
    w()
w("---"); w()

w("## SECTION B: THEORY (60 marks)"); w()
w("*Answer ALL questions. Write your answers in your answer booklet. The marks for each question are shown "
  "in brackets.*"); w()
for qb in SECTION_B:
    w(f"### Question {qb['num']}  [{qb['total']} marks]"); w()
    w(qb["stem"]); w()
    if qb.get("table") == "systems":
        w("| " + " | ".join(SYS_HEADERS) + " |")
        w("| " + " | ".join(["---"] * len(SYS_HEADERS)) + " |")
        for r in SYS_ROWS:
            w("| " + " | ".join(r) + " |")
        w()
        w("*Table 1: The five farming systems*"); w()
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        w(f"**{lab}** {text}  **[{mk} mark{'s' if mk > 1 else ''}]**"); w()
w("---"); w()

w("## ANSWER KEY"); w()
w("### Section A - Objective Test"); w()
w("| Question | Answer | Curriculum Area (Topic) | Cognitive Level |")
w("| -------- | ------ | ----------------------- | --------------- |")
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"| {i} | {ans} | {TOPIC[tp]} | {cog} |")
counts = {L2: sum(1 for q in MCQ if q[2] == L2) for L2 in "ABCD"}
w()
w("Correct-answer distribution: " + ", ".join(f"{L2} = {counts[L2]}" for L2 in "ABCD") + " (40 items).")
w()
w("### Section B - Theory (summary answers; full detail in the Marking Scheme)"); w()
w("| Question | Expected Answer | Curriculum Area | Cognitive Level |")
w("| -------- | --------------- | --------------- | --------------- |")
sba = [
 ("1 (a)", "The particular way in which a farmer organises the land, the crops and the animals; the method or plan a farmer follows in using the land.", "10.1", "Understand"),
 ("1 (b)", "Any three of: land rotation; crop rotation; mixed cropping; mixed farming; organic farming.", "10.1", "Remember"),
 ("1 (c)", "Land rotation needs a lot of land, so it only suits places where land is plentiful; the crops wanted decide the system; mixed farming needs money to buy and feed animals while organic farming needs labour and bulky manure instead of cash.", "10.1", "Analyse"),
 ("2 (a)", "The farmer farms a piece of land for a few seasons, then leaves it to rest (fallow) for several years and moves to another piece.", "10.2", "Understand"),
 ("2 (b)", "Any three of: it lets the soil regain its fertility; it needs no artificial fertilizer and so costs little; it is simple and needs no special tools; it suits a place with plenty of land; it lets the bush grow back.", "10.2", "Understand"),
 ("2 (c)", "Any three of: it needs a very large area of land; trees and forest are destroyed each time new land is cleared; abandoned land can be eroded; the farmer must keep moving; it cannot feed many people on a small area.", "10.2", "Apply"),
 ("3 (a)", "Growing different crops one after another in a planned order on the same piece of land.", "10.3", "Understand"),
 ("3 (b)", "A sensible three-season rotation, e.g. maize, then a legume such as groundnuts or beans, then cassava or a vegetable; the legume goes in the middle because it puts nitrogen back, and changing the crop breaks the life cycle of pests that live on maize.", "10.3", "Create"),
 ("3 (c)", "Any three of: the soil stays fertile because different crops take different nutrients; pests and diseases die out when the host crop is not grown; the soil structure improves; the farmer gets a variety of produce; the same land can be used every year.", "10.3", "Understand"),
 ("4 (a)", "Growing two or more different crops together on the same piece of land at the same time.", "10.4", "Understand"),
 ("4 (b)", "Any three of: crops with different root depths use different layers of soil; if one crop fails the others may still do well; the family gets a variety of food from one plot; the leaves cover the soil and keep moisture in and weeds down; tall and short crops use the light at different heights.", "10.4", "Apply"),
 ("4 (c)", "Any three of: the crops compete for light, water and nutrients; it is difficult to weed, spray and harvest, and harder to use machines; the yield of each crop is often lower; it is hard to apply fertilizer to one crop alone; some crops may shade the others.", "10.4", "Understand"),
 ("5 (a)", "The system in which the farmer keeps animals and grows crops on the same farm, e.g. maize and cassava with goats or poultry.", "10.5", "Understand"),
 ("5 (b)", "The animals give droppings used as manure on the crops; the crops give waste, stalks, leaves and peelings used to feed the animals.", "10.5", "Understand"),
 ("5 (c)", "MIXED FARMING. Any two of: the animals may damage the crops if they are not fenced or tethered; it needs more land, labour, capital and knowledge; the animals need water and care all year; disease can kill the animals and that part of the income.", "10.5", "Analyse"),
 ("6 (a)", "Farming without artificial (synthetic) fertilizers, weedicides or pesticides, using only natural materials such as compost, manure, green manure and neem extract.", "10.6", "Understand"),
 ("6 (b)", "Any two of: compost; animal manure; green manure; crop residue; wood ash; decayed leaves.", "10.6", "Remember"),
 ("6 (c)", "Any three of: the yield may be lower at first so the farmer earns less; compost and manure are bulky and hard to carry and spread; it needs more labour; results take longer to show; pests and diseases are harder to control without chemicals.", "10.6", "Analyse"),
 ("7 (a)", "(i) farms a piece of land for a few seasons, then leaves it to rest and moves to another piece; (ii) it needs a very large area of land; (iii) it needs careful planning and knowledge of which crop should follow which; (iv) grows two or more different crops together on the same land at the same time; (v) keeps animals and grows crops on the same farm; (vi) the animals may damage the crops if they are not fenced or tethered.", "10.7", "Understand"),
 ("7 (b)", "Any four of: crop rotation changes the crop over time while mixed cropping grows several crops at the same time; only one crop occupies the land at a time in rotation; rotation is a plan across seasons while mixed cropping is a plan for one season; rotation varies the nutrients taken while mixed cropping uses different root depths; rotation is easier to weed, spray and harvest; rotation guards against pests while mixed cropping guards against the failure of one crop.", "10.7", "Analyse"),
]
for r in sba: w(f"| {r[0]} | {r[1]} | {r[2]} | {r[3]} |")
w(); w("---"); w()

w("## MARKING SCHEME - SECTION B (60 marks)"); w()
w("*General rules: (1) Accept any other correct and relevant answer. (2) Award marks for correct points, not "
  "for repeating the question. (3) For procedures, award method marks. (4) Do not deduct marks for spelling "
  "unless the meaning is changed. (5) Where a candidate gives more answers than are asked for, mark only the "
  "first ones up to the number required.*"); w()
for qb in SECTION_B:
    n = qb["num"]
    w(f"### Question {n} ({qb['total']} marks)"); w()
    for (lab, points, note) in MARKING[n]:
        mkv = [p_[2] for p_ in qb["parts"] if p_[0] == lab]
        head = f"**{lab}**"
        if mkv: head += f" [{mkv[0]} mark{'s' if mkv[0] > 1 else ''}]"
        w(head); w()
        for pt in points: w(f"- {pt}")
        w(f"  - *Marking note: {note}*"); w()
w("---"); w()

w("## CURRICULUM ASSESSMENT BLUEPRINT"); w()
w(f"**Strand:** {STRAND} | **Sub-strand:** {SUBSTRAND} | **Class:** {CLASS}"); w()
w(f"**Content Standard:** {CS} - {CS_TEXT}"); w()
w("> Source: NaCCA Science Common Core Programme Curriculum (B7/JHS1-B9/JHS3), September 2020, "
  "Strand 3: Systems, Sub-strand 4: Farming Systems, pp. 23-24. Indicators are quoted, not "
  "invented."); w()

w("### Section A"); w()
w("| Qn | Sub-strand | Content Standard | Indicator (NaCCA) - Indicator Text | Topic / Content | Cognitive Level | Marks |")
w("| -- | ---------- | ---------------- | ---------------------------------- | --------------- | --------------- | ----- |")
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"| A{i} | {SUBSTRAND} | {CS_BY_TOPIC[tp]} | {IND[tp]} - {IND_TEXT[tp]} | {TOPIC[tp]} | {cog} | 1 |")
w()
w("### Section B"); w()
w("| Qn | Sub-strand | Content Standard | Indicator (NaCCA) - Indicator Text | Topic / Content | Cognitive Level | Marks |")
w("| -- | ---------- | ---------------- | ---------------------------------- | --------------- | --------------- | ----- |")
for qb in SECTION_B:
    for (lab, text, mkv, cog, tp, diff) in qb["parts"]:
        key = tp if tp in TOPIC else tp.split(",")[0].strip()
        w(f"| B{qb['num']}{lab.strip('()')} | {SUBSTRAND} | {CS_BY_TOPIC[key]} | {IND[key]} - {IND_TEXT[key]} | {TOPIC[key]} | {cog} | {mkv} |")
w(); w("---"); w()

def topic_totals():
    m = {k: 0 for k in TOPIC}; it = {k: 0 for k in TOPIC}
    for q in MCQ: m[q[3]] += 1; it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk; it[key] += 1
    return m, it

def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}; b = {k: 0 for k in order}
    for q in MCQ: a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: b[cog] += mk
    return order, a, b

def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ: d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: d[diff] += mk
    return d

m, it = topic_totals(); diff_ = difficulty_totals(); order, ca, cb = cognitive_by_section()

w("### Summary 1 - Coverage by Curriculum Area (Topic)"); w()
w("| Topic / Content Area | No. of Items | Marks | % of Total Marks | Core Competencies |")
w("| -------------------- | ------------ | ----- | ---------------- | ----------------- |")
for k in TOPIC: w(f"| {TOPIC[k]} | {it[k]} | {m[k]} | {(m[k]/100)*100:.1f}% | {CC[k]} |")
w(f"| **TOTAL** | **{sum(it.values())}** | **{sum(m.values())}** | **100%** | - |")
w()
w("*CC = Communication and Collaboration; CP = Critical Thinking and Problem Solving; DL = Digital Literacy; "
  "CI = Creativity and Innovation.*"); w()
w("### Summary 2 - Cognitive-Level Distribution (Bloom's Taxonomy)"); w()
w("| Cognitive Level | Section A Marks | Section B Marks | Total Marks | % of Total |")
w("| --------------- | --------------- | --------------- | ----------- | ---------- |")
for lv in order:
    tot = ca[lv] + cb[lv]
    w(f"| {lv} | {ca[lv]} | {cb[lv]} | {tot} | {(tot/100)*100:.1f}% |")
w(f"| **TOTAL** | **{sum(ca.values())}** | **{sum(cb.values())}** | **{sum(ca.values())+sum(cb.values())}** | **100%** |")
w()
w("### Summary 3 - Difficulty Distribution"); w()
w("| Difficulty | Marks | % of Total Marks |")
w("| ---------- | ----- | ---------------- |")
for k, v in diff_.items(): w(f"| {k} | {v} | {(v/100)*100:.1f}% |")
w(f"| **TOTAL** | **{sum(diff_.values())}** | **100%** |")
w()
w("*Target in the master prompt: approximately 30% easy / 50% moderate / 20% challenging.*"); w()
w("### Summary 4 - Section Weighting"); w()
w("| Section | Question Type | Items | Marks | % of Total |")
w("| ------- | ------------- | ----- | ----- | ---------- |")
w("| A | Objective (multiple choice) | 40 | 40 | 40% |")
w("| B | Theory / constructed response | 20 | 60 | 60% |")
w("| **TOTAL** | - | **60** | **100** | **100%** |")
w(); w("---"); w()

w("## QUALITY-CONTROL SUMMARY")
w("")
w("| Check | Status |")
w("| --- | --- |")
for q_, a_ in [
 ("Every question within supplied curriculum scope",
  "Yes - topics 10.1-10.7 of Strand 3, Sub-Strand 4 (Farming Systems), mapped to indicators B7/JHS1.3.4.1.1 and B7/JHS1.3.4.1.2"),
 ("Appropriate for the class",
  "Yes - B7 level; no yield calculation, no farm budgeting and no soil-chemistry detail, all of which sit outside the B7 indicator"),
 ("Genuinely BECE-style",
  "Yes - 40 four-option objectives plus structured theory with printed mark allocations and a completion table"),
 ("Sufficient application and reasoning",
  "Yes - 30 of 100 marks (30%) at Apply level or above (Apply 11, Analyse 15, Evaluate 1, Create 3)"),
 ("Plausible MCQ distractors",
  "Yes - drawn from the same content family as the key: another named farming system, a farming method that is not one of the five, a plausible but wrong reason, and a real fertilizing material that is not organic"),
 ("Single best answer per MCQ",
  "Yes - reviewed item by item; special care with A2, where irrigation is a real method but is not one of the five, and A31, where wood ash is organic and the other three are manufactured"),
 ("Marks internally consistent",
  "Yes - Section A 40 x 1 = 40; Section B 8 + 9 + 9 + 8 + 8 + 8 + 10 = 60; sub-question marks match the marking scheme"),
 ("Total adds up correctly",
  "Yes - 40 + 60 = 100"),
 ("Answer key correct",
  "Yes - all 40 keys and all 20 Section B answers verified against the marking scheme"),
 ("Marking scheme matches questions",
  "Yes - expected answers plus marking notes covering partial credit, alternatives, common wrong answers and method marks; the completion table, the rotation plan and the comparison have explicit marking grids"),
 ("Free from unnecessary ambiguity",
  "Yes - open items are anchored with 'state three', 'name two' and the mark allocation; Question 7(a) numbers every blank (i) to (vi), Question 5(c) requires the name of the system first, and Questions 4(a) and 5(a) warn against the mixed-cropping/mixed-farming swap"),
 ("Ghanaian contexts natural and accurate",
  "Yes - maize, cassava, cocoyam, groundnuts and beans; goats, sheep, cattle and poultry; a maize farmer in the Ashanti Region, a group of farmers near Kumasi, the fallow period, the dry season, neem extract and wood ash, and the bush growing back on abandoned land"),
 ("No content beyond the curriculum",
  "No - Questions 2 to 6 each take one of the five named systems; Question 1 uses exemplar 1 of B7/JHS1.3.4.1.1; Question 7 uses exemplar 3, the comparison and contrast of characteristics"),
 ("Questions sufficiently varied",
  "Yes - definition, listing, explaining a choice, defining and giving problems for each of five systems, planning a rotation, explaining mutual benefit, completing a comparison table, and stating differences between two systems"),
]:
    w("| " + q_ + " | " + a_ + " |")
w("")
w("### EXAMINER NOTES")
w("")
for n_ in [
 "The single most common error in this topic is the swap between MIXED CROPPING (several crops together at the same time) and CROP ROTATION (different crops one after another on the same land). Question 7(b) is written to test exactly that, and the marking note insists that each point must contrast the two systems, not just describe one of them.",
 "The second most common error is the swap between MIXED CROPPING (crops + crops) and MIXED FARMING (crops + animals). Question 5(c) makes pupils name the system before they earn the marks.",
 "Question 3(b) is a design task: a three-season rotation. Award method marks - any sensible order earns credit provided the pupil says WHY the crops are in that order. Putting a legume in the middle is the answer to look for.",
 "Question 7(a) is the comparison table. The six blanks are numbered (i) to (vi), so marking is quick and fair: 1 mark each, and the blank number must be matched to the answer.",
 "Topic weightings are deliberately even here - every system carries 13 to 15 marks - because the indicator asks for the differences AMONG the systems rather than for depth on any one of them. If you want to stress one system, move marks towards Questions 2 to 6.",
 "B7 does not expect the words 'shifting cultivation' or 'slash-and-burn'. Accept them if a pupil offers them, but the expected answer is that the farmer moves on and leaves the land to rest.",
 "If your school has a farm or a garden, walk the class round it before the mock and ask them to classify what they see - that is exemplar 2 of B7/JHS1.3.4.1.2, which asks pupils to group the farming systems prevailing in their own community.",
 "Edit the school name, academic year and examination title on page 1 before printing.",
 "This is an original, teacher-made mock. It is not a reproduction of any WAEC or NaCCA examination paper.",
]:
    w("- " + n_)
w()

open("/home/user/Basic7_Integrated_Science_Mock_Strand3_FarmingSystems.md", "w", encoding="utf-8").write("\n".join(L))
print("md written", len("\n".join(L)), "chars")
