# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "/home/user")
from build_crop import *

from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT

doc = Document()
sec = doc.sections[0]
sec.left_margin = Inches(0.7); sec.right_margin = Inches(0.7)
sec.top_margin = Inches(0.7); sec.bottom_margin = Inches(0.6)

st = doc.styles["Normal"]; st.font.name = "Calibri"; st.font.size = Pt(11)


def set_font(run, size=11, bold=False, italic=False, mono=False, color=None):
    run.font.size = Pt(size); run.bold = bold; run.italic = italic
    run.font.name = "Consolas" if mono else "Calibri"
    if color: run.font.color.rgb = color
    return run


def para(text="", size=11, bold=False, italic=False, align=None, mono=False,
         space_before=0, space_after=4, color=None):
    p = doc.add_paragraph()
    if align == "c": p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    elif align == "j": p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p.paragraph_format.space_before = Pt(space_before)
    p.paragraph_format.space_after = Pt(space_after)
    if text: set_font(p.add_run(text), size, bold, italic, mono, color)
    return p


def rule():
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(6); p.paragraph_format.space_before = Pt(2)
    set_font(p.add_run("_" * 78), 9, color=RGBColor(0x99, 0x99, 0x99))


def add_table(headers, rows, widths=None, size=9, head_size=9):
    t = doc.add_table(rows=1, cols=len(headers)); t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, h in enumerate(headers):
        c = t.rows[0].cells[i]; c.text = ""
        p = c.paragraphs[0]; p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_font(p.add_run(str(h)), head_size, bold=True)
    for row in rows:
        cells = t.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = ""
            p = cells[i].paragraphs[0]; p.paragraph_format.space_after = Pt(1)
            set_font(p.add_run(str(v)), size)
    if widths:
        for r_ in t.rows:
            for i, w in enumerate(widths): r_.cells[i].width = Inches(w)
    return t


def draw_diagram(lines, caption):
    t = doc.add_table(rows=2, cols=1); t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = t.rows[0].cells[0]
    for k, line in enumerate(lines):
        p = cell.paragraphs[0] if k == 0 else cell.add_paragraph()
        p.paragraph_format.space_after = Pt(0); p.paragraph_format.space_before = Pt(0)
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_font(p.add_run(line), 10, mono=True)
    c2 = t.rows[1].cells[0].paragraphs[0]
    c2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_font(c2.add_run(caption), 9, italic=True)
    t.rows[0].cells[0].width = Inches(6.6)
    t.rows[1].cells[0].width = Inches(6.6)


# ============================================================= TITLE BLOCK
para(SCHOOL, size=15, bold=True, align="c", space_after=2)
para(SUBJECT, size=13, bold=True, align="c", space_after=2)
para(EXAM, size=12, bold=True, align="c", space_after=2)
para(YEAR, size=10, italic=True, align="c", space_after=8)

info = doc.add_table(rows=1, cols=3); info.style = "Table Grid"
info.alignment = WD_TABLE_ALIGNMENT.CENTER
for i, v in enumerate([f"Class: {CLASS}", f"Time: {TIME}", f"Total Marks: {MARKS}"]):
    c = info.rows[0].cells[i]; c.text = ""
    set_font(c.paragraphs[0].add_run(v), 10, bold=True)
para("", space_after=6)

para("INSTRUCTIONS", size=11, bold=True, space_after=3)
for txt in [
    "1. Write your name and class clearly in the spaces provided on your answer sheet.",
    "2. This paper has TWO sections: Section A and Section B.",
    "3. Answer ALL the questions in both sections.",
    "4. Section A has 40 multiple-choice questions. Each question carries 1 mark. Choose the best answer "
    "(A, B, C or D) and record it on the answer sheet provided.",
    "5. Section B has 7 theory questions totalling 60 marks. Write your answers clearly and neatly in your "
    "answer booklet. Draw and label diagrams or tables where you are asked to.",
    "6. Read every question carefully before you answer it.",
    "7. Do not use correction fluid. Cancel any mistake neatly with a single line.",
    "8. Hand in your answer sheet and your answer booklet at the end of the examination.",
]:
    para(txt, size=10.5, space_after=2)
rule()

# =============================================================== SECTION A
para("SECTION A - OBJECTIVE TEST (40 marks)", size=12, bold=True, align="c", space_after=2)
para("Answer ALL questions. Each question carries 1 mark. Choose the BEST answer and write its letter "
     "(A, B, C or D) against the question number on your answer sheet.",
     size=10, italic=True, align="c", space_after=8)

for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(1); p.paragraph_format.space_before = Pt(4)
    set_font(p.add_run(f"{i}. {q}"), 10.5)
    for j, o in enumerate(opts):
        p2 = doc.add_paragraph()
        p2.paragraph_format.left_indent = Inches(0.28)
        p2.paragraph_format.space_after = Pt(0); p2.paragraph_format.space_before = Pt(0)
        set_font(p2.add_run(f"{'ABCD'[j]}. {o}"), 10.5)

doc.add_page_break()

# =============================================================== SECTION B
para("SECTION B - THEORY (60 marks)", size=12, bold=True, align="c", space_after=2)
para("Answer ALL questions. Write your answers in your answer booklet. The marks for each question are "
     "shown in brackets.", size=10, italic=True, align="c", space_after=8)

for qb in SECTION_B:
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(8); p.paragraph_format.space_after = Pt(2)
    set_font(p.add_run(f"Question {qb['num']}"), 11, bold=True)
    set_font(p.add_run(f"  [{qb['total']} marks]"), 10, bold=True, italic=True)
    para(qb["stem"], size=10.5, space_after=4)
    if qb.get("table") == "compare":
        add_table(COMPARE_HEADERS, COMPARE_ROWS, widths=[1.6, 2.4, 2.4], size=9, head_size=9)
        para("Table 1: Differences between organic and inorganic plant nutrients", size=9,
             italic=True, align="c", space_after=6)
        para("", space_after=2)
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Inches(0.25)
        p.paragraph_format.space_after = Pt(3); p.paragraph_format.space_before = Pt(2)
        set_font(p.add_run(f"{lab} {text}  "), 10.5)
        set_font(p.add_run(f"[{mk} mark{'s' if mk > 1 else ''}]"), 10, bold=True)

doc.add_page_break()

# ============================================================== ANSWER KEY
para("ANSWER KEY", size=13, bold=True, align="c", space_after=6)
para("SECTION A - OBJECTIVE TEST", size=11, bold=True, space_after=4)
rows = [[i, ans, TOPIC[tp], cog] for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1)]
add_table(["Question", "Answer", "Curriculum Area (Topic)", "Cognitive Level"],
          rows, widths=[0.8, 0.7, 3.6, 1.5], size=9)
counts = {L: sum(1 for q in MCQ if q[2] == L) for L in "ABCD"}
para("", space_after=4)
para("Correct-answer distribution: " + ", ".join(f"{L} = {counts[L]}" for L in "ABCD") + " (30 items).",
     size=9, italic=True)

para("", space_after=8)
para("SECTION B - THEORY (summary answers; see the Marking Scheme for full detail)",
     size=11, bold=True, space_after=4)
sba = [
 ("1 (a)", "Any substance that a plant takes in and uses for its growth and development; it is the plant's "
  "food, taken mainly from the soil, air and water.", "5.1", "Understand"),
 ("1 (b)", "Any three of: to grow tall and produce leaves and stems; to produce a good root system; to "
  "produce flowers, fruits and seeds; to stay healthy and resist disease and drought; to give a dark "
  "green leaf colour.", "5.1", "Understand"),
 ("1 (c)", "Each harvest carries nutrients away in the grain, leaves and stalks, so the soil store gets "
  "smaller; rain also washes nutrients away; they must be replaced or the yield falls.", "5.1", "Analyse"),
 ("2 (a)", "Any three of: poultry manure; cow dung; goat or sheep droppings; compost; green manure; crop "
  "residue; kitchen refuse; wood ash; fish waste; decayed leaves.", "5.2", "Remember"),
 ("2 (b)", "Any three of: NPK 15-15-15; urea; sulphate of ammonia; muriate of potash; single "
  "superphosphate.", "5.2", "Remember"),
 ("2 (c)", "Decide where the material comes from: from the remains of plants and animals = organic; "
  "manufactured or mined = inorganic. Organic material is bulky, dark and rots; inorganic material is "
  "usually dry, clean granules or crystals with the nutrient content printed on the bag.", "5.2",
  "Understand"),
 ("3 (a)", "(i) manufactured from mineral deposits or chemicals; (ii) low, and it varies from heap to "
  "heap; (iii) slow, because soil organisms must break it down first; (iv) little or no humus is added "
  "and long use can make the soil hard; (v) large; (vi) very low - it rarely burns the plant.", "5.3",
  "Understand"),
 ("3 (b)", "NPK is concentrated: each kilogram contains far more nutrient than a kilogram of manure, so "
  "a small volume supplies as much nutrient as a very large volume of poultry manure.", "5.3", "Apply"),
 ("3 (c)", "Organic nutrient source (compost or manure), because it adds humus which binds sandy "
  "particles together and helps the soil hold water, and it improves the soil year after year.", "5.3",
  "Evaluate"),
 ("4 (a)", "Any three of: dry; granules, crystals or powder; small uniform particles; often coloured; "
  "packed in labelled bags; little smell of decay; dissolves readily in water; heavy for its size.",
  "5.4", "Remember"),
 ("4 (b)", "Any three of: dark brown or black; crumbly or powdery; moist; smells of decay; bulky; "
  "contains visible straw, husks or fibre; particles of many sizes; light for its size.", "5.4",
  "Remember"),
 ("4 (c)", "NPK is dry and flows freely, so it can be measured with a tin and placed in a ring or band "
  "beside each plant; because it dissolves quickly it must be covered with soil or rain will wash it "
  "away. Compost is bulky and coarse, so it is spread over the whole bed and mixed into the topsoil, or "
  "used as a mulch.", "5.4", "Apply"),
 ("5 (a)", "Wait until the soil is moist; measure the amount needed; place it in a ring or band about "
  "5-10 cm from the base of each maize plant; cover it with soil; apply it in two or three split doses "
  "during the season.", "5.5", "Understand"),
 ("5 (b)", "Spread it evenly over the whole bed, work it lightly into the topsoil with a hoe or rake "
  "before planting (or round established plants without touching the stem), then water the plot.", "5.5",
  "Understand"),
 ("5 (c)", "Fertilizer against the stem can draw water out of the young tissues and burn the plant; "
  "placing it a few centimetres away puts the nutrient where the feeding roots are; covering it with "
  "soil stops rain and wind from carrying it away before the roots take it up.", "5.5", "Understand"),
 ("6 (a)", "Any three of: hoe or hand fork; rake; bucket or basin; measuring tin or cup; watering can; "
  "string and pegs; gloves; nose mask; boots; notebook and pencil.", "5.6", "Remember"),
 ("6 (b)", "Clear and loosen the bed; mark out the planting positions; measure the compost so every part "
  "gets the same amount; spread it evenly; work it lightly into the topsoil; plant and water well; "
  "record the date and the amount.", "5.6", "Apply"),
 ("6 (c)", "Any four of: date; bed or plot name; what was applied and how much; plant height measured at "
  "regular intervals; number of leaves or leaf colour; yield (number or mass harvested); other "
  "observations; a comparison bed with no compost; space for comments.", "5.6", "Create"),
 ("7 (a)", "Use beds of the same size, soil and place; plant the same crop at the same spacing on the "
  "same day; give the same water, weeding and care; change only the type of nutrient; keep one bed with "
  "no nutrient as a control.", "5.6", "Create"),
 ("7 (b)", "Any two of: plant height measured at the same time; leaf colour; number of leaves; how "
  "quickly plants flower or fruit; number or mass of the crop harvested.", "5.6", "Evaluate"),
]
add_table(["Question", "Expected Answer", "Curriculum Area", "Cognitive Level"],
          [list(r) for r in sba], widths=[0.8, 4.2, 1.2, 1.2], size=9)

doc.add_page_break()

# =========================================================== MARKING SCHEME
para("MARKING SCHEME - SECTION B (60 marks)", size=13, bold=True, align="c", space_after=4)
para("General rules: (1) Accept any other correct and relevant answer. (2) Award marks for correct points, "
     "not for repeating the question. (3) For procedures, award method marks. (4) Do not deduct marks for "
     "spelling unless the meaning is changed. (5) Where a candidate gives more answers than are asked for, "
     "mark only the first ones up to the number required.",
     size=9.5, italic=True, space_after=8)

for qb in SECTION_B:
    n = qb["num"]
    para(f"Question {n}  ({qb['total']} marks)", size=11, bold=True, space_before=8, space_after=3)
    for (lab, points, note) in MARKING[n]:
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(2)
        set_font(p.add_run(f"{lab} "), 10.5, bold=True)
        mkv = [p_[2] for p_ in qb["parts"] if p_[0] == lab]
        if mkv: set_font(p.add_run(f"[{mkv[0]} mark{'s' if mkv[0] > 1 else ''}]"), 10, bold=True)
        for pt in points:
            pp = doc.add_paragraph()
            pp.paragraph_format.left_indent = Inches(0.35); pp.paragraph_format.space_after = Pt(1)
            set_font(pp.add_run("- " + pt), 10.5)
        pp = doc.add_paragraph()
        pp.paragraph_format.left_indent = Inches(0.35); pp.paragraph_format.space_after = Pt(6)
        set_font(pp.add_run("Marking note: " + note), 9.5, italic=True)

doc.add_page_break()

# ================================================================ BLUEPRINT
para("CURRICULUM ASSESSMENT BLUEPRINT", size=13, bold=True, align="c", space_after=3)
para(f"Strand: {STRAND}   |   Sub-strand: {SUBSTRAND}   |   Class: {CLASS}",
     size=10, italic=True, align="c", space_after=3)
para(f"Content Standard: {CS} - {CS_TEXT}", size=9, italic=True, align="c", space_after=3)
para("Source: NaCCA Science Common Core Programme Curriculum (B7/JHS1-B9/JHS3), September 2020, "
     "Strand 2: Cycles, Sub-strand 3: Crop Production, p. 11. Indicators are quoted, not invented.",
     size=9, italic=True, space_after=8)

hdr = ["Qn", "Sub-strand", "Content Standard", "Indicator (NaCCA) - Indicator Text", "Topic / Content",
       "Cognitive Level", "Marks"]

rows = [[f"A{i}", SUBSTRAND, CS, f"{IND[tp]} - {IND_TEXT[tp]}", TOPIC[tp], cog, 1]
        for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1)]
add_table(hdr, rows, widths=[0.35, 0.75, 0.75, 1.75, 1.4, 0.8, 0.35], size=7, head_size=7.5)

para("", space_after=8)
rows = []
for qb in SECTION_B:
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        key = tp if tp in TOPIC else tp.split(",")[0].strip()
        rows.append([f"B{qb['num']}{lab.strip('()')}", SUBSTRAND, CS,
                     f"{IND[key]} - {IND_TEXT[key]}", TOPIC[key], cog, mk])
add_table(hdr, rows, widths=[0.35, 0.75, 0.75, 1.75, 1.4, 0.8, 0.35], size=7, head_size=7.5)

doc.add_page_break()

# ----------------------------------------------------------------- helpers
def topic_totals():
    m = {k: 0 for k in TOPIC}; it = {k: 0 for k in TOPIC}
    for q in MCQ:
        m[q[3]] += 1; it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk; it[key] += 1
    return m, it

def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}; b = {k: 0 for k in order}
    for q in MCQ: a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: b[cog] += mk
    return order, a, b

def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ: d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: d[diff] += mk
    return d

m, it = topic_totals(); diff = difficulty_totals(); order, ca, cb = cognitive_by_section()

para("SUMMARY 1 - COVERAGE BY CURRICULUM AREA (TOPIC)", size=12, bold=True, space_after=4)
rows = [[TOPIC[k], it[k], m[k], f"{(m[k]/100)*100:.1f}%", CC[k]] for k in TOPIC]
rows.append(["TOTAL", sum(it.values()), sum(m.values()), "100%", "-"])
add_table(["Topic / Content Area", "No. of Items", "Marks", "% of Total Marks", "Core Competencies"],
          rows, widths=[2.7, 0.8, 0.6, 1.0, 1.1], size=8.5)
para("CC = Communication and Collaboration; CP = Critical Thinking and Problem Solving; "
     "DL = Digital Literacy; CI = Creativity and Innovation.", size=8.5, italic=True, space_after=2)

para("", space_after=8)
para("SUMMARY 2 - COGNITIVE-LEVEL DISTRIBUTION (Bloom's Taxonomy)", size=12, bold=True, space_after=4)
rows = []
for lv in order:
    tot = ca[lv] + cb[lv]
    rows.append([lv, ca[lv], cb[lv], tot, f"{(tot/100)*100:.1f}%"])
rows.append(["TOTAL", sum(ca.values()), sum(cb.values()), sum(ca.values()) + sum(cb.values()), "100%"])
add_table(["Cognitive Level", "Section A Marks", "Section B Marks", "Total Marks", "% of Total"],
          rows, widths=[1.6, 1.3, 1.3, 1.1, 1.1], size=9.5)

para("", space_after=8)
para("SUMMARY 3 - DIFFICULTY DISTRIBUTION", size=12, bold=True, space_after=4)
rows = [[k, v, f"{(v/100)*100:.1f}%"] for k, v in diff.items()]
rows.append(["TOTAL", sum(diff.values()), "100%"])
add_table(["Difficulty", "Marks", "% of Total Marks"], rows, widths=[2.0, 1.2, 1.5], size=9.5)
para("Target in the master prompt: approximately 30% easy / 50% moderate / 20% challenging.",
     size=9, italic=True, space_after=2)

para("", space_after=8)
para("SUMMARY 4 - SECTION WEIGHTING", size=12, bold=True, space_after=4)
add_table(["Section", "Question Type", "Items", "Marks", "% of Total"],
          [["A", "Objective (multiple choice)", 40, 40, "40%"],
           ["B", "Theory / constructed response", 20, 60, "60%"],
           ["TOTAL", "-", 60, 100, "100%"]],
          widths=[0.9, 2.4, 0.8, 0.8, 1.0], size=9.5)

doc.add_page_break()

# ===================================================== QUALITY-CONTROL
para("QUALITY-CONTROL SUMMARY", size=13, bold=True, align="c", space_after=4)
para("Carried out against the 14-point validation list in the master prompt before the examination was "
     "finalised.", size=9.5, italic=True, space_after=8)

qc = [
 ("Does every question belong to the supplied curriculum scope?",
  "Yes. All 46 items trace to Strand 2 (Cycles), Sub-Strand 3 (Crop Production), topics 5.1-5.6, and to "
  "the two official B7 indicators (B7/JHS1.2.3.1.1 and B7/JHS1.2.3.1.2). Irrigation, pest control, "
  "propagation and soil formation appear only as distractors, never as things pupils must answer on."),
 ("Is the examination appropriate for the stated class?",
  "Yes. The B7 curriculum requires learners to list community nutrient sources, sort them into organic "
  "and inorganic, tabulate the differences, compare the volumes needed, describe physical "
  "characteristics and application, and demonstrate application in a school garden. No micronutrient "
  "chemistry, no fertilizer-formula calculation and no NPK ratio arithmetic are tested, as these fall "
  "outside the B7 indicator."),
 ("Are the questions genuinely BECE-style?",
  "Yes: Section A is 40 four-option objectives worth 1 mark each, and Section B is structured theory "
  "with sub-questions carrying printed mark allocations. Question 3 uses a table for pupils to "
  "complete, matching the BECE science convention and the indicator's own exemplar 1, which asks "
  "learners to create a table of differences."),
 ("Are there enough application and reasoning questions?",
  "Yes. 30 of 100 marks (30%) are at Apply level or above (Apply 14, Analyse 5, Evaluate 4, Create 7). "
  "Create is well represented because the exemplars ask pupils to create a table, compare volumes, "
  "design a record sheet and set up a fair comparison in the school garden."),
 ("Are the MCQ distractors plausible?",
  "Yes. Distractors are drawn from the same content family as the key: the other nutrient category "
  "(A7-A13), the other nutrient element (A3, A4), the wrong application method (A28, A30, A34), and "
  "plausible but wrong timings (A31, A37)."),
 ("Is there only one best answer for each MCQ?",
  "Yes. Every item was reviewed for a single defensible key. Special care was taken with A2, where "
  "carbon, hydrogen and oxygen are indeed needed in large amounts, so the stem asks specifically for the "
  "three most often supplied in fertilizers."),
 ("Are the marks internally consistent?",
  "Yes. Section A = 40 items x 1 mark = 40. Section B = 8 + 9 + 10 + 9 + 9 + 10 + 5 = 60. "
  "Each Section B sub-question's printed marks match its marking-scheme allocation."),
 ("Does the total add up correctly?",
  "Yes: 40 + 60 = 100 marks, matching the stated total on the front page."),
 ("Are the answers in the answer key correct?",
  "Yes. All 40 objective keys and all 20 Section B answers were verified against the marking scheme."),
 ("Does the marking scheme match the questions?",
  "Yes. Every Section B sub-question has an expected-answer list and a marking note covering partial "
  "credit, acceptable alternatives, common wrong answers and method marks. The two design tasks "
  "(Question 6(c), 4 marks, and Question 7(a), 3 marks) have opening marking grids so they can be "
  "marked consistently across a class."),
 ("Are the questions free from unnecessary ambiguity?",
  "Yes. Open items are anchored with 'state three', 'name two' and the mark allocation. Question 3(a) "
  "numbers every blank (i) to (vi), so there is no doubt which answer belongs where."),
 ("Are Ghanaian contexts used naturally and accurately?",
  "Yes: maize, garden eggs, pepper, cocoa husks, poultry manure, NPK 15-15-15 and sulphate of ammonia "
  "under its local trade name, chop-bar and market fish waste, the harmattan, and a school garden bed "
  "marked out with string and pegs. Question 6 and Question 7 are set in the pupils' own school "
  "garden, as the indicator requires."),
 ("Has any content outside the supplied curriculum been introduced?",
  "No. Every item sits inside topics 5.1-5.6. Question 3 is built on the tabular comparison asked for "
  "in exemplar 1 and the volume comparison in exemplar 2; Question 7 repeats that volume comparison as "
  "a practical fair test; Question 6 is exemplar 3, the practical application itself."),
 ("Are the questions sufficiently varied?",
  "Yes. Item types include definition, listing and classification, completing a comparison table, "
  "explaining concentration and volume, describing physical characteristics, linking form to method of "
  "application, describing field method, designing a record sheet, and designing a fair test."),
]
for i, (q, a) in enumerate(qc, start=1):
    p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(2)
    set_font(p.add_run(f"{i}. {q}"), 10.5, bold=True)
    p2 = doc.add_paragraph()
    p2.paragraph_format.left_indent = Inches(0.3); p2.paragraph_format.space_after = Pt(6)
    set_font(p2.add_run(a), 10)

para("", space_after=8)
para("EXAMINER NOTES (for the teacher, not for candidates)", size=11, bold=True, space_after=4)
for n in [
 "Question 3(a) is the 'create a table' exemplar (B7/JHS1.2.3.1.1, Ex. 1) turned into a completion "
 "task. The six blanks are numbered (i) to (vi) so marking is quick and fair: 1 mark each, and the "
 "blank number must be matched to the answer.",
 "Question 7 is the volume-comparison exemplar (B7/JHS1.2.3.1.1, Ex. 2) set up as a fair test. The "
 "thing to look for is the principle that only the type of nutrient changes - same bed size, same crop, "
 "same spacing, same water and a control bed.",
 "Question 6 is the practical-application exemplar (B7/JHS1.2.3.1.2, Ex. 3). If your school has a "
 "garden, run Question 6 and Question 7 as real activities before the mock, and accept what pupils "
 "actually did as evidence in the answers.",
 "Topic 5.6 carries 21 of 100 marks (21%), the highest weighting, because the indicator ends in "
 "practical application. If you want a flatter spread, move marks from Questions 6 and 7 to Questions "
 "1 and 2.",
 "A6 and A20 deliberately avoid any calculation. An NPK bag's figures (A24) are tested as labels to "
 "read, not as numbers to work with - that is the B7 limit.",
 "If you supply real bags or samples of compost, manure and NPK during revision, pupils handle A21 to "
 "A27 far better, since those items are about what the material looks and feels like.",
 "Safety note for any practical follow-up: gloves, hand washing, no eating in the garden, and no "
 "handling of fertilizer dust without supervision. Do not let pupils taste or smell fertilizers.",
 "Edit the school name, academic year and examination title on page 1 before printing.",
 "This is an original, teacher-made mock. It is not a reproduction of any WAEC or NaCCA examination "
 "paper.",
]:
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Inches(0.3); p.paragraph_format.space_after = Pt(3)
    set_font(p.add_run("- " + n), 10)

doc.save("/home/user/Basic7_Integrated_Science_Mock_Strand2_CropProduction.docx")
print("docx written")

print("Section A:", len(MCQ), "items")
print("Section B total:", sum(q["total"] for q in SECTION_B))
print("Topic marks:", m, "sum", sum(m.values()))
print("Difficulty:", diff, "sum", sum(diff.values()))
print("Cognitive A:", ca)
print("Cognitive B:", cb)
print("Answer counts:", counts)
print("Totals:", sum(m.values()), sum(diff.values()),
      sum(ca.values()) + sum(cb.values()))
