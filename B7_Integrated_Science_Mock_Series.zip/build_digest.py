# -*- coding: utf-8 -*-
"""Basic 7 Integrated Science mock - Strand 3 Sub-strand 1: THE HUMAN BODY SYSTEM (Digestion). 100 marks.
Indicators sourced from the official NaCCA Science CCP curriculum (B7/JHS1-B9/JHS3, Sept 2020),
Strand 3: Systems, Sub-strand 1: The Human Body System, printed pages 16-18."""

SCHOOL = "[SCHOOL NAME]"
SUBJECT = "INTEGRATED SCIENCE (SCIENCE)"
EXAM = "END-OF-TERM MOCK EXAMINATION"
CLASS = "Basic 7 (JHS 1)"
TIME = "2 hours (Suggested: Section A - 40 min; Section B - 80 min)"
MARKS = "100"
YEAR = "2025/2026 Academic Year"

STRAND = "Systems"
SUBSTRAND = "The Human Body System"

TOPIC = {
    "7.1": "7.1 What is Food? Nutrients and Their Importance",
    "7.2": "7.2 Why Humans Need to Eat",
    "7.3": "7.3 The Digestive System: Parts of the Alimentary Canal",
    "7.4": "7.4 What Happens to Food at Each Stage of Digestion",
    "7.5": "7.5 End Products of Digestion: Starch, Protein and Fats",
    "7.6": "7.6 Absorption of Digested Food in the Small Intestine",
    "7.7": "7.7 Food Tests: Starch, Glucose, Protein, Fats and Oils",
}

CS = "B7/JHS1.3.1.1"
CS_BY_TOPIC = {k: "B7/JHS1.3.1.1" for k in ["7.1", "7.2", "7.3", "7.4",
                                                    "7.5", "7.6", "7.7"]}
CS_TEXT = "Show an understanding of the concept of food, and the process of digestion and appreciate its " \
          "importance in humans"

IND = {
    "7.1": "B7/JHS1.3.1.1.1 (Ex. 1)",
    "7.2": "B7/JHS1.3.1.1.1 (Ex. 2, 3)",
    "7.3": "B7/JHS1.3.1.1.2 (Ex. 1, 3)",
    "7.4": "B7/JHS1.3.1.1.2 (Ex. 2)",
    "7.5": "B7/JHS1.3.1.1.3 (Ex. 2)",
    "7.6": "B7/JHS1.3.1.1.3 (Ex. 1)",
    "7.7": "B7/JHS1.3.1.1.3 (Ex. 3)",
}
IND_TEXT = {
    "7.1": "Explain what food is, name the nutrients found in food, and deduce its definition.",
    "7.2": "Compare the appearance of people who have been starved with those who have been eating and "
           "look healthy and strong; deduce the importance of feeding in humans.",
    "7.3": "Identify the parts of the alimentary canal in a drawing of the digestive system; draw and "
           "label the digestive system of humans.",
    "7.4": "Research and describe what happens to food e.g. a piece of boiled yam / cassava / plantain / "
           "cocoyam / bread, egg, meat, orange, palm oil when it gets into the mouth, stomach, large and "
           "small intestines.",
    "7.5": "Draw a flow chart to show that starch is digested to sugar, protein is digested to amino "
           "acids and oils are digested into fatty acids.",
    "7.6": "Observe and describe how digested food is absorbed into the body of humans.",
    "7.7": "Perform practical tests on food: starch, glucose, protein and fats and oils.",
}
CC = {
    "7.1": "DL, CP", "7.2": "DL, CP", "7.3": "DL, CP, CC, CI", "7.4": "DL, CP, CC, CI",
    "7.5": "DL, CP, CC, CI, PL", "7.6": "DL, CP, CC, CI, PL", "7.7": "DL, CP, CC, CI, PL",
}

# ---------------------------------------------------------------- SECTION A
# (question, [A,B,C,D], answer, topic, cognitive, difficulty)
MCQ = [
 ("Food is best described as",
  ["any solid thing that can be chewed", "any liquid that can be drunk",
   "any substance a living thing takes in that provides nutrients for growth, energy and health",
   "any substance that tastes sweet"],
  "C", "7.1", "Understand", "Easy"),
 ("Which of the following lists contains ONLY nutrients found in food?",
  ["carbohydrate, protein, fat, vitamins", "soil, water, air, sunlight",
   "rice, yam, plantain, maize", "sugar, pepper, salt, gari"],
  "A", "7.1", "Remember", "Easy"),
 ("The nutrient that provides the body with most of its energy is",
  ["protein", "vitamins", "mineral salts", "carbohydrate"],
  "D", "7.1", "Understand", "Easy"),
 ("The nutrient needed mainly for growth and for the repair of worn-out body parts is",
  ["carbohydrate", "protein", "water", "vitamins"],
  "B", "7.1", "Understand", "Easy"),
 ("Which of the following foods is the best source of starch?",
  ["egg", "palm oil", "gari", "sugar"], "C", "7.1", "Apply", "Challenging"),
 ("Vitamins and mineral salts are needed in small amounts mainly to",
  ["keep the body healthy and protect it from disease", "give the body most of its energy",
   "build the muscles", "keep the body warm only"],
  "A", "7.1", "Understand", "Easy"),
 ("A person who has not eaten well for a long time is most likely to look",
  ["fat and strong", "tall and heavy", "dark and oily", "thin and weak"],
  "D", "7.2", "Understand", "Easy"),
 ("The main reason why human beings need to eat is to",
  ["pass the time", "get energy and materials for growth and repair",
   "grow tall very quickly", "keep the mouth busy"],
  "B", "7.2", "Understand", "Easy"),
 ("Which of these is NOT a reason why human beings need food?",
  ["to provide energy", "to build and repair the body", "to make the heart beat faster",
   "to protect the body against disease"],
  "C", "7.2", "Understand", "Moderate"),
 ("A child who does not get enough of the right food may",
  ["fall sick often and grow slowly", "grow taller than other children",
   "become stronger than other children", "never feel hungry again"],
  "A", "7.2", "Understand", "Easy"),
 ("Which of these best shows the importance of eating the right kind of food?",
  ["a girl who eats only sugar grows very fast", "a boy who eats only rice never falls sick",
   "a child who eats a lot of one food is always healthy",
   "a child who eats a variety of foods grows well and stays healthy"],
  "D", "7.2", "Evaluate", "Moderate"),
 ("Which of the following gives the correct order of the parts of the alimentary canal?",
  ["mouth -> oesophagus -> small intestine -> stomach -> large intestine",
   "mouth -> oesophagus -> stomach -> small intestine -> large intestine",
   "mouth -> stomach -> oesophagus -> small intestine -> large intestine",
   "stomach -> mouth -> small intestine -> large intestine -> oesophagus"],
  "B", "7.3", "Remember", "Moderate"),
 ("Food is pushed down the oesophagus by",
  ["the force of gravity alone", "the beating of the heart",
   "the wave-like squeezing of the muscles in its wall", "the air we breathe in"],
  "C", "7.3", "Understand", "Moderate"),
 ("Which of these is NOT part of the alimentary canal?",
  ["liver", "stomach", "small intestine", "large intestine"],
  "A", "7.3", "Understand", "Moderate"),
 ("The part of the alimentary canal where most of the water is absorbed is the",
  ["stomach", "mouth", "oesophagus", "large intestine"],
  "D", "7.3", "Understand", "Moderate"),
 ("Saliva is produced in the",
  ["stomach", "mouth", "liver", "small intestine"],
  "B", "7.3", "Remember", "Easy"),
 ("Faeces are stored in the rectum and then leave the body through the",
  ["stomach", "small intestine", "anus", "liver"],
  "C", "7.3", "Understand", "Easy"),
 ("In the mouth, food is",
  ["chewed into small pieces and mixed with saliva", "digested completely",
   "absorbed into the blood", "turned into faeces"],
  "A", "7.4", "Understand", "Easy"),
 ("Saliva begins the digestion of",
  ["protein", "fats and oils", "vitamins", "starch"],
  "D", "7.4", "Understand", "Moderate"),
 ("In the stomach the food is",
  ["absorbed into the blood", "churned and mixed with gastric juice",
   "turned into faeces", "breathed out"],
  "B", "7.4", "Understand", "Easy"),
 ("The digestion of protein begins in the",
  ["mouth", "oesophagus", "stomach", "large intestine"],
  "C", "7.4", "Understand", "Moderate"),
 ("Bile is made by the liver and helps in the digestion of",
  ["fats and oils", "starch", "protein", "vitamins"],
  "A", "7.4", "Understand", "Moderate"),
 ("The part of the alimentary canal where digestion is completed is the",
  ["mouth", "stomach", "large intestine", "small intestine"],
  "D", "7.4", "Understand", "Moderate"),
 ("A pupil swallows a piece of meat without chewing it. The most likely result is that",
  ["it is digested faster",
   "it is digested more slowly, because there is less surface for the juices to act on",
   "it is absorbed in the mouth", "nothing at all happens to it"],
  "B", "7.4", "Apply", "Challenging"),
 ("Starch is finally digested to",
  ["amino acids", "fatty acids and glycerol", "simple sugars such as glucose", "vitamins"],
  "C", "7.5", "Remember", "Moderate"),
 ("Protein is finally digested to",
  ["amino acids", "glucose", "fatty acids", "starch"],
  "A", "7.5", "Remember", "Moderate"),
 ("Fats and oils are finally digested to",
  ["glucose", "starch", "amino acids", "fatty acids and glycerol"],
  "D", "7.5", "Remember", "Moderate"),
 ("A food sample is digested to amino acids. The food must have been rich in",
  ["starch", "protein", "sugar", "oil"], "B", "7.5", "Apply", "Challenging"),
 ("Food must be digested before the body can use it because",
  ["food tastes better after digestion", "the blood can only carry solids",
   "the food molecules are too large to pass through the wall of the intestine into the blood",
   "digestion makes the food heavier"],
  "C", "7.5", "Analyse", "Challenging"),
 ("A pupil eats gari and beans. The end products of digestion will include",
  ["glucose and amino acids", "amino acids only", "fatty acids only", "starch and protein"],
  "A", "7.5", "Apply", "Challenging"),
 ("Digested food is absorbed mainly through the wall of the",
  ["stomach", "oesophagus", "large intestine", "small intestine"],
  "D", "7.6", "Understand", "Easy"),
 ("The tiny finger-like structures on the inner wall of the small intestine that absorb digested food "
  "are the",
  ["veins", "villi", "glands", "muscles"], "B", "7.6", "Remember", "Moderate"),
 ("After absorption, the digested food is carried away by the",
  ["nerves", "bones", "blood", "air we breathe"],
  "C", "7.6", "Understand", "Easy"),
 ("The small intestine absorbs digested food quickly mainly because",
  ["its inner wall has many villi, which give it a very large surface area",
   "it is very short", "it has a very thick wall", "it contains no blood vessels"],
  "A", "7.6", "Analyse", "Challenging"),
 ("The part of the food that cannot be digested passes into the",
  ["stomach", "mouth", "liver", "large intestine"],
  "D", "7.6", "Understand", "Easy"),
 ("The reagent used to test for starch is",
  ["Benedict's solution", "iodine solution", "Biuret solution", "lime water"],
  "B", "7.7", "Remember", "Easy"),
 ("The positive result for starch with iodine solution is",
  ["a brick-red precipitate", "a violet colour", "a blue-black colour", "no change"],
  "C", "7.7", "Remember", "Moderate"),
 ("To test for glucose, a pupil adds Benedict's solution and heats the mixture in a water bath. A "
  "positive result is",
  ["a brick-red precipitate", "a blue-black colour", "a violet colour", "no change"],
  "A", "7.7", "Remember", "Moderate"),
 ("A food sample is tested and turns violet (purple). The food contains",
  ["starch", "glucose", "fat", "protein"], "D", "7.7", "Apply", "Moderate"),
 ("A pupil rubs a food sample on a piece of paper and a translucent (see-through) spot is left. This "
  "shows that the food contains",
  ["starch", "fat or oil", "protein", "glucose"], "B", "7.7", "Apply", "Challenging"),
]

# ------------------------------------------------- SECTION B DIAGRAM (Q3)
DIGESTIVE_SYSTEM = [
 "   1   +-------------+",
 "       |    MOUTH    |    teeth chew the food; saliva mixes with it",
 "       +-------------+",
 "              |",
 "   2          |    OESOPHAGUS (gullet): the food is pushed downwards",
 "              |",
 "       +-------------+",
 "   3   |   STOMACH   |    the food is churned with gastric juice",
 "       +-------------+",
 "              |",
 "   4          |    SMALL INTESTINE: digestion is finished here and",
 "              |    the digested food is absorbed into the blood",
 "              |",
 "       +-------------+",
 "   5   |    LARGE    |    water is absorbed; the faeces are formed",
 "       |  INTESTINE  |",
 "       +-------------+",
 "              |",
 "         rectum and anus",
]

# --------------------------------------------------- SECTION B TABLES (Q5, Q7)
END_HEADERS = ["Food digested", "End product of digestion"]
END_ROWS = [
 ["Starch (for example boiled yam, rice, bread, gari)", "(i)"],
 ["Protein (for example egg, meat, fish, beans)", "(ii)"],
 ["Fats and oils (for example palm oil, groundnut oil, margarine)", "(iii)"],
]

TEST_HEADERS = ["Food substance tested for", "Reagent or method used", "Positive result"]
TEST_ROWS = [
 ["Starch", "iodine solution", "(i)"],
 ["Glucose", "(ii)", "a brick-red precipitate after heating"],
 ["Protein", "Biuret solution (or sodium hydroxide and copper(II) sulphate solution)", "(iii)"],
 ["Fats and oils", "(iv)", "a translucent (see-through) spot is left on the paper"],
]

# ---------------------------------------------------------------- SECTION B
SECTION_B = [
 dict(
   num=1, total=8, topic="7.1",
   stem="Everything a person eats and drinks that keeps the body alive and healthy is called food.",
   parts=[
     ("(a)", "Explain what is meant by food, and name the nutrients found in food.",
      3, "Understand", "7.1", "Easy"),
     ("(b)", "State three importance of the nutrients in food to the human body.",
      3, "Understand", "7.1", "Easy"),
     ("(c)", "A pupil says that a soft drink is a food because it contains sugar. Do you agree? Give a "
             "reason for your answer.", 2, "Evaluate", "7.1", "Moderate"),
   ]),
 dict(
   num=2, total=9, topic="7.2",
   stem="The curriculum asks pupils to compare the appearance of people who have been starved with "
        "those who have been eating well.",
   parts=[
     ("(a)", "Describe how the appearance of a person who has not eaten well for a long time differs "
             "from that of a healthy, well-fed person.", 3, "Analyse", "7.2", "Moderate"),
     ("(b)", "State three reasons why human beings need to eat.", 3, "Understand", "7.2", "Easy"),
     ("(c)", "Explain why a child who does not get enough of the right food may fall sick often and "
             "not grow well.", 3, "Analyse", "7.2", "Challenging"),
   ]),
 dict(
   num=3, total=10, topic="7.3",
   stem="The diagram below shows the human digestive system. Study it and answer the questions that "
        "follow.",
   diagram=True,
   parts=[
     ("(a)", "Name the parts labelled 1, 2, 3, 4 and 5.", 5, "Remember", "7.3", "Easy"),
     ("(b)", "Name two organs that help with digestion but are NOT part of the alimentary canal, and "
             "say what each of them does.", 2, "Understand", "7.3", "Moderate"),
     ("(c)", "State three things that happen to the food in the part labelled 3.",
      3, "Understand", "7.3", "Moderate"),
   ]),
 dict(
   num=4, total=9, topic="7.4",
   stem="A pupil eats a piece of boiled yam with some meat and a little palm oil.",
   parts=[
     ("(a)", "Describe what happens to the yam in the mouth.", 3, "Understand", "7.4", "Moderate"),
     ("(b)", "Describe what happens to the food in the stomach.", 3, "Understand", "7.4", "Moderate"),
     ("(c)", "Explain what would happen to the digestion of the meat if the pupil swallowed it without "
             "chewing it properly.", 3, "Apply", "7.4", "Challenging"),
   ]),
 dict(
   num=5, total=8, topic="7.5",
   stem="The class was asked to draw a flow chart showing what starch, protein and oils are finally "
        "digested into. Study the incomplete table below and answer the questions that follow.",
   table="endproducts",
   parts=[
     ("(a)", "Copy and complete the table.", 3, "Understand", "7.5", "Moderate"),
     ("(b)", "Name one food that would give the end product in (ii), and state one use the body makes "
             "of that end product.", 2, "Apply", "7.5", "Moderate"),
     ("(c)", "Explain why food must be digested before the body can use it.",
      3, "Analyse", "7.5", "Challenging"),
   ]),
 dict(
   num=6, total=9, topic="7.6",
   stem="Digested food has to get from the small intestine into the body before it can be used.",
   parts=[
     ("(a)", "Describe how the digested food gets from the small intestine into the blood.",
      3, "Understand", "7.6", "Moderate"),
     ("(b)", "Explain how the small intestine is adapted to absorb digested food quickly.",
      3, "Analyse", "7.6", "Challenging"),
     ("(c)", "State what happens to the part of the food that cannot be digested, and where this "
             "happens.", 3, "Understand", "7.6", "Moderate"),
   ]),
 dict(
   num=7, total=7, topic="7.7",
   stem="Your class is about to carry out practical tests on food.",
   table="foodtests",
   parts=[
     ("(a)", "Copy and complete the table of food tests.", 4, "Understand", "7.7", "Moderate"),
     ("(b)", "Design a plan your class could follow to test three food samples - gari, beans and palm "
             "oil - for starch, protein and fat. Say what you would do, what you would expect to see "
             "for each, and give one safety precaution.", 3, "Create", "7.7", "Challenging"),
   ]),
]

# ------------------------------------------------------- MARKING SCHEME
MARKING = {
 1: [
   ("(a)", ["Food is any substance, solid or liquid, that a living thing takes in and that provides "
            "nutrients for growth, energy and health.",
            "It is anything eaten or drunk that keeps the body alive, healthy and able to work.",
            "The nutrients found in food are carbohydrates, proteins, fats and oils, vitamins, "
            "mineral salts and water."],
    "1 mark for a correct definition of food and 1 mark each for any TWO nutrients correctly named "
    "(3 marks). Accept 'roughage/fibre' as a nutrient. Do NOT accept a named dish such as 'rice' as a "
    "nutrient."),
   ("(b)", ["To provide energy for work, play, warmth and all body activities.",
            "To build the body and repair worn-out or damaged parts (growth).",
            "To protect the body against disease and keep it healthy.",
            "To keep the body warm.",
            "To provide water, which the body needs for all its processes."],
    "1 mark each for any THREE correct importance (3 marks). Do NOT award three marks for the same "
    "point worded three times, e.g. 'energy, energy, energy'."),
   ("(c)", ["Yes, in part: a soft drink supplies sugar, which gives the body energy, so it is a source "
            "of a nutrient.",
            "But it is not a complete food, because it contains only sugar and water and no protein, "
            "fat, vitamins or mineral salts.",
            "A person cannot stay healthy on soft drinks alone."],
    "1 mark for a clear decision (yes, in part / no, not on its own) and 1 mark for the reason "
    "(2 marks). Accept either view if the reason is sound: the point is that a nutrient is not the "
    "same as a complete food."),
 ],
 2: [
   ("(a)", ["The person who has not eaten well looks thin, with the ribs and bones showing, because "
            "the body has used up its stored fat and muscle.",
            "She looks weak and tired, and has little energy for work or play.",
            "Her skin may look dry and pale, and her hair may lose its colour and sheen.",
            "A child who has been starved may have a swollen belly.",
            "The well-fed person looks well covered, with firm muscles, bright eyes and healthy skin, "
            "and she is active and strong."],
    "1 mark each for any THREE correct differences (3 marks). The answer must say something about both "
    "appearances to earn full marks; award at most 2 marks if only the starved person is described."),
   ("(b)", ["To give the body energy for everything it does.",
            "To build the body and to repair worn-out parts.",
            "To help the body to grow.",
            "To keep the body healthy and protect it from disease.",
            "To keep the body warm."],
    "1 mark each for any THREE correct reasons (3 marks). Accept 'so that we do not die' once."),
   ("(c)", ["Without enough food the body has no energy, so the child is weak and cannot fight disease.",
            "Without the right nutrients the body cannot build new tissue, so the child grows slowly "
            "or stops growing.",
            "A lack of vitamins and mineral salts lowers the body's protection against disease, so the "
            "child falls sick often.",
            "The child's body may begin to use up its own muscle and fat, which makes the child thin "
            "and weaker still.",
            "Poor feeding also makes a child too tired to learn and play well."],
    "1 mark each for any THREE correct points (3 marks). The key ideas are: no energy, no material for "
    "growth and repair, and less protection against disease."),
 ],
 3: [
   ("(a)", ["1 = mouth", "2 = oesophagus (gullet)", "3 = stomach", "4 = small intestine",
            "5 = large intestine"],
    "1 mark each for all FIVE parts correctly named (5 marks). The number must be matched to the "
    "correct part. Accept 'gullet' for 2."),
   ("(b)", ["The liver: it makes bile, which helps with the digestion of fats and oils.",
            "The pancreas: it makes pancreatic juice, which helps to digest starch, protein and fat.",
            "The salivary glands: they make saliva, which moistens the food and begins the digestion "
            "of starch."],
    "1 mark each for any TWO organs correctly named with what each does (2 marks). Do NOT accept the "
    "stomach or the intestines, because they are part of the alimentary canal."),
   ("(c)", ["The food is churned and squeezed by the muscular walls of the stomach.",
            "It is mixed with gastric juice, which is acidic.",
            "The digestion of protein begins in the stomach.",
            "The food is turned into a thick, semi-liquid mass.",
            "It is then released a little at a time into the small intestine."],
    "1 mark each for any THREE correct points (3 marks). Accept plain wording such as 'the food is "
    "squeezed and mixed with juice'."),
 ],
 4: [
   ("(a)", ["The teeth cut and chew the yam into small pieces (physical breakdown).",
            "The small pieces give a larger surface for the digestive juices to act on.",
            "Saliva mixes with the yam to moisten it and make it easy to swallow.",
            "The saliva begins to digest the starch in the yam into sugar.",
            "The tongue rolls the chewed yam into a ball so that it can be swallowed."],
    "1 mark each for any THREE correct points (3 marks). The key ideas are chewing, mixing with "
    "saliva, and the start of starch digestion."),
   ("(b)", ["The food is churned and squeezed by the muscular walls of the stomach.",
            "It is mixed with gastric juice.",
            "The digestion of the protein in the meat begins here.",
            "The food becomes a thick, semi-liquid mass.",
            "It is released a little at a time into the small intestine."],
    "1 mark each for any THREE correct points (3 marks). Accept 'the food is mixed with acid and "
    "juices'."),
   ("(c)", ["The meat would be digested more slowly, because the pieces are large and there is less "
            "surface for the gastric juice and other juices to act on.",
            "Large pieces take longer to break down, so some of the meat may pass through without "
            "being fully digested.",
            "The pupil also loses the benefit of chewing, which mixes the food with saliva and makes "
            "it easier to swallow.",
            "Chewing properly therefore speeds up digestion and helps the body to get more food from "
            "the meat."],
    "1 mark each for any THREE correct points (3 marks). The key idea is SURFACE AREA: smaller pieces "
    "give the juices more surface to work on. Award at least 1 mark for 'it would be digested more "
    "slowly'."),
 ],
 5: [
   ("(a)", ["(i) simple sugars, such as glucose (sugar).",
            "(ii) amino acids.",
            "(iii) fatty acids and glycerol."],
    "1 mark each for all THREE end products correctly stated (3 marks). The blank number must be "
    "matched to the correct answer. Accept 'sugar' for (i) and 'fatty acids' alone for (iii)."),
   ("(b)", ["Any protein food: egg, meat, fish, beans, groundnuts, milk, cheese, soya.",
            "The amino acids are used to build the body: for growth and for the repair of worn-out "
            "parts.",
            "They are also used to make the body's own chemicals, such as the substances that fight "
            "disease."],
    "1 mark for naming a protein food and 1 mark for a correct use of the end product (2 marks). The "
    "food named must be a protein food to earn the first mark."),
   ("(c)", ["The molecules in food such as starch, protein and fat are far too large to pass through "
            "the wall of the small intestine and into the blood.",
            "Digestion breaks these large molecules into small, soluble ones - glucose, amino acids, "
            "fatty acids and glycerol.",
            "Only these small soluble molecules can pass through the wall of the intestine and be "
            "carried round the body.",
            "Food that is not digested cannot be used by the body and is passed out as faeces."],
    "1 mark each for any THREE correct points (3 marks). The key idea is that large insoluble "
    "molecules must be broken into small soluble ones before they can pass into the blood."),
 ],
 6: [
   ("(a)", ["The inner wall of the small intestine is covered with many tiny finger-like villi.",
            "The small soluble molecules of digested food pass through the thin wall of the villi.",
            "They pass into the blood in the tiny blood vessels inside the villi.",
            "The blood then carries the digested food to the liver and round the body to the parts "
            "that need it.",
            "Fatty acids and glycerol pass first into the lymph before reaching the blood."],
    "1 mark each for any THREE correct points (3 marks). The key ideas are: through the thin wall of "
    "the villi, into the blood, and carried round the body."),
   ("(b)", ["Its inner wall is folded and covered with thousands of tiny villi, which give it a very "
            "large surface area for absorption.",
            "Its wall is very thin - only one cell thick - so the digested food has only a short "
            "distance to travel.",
            "It is long, so the food takes a long time to pass through and there is time to absorb it.",
            "It has a rich supply of blood vessels, which carry the absorbed food away quickly and so "
            "keep absorption going.",
            "Each villus has a lymph vessel to carry away the products of fat digestion."],
    "1 mark each for any THREE correct points (3 marks). The single most important point is the large "
    "surface area given by the villi; award at least 1 mark for it."),
   ("(c)", ["The part that cannot be digested - mostly roughage or fibre and dead cells - passes into "
            "the large intestine.",
            "In the large intestine most of the remaining water and mineral salts are absorbed.",
            "The material that is left becomes more solid and is formed into faeces.",
            "The faeces are stored in the rectum and then pass out of the body through the anus."],
    "1 mark each for any THREE correct points (3 marks). The answer must say WHERE it happens (the "
    "large intestine) to earn full marks; award at most 2 marks if the place is not named."),
 ],
 7: [
   ("(a)", ["(i) a blue-black colour.",
            "(ii) Benedict's solution, added to the food and heated in a water bath (Fehling's "
            "solution may also be used).",
            "(iii) a violet (purple) colour.",
            "(iv) rub a small amount of the food on a piece of paper - the grease-spot test."],
    "1 mark each for all FOUR blanks correctly filled (4 marks). The blank number must be matched to "
    "the correct answer. For (ii) accept 'Benedict's solution and heat'. For (iv) accept 'the "
    "grease-spot test' or an ethanol emulsion test with a cloudy white result."),
   ("(b)", ["Crush or grind each sample and put a small amount of each into separate test tubes or "
            "dishes, and label them.",
            "Gari: add a few drops of iodine solution; a blue-black colour shows that starch is "
            "present.",
            "Beans: crush them, add Biuret solution (or sodium hydroxide and copper(II) sulphate "
            "solution); a violet colour shows that protein is present.",
            "Palm oil: rub a little on a piece of paper; a translucent spot shows that fat or oil is "
            "present.",
            "Keep one tube or dish untreated as a control, so the class can see what a negative result "
            "looks like.",
            "Write down what is seen for each sample in a table.",
            "Safety: do not taste any of the samples, handle iodine and Biuret solution with care, "
            "wear eye protection, heat only in a water bath, and wash hands afterwards."],
    "1 mark each for any THREE correct points (3 marks). This is a design task, so award method marks: "
    "any sensible step earns credit. The three things to look for first are: a test for each of the "
    "three samples, the expected result for each, and a safety precaution. Do NOT award a mark for a "
    "plan that tells pupils to taste an unknown sample."),
 ],
}


# --------------------------------------------- derive summary statistics
def topic_totals():
    m = {k: 0 for k in TOPIC}
    it = {k: 0 for k in TOPIC}
    for q in MCQ:
        m[q[3]] += 1
        it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk
            it[key] += 1
    return m, it


def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}
    b = {k: 0 for k in order}
    for q in MCQ:
        a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            b[cog] += mk
    return order, a, b


def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ:
        d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            d[diff] += mk
    return d
