# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "/home/user")
from build_special import *

A_TOTAL, B_TOTAL = section_totals()
GRAND = A_TOTAL + B_TOTAL
N_B_PARTS = sum(len(q["parts"]) for q in SECTION_B)
m, it = topic_totals()
sm, si = strand_totals()
order, ca, cb = cognitive_by_section()
diff = difficulty_totals()

out = []
w = out.append

w("# %s" % SCHOOL)
w("%s" % SUBJECT)
w("## %s" % EXAM)
w("**Class:** %s   **Time:** %s   **Total Marks:** %s   **%s**" % (CLASS, TIME, MARKS, YEAR))
w("")
w("---")
w("")
w("### INSTRUCTIONS TO CANDIDATES")
w("")
w("1. This paper has TWO sections, A and B. Answer ALL the questions in BOTH sections.")
w("2. SECTION A has 100 multiple-choice questions. Each carries 2 marks. Total = 200 marks.")
w("3. SECTION B has 20 essay questions with sub-questions. The marks for each question are "
  "printed beside it. Total = 200 marks.")
w("4. Write your answers to Section A on the answer sheet provided. Write your answers to "
  "Section B in the answer book.")
w("5. For Section A, choose the BEST answer and write its letter (A, B, C or D) against the "
  "question number.")
w("6. For Section B, answer the sub-questions in the order given and number them clearly. "
  "Where a question asks for a stated number of points, give that number - extra answers are "
  "not marked.")
w("7. Write clearly and show all your working. Marks are awarded for correct points, not for "
  "repeating the question.")
w("")
w("---")
w("")

# ------------------------------------------------------------ SECTION A
w("## SECTION A - OBJECTIVE TEST (100 questions)")
w("")
w("*Answer ALL questions. Each question carries 2 marks. Total = 200 marks.*")
w("")
for i, (q, opts, ans, tp, cog, dl) in enumerate(MCQ, 1):
    w("%d. %s" % (i, q))
    w("")
    for L, o in zip("ABCD", opts):
        w("   %s. %s" % (L, o))
    w("")
w("---")
w("")

# ------------------------------------------------------------ ANSWER KEY
w("## ANSWER KEY - SECTION A")
w("")
w("*Each question carries 2 marks.*")
w("")
w("| Q | Ans | Q | Ans | Q | Ans | Q | Ans |")
w("|---|---|---|---|---|---|---|---|")
for r0 in range(25):
    row = []
    for k in range(4):
        n = r0 + 25 * k + 1
        row += [str(n), MCQ[n - 1][2]] if n <= 100 else ["", ""]
    w("| " + " | ".join(row) + " |")
w("")
w("---")
w("")

# ------------------------------------------------------------ SECTION B
w("## SECTION B - ESSAY QUESTIONS (20 questions)")
w("")
w("*Answer ALL questions. The marks for each question are printed beside it. Total = 200 "
  "marks.*")
w("")
for qb in SECTION_B:
    w("### Question %d  [%d marks]  %s" % (qb["num"], qb["total"], TOPIC[qb["topic"]]))
    w("")
    w(qb["stem"])
    w("")
    for (lab, text, mk, cog, tp, dl) in qb["parts"]:
        w("- **%s** %s  *[%d mark%s]*" % (lab, text, mk, "" if mk == 1 else "s"))
    w("")
w("---")
w("")

# ------------------------------------------- EXPECTED ANSWERS (short form)
w("## SECTION B - EXPECTED ANSWERS (SUMMARY)")
w("")
w("| Question | Expected Answer | Curriculum Area | Cognitive Level |")
w("|---|---|---|---|")
for qb in SECTION_B:
    mm = {lab: a_ for (lab, a_, note) in MARKING[qb["num"]]}
    for (lab, text, mk, cog, tp, dl) in qb["parts"]:
        w("| %d %s | %s | %s | %s |" % (qb["num"], lab.strip("()"), " ".join(mm[lab]),
                                        TOPIC[tp], cog))
w("")
w("---")
w("")

# ------------------------------------------------------------ MARKING SCHEME
w("## MARKING SCHEME - SECTION B (200 marks)")
w("")
w("*General rules: (1) Accept any other correct and relevant answer. (2) Award marks for "
  "correct points, not for repeating the question. (3) For procedures, award method marks. "
  "(4) Do not deduct marks for spelling unless the meaning is changed. (5) Where a candidate "
  "gives more answers than are asked for, mark only the first ones up to the number asked "
  "for. (6) Each sub-question is marked out of the figure printed beside it.*")
w("")
for qb in SECTION_B:
    w("### Question %d  [%d marks]" % (qb["num"], qb["total"]))
    w("")
    for (lab, ans_list, note) in MARKING[qb["num"]]:
        w("**%s**" % lab)
        w("")
        for a_ in ans_list:
            w("- %s" % a_)
        w("")
        w("*Marking note: %s*" % note)
        w("")
    w("---")
    w("")

# ------------------------------------------------------------ BLUEPRINT
w("## BLUEPRINT / TEST SPECIFICATION")
w("")
w("### Summary 1 - Coverage by Strand")
w("")
w("| Strand | Code | No. of Items | Marks | % of Total Marks |")
w("|---|---|---|---|---|")
for k in sorted(sm):
    w("| %s | %s | %d | %d | %.1f%% |" % (STRAND_NAME[k], k, si[k], sm[k],
                                          100.0 * sm[k] / GRAND))
w("| **TOTAL** | - | **%d** | **%d** | **100%%** |" % (sum(si.values()), sum(sm.values())))
w("")
w("### Summary 2 - Coverage by Sub-strand")
w("")
w("| Sub-strand / Content Area | Content Standard | No. of Items | Marks | % of Total Marks | "
  "Core Competencies |")
w("|---|---|---|---|---|---|")
for k in sorted(m, key=lambda x: (x[1:2], float(x[2:]))):
    w("| %s | %s | %d | %d | %.1f%% | %s |" % (TOPIC[k], CS_BY_TOPIC[k], it[k], m[k],
                                               100.0 * m[k] / GRAND, CC[k]))
w("| **TOTAL** | - | **%d** | **%d** | **100%%** | - |" % (sum(it.values()), sum(m.values())))
w("")
w("### Summary 3 - Distribution by Cognitive Level")
w("")
w("| Cognitive Level | Section A Marks | Section B Marks | Total Marks | % of Total |")
w("|---|---|---|---|---|")
for k in order:
    w("| %s | %d | %d | %d | %.1f%% |" % (k, ca[k], cb[k], ca[k] + cb[k],
                                          100.0 * (ca[k] + cb[k]) / GRAND))
w("| **TOTAL** | **%d** | **%d** | **%d** | **100%%** |" % (sum(ca.values()), sum(cb.values()),
                                                            GRAND))
w("")
w("### Summary 4 - Distribution by Difficulty")
w("")
w("| Difficulty | Marks | % of Total Marks |")
w("|---|---|---|")
for k in ("Easy", "Moderate", "Challenging"):
    w("| %s | %d | %.1f%% |" % (k, diff[k], 100.0 * diff[k] / GRAND))
w("| **TOTAL** | **%d** | **100%%** |" % sum(diff.values()))
w("")
w("### Summary 5 - Structure of the Paper")
w("")
w("| Section | Question Type | Items | Marks | % of Total |")
w("|---|---|---|---|---|")
w("| A | Multiple choice (2 marks each) | 100 | %d | %.0f%% |" % (A_TOTAL,
                                                                   100.0 * A_TOTAL / GRAND))
w("| B | Essay questions with sub-questions | %d | %d | %.0f%% |" % (N_B_PARTS, B_TOTAL,
                                                                      100.0 * B_TOTAL / GRAND))
w("| **TOTAL** | - | **%d** | **%d** | **100%%** |" % (100 + N_B_PARTS, GRAND))
w("")
w("---")
w("")

# ------------------------------------------------------------ QC
w("## QUALITY-CONTROL SUMMARY")
w("")
w("*Every question was checked against the following fourteen points.*")
w("")
qc = [
 ("Does every question belong to the supplied curriculum scope?",
  "Yes. All %d items - 100 objectives and %d essay sub-questions - trace to the Basic 7 "
  "Integrated Science curriculum, Strands 1 to 5, all 22 sub-strands. Every question carries a "
  "content standard and an official indicator code, shown in the blueprint. Nothing outside the "
  "B7 curriculum is tested." % (100 + N_B_PARTS, N_B_PARTS)),
 ("Is the examination appropriate for the stated class?",
  "Yes. The whole B7 syllabus is covered at B7 depth. No calculation is harder than simple "
  "arithmetic, no classification goes beyond what the curriculum names, and the essay tasks ask "
  "for the number of points a JHS 1 pupil can reasonably produce in the time allowed."),
 ("Are the questions genuinely BECE-style?",
  "Yes: Section A is 100 four-option objectives, and Section B is 20 essay questions with "
  "sub-questions, each carrying a printed mark allocation. The instruction block, the answer "
  "sheet and the mark-per-question layout all follow the BECE format."),
 ("Are there enough application and reasoning questions?",
  "Yes. 120 of 400 marks (30%%) are at Apply level or above: Apply 98, Analyse 12, Evaluate 6, "
  "Create 4. Create appears in Question 7(b), where pupils design a fair-test experiment on "
  "germination; Evaluate in Questions 12(b) and 14(c), where they must weigh options and "
  "justify a choice."),
 ("Are the MCQ distractors plausible?",
  "Yes. Distractors are drawn from the same content family as the key: a real process that "
  "happens at a different stage, a real organism placed in the wrong habitat, a real component "
  "that does something else in the circuit, and a real property that belongs to the other "
  "category. None is obviously absurd, so guessing does not reward a pupil who has not "
  "studied."),
 ("Is there only one best answer for each MCQ?",
  "Yes. Every item was reviewed for a single defensible key, and all 100 option lists were "
  "machine-checked so that the declared key sits on the correct answer. Special care was taken "
  "with the planets-in-order item, where only one ordering is correct, and with the "
  "alimentary-canal item, where the order is part of the answer."),
 ("Are the marks internally consistent?",
  "Yes. Section A = 100 items x 2 marks = %d. Section B = %s = %d. Each sub-question's printed "
  "marks match its marking-scheme allocation, and every N-mark sub-question asks for N things."
  % (A_TOTAL, " + ".join(str(q["total"]) for q in SECTION_B), B_TOTAL)),
 ("Does the total add up correctly?",
  "Yes: %d + %d = %d marks, matching the stated total on the front page. The strand table, the "
  "sub-strand table, the cognitive table, the difficulty table and the structure table all sum "
  "to the same figure." % (A_TOTAL, B_TOTAL, GRAND)),
 ("Are the answers in the answer key correct?",
  "Yes. All 100 objective keys and all %d Section B answers were verified against the marking "
  "scheme, and the objective keys were re-derived from first principles as a cross-check." %
  N_B_PARTS),
 ("Does the marking scheme match the questions?",
  "Yes. Every sub-question has an expected-answer list and a marking note covering partial "
  "credit, acceptable alternatives, common wrong answers and method marks. Notes that bite: "
  "the alimentary canal is marked in order and stops at the first error; a food chain that "
  "starts with an animal scores 0; 'sunlight' is not accepted for germination; and choosing a "
  "farming system without a reason earns 1 of 4."),
 ("Are the questions free from unnecessary ambiguity?",
  "Yes. Open items are anchored with 'name four', 'state three', 'explain TWO' and 'give ONE' "
  "plus the mark allocation. Where a question could be read two ways, the marking note states "
  "which reading is intended, as in Question 19(b), where a vague 'use solar power' is capped "
  "at 2 of 4."),
 ("Are Ghanaian contexts used naturally and accurately?",
  "Yes: maize, beans and groundnuts, cocoa and shea, the Kwahu Plateau, the Accra Plains and "
  "Mount Afadjato, streams and boreholes, wells and pulleys, tro-tro travel, sachet water, "
  "iodised salt, and a village pond. The contexts carry the question rather than decorate it."),
 ("Has any content outside the supplied curriculum been introduced?",
  "No. Every item sits inside the 22 sub-strands. No organic chemistry, no numerical physics "
  "beyond simple arithmetic, and no classification scheme the curriculum does not name. Where "
  "a term such as 'malleable' or 'inertia' appears, it is one the B7 syllabus itself uses."),
 ("Are the questions sufficiently varied?",
  "Yes. Item types include explaining physical and chemical change, justifying material "
  "choices, separating mixtures, comparing plant and animal cells, ordering levels of "
  "organisation, treating unsafe water, describing the water cycle and a crop life cycle, "
  "designing a germination experiment, ordering the alimentary canal, describing rotation and "
  "revolution, building a food chain, comparing farming systems, evaluating one for a small "
  "farm, tracing energy changes in a falling stone, building a circuit, explaining inertia, "
  "pairing deficiency diseases with nutrients, and weighing a factory's energy choice."),
]
for i, (q_, a_) in enumerate(qc, start=1):
    w("**%d. %s**" % (i, q_))
    w("")
    w(a_)
    w("")
w("---")
w("")
w("## EXAMINER NOTES (for the teacher, not for candidates)")
w("")
for n in [
 "The 22 sub-strand papers each test one sub-strand in depth. This paper is deliberately "
 "different: it tests the whole year in one sitting and it asks the questions those papers "
 "left out. No question here is repeated from any of them, so a class can sit both without "
 "seeing the same item twice.",
 "Difficulty is set at 30% easy, 50% moderate and 20% challenging, and 30% of the marks are at "
 "Apply level or above. If you want a harder paper, move the Section A items marked "
 "Challenging into an earlier block; they are identified in the module, not on the paper.",
 "Question 7(b) is the only Create item and it is the one pupils find hardest. They can name "
 "the conditions a seed needs but cannot set up a fair test. The marking note requires two "
 "groups, one difference, the expected result and a conclusion - teach that shape explicitly "
 "and the marks follow.",
 "Questions 12(b) and 14(c) are the Evaluate items, and both are capped at 1 mark if the pupil "
 "makes a choice with no reason. That is deliberate: the skill being tested is the "
 "justification, not the choice. There is no single right answer to either.",
 "Question 9(a) is marked in order and stops at the first part that is out of sequence. Tell "
 "the class this before the examination - it is the single easiest place to lose 5 marks "
 "through carelessness rather than ignorance.",
 "Question 11(b) scores 0 if the food chain begins with an animal, and 0 again if the arrows "
 "point the wrong way. Drill the direction: the arrow means 'is eaten by' and the chain always "
 "starts with a plant.",
 "Question 17(c) - why antibiotics do not cure a viral disease - is the kind of item that "
 "separates pupils who have understood from pupils who have memorised. It is worth a whole "
 "lesson, and it connects directly to the COVID-19 and Ebola work.",
 "Each strand carries exactly 80 marks and four essay questions. If your scheme of work spent "
 "longer on one strand than another, re-weight by moving Section A items rather than by "
 "changing the essays, so that the marking scheme stays valid.",
 "At 400 marks this paper is longer than anything a JHS 1 class will sit officially. It works "
 "best as two sittings - Section A in one session and Section B in another - or as a revision "
 "bank from which you draw items for shorter class tests.",
 "Three cheap revision activities that raise marks across the whole paper: (1) set up the "
 "germination experiment from Question 7(b) on a windowsill and leave it for a week; (2) build "
 "the Question 14 circuit with a battery, a bulb and a switch from the electronics kit; and "
 "(3) walk the class to the nearest water source and ask them to design a treatment chain for "
 "it, which is Question 5(c) done for real.",
 "Edit the school name, academic year and examination title on page 1 before printing.",
 "This is an original, teacher-made mock. It is not a reproduction of any WAEC or NaCCA "
 "examination paper.",
]:
    w("- %s" % n)
    w("")

txt = "\n".join(out) + "\n"
open("/home/user/Basic7_Integrated_Science_SPECIAL_MOCK_FullCurriculum.md",
     "w", encoding="utf-8").write(txt)
print("md written")
print("Section A:", len(MCQ), "x 2 =", A_TOTAL, "| Section B:", len(SECTION_B), "q /",
      N_B_PARTS, "parts =", B_TOTAL, "| GRAND:", GRAND)
print("Strands:", dict(sorted(sm.items())))
print("Difficulty:", diff, "sum", sum(diff.values()))
print("Cognitive:", {k: ca[k] + cb[k] for k in order}, "sum",
      sum(ca[k] + cb[k] for k in order))
print("Answer counts:", {L: sum(1 for q in MCQ if q[2] == L) for L in "ABCD"})
print("chars:", len(txt))
