# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "/home/user")
from build_cells import *

L = []
def w(s=""): L.append(s)

w(f"# {SCHOOL}"); w()
w(f"## {SUBJECT}"); w()
w(f"### {EXAM}"); w()
w(f"**Class:** {CLASS}  ")
w(f"**Time:** {TIME}  ")
w(f"**Total Marks:** {MARKS}  ")
w(f"**Academic Year:** {YEAR}"); w()
w("---"); w()
w("### INSTRUCTIONS"); w()
for i, t in enumerate([
    "Write your name and class clearly in the spaces provided on your answer sheet.",
    "This paper has TWO sections: Section A and Section B.",
    "Answer ALL the questions in both sections.",
    "Section A has 40 multiple-choice questions. Each question carries 1 mark. Choose the best answer (A, B, C or D) and record it on the answer sheet provided.",
    "Section B has 7 theory questions totalling 60 marks. Write your answers clearly and neatly in your answer booklet. Draw and label diagrams where you are asked to.",
    "Read every question carefully before you answer it.",
    "Do not use correction fluid. Cancel any mistake neatly with a single line.",
    "Hand in your answer sheet and your answer booklet at the end of the examination.",
], start=1):
    w(f"{i}. {t}")
w(); w("---"); w()

w("## SECTION A: OBJECTIVE TEST (40 marks)"); w()
w("*Answer ALL questions. Each question carries 1 mark. Choose the BEST answer and write its letter "
  "(A, B, C or D) against the question number on your answer sheet.*"); w()
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"**{i}. {q}**"); w()
    for j, o in enumerate(opts): w(f"{'ABCD'[j]}. {o}")
    w()
w("---"); w()

w("## SECTION B: THEORY (60 marks)"); w()
w("*Answer ALL questions. Write your answers in your answer booklet. The marks for each question are shown "
  "in brackets.*"); w()
for qb in SECTION_B:
    w(f"### Question {qb['num']}  [{qb['total']} marks]"); w()
    w(qb["stem"]); w()
    if qb.get("diagram") == "animal":
        w("```"); 
        for line in ANIMAL_CELL: w(line)
        w("```")
        w("*Fig. 1: An animal cell (not drawn to scale)*"); w()
    if qb.get("diagram") == "plant":
        w("```")
        for line in PLANT_CELL: w(line)
        w("```")
        w("*Fig. 2: A plant cell (not drawn to scale)*"); w()
    if qb.get("table") == "organelles":
        w("| " + " | ".join(Q3_TABLE_HEAD) + " |")
        w("|" + "---|" * len(Q3_TABLE_HEAD))
        for row in Q3_TABLE_ROWS: w("| " + " | ".join(row) + " |")
        w()
    if qb.get("table") == "compare":
        w("| " + " | ".join(Q6_TABLE_HEAD) + " |")
        w("|" + "---|" * len(Q6_TABLE_HEAD))
        for row in Q6_TABLE_ROWS: w("| " + " | ".join(row) + " |")
        w()
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        w(f"**{lab}** {text}  **[{mk} mark{'s' if mk > 1 else ''}]**"); w()
w("---"); w()

w("## ANSWER KEY"); w()
w("### Section A - Objective Test"); w()
w("| Question | Answer | Curriculum Area (Topic) | Cognitive Level |")
w("| -------- | ------ | ----------------------- | --------------- |")
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"| {i} | {ans} | {TOPIC[tp]} | {cog} |")
counts = {L2: sum(1 for q in MCQ if q[2] == L2) for L2 in "ABCD"}
w()
w("Correct-answer distribution: " + ", ".join(f"{L2} = {counts[L2]}" for L2 in "ABCD") + " (40 items).")
w()
w("### Section B - Theory (summary answers; full detail in the Marking Scheme)"); w()
w("| Question | Expected Answer | Curriculum Area | Cognitive Level |")
w("| -------- | --------------- | --------------- | --------------- |")
sba = [
 ("1 (a)", "The smallest (basic) unit of structure and function of a living thing.", "2.1", "Remember"),
 ("1 (b)", "All living things are made of cells; the cell is the smallest part that can carry out all life processes; nothing smaller than a cell can live on its own.", "2.1", "Understand"),
 ("1 (c)", "Peel a thin piece of onion skin, mount it in a drop of water on a slide with a cover slip, place it on the microscope stage and focus (low power, then high power). Many small box-like compartments (cells) are seen.", "2.1", "Create"),
 ("1 (d)", "Cells are extremely small and the naked eye cannot magnify them; a microscope is needed to make them large enough to see.", "2.1", "Understand"),
 ("2 (a)", "1 = cell membrane; 2 = cytoplasm; 3 = nucleus; 4 = vacuole", "2.2", "Remember"),
 ("2 (b)", "It holds the cell together and controls the movement of substances into and out of the cell.", "2.3", "Understand"),
 ("2 (c)", "It controls all the activities of the cell and contains the hereditary material.", "2.3", "Understand"),
 ("2 (d)", "The cell would lose control of what enters and leaves; useful substances leak out, harmful ones enter, and the cell may die.", "2.3", "Analyse"),
 ("2 (e)", "An animal cell has no rigid cell wall, only a thin flexible cell membrane, so it has no fixed shape.", "2.2", "Understand"),
 ("3 (a)", "(i) Controls all the activities of the cell. (ii) Jelly-like substance where the organelles are found and where most activities take place. (iii) Holds the cell together and controls what enters and leaves. (iv) Releases energy from food during respiration.", "2.3", "Understand"),
 ("3 (b)", "Any suitable material with a matching reason, e.g. clear glue or jelly - because cytoplasm is a jelly-like substance.", "2.3", "Create"),
 ("3 (c)", "It releases the energy the cell needs, from the food the cell takes in during respiration.", "2.3", "Understand"),
 ("3 (d)", "The cell loses its control centre, cannot control its activities or repair itself, and eventually dies.", "2.3", "Analyse"),
 ("4 (a)", "1 = cell wall; 2 = cell membrane; 3 = cytoplasm; 4 = vacuole; 5 = chloroplast; 6 = nucleus", "2.4", "Remember"),
 ("4 (b)", "1 (cell wall) and 5 (chloroplast)", "2.5", "Analyse"),
 ("4 (c)", "It gives the cell a definite shape and supports and protects the plant.", "2.4", "Understand"),
 ("4 (d)", "It contains chlorophyll and is where the plant makes its own food by photosynthesis.", "2.5", "Understand"),
 ("4 (e)", "The rigid cell wall holds the cell in a fixed, regular shape.", "2.4", "Understand"),
 ("5 (a)", "Chlorophyll - it traps light energy so the plant can make its own food by photosynthesis.", "2.5", "Understand"),
 ("5 (b)", "The plant cannot make enough food, so it becomes weak and yellow and may die, because chlorophyll needs light for photosynthesis.", "2.5", "Apply"),
 ("5 (c)", "Any two of: stores water; stores salts, sugars and waste; keeps the cell firm.", "2.5", "Understand"),
 ("5 (d)", "Cellulose.", "2.5", "Remember"),
 ("6 (a)", "Any three of: cell wall present in plants only; chloroplasts present in plants only; large permanent vacuole in plants, small temporary vacuoles in animals; regular shape in plants, irregular in animals.", "2.6", "Understand"),
 ("6 (b)", "Any three of: cell membrane, cytoplasm, nucleus, mitochondria, vacuole.", "2.6", "Remember"),
 ("6 (c)", "Disagree - a plant cell also has chloroplasts and a large permanent vacuole, which an animal cell does not have, and the two cell types obtain food differently.", "2.6", "Evaluate"),
 ("6 (d)", "(i) Yes   (ii) No   (iii) No   (iv) Yes   (v) Yes", "2.6", "Understand"),
]
for r in sba: w(f"| {r[0]} | {r[1]} | {r[2]} | {r[3]} |")
w(); w("---"); w()

w("## MARKING SCHEME - SECTION B (60 marks)"); w()
w("*General rules: (1) Accept any other correct and relevant answer. (2) Award marks for correct points, not "
  "for repeating the question. (3) For procedures, award method marks. (4) Do not deduct marks for spelling "
  "unless the meaning is changed. (5) Where a candidate gives more answers than are asked for, mark only the "
  "first ones up to the number required.*"); w()
for qb in SECTION_B:
    n = qb["num"]
    w(f"### Question {n} ({qb['total']} marks)"); w()
    for (lab, points, note) in MARKING[n]:
        mkv = [p_[2] for p_ in qb["parts"] if p_[0] == lab]
        head = f"**{lab}**"
        if mkv: head += f" [{mkv[0]} mark{'s' if mkv[0] > 1 else ''}]"
        w(head); w()
        for pt in points: w(f"- {pt}")
        w(f"  - *Marking note: {note}*"); w()
w("---"); w()

w("## CURRICULUM ASSESSMENT BLUEPRINT"); w()
w(f"**Strand:** {STRAND} | **Sub-strand:** {SUBSTRAND} | **Class:** {CLASS}"); w()
w(f"**Content Standard:** {CS} - {CS_TEXT}"); w()
w("> Source: NaCCA Science Common Core Programme Curriculum (B7/JHS1-B9/JHS3), September 2020, Strand 1: "
  "Diversity of Matter, Sub-strand 2: Living Cells, pp. 5-6. Indicators are quoted, not invented."); w()

w("### Section A"); w()
w("| Qn | Sub-strand | Content Standard | Indicator (NaCCA) - Indicator Text | Topic / Content | Cognitive Level | Marks |")
w("| -- | ---------- | ---------------- | ---------------------------------- | --------------- | --------------- | ----- |")
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"| A{i} | {SUBSTRAND} | {CS} | {IND[tp]} - {IND_TEXT[tp]} | {TOPIC[tp]} | {cog} | 1 |")
w()
w("### Section B"); w()
w("| Qn | Sub-strand | Content Standard | Indicator (NaCCA) - Indicator Text | Topic / Content | Cognitive Level | Marks |")
w("| -- | ---------- | ---------------- | ---------------------------------- | --------------- | --------------- | ----- |")
for qb in SECTION_B:
    for (lab, text, mkv, cog, tp, diff) in qb["parts"]:
        key = tp if tp in TOPIC else tp.split(",")[0].strip()
        w(f"| B{qb['num']}{lab.strip('()')} | {SUBSTRAND} | {CS} | {IND[key]} - {IND_TEXT[key]} | {TOPIC[key]} | {cog} | {mkv} |")
w(); w("---"); w()

def topic_totals():
    m = {k: 0 for k in TOPIC}; it = {k: 0 for k in TOPIC}
    for q in MCQ: m[q[3]] += 1; it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk; it[key] += 1
    return m, it

def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}; b = {k: 0 for k in order}
    for q in MCQ: a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: b[cog] += mk
    return order, a, b

def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ: d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: d[diff] += mk
    return d

m, it = topic_totals(); diff_ = difficulty_totals(); order, ca, cb = cognitive_by_section()

w("### Summary 1 - Coverage by Curriculum Area (Topic)"); w()
w("| Topic / Content Area | No. of Items | Marks | % of Total Marks | Core Competencies |")
w("| -------------------- | ------------ | ----- | ---------------- | ----------------- |")
for k in TOPIC: w(f"| {TOPIC[k]} | {it[k]} | {m[k]} | {(m[k]/100)*100:.1f}% | {CC[k]} |")
w(f"| **TOTAL** | **{sum(it.values())}** | **{sum(m.values())}** | **100%** | - |")
w()
w("*CC = Communication and Collaboration; CP = Critical Thinking and Problem Solving; DL = Digital Literacy; "
  "CI = Creativity and Innovation.*"); w()
w("### Summary 2 - Cognitive-Level Distribution (Bloom's Taxonomy)"); w()
w("| Cognitive Level | Section A Marks | Section B Marks | Total Marks | % of Total |")
w("| --------------- | --------------- | --------------- | ----------- | ---------- |")
for lv in order:
    tot = ca[lv] + cb[lv]
    w(f"| {lv} | {ca[lv]} | {cb[lv]} | {tot} | {(tot/100)*100:.1f}% |")
w(f"| **TOTAL** | **{sum(ca.values())}** | **{sum(cb.values())}** | **{sum(ca.values())+sum(cb.values())}** | **100%** |")
w()
w("### Summary 3 - Difficulty Distribution"); w()
w("| Difficulty | Marks | % of Total Marks |")
w("| ---------- | ----- | ---------------- |")
for k, v in diff_.items(): w(f"| {k} | {v} | {(v/100)*100:.1f}% |")
w(f"| **TOTAL** | **{sum(diff_.values())}** | **100%** |")
w()
w("*Target in the master prompt: approximately 30% easy / 50% moderate / 20% challenging.*"); w()
w("### Summary 4 - Section Weighting"); w()
w("| Section | Question Type | Items | Marks | % of Total |")
w("| ------- | ------------- | ----- | ----- | ---------- |")
w("| A | Objective (multiple choice) | 40 | 40 | 40% |")
w("| B | Theory / constructed response | 26 | 60 | 60% |")
w("| **TOTAL** | - | **66** | **100** | **100%** |")
w(); w("---"); w()

w("## QUALITY-CONTROL SUMMARY"); w()
w("*Carried out against the 14-point validation list in the master prompt before the examination was finalised.*"); w()
qc = [
 ("Does every question belong to the supplied curriculum scope?",
  "Yes. All 46 items trace to Strand 1 (Diversity of Matter), Sub-Strand 2 (Living Cells), topics 2.1-2.6, and to the two official B7 indicators (B7/JHS1.1.2.1.1 and B7/JHS1.1.2.1.2). Viruses and bacteria (A28) appear only as distractors, never as content to be taught."),
 ("Is the examination appropriate for the stated class?",
  "Yes. The B7 curriculum introduces cells at identification-and-description level, so organelles are limited to cell membrane, cytoplasm, nucleus, vacuole, mitochondrion, cell wall and chloroplast. No mitosis, meiosis, DNA structure, osmosis or tissue/organ-system hierarchy is tested, as these fall outside the B7 indicators."),
 ("Are the questions genuinely BECE-style?",
  "Yes: Section A is 30 four-option objectives worth 1 mark each, and Section B is structured theory with sub-questions carrying printed mark allocations. Two labelled diagrams are included, matching the BECE science convention."),
 ("Are there enough application and reasoning questions?",
  "Yes. 28 of 100 marks (28%) are at Apply level or above (Apply 10, Analyse 9, Evaluate 5, Create 4), including diagram analysis, a damage-to-the-cell consequence item, an experimental procedure, model design and a claim to evaluate."),
 ("Are the MCQ distractors plausible?",
  "Yes. Distractors are drawn from the same content family as the key: other organelles, functions swapped between organelles (A23), and structures wrongly assigned to the wrong cell type (A26)."),
 ("Is there only one best answer for each MCQ?",
  "Yes. Every item was reviewed for a single defensible key. Special care was taken with A21 (vacuole), where 'cytoplasm' and 'nucleus' are plausible to a weak candidate but only 'vacuole' stores water, salts and waste."),
 ("Are the marks internally consistent?",
  "Yes. Section A = 40 items x 1 mark = 40. Section B = 8 + 9 + 9 + 11 + 8 + 15 = 60. Every Section B sub-question's printed marks match its marking-scheme allocation."),
 ("Does the total add up correctly?",
  "Yes: 40 + 60 = 100 marks, matching the stated total on the front page."),
 ("Are the answers in the answer key correct?",
  "Yes. All 40 objective keys and all 26 Section B answers were verified against the marking scheme and checked for internal consistency (e.g. B2(a) labels feed B2(b) and B2(c))."),
 ("Does the marking scheme match the questions?",
  "Yes. Every Section B sub-question has an expected-answer list and a marking note covering partial credit, acceptable alternatives, common wrong answers and method marks."),
 ("Are the questions free from unnecessary ambiguity?",
  "Yes. Open items are anchored with 'state two', 'name the green substance' and the mark allocation. The two diagram questions were checked so that each label points to exactly one structure and no organelle is named in the artwork itself (which would give away the answer)."),
 ("Are Ghanaian contexts used naturally and accurately?",
  "Yes: Kwame, Ama, Kofi and Akosua; onion skin; a dark cupboard; local materials for modelling a cell (corn dough, clear glue, sand). Contexts support the science rather than decorating it."),
 ("Has any content outside the supplied curriculum been introduced?",
  "No. Every item sits inside topics 2.1-2.6. 'Mitochondrion' (A13, A29) is required by indicator B7/JHS1.1.2.1.1 exemplar 2, which asks for the function of each organelle in the animal cell. No chemical formulae, equations or biochemistry were introduced."),
 ("Are the questions sufficiently varied?",
  "Yes. Item types include definition, identification, function matching, diagram labelling, diagram analysis, table completion, experimental procedure, model design, application to a novel situation and evaluation of a claim."),
]
for i, (q, a) in enumerate(qc, start=1):
    w(f"{i}. **{q}**"); w(f"   {a}")
w()
w("### Examiner Notes (for the teacher, not for candidates)"); w()
for n in [
 "Cognitive demand and the indicators: the action verbs in the two official B7 indicators are 'describe' (B7/JHS1.1.2.1.1) and 'state' (B7/JHS1.1.2.1.2), which sit at Understand level. That sets the floor for this sub-strand. The Apply, Analyse, Evaluate and Create items in this paper are deliberate extensions beyond the minimum - standard practice for a mock examination, and directly supported by the indicators' own exemplars, which ask learners to 'draw and label a cell' and to 'develop a model to represent a cell' (Create). If you want a paper that sits exactly at the indicator level, drop Questions 1(c), 2(c), 3(b), 5(b) and 6(c).",
 "Topic 2.6 carries 23 of 100 marks (23%), the highest weighting, because comparing the two cell types is the natural synthesis of the sub-strand and is heavily examined at this level.",
 "Question 3(b) and Question 1(c) are the two items most likely to separate strong candidates from weak ones. Both are marked generously for method and reasoning, so partial credit is common.",
 "The two diagrams are drawn with text characters inside Word tables. Enlarge the font, replace the characters with real shapes, or paste in a hand-drawn figure - the numbering (1-4 and 1-6) is what the questions depend on.",
 "Edit the school name, academic year and examination title on page 1 before printing.",
 "This is an original, teacher-made mock. It is not a reproduction of any WAEC or NaCCA examination paper.",
]:
    w(f"- {n}")
w()

open("/home/user/Basic7_Integrated_Science_Mock_Strand1_LivingCells.md", "w", encoding="utf-8").write("\n".join(L))
print("md written", len("\n".join(L)), "chars")
