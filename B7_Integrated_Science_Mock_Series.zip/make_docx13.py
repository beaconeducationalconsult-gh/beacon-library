# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "/home/user")
from build_conserve import *

from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT

doc = Document()
sec = doc.sections[0]
sec.left_margin = Inches(0.7); sec.right_margin = Inches(0.7)
sec.top_margin = Inches(0.7); sec.bottom_margin = Inches(0.6)

st = doc.styles["Normal"]; st.font.name = "Calibri"; st.font.size = Pt(11)


def set_font(run, size=11, bold=False, italic=False, mono=False, color=None):
    run.font.size = Pt(size); run.bold = bold; run.italic = italic
    run.font.name = "Consolas" if mono else "Calibri"
    if color: run.font.color.rgb = color
    return run


def para(text="", size=11, bold=False, italic=False, align=None, mono=False,
         space_before=0, space_after=4, color=None):
    p = doc.add_paragraph()
    if align == "c": p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    elif align == "j": p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p.paragraph_format.space_before = Pt(space_before)
    p.paragraph_format.space_after = Pt(space_after)
    if text: set_font(p.add_run(text), size, bold, italic, mono, color)
    return p


def rule():
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(6); p.paragraph_format.space_before = Pt(2)
    set_font(p.add_run("_" * 78), 9, color=RGBColor(0x99, 0x99, 0x99))


def add_table(headers, rows, widths=None, size=9, head_size=9):
    t = doc.add_table(rows=1, cols=len(headers)); t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, h in enumerate(headers):
        c = t.rows[0].cells[i]; c.text = ""
        p = c.paragraphs[0]; p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_font(p.add_run(str(h)), head_size, bold=True)
    for row in rows:
        cells = t.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = ""
            p = cells[i].paragraphs[0]; p.paragraph_format.space_after = Pt(1)
            set_font(p.add_run(str(v)), size)
    if widths:
        for r_ in t.rows:
            for i, w in enumerate(widths): r_.cells[i].width = Inches(w)
    return t


def draw_diagram(lines, caption):
    t = doc.add_table(rows=2, cols=1); t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = t.rows[0].cells[0]
    for k, line in enumerate(lines):
        p = cell.paragraphs[0] if k == 0 else cell.add_paragraph()
        p.paragraph_format.space_after = Pt(0); p.paragraph_format.space_before = Pt(0)
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_font(p.add_run(line), 10, mono=True)
    c2 = t.rows[1].cells[0].paragraphs[0]
    c2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_font(c2.add_run(caption), 9, italic=True)
    t.rows[0].cells[0].width = Inches(6.6)
    t.rows[1].cells[0].width = Inches(6.6)


# ============================================================= TITLE BLOCK
para(SCHOOL, size=15, bold=True, align="c", space_after=2)
para(SUBJECT, size=13, bold=True, align="c", space_after=2)
para(EXAM, size=12, bold=True, align="c", space_after=2)
para(YEAR, size=10, italic=True, align="c", space_after=8)

info = doc.add_table(rows=1, cols=3); info.style = "Table Grid"
info.alignment = WD_TABLE_ALIGNMENT.CENTER
for i, v in enumerate([f"Class: {CLASS}", f"Time: {TIME}", f"Total Marks: {MARKS}"]):
    c = info.rows[0].cells[i]; c.text = ""
    set_font(c.paragraphs[0].add_run(v), 10, bold=True)
para("", space_after=6)

para("INSTRUCTIONS", size=11, bold=True, space_after=3)
for txt in [
    "1. Write your name and class clearly in the spaces provided on your answer sheet.",
    "2. This paper has TWO sections: Section A and Section B.",
    "3. Answer ALL the questions in both sections.",
    "4. Section A has 40 multiple-choice questions. Each question carries 1 mark. Choose the best answer "
    "(A, B, C or D) and record it on the answer sheet provided.",
    "5. Section B has 7 theory questions totalling 60 marks. Write your answers clearly and neatly in your "
    "answer booklet. Draw and label diagrams or tables where you are asked to.",
    "6. Read every question carefully before you answer it.",
    "7. Do not use correction fluid. Cancel any mistake neatly with a single line.",
    "8. Hand in your answer sheet and your answer booklet at the end of the examination.",
]:
    para(txt, size=10.5, space_after=2)
rule()

# =============================================================== SECTION A
para("SECTION A - OBJECTIVE TEST (40 marks)", size=12, bold=True, align="c", space_after=2)
para("Answer ALL questions. Each question carries 1 mark. Choose the BEST answer and write its letter "
     "(A, B, C or D) against the question number on your answer sheet.",
     size=10, italic=True, align="c", space_after=8)

for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(1); p.paragraph_format.space_before = Pt(4)
    set_font(p.add_run(f"{i}. {q}"), 10.5)
    for j, o in enumerate(opts):
        p2 = doc.add_paragraph()
        p2.paragraph_format.left_indent = Inches(0.28)
        p2.paragraph_format.space_after = Pt(0); p2.paragraph_format.space_before = Pt(0)
        set_font(p2.add_run(f"{'ABCD'[j]}. {o}"), 10.5)

doc.add_page_break()

# =============================================================== SECTION B
para("SECTION B - THEORY (60 marks)", size=12, bold=True, align="c", space_after=2)
para("Answer ALL questions. Write your answers in your answer booklet. The marks for each question are "
     "shown in brackets.", size=10, italic=True, align="c", space_after=8)

for qb in SECTION_B:
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(8); p.paragraph_format.space_after = Pt(2)
    set_font(p.add_run(f"Question {qb['num']}"), 11, bold=True)
    set_font(p.add_run(f"  [{qb['total']} marks]"), 10, bold=True, italic=True)
    para(qb["stem"], size=10.5, space_after=4)
    if qb.get("diagram"):
        draw_diagram(TORCH, "Fig. 1: Energy conversion in a torch")
        para("", space_after=2)
    if qb.get("table") == "conversion":
        add_table(CVS_HEADERS, CVS_ROWS, widths=[1.9, 1.9, 2.2], size=8.5, head_size=8.5)
        para("Table 1: Energy conversion in everyday devices", size=9, italic=True, align="c",
             space_after=6)
        para("", space_after=2)
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Inches(0.25)
        p.paragraph_format.space_after = Pt(3); p.paragraph_format.space_before = Pt(2)
        set_font(p.add_run(f"{lab} {text}  "), 10.5)
        set_font(p.add_run(f"[{mk} mark{'s' if mk > 1 else ''}]"), 10, bold=True)

doc.add_page_break()

# ============================================================== ANSWER KEY
para("ANSWER KEY", size=13, bold=True, align="c", space_after=6)
para("SECTION A - OBJECTIVE TEST", size=11, bold=True, space_after=4)
rows = [[i, ans, TOPIC[tp], cog] for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1)]
add_table(["Question", "Answer", "Curriculum Area (Topic)", "Cognitive Level"],
          rows, widths=[0.8, 0.7, 3.6, 1.5], size=9)
counts = {L: sum(1 for q in MCQ if q[2] == L) for L in "ABCD"}
para("", space_after=4)
para("Correct-answer distribution: " + ", ".join(f"{L} = {counts[L]}" for L in "ABCD") + " (30 items).",
     size=9, italic=True)

para("", space_after=8)
para("SECTION B - THEORY (summary answers; see the Marking Scheme for full detail)",
     size=11, bold=True, space_after=4)
sba = [
 ("1 (a)", "Energy cannot be created and it cannot be destroyed; it can only be changed from one form into another, and the total amount always stays the same.", "13.1", "Understand"),
 ("1 (b)", "A closed system is one in which no energy enters and no energy leaves; all the energy stays inside.", "13.1", "Understand"),
 ("1 (c)", "The dry cell stores chemical energy, which changes into electrical energy in the wires and then into light and heat in the bulb. No energy is lost - the total at the end is exactly the same as the chemical energy at the start.", "13.1", "Apply"),
 ("1 (d)", "The claim is impossible. Energy cannot be created, so a machine cannot give out more than it was given; the most it can do is change all the energy it was given into other forms.", "13.1", "Evaluate"),
 ("2 (a)", "(i) chemical energy; (ii) electrical energy; (iii) light energy; (iv) heat energy.", "13.2", "Understand"),
 ("2 (b)", "Energy conversion is the changing of energy from one form into another.", "13.2", "Remember"),
 ("2 (c)", "The total amount of energy stays the same throughout; no energy is lost or destroyed, it only changes form.", "13.2", "Understand"),
 ("3 (a)", "(i) chemical energy from the dry cells; (ii) heat energy; (iii) sound energy; (iv) chemical energy from the fuel; (v) kinetic or movement energy; (vi) solar energy (light from the sun).", "13.2", "Understand"),
 ("3 (b)", "Any one device from the table plus the form of energy from it that is NOT useful - e.g. a torch also gives out heat, a radio gives out heat, a car engine gives out heat and sound.", "13.2", "Apply"),
 ("4 (a)", "Any three appliances with the correct conversion - e.g. a pressing iron (electrical to heat), a radio (electrical to sound), a bulb (electrical to light), a maize mill (electrical to movement).", "13.3", "Apply"),
 ("4 (b)", "Any three of: they give light to see by at night; heat for cooking and ironing; sound for the radio and television; movement for a fan or a blender.", "13.3", "Understand"),
 ("4 (c)", "The wasted form for each of the three appliances named in (a) - e.g. heat from a bulb, heat from a radio, heat and sound from a fan.", "13.3", "Understand"),
 ("5 (a)", "A row of boxes joined by arrows showing the chain from the source to the appliance to the useful form, with each box labelled with the energy form and a caption 'changes into' under each arrow.", "13.3", "Create"),
 ("5 (b)", "The food the pupil ate stores chemical energy; the body releases it, and in the muscles it is changed into kinetic energy that moves the legs, with some changed into heat.", "13.3", "Understand"),
 ("5 (c)", "Heat energy, from the body and from friction in the moving parts; and sound energy from the tyres and the chain.", "13.3", "Understand"),
 ("6 (a)", "Any four of: switch off lights and fans when nobody is in the room; use energy-saving bulbs; put a lid on the pot; boil only as much water as is needed; close the fridge door quickly; iron all the clothes at one time; dry food and clothes in the sun.", "13.4", "Understand"),
 ("6 (b)", "The law says the TOTAL energy stays the same, but it does not stay in a form we can use. Useful energy such as fuel and electricity is changed into heat and sound that spread out and cannot be gathered up again, so the energy that is easy to use keeps going down.", "13.4", "Analyse"),
 ("7 (a)", "Any three of: it saves the family money; it makes fuel and electricity last longer; it reduces power cuts; it reduces smoke in the home; the money saved can go on other needs.", "13.4", "Understand"),
 ("7 (b)", "Any four of: fewer trees are cut for fuel so forest animals keep their habitat; less smoke and fewer gases so plants and animals are not damaged; rivers are less dammed or polluted so fish survive; the climate warms more slowly; the plants that give out oxygen are left standing.", "13.4", "Evaluate"),
]
add_table(["Question", "Expected Answer", "Curriculum Area", "Cognitive Level"],
          [list(r) for r in sba], widths=[0.8, 4.2, 1.2, 1.2], size=9)

doc.add_page_break()

# =========================================================== MARKING SCHEME
para("MARKING SCHEME - SECTION B (60 marks)", size=13, bold=True, align="c", space_after=4)
para("General rules: (1) Accept any other correct and relevant answer. (2) Award marks for correct points, "
     "not for repeating the question. (3) For procedures, award method marks. (4) Do not deduct marks for "
     "spelling unless the meaning is changed. (5) Where a candidate gives more answers than are asked for, "
     "mark only the first ones up to the number required.",
     size=9.5, italic=True, space_after=8)

for qb in SECTION_B:
    n = qb["num"]
    para(f"Question {n}  ({qb['total']} marks)", size=11, bold=True, space_before=8, space_after=3)
    for (lab, points, note) in MARKING[n]:
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(2)
        set_font(p.add_run(f"{lab} "), 10.5, bold=True)
        mkv = [p_[2] for p_ in qb["parts"] if p_[0] == lab]
        if mkv: set_font(p.add_run(f"[{mkv[0]} mark{'s' if mkv[0] > 1 else ''}]"), 10, bold=True)
        for pt in points:
            pp = doc.add_paragraph()
            pp.paragraph_format.left_indent = Inches(0.35); pp.paragraph_format.space_after = Pt(1)
            set_font(pp.add_run("- " + pt), 10.5)
        pp = doc.add_paragraph()
        pp.paragraph_format.left_indent = Inches(0.35); pp.paragraph_format.space_after = Pt(6)
        set_font(pp.add_run("Marking note: " + note), 9.5, italic=True)

doc.add_page_break()

# ================================================================ BLUEPRINT
para("CURRICULUM ASSESSMENT BLUEPRINT", size=13, bold=True, align="c", space_after=3)
para(f"Strand: {STRAND}   |   Sub-strand: {SUBSTRAND}   |   Class: {CLASS}",
     size=10, italic=True, align="c", space_after=3)
para(f"Content Standard: {CS} - {CS_TEXT}", size=9, italic=True, align="c", space_after=3)
para("Source: NaCCA Science Common Core Programme Curriculum (B7/JHS1-B9/JHS3), September 2020, "
     "Strand 4: Forces and Energy, Sub-strand 3: Conversion and Conservation of Energy, "
     "pp. 33-34. Indicators are quoted, not invented.",
     size=9, italic=True, space_after=8)

hdr = ["Qn", "Sub-strand", "Content Standard", "Indicator (NaCCA) - Indicator Text", "Topic / Content",
       "Cognitive Level", "Marks"]

rows = [[f"A{i}", SUBSTRAND, CS_BY_TOPIC[tp], f"{IND[tp]} - {IND_TEXT[tp]}", TOPIC[tp], cog, 1]
        for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1)]
add_table(hdr, rows, widths=[0.35, 0.75, 0.75, 1.75, 1.4, 0.8, 0.35], size=7, head_size=7.5)

para("", space_after=8)
rows = []
for qb in SECTION_B:
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        key = tp if tp in TOPIC else tp.split(",")[0].strip()
        rows.append([f"B{qb['num']}{lab.strip('()')}", SUBSTRAND, CS_BY_TOPIC[key],
                     f"{IND[key]} - {IND_TEXT[key]}", TOPIC[key], cog, mk])
add_table(hdr, rows, widths=[0.35, 0.75, 0.75, 1.75, 1.4, 0.8, 0.35], size=7, head_size=7.5)

doc.add_page_break()

# ----------------------------------------------------------------- helpers
def topic_totals():
    m = {k: 0 for k in TOPIC}; it = {k: 0 for k in TOPIC}
    for q in MCQ:
        m[q[3]] += 1; it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk; it[key] += 1
    return m, it

def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}; b = {k: 0 for k in order}
    for q in MCQ: a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: b[cog] += mk
    return order, a, b

def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ: d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: d[diff] += mk
    return d

m, it = topic_totals(); diff = difficulty_totals(); order, ca, cb = cognitive_by_section()

para("SUMMARY 1 - COVERAGE BY CURRICULUM AREA (TOPIC)", size=12, bold=True, space_after=4)
rows = [[TOPIC[k], it[k], m[k], f"{(m[k]/100)*100:.1f}%", CC[k]] for k in TOPIC]
rows.append(["TOTAL", sum(it.values()), sum(m.values()), "100%", "-"])
add_table(["Topic / Content Area", "No. of Items", "Marks", "% of Total Marks", "Core Competencies"],
          rows, widths=[2.7, 0.8, 0.6, 1.0, 1.1], size=8.5)
para("CC = Communication and Collaboration; CP = Critical Thinking and Problem Solving; "
     "DL = Digital Literacy; CI = Creativity and Innovation.", size=8.5, italic=True, space_after=2)

para("", space_after=8)
para("SUMMARY 2 - COGNITIVE-LEVEL DISTRIBUTION (Bloom's Taxonomy)", size=12, bold=True, space_after=4)
rows = []
for lv in order:
    tot = ca[lv] + cb[lv]
    rows.append([lv, ca[lv], cb[lv], tot, f"{(tot/100)*100:.1f}%"])
rows.append(["TOTAL", sum(ca.values()), sum(cb.values()), sum(ca.values()) + sum(cb.values()), "100%"])
add_table(["Cognitive Level", "Section A Marks", "Section B Marks", "Total Marks", "% of Total"],
          rows, widths=[1.6, 1.3, 1.3, 1.1, 1.1], size=9.5)

para("", space_after=8)
para("SUMMARY 3 - DIFFICULTY DISTRIBUTION", size=12, bold=True, space_after=4)
rows = [[k, v, f"{(v/100)*100:.1f}%"] for k, v in diff.items()]
rows.append(["TOTAL", sum(diff.values()), "100%"])
add_table(["Difficulty", "Marks", "% of Total Marks"], rows, widths=[2.0, 1.2, 1.5], size=9.5)
para("Target in the master prompt: approximately 30% easy / 50% moderate / 20% challenging.",
     size=9, italic=True, space_after=2)

para("", space_after=8)
para("SUMMARY 4 - SECTION WEIGHTING", size=12, bold=True, space_after=4)
add_table(["Section", "Question Type", "Items", "Marks", "% of Total"],
          [["A", "Objective (multiple choice)", 40, 40, "40%"],
           ["B", "Theory / constructed response", 19, 60, "60%"],
           ["TOTAL", "-", 59, 100, "100%"]],
          widths=[0.9, 2.4, 0.8, 0.8, 1.0], size=9.5)

doc.add_page_break()

# ===================================================== QUALITY-CONTROL
para("QUALITY-CONTROL SUMMARY", size=13, bold=True, align="c", space_after=4)
para("Carried out against the 14-point validation list in the master prompt before the examination was "
     "finalised.", size=9.5, italic=True, space_after=8)

qc = [
 ("Does every question belong to the supplied curriculum scope?",
  "Yes. All 59 items - 40 objectives and 19 theory sub-questions - trace to Strand 4 (Forces and "
  "Energy), Sub-Strand 3 (Conversion and Conservation of Energy), topics 13.1-13.4, and to the "
  "three official B7 indicators (B7/JHS1.4.3.1.1, B7/JHS1.4.3.1.2 and B7/JHS1.4.3.1.3). "
  "Efficiency calculations, Sankey diagrams, power in watts, the kilowatt-hour and work done "
  "appear nowhere; machines are discussed only through the energy forms involved."),
 ("Is the examination appropriate for the stated class?",
  "Yes. The B7 curriculum requires learners to explain the law of conservation of energy using a "
  "closed system and a dry cell, explain energy conversion and its application to life, "
  "illustrate everyday conversions diagrammatically, and describe how energy could be conserved "
  "for future use for the benefit of humans and other life forms. The only arithmetic in the "
  "whole paper is one subtraction in Question 11 (100 J - 20 J), which applies the law rather "
  "than any formula."),
 ("Are the questions genuinely BECE-style?",
  "Yes: Section A is 40 four-option objectives worth 1 mark each, and Section B is structured "
  "theory with sub-questions carrying printed mark allocations. A labelled diagram and a "
  "completion table are both included, matching the BECE science convention and the 'by using "
  "diagram' and 'show diagrammatically' wording of the exemplars."),
 ("Are there enough application and reasoning questions?",
  "Yes. 30 of 100 marks (30%) are at Apply level or above (Apply 15, Analyse 5, Evaluate 7, "
  "Create 3). Evaluate is unusually well represented here because two of the three indicators "
  "ask pupils to explain a claim (Question 1(d)) and to justify conserving energy for other "
  "life forms (Question 7(b))."),
 ("Are the MCQ distractors plausible?",
  "Yes. Distractors are drawn from the same content family as the key: another form of energy "
  "(A4, A14, A21), a statement that is true of saving energy but not of the law (A8), a real "
  "but wrong reason for conserving energy (A32), and the single hardest confusion in this "
  "sub-strand - saying that energy is 'used up' or 'lost' (A1, A6, A9)."),
 ("Is there only one best answer for each MCQ?",
  "Yes. Every item was reviewed for a single defensible key. Special care was taken with A8, "
  "where 'energy should be saved for future use' is a true and worthwhile statement but is NOT "
  "the law of conservation of energy, and with A20, where light can be wasted but the standard "
  "wasted forms are heat and sound."),
 ("Are the marks internally consistent?",
  "Yes. Section A = 40 items x 1 mark = 40. Section B = 12 + 8 + 8 + 9 + 8 + 8 + 7 = 60. "
  "Each Section B sub-question's printed marks match its marking-scheme allocation, and every "
  "N-mark sub-question asks for N things."),
 ("Does the total add up correctly?",
  "Yes: 40 + 60 = 100 marks, matching the stated total on the front page."),
 ("Are the answers in the answer key correct?",
  "Yes. All 40 objective keys and all 19 Section B answers were verified against the marking "
  "scheme. Question 11 was checked: 100 J in, 20 J as light, so 80 J as heat."),
 ("Does the marking scheme match the questions?",
  "Yes. Every Section B sub-question has an expected-answer list and a marking note covering "
  "partial credit, acceptable alternatives, common wrong answers and method marks. The labelled "
  "diagram, the completion table, the poster-design task and the law-versus-saving distinction "
  "in Question 6(b) all have explicit marking grids."),
 ("Are the questions free from unnecessary ambiguity?",
  "Yes. Open items are anchored with 'state three', 'give two examples' and the mark allocation. "
  "Question 2(a) numbers every blank, (i) to (iv), and Question 3(a) numbers (i) to (vi). "
  "Question 4(c) says explicitly that the answer must match the appliances named in 4(a), and "
  "Question 7(b) requires at least two points to be about other life forms. Question 6(b) states "
  "the distinction it is looking for."),
 ("Are Ghanaian contexts used naturally and accurately?",
  "Yes: a maize mill, a charcoal pot, a pressing iron, cocoa beans dried in the sun, the "
  "Akosombo Dam, a windmill on a hill, a pupil riding a bicycle to school, a school switching "
  "off lights and fans during break, and a class display for the school open day."),
 ("Has any content outside the supplied curriculum been introduced?",
  "No. Every item sits inside topics 13.1-13.4. No efficiency percentages, no Sankey diagrams, "
  "no power or work calculations and no kilowatt-hour billing are required, all of which belong "
  "to later years."),
 ("Are the questions sufficiently varied?",
  "Yes. Item types include stating a law, defining a closed system, explaining the law with an "
  "example, judging an impossible claim, naming forms of energy from a diagram, defining "
  "conversion, completing a conversion table, naming a wasted form, matching appliances to "
  "conversions, designing a wall display, tracing the energy in a cyclist, listing ways to "
  "conserve energy, and explaining benefits to people and to other life forms."),
]
for i, (q, a) in enumerate(qc, start=1):
    p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(2)
    set_font(p.add_run(f"{i}. {q}"), 10.5, bold=True)
    p2 = doc.add_paragraph()
    p2.paragraph_format.left_indent = Inches(0.3); p2.paragraph_format.space_after = Pt(6)
    set_font(p2.add_run(a), 10)

para("", space_after=8)
para("EXAMINER NOTES (for the teacher, not for candidates)", size=11, bold=True, space_after=4)
for n in [
 "The whole paper turns on ONE distinction, and it is the one pupils get wrong most: the law of "
 "conservation of energy says the TOTAL energy stays the same; conserving energy for future use "
 "means looking after the USEFUL energy, because it keeps changing into forms we cannot gather "
 "up again. Question 6(b) tests exactly that, and the marking note allows at most 3 of 4 marks "
 "if the pupil does not make the distinction clear. Teach it explicitly before the mock.",
 "Fig. 1 is drawn with text characters because this is a plain Word file. Redraw it before "
 "printing if you can, but the numbering is what the questions depend on. Key: (i) chemical, "
 "(ii) electrical, (iii) light, (iv) heat.",
 "Question 1(d) asks pupils to judge a man who claims he has built a machine that gives out "
 "more energy than it is given. There is no marks for 'maybe' - the law says it is impossible, "
 "and the two marks are for the reasons. This is the item that separates pupils who have "
 "understood the law from those who have only memorised its wording.",
 "Question 5(a) is a design task: award method marks generously. Any workable diagram that is "
 "clearly described earns credit - the three marks are for the overall design, the labels, and "
 "showing at least two real conversions.",
 "Question 7(b) is the 'benefit to humans and other life forms' part of "
 "B7/JHS1.4.3.1.3. Insist on at least two points that are genuinely about plants or animals; "
 "a list of four human benefits earns only 2 of the 4 marks.",
 "The only arithmetic in the paper is Question 11 (100 J in, 20 J as light, so 80 J as heat). "
 "It applies the law rather than a formula, and it is the single Challenging item in Section A "
 "on this topic. Do not extend it into efficiency percentages - that is not B7 work.",
 "Topic weighting is 23 marks for 13.1 and 25 to 26 for each of the other three topics. If you "
 "would rather weight the everyday examples more heavily, move marks towards Questions 4 and 5.",
 "A good practical lesson before this mock: take a torch to pieces with the class and trace the "
 "chain dry cell, wires, bulb - chemical, electrical, light and heat. That is exemplar 1 of "
 "B7/JHS1.4.3.1.1, and it makes Questions 1(c) and 2 straightforward.",
 "Edit the school name, academic year and examination title on page 1 before printing.",
 "This is an original, teacher-made mock. It is not a reproduction of any WAEC or NaCCA examination "
 "paper.",
]:
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Inches(0.3); p.paragraph_format.space_after = Pt(3)
    set_font(p.add_run("- " + n), 10)

doc.save("/home/user/Basic7_Integrated_Science_Mock_Strand4_ConversionConservation.docx")
print("docx written")

print("Section A:", len(MCQ), "items")
print("Section B total:", sum(q["total"] for q in SECTION_B))
print("Topic marks:", m, "sum", sum(m.values()))
print("Difficulty:", diff, "sum", sum(diff.values()))
print("Cognitive A:", ca)
print("Cognitive B:", cb)
print("Answer counts:", counts)
print("Totals:", sum(m.values()), sum(diff.values()),
      sum(ca.values()) + sum(cb.values()))
