# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "/home/user")
from build_conserve import *

L = []
def w(s=""): L.append(s)

w(f"# {SCHOOL}"); w()
w(f"## {SUBJECT}"); w()
w(f"### {EXAM}"); w()
w(f"**Class:** {CLASS}  ")
w(f"**Time:** {TIME}  ")
w(f"**Total Marks:** {MARKS}  ")
w(f"**Academic Year:** {YEAR}"); w()
w("---"); w()
w("### INSTRUCTIONS"); w()
for i, t in enumerate([
    "Write your name and class clearly in the spaces provided on your answer sheet.",
    "This paper has TWO sections: Section A and Section B.",
    "Answer ALL the questions in both sections.",
    "Section A has 40 multiple-choice questions. Each question carries 1 mark. Choose the best answer (A, B, C or D) and record it on the answer sheet provided.",
    "Section B has 7 theory questions totalling 60 marks. Write your answers clearly and neatly in your answer booklet. Draw and label diagrams or tables where you are asked to.",
    "Read every question carefully before you answer it.",
    "Do not use correction fluid. Cancel any mistake neatly with a single line.",
    "Hand in your answer sheet and your answer booklet at the end of the examination.",
], start=1):
    w(f"{i}. {t}")
w(); w("---"); w()

w("## SECTION A: OBJECTIVE TEST (40 marks)"); w()
w("*Answer ALL questions. Each question carries 1 mark. Choose the BEST answer and write its letter "
  "(A, B, C or D) against the question number on your answer sheet.*"); w()
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"**{i}. {q}**"); w()
    for j, o in enumerate(opts): w(f"{'ABCD'[j]}. {o}")
    w()
w("---"); w()

w("## SECTION B: THEORY (60 marks)"); w()
w("*Answer ALL questions. Write your answers in your answer booklet. The marks for each question are shown "
  "in brackets.*"); w()
for qb in SECTION_B:
    w(f"### Question {qb['num']}  [{qb['total']} marks]"); w()
    w(qb["stem"]); w()
    if qb.get("diagram"):
        w("```")
        for line in TORCH: w(line)
        w("```")
        w("*Fig. 1: Energy conversion in a torch*"); w()
    if qb.get("table") == "conversion":
        w("| " + " | ".join(CVS_HEADERS) + " |")
        w("| " + " | ".join(["---"] * len(CVS_HEADERS)) + " |")
        for r in CVS_ROWS:
            w("| " + " | ".join(r) + " |")
        w()
        w("*Table 1: Energy conversion in everyday devices*"); w()
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        w(f"**{lab}** {text}  **[{mk} mark{'s' if mk > 1 else ''}]**"); w()
w("---"); w()

w("## ANSWER KEY"); w()
w("### Section A - Objective Test"); w()
w("| Question | Answer | Curriculum Area (Topic) | Cognitive Level |")
w("| -------- | ------ | ----------------------- | --------------- |")
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"| {i} | {ans} | {TOPIC[tp]} | {cog} |")
counts = {L2: sum(1 for q in MCQ if q[2] == L2) for L2 in "ABCD"}
w()
w("Correct-answer distribution: " + ", ".join(f"{L2} = {counts[L2]}" for L2 in "ABCD") + " (40 items).")
w()
w("### Section B - Theory (summary answers; full detail in the Marking Scheme)"); w()
w("| Question | Expected Answer | Curriculum Area | Cognitive Level |")
w("| -------- | --------------- | --------------- | --------------- |")
sba = [
 ("1 (a)", "Energy cannot be created and it cannot be destroyed; it can only be changed from one form into another, and the total amount always stays the same.", "13.1", "Understand"),
 ("1 (b)", "A closed system is one in which no energy enters and no energy leaves; all the energy stays inside.", "13.1", "Understand"),
 ("1 (c)", "The dry cell stores chemical energy, which changes into electrical energy in the wires and then into light and heat in the bulb. No energy is lost - the total at the end is exactly the same as the chemical energy at the start.", "13.1", "Apply"),
 ("1 (d)", "The claim is impossible. Energy cannot be created, so a machine cannot give out more than it was given; the most it can do is change all the energy it was given into other forms.", "13.1", "Evaluate"),
 ("2 (a)", "(i) chemical energy; (ii) electrical energy; (iii) light energy; (iv) heat energy.", "13.2", "Understand"),
 ("2 (b)", "Energy conversion is the changing of energy from one form into another.", "13.2", "Remember"),
 ("2 (c)", "The total amount of energy stays the same throughout; no energy is lost or destroyed, it only changes form.", "13.2", "Understand"),
 ("3 (a)", "(i) chemical energy from the dry cells; (ii) heat energy; (iii) sound energy; (iv) chemical energy from the fuel; (v) kinetic or movement energy; (vi) solar energy (light from the sun).", "13.2", "Understand"),
 ("3 (b)", "Any one device from the table plus the form of energy from it that is NOT useful - e.g. a torch also gives out heat, a radio gives out heat, a car engine gives out heat and sound.", "13.2", "Apply"),
 ("4 (a)", "Any three appliances with the correct conversion - e.g. a pressing iron (electrical to heat), a radio (electrical to sound), a bulb (electrical to light), a maize mill (electrical to movement).", "13.3", "Apply"),
 ("4 (b)", "Any three of: they give light to see by at night; heat for cooking and ironing; sound for the radio and television; movement for a fan or a blender.", "13.3", "Understand"),
 ("4 (c)", "The wasted form for each of the three appliances named in (a) - e.g. heat from a bulb, heat from a radio, heat and sound from a fan.", "13.3", "Understand"),
 ("5 (a)", "A row of boxes joined by arrows showing the chain from the source to the appliance to the useful form, with each box labelled with the energy form and a caption 'changes into' under each arrow.", "13.3", "Create"),
 ("5 (b)", "The food the pupil ate stores chemical energy; the body releases it, and in the muscles it is changed into kinetic energy that moves the legs, with some changed into heat.", "13.3", "Understand"),
 ("5 (c)", "Heat energy, from the body and from friction in the moving parts; and sound energy from the tyres and the chain.", "13.3", "Understand"),
 ("6 (a)", "Any four of: switch off lights and fans when nobody is in the room; use energy-saving bulbs; put a lid on the pot; boil only as much water as is needed; close the fridge door quickly; iron all the clothes at one time; dry food and clothes in the sun.", "13.4", "Understand"),
 ("6 (b)", "The law says the TOTAL energy stays the same, but it does not stay in a form we can use. Useful energy such as fuel and electricity is changed into heat and sound that spread out and cannot be gathered up again, so the energy that is easy to use keeps going down.", "13.4", "Analyse"),
 ("7 (a)", "Any three of: it saves the family money; it makes fuel and electricity last longer; it reduces power cuts; it reduces smoke in the home; the money saved can go on other needs.", "13.4", "Understand"),
 ("7 (b)", "Any four of: fewer trees are cut for fuel so forest animals keep their habitat; less smoke and fewer gases so plants and animals are not damaged; rivers are less dammed or polluted so fish survive; the climate warms more slowly; the plants that give out oxygen are left standing.", "13.4", "Evaluate"),
]
for r in sba: w(f"| {r[0]} | {r[1]} | {r[2]} | {r[3]} |")
w(); w("---"); w()

w("## MARKING SCHEME - SECTION B (60 marks)"); w()
w("*General rules: (1) Accept any other correct and relevant answer. (2) Award marks for correct points, not "
  "for repeating the question. (3) For procedures, award method marks. (4) Do not deduct marks for spelling "
  "unless the meaning is changed. (5) Where a candidate gives more answers than are asked for, mark only the "
  "first ones up to the number required.*"); w()
for qb in SECTION_B:
    n = qb["num"]
    w(f"### Question {n} ({qb['total']} marks)"); w()
    for (lab, points, note) in MARKING[n]:
        mkv = [p_[2] for p_ in qb["parts"] if p_[0] == lab]
        head = f"**{lab}**"
        if mkv: head += f" [{mkv[0]} mark{'s' if mkv[0] > 1 else ''}]"
        w(head); w()
        for pt in points: w(f"- {pt}")
        w(f"  - *Marking note: {note}*"); w()
w("---"); w()

w("## CURRICULUM ASSESSMENT BLUEPRINT"); w()
w(f"**Strand:** {STRAND} | **Sub-strand:** {SUBSTRAND} | **Class:** {CLASS}"); w()
w(f"**Content Standard:** {CS} - {CS_TEXT}"); w()
w("> Source: NaCCA Science Common Core Programme Curriculum (B7/JHS1-B9/JHS3), September 2020, "
  "Strand 4: Forces and Energy, Sub-strand 3: Conversion and Conservation of Energy, "
  "pp. 33-34. Indicators are quoted, not invented."); w()

w("### Section A"); w()
w("| Qn | Sub-strand | Content Standard | Indicator (NaCCA) - Indicator Text | Topic / Content | Cognitive Level | Marks |")
w("| -- | ---------- | ---------------- | ---------------------------------- | --------------- | --------------- | ----- |")
for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    w(f"| A{i} | {SUBSTRAND} | {CS_BY_TOPIC[tp]} | {IND[tp]} - {IND_TEXT[tp]} | {TOPIC[tp]} | {cog} | 1 |")
w()
w("### Section B"); w()
w("| Qn | Sub-strand | Content Standard | Indicator (NaCCA) - Indicator Text | Topic / Content | Cognitive Level | Marks |")
w("| -- | ---------- | ---------------- | ---------------------------------- | --------------- | --------------- | ----- |")
for qb in SECTION_B:
    for (lab, text, mkv, cog, tp, diff) in qb["parts"]:
        key = tp if tp in TOPIC else tp.split(",")[0].strip()
        w(f"| B{qb['num']}{lab.strip('()')} | {SUBSTRAND} | {CS_BY_TOPIC[key]} | {IND[key]} - {IND_TEXT[key]} | {TOPIC[key]} | {cog} | {mkv} |")
w(); w("---"); w()

def topic_totals():
    m = {k: 0 for k in TOPIC}; it = {k: 0 for k in TOPIC}
    for q in MCQ: m[q[3]] += 1; it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk; it[key] += 1
    return m, it

def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}; b = {k: 0 for k in order}
    for q in MCQ: a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: b[cog] += mk
    return order, a, b

def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ: d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: d[diff] += mk
    return d

m, it = topic_totals(); diff_ = difficulty_totals(); order, ca, cb = cognitive_by_section()

w("### Summary 1 - Coverage by Curriculum Area (Topic)"); w()
w("| Topic / Content Area | No. of Items | Marks | % of Total Marks | Core Competencies |")
w("| -------------------- | ------------ | ----- | ---------------- | ----------------- |")
for k in TOPIC: w(f"| {TOPIC[k]} | {it[k]} | {m[k]} | {(m[k]/100)*100:.1f}% | {CC[k]} |")
w(f"| **TOTAL** | **{sum(it.values())}** | **{sum(m.values())}** | **100%** | - |")
w()
w("*CC = Communication and Collaboration; CP = Critical Thinking and Problem Solving; DL = Digital Literacy; "
  "CI = Creativity and Innovation.*"); w()
w("### Summary 2 - Cognitive-Level Distribution (Bloom's Taxonomy)"); w()
w("| Cognitive Level | Section A Marks | Section B Marks | Total Marks | % of Total |")
w("| --------------- | --------------- | --------------- | ----------- | ---------- |")
for lv in order:
    tot = ca[lv] + cb[lv]
    w(f"| {lv} | {ca[lv]} | {cb[lv]} | {tot} | {(tot/100)*100:.1f}% |")
w(f"| **TOTAL** | **{sum(ca.values())}** | **{sum(cb.values())}** | **{sum(ca.values())+sum(cb.values())}** | **100%** |")
w()
w("### Summary 3 - Difficulty Distribution"); w()
w("| Difficulty | Marks | % of Total Marks |")
w("| ---------- | ----- | ---------------- |")
for k, v in diff_.items(): w(f"| {k} | {v} | {(v/100)*100:.1f}% |")
w(f"| **TOTAL** | **{sum(diff_.values())}** | **100%** |")
w()
w("*Target in the master prompt: approximately 30% easy / 50% moderate / 20% challenging.*"); w()
w("### Summary 4 - Section Weighting"); w()
w("| Section | Question Type | Items | Marks | % of Total |")
w("| ------- | ------------- | ----- | ----- | ---------- |")
w("| A | Objective (multiple choice) | 40 | 40 | 40% |")
w("| B | Theory / constructed response | 19 | 60 | 60% |")
w("| **TOTAL** | - | **59** | **100** | **100%** |")
w(); w("---"); w()

w("## QUALITY-CONTROL SUMMARY")
w("")
w("| Check | Status |")
w("| --- | --- |")
for q_, a_ in [
 ("Every question within supplied curriculum scope",
  "Yes - all 59 items (40 objectives and 19 theory sub-questions) sit in topics 13.1-13.4 of Strand 4, Sub-Strand 3 (Conversion and Conservation of Energy), mapped to indicators B7/JHS1.4.3.1.1, B7/JHS1.4.3.1.2 and B7/JHS1.4.3.1.3"),
 ("Appropriate for the class",
  "Yes - B7 level; the only arithmetic in the paper is one subtraction in Question 11 (100 J in, 20 J as light, so 80 J as heat), which applies the law rather than any formula. No efficiency calculations, power or kilowatt-hours"),
 ("Genuinely BECE-style",
  "Yes - 40 four-option objectives plus structured theory with printed mark allocations, a labelled diagram and a completion table"),
 ("Sufficient application and reasoning",
  "Yes - 30 of 100 marks (30%) at Apply level or above (Apply 15, Analyse 5, Evaluate 7, Create 3)"),
 ("Plausible MCQ distractors",
  "Yes - another form of energy, a statement that is true of saving energy but not of the law, a real but wrong reason for conserving energy, and the single hardest confusion in this sub-strand (saying that energy is used up or lost)"),
 ("Single best answer per MCQ",
  "Yes - reviewed item by item; special care with A8, where 'energy should be saved for future use' is true but is NOT the law, and A20, where the standard wasted forms are heat and sound"),
 ("Marks internally consistent",
  "Yes - Section A 40 x 1 = 40; Section B 12 + 8 + 8 + 9 + 8 + 8 + 7 = 60; sub-question marks match the marking scheme"),
 ("Total adds up correctly",
  "Yes - 40 + 60 = 100"),
 ("Answer key correct",
  "Yes - all 40 keys and all 19 Section B answers verified against the marking scheme; Question 11 checked (100 J in, 20 J light, 80 J heat)"),
 ("Marking scheme matches questions",
  "Yes - expected answers plus marking notes covering partial credit, alternatives, common wrong answers and method marks; the labelled diagram, the completion table, the poster-design task and the law-versus-saving distinction in Question 6(b) all have explicit marking grids"),
 ("Free from unnecessary ambiguity",
  "Yes - open items are anchored with 'state three' and 'give two examples' plus the mark allocation; Question 2(a) numbers every blank (i) to (iv) and Question 3(a) (i) to (vi); Question 4(c) says the answer must match the appliances named in 4(a), Question 7(b) requires at least two points about other life forms, and Question 6(b) states the distinction it is looking for"),
 ("Ghanaian contexts natural and accurate",
  "Yes - a maize mill, a charcoal pot, a pressing iron, cocoa beans dried in the sun, the Akosombo Dam, a windmill on a hill, a pupil riding a bicycle to school, a school switching off lights and fans during break, and a class display for the school open day"),
 ("No content beyond the curriculum",
  "No - every item sits inside topics 13.1-13.4; no efficiency percentages, Sankey diagrams, power or work calculations, or kilowatt-hour billing, all of which belong to later years"),
 ("Questions sufficiently varied",
  "Yes - stating a law, defining a closed system, explaining the law with an example, judging an impossible claim, naming forms of energy from a diagram, defining conversion, completing a conversion table, naming a wasted form, matching appliances to conversions, designing a wall display, tracing the energy in a cyclist, listing ways to conserve energy, and explaining benefits to people and to other life forms"),
]:
    w("| " + q_ + " | " + a_ + " |")
w("")
w("### EXAMINER NOTES")
w("")
for n_ in [
 "The whole paper turns on ONE distinction, and it is the one pupils get wrong most: the law of conservation of energy says the TOTAL energy stays the same; conserving energy for future use means looking after the USEFUL energy, because it keeps changing into forms we cannot gather up again. Question 6(b) tests exactly that, and the marking note allows at most 3 of 4 marks if the pupil does not make the distinction clear. Teach it explicitly before the mock.",
 "Fig. 1 is drawn with text characters because this is a plain Markdown file. Redraw it before printing if you can, but the numbering is what the questions depend on. Key: (i) chemical, (ii) electrical, (iii) light, (iv) heat.",
 "Question 1(d) asks pupils to judge a man who claims he has built a machine that gives out more energy than it is given. There are no marks for 'maybe' - the law says it is impossible, and the two marks are for the reasons. This is the item that separates pupils who have understood the law from those who have only memorised its wording.",
 "Question 5(a) is a design task: award method marks generously. Any workable diagram that is clearly described earns credit - the three marks are for the overall design, the labels, and showing at least two real conversions.",
 "Question 7(b) is the 'benefit to humans and other life forms' part of B7/JHS1.4.3.1.3. Insist on at least two points that are genuinely about plants or animals; a list of four human benefits earns only 2 of the 4 marks.",
 "The only arithmetic in the paper is Question 11 (100 J in, 20 J as light, so 80 J as heat). It applies the law rather than a formula, and it is the single Challenging item in Section A on this topic. Do not extend it into efficiency percentages - that is not B7 work.",
 "Topic weighting is 23 marks for 13.1 and 25 to 26 for each of the other three topics. If you would rather weight the everyday examples more heavily, move marks towards Questions 4 and 5.",
 "A good practical lesson before this mock: take a torch to pieces with the class and trace the chain dry cell, wires, bulb - chemical, electrical, light and heat. That is exemplar 1 of B7/JHS1.4.3.1.1, and it makes Questions 1(c) and 2 straightforward.",
 "Edit the school name, academic year and examination title on page 1 before printing.",
 "This is an original, teacher-made mock. It is not a reproduction of any WAEC or NaCCA examination paper.",
]:
    w("- " + n_)
w()

open("/home/user/Basic7_Integrated_Science_Mock_Strand4_ConversionConservation.md", "w", encoding="utf-8").write("\n".join(L))
print("md written", len("\n".join(L)), "chars")
