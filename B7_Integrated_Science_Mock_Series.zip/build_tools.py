# -*- coding: utf-8 -*-
"""Basic 7 Integrated Science mock - Strand 4 Sub-strand 5: AGRICULTURAL TOOLS.
Covers topics 15.1 to 15.4 (basic and simple agricultural tools; the importance of proper
handling and maintenance; the rules for handling tools safely; and maintaining tools in the
community). 100 marks.
Indicators sourced from the official NaCCA Science CCP curriculum (B7/JHS1-B9/JHS3, Sept 2020),
Strand 4: Forces and Energy, Sub-strand 5: Agricultural Tools, printed pages 41-43.
Content standard: B7/JHS1.4.5.1."""

SCHOOL = "[SCHOOL NAME]"
SUBJECT = "INTEGRATED SCIENCE (SCIENCE)"
EXAM = "END-OF-TERM MOCK EXAMINATION"
CLASS = "Basic 7 (JHS 1)"
TIME = "2 hours (Suggested: Section A - 40 min; Section B - 80 min)"
MARKS = "100"
YEAR = "2025/2026 Academic Year"

STRAND = "Forces and Energy"
SUBSTRAND = "Agricultural Tools"

TOPIC = {
    "15.1": "15.1 Basic and Simple Agricultural Tools",
    "15.2": "15.2 Importance of Proper Handling and Maintenance of Agricultural Tools",
    "15.3": "15.3 Rules for Handling Agricultural Tools Safely",
    "15.4": "15.4 Maintaining Agricultural Tools in the Community",
}

CS = "B7/JHS1.4.5.1"
CS_BY_TOPIC = {k: "B7/JHS1.4.5.1" for k in ["15.1", "15.2", "15.3", "15.4"]}
CS_TEXT = ("Demonstrate knowledge and skills in handling and maintenance of basic and simple "
           "agricultural tools")

IND = {
    "15.1": "B7/JHS1.4.5.1.1 (Ex. 1)",
    "15.2": "B7/JHS1.4.5.1.1 (Ex. 2)",
    "15.3": "B7/JHS1.4.5.1.1 (Ex. 3, 4)",
    "15.4": "B7/JHS1.4.5.1.2 (Ex. 1-3)",
}
IND_TEXT = {
    "15.1": "Explain the basic rules in handling and maintaining simple agricultural tools. "
            "Ex. 1: List some simple or basic farm tools in agriculture (give examples found in "
            "animal and crop farms).",
    "15.2": "Explain the basic rules in handling and maintaining simple agricultural tools. "
            "Ex. 2: Discuss the meaning and importance of handling and maintenance of "
            "agricultural tools.",
    "15.3": "Explain the basic rules in handling and maintaining simple agricultural tools. "
            "Ex. 3, 4: List and match the basic rules in handling and maintenance of tools with "
            "specific simple tools used in agriculture; describe how handling and maintenance of "
            "simple and basic agricultural tools are done.",
    "15.4": "Apply the handling and maintenance of basic and simple agricultural tools in their "
            "community. Ex. 1-3: Observe and discuss the handling and maintenance of basic and "
            "simple agricultural tools used in farms visited in the community and write a report; "
            "assemble agricultural tools from the community and practice handling the tools to "
            "perform simple agricultural operations and write down the operational rules of "
            "handling agricultural tools; assemble agricultural tools from the community and "
            "practice the basic rules in tools maintenance and list the rules used.",
}
CC = {"15.1": "CC, CP, CI, DL, CG", "15.2": "CC, CP, CI, DL, CG",
      "15.3": "CC, CP, CI, DL, CG", "15.4": "CC, CP, CI, DL, CG"}

# ---------------------------------------------------------------- SECTION A
# (question, [A,B,C,D], answer, topic, cognitive, difficulty)
MCQ = [
 ("Which of these is a basic or simple agricultural tool?",
  ["a tractor", "a combine harvester", "a hoe", "a plough"],
  "C", "15.1", "Remember", "Easy"),
 ("A cutlass is used mainly for",
  ["cutting and clearing bushes", "digging holes", "carrying water", "gathering leaves"],
  "A", "15.1", "Remember", "Easy"),
 ("The farm tool used for turning and loosening the soil is a",
  ["rake", "cutlass", "head pan", "hoe"],
  "D", "15.1", "Understand", "Moderate"),
 ("A rake is used to",
  ["dig deep holes", "gather leaves and grass together", "spray chemicals", "sharpen a cutlass"],
  "B", "15.1", "Remember", "Easy"),
 ("A knapsack sprayer is used to",
  ["apply chemicals such as pesticides and weedicides", "water seedlings",
   "carry harvested maize", "dig planting holes"],
  "A", "15.1", "Understand", "Moderate"),
 ("Which of these tools is used on an animal farm?",
  ["a dibber", "a sickle", "a feeding trough", "a trowel"],
  "C", "15.1", "Apply", "Moderate"),
 ("A watering can is used to",
  ["apply weedicide", "store seeds", "carry manure", "water young seedlings"],
  "D", "15.1", "Remember", "Easy"),
 ("A wheelbarrow is used on the farm to",
  ["spray crops", "carry loads from one place to another", "sharpen tools", "measure the land"],
  "B", "15.1", "Remember", "Easy"),
 ("The tool used to harvest rice or guinea corn by cutting the stems is a",
  ["hoe", "rake", "sickle", "trowel"],
  "C", "15.1", "Apply", "Challenging"),
 ("A dibber is used to",
  ["make holes for planting seeds", "cut grass", "spray insecticides", "carry water"],
  "A", "15.1", "Understand", "Challenging"),
 ("A trowel is used to",
  ["clear bush", "prune trees", "harvest yam",
   "dig small holes and transplant seedlings"],
  "D", "15.1", "Understand", "Moderate"),
 ("A head pan is used to",
  ["spray crops", "carry soil, manure or harvested produce", "sharpen cutlasses",
   "measure chemicals"],
  "B", "15.1", "Apply", "Moderate"),

 ("Handling a farm tool means",
  ["buying the tool", "selling the tool",
   "the way the tool is carried, used and kept", "the price of the tool"],
  "C", "15.2", "Understand", "Moderate"),
 ("Maintaining a farm tool means",
  ["making the tool bigger", "painting it every day", "keeping it in the sun",
   "looking after it so that it stays clean, sharp and in good working order"],
  "D", "15.2", "Understand", "Moderate"),
 ("One importance of proper handling of farm tools is that it",
  ["prevents accidents and injuries", "makes the tools heavier", "makes the tools rust",
   "makes the work slower"],
  "A", "15.2", "Understand", "Easy"),
 ("A tool that is well maintained",
  ["becomes blunt quickly", "lasts longer and does its work better", "costs more to repair",
   "breaks more often"],
  "B", "15.2", "Remember", "Easy"),
 ("A rusty cutlass is difficult to use because",
  ["it is too light", "it is too long", "it looks old", "rust makes the blade blunt and weak"],
  "D", "15.2", "Understand", "Moderate"),
 ("The main reason for cleaning a tool after use is to",
  ["make it look new", "make it heavier", "remove soil and moisture that cause rust",
   "make the handle longer"],
  "C", "15.2", "Understand", "Moderate"),
 ("A wooden handle that is left out in the rain may",
  ["grow bigger", "rot and break", "turn to metal", "become sharper"],
  "B", "15.2", "Understand", "Moderate"),
 ("Proper maintenance of farm tools saves the farmer money because",
  ["the tools do not have to be replaced often", "the farmer works slower",
   "the tools need more repairs", "the tools become heavier"],
  "A", "15.2", "Apply", "Easy"),

 ("One basic rule in handling a cutlass is to",
  ["cut towards the body", "cut away from the body", "cut with the eyes closed",
   "cut with the blade pointing up"],
  "B", "15.3", "Remember", "Easy"),
 ("A blunt tool is more dangerous than a sharp one because",
  ["it is heavier", "it is shorter", "it needs more force and can slip", "it is made of iron"],
  "C", "15.3", "Analyse", "Challenging"),
 ("A cutlass should be carried with",
  ["the blade pointing downwards", "the blade pointing forwards",
   "the blade held between the teeth", "the blade resting on the shoulder"],
  "A", "15.3", "Understand", "Moderate"),
 ("While working, a tool that is not being used should be",
  ["left lying on the path", "thrown into the bush", "held under the arm",
   "put down safely away from the working area"],
  "D", "15.3", "Understand", "Moderate"),
 ("Before using a sprayer, a farmer should",
  ["fill it with any liquid", "read the label on the chemical", "pour the chemical away",
   "test it on his hands"],
  "B", "15.3", "Apply", "Moderate"),
 ("After spraying chemicals, the farmer should",
  ["eat immediately", "sleep in the field", "wash hands and body with soap and water",
   "breathe the chemical deeply"],
  "C", "15.3", "Remember", "Easy"),
 ("Children should use farm tools",
  ["only under the supervision of an adult", "at night", "in the rain", "without any training"],
  "A", "15.3", "Understand", "Easy"),
 ("A tool with a loose handle should be",
  ["used carefully", "given to a child", "thrown away at once",
   "repaired before it is used again"],
  "D", "15.3", "Apply", "Moderate"),
 ("Wearing boots and gloves on the farm",
  ["makes the work slower", "protects the farmer from cuts and infections",
   "makes the tools blunt", "keeps the tools clean"],
  "B", "15.3", "Understand", "Easy"),
 ("A hoe is best kept after work by",
  ["leaving it in the field", "throwing it into the bush",
   "cleaning and drying it and hanging it in a dry place", "putting it into a river"],
  "C", "15.3", "Apply", "Moderate"),
 ("Oiling the metal parts of a tool helps to",
  ["prevent rust", "make the tool blunt", "make the tool heavier", "make the handle rot"],
  "A", "15.3", "Understand", "Easy"),

 ("A group of farmers in a community may share tools so that",
  ["the tools get lost", "nobody can farm", "the tools rust quickly",
   "everybody can farm without each buying every tool"],
  "D", "15.4", "Understand", "Challenging"),
 ("After a visit to a community farm, pupils are usually asked to",
  ["write a report on what they observed", "buy new tools for the farm", "sell the farm tools",
   "stay away from the farm"],
  "A", "15.4", "Remember", "Easy"),
 ("The best way to learn how to handle a hoe is to",
  ["read about it only", "watch television", "practise using it under supervision",
   "guess how it works"],
  "C", "15.4", "Understand", "Easy"),
 ("A community tool store should be",
  ["open to the rain", "dry, well ventilated and locked", "built on wet ground",
   "left without a roof"],
  "B", "15.4", "Understand", "Moderate"),
 ("Before tools are put into store for the dry season, they should be",
  ["left dirty", "buried in the soil", "piled in a heap", "cleaned, dried and oiled"],
  "D", "15.4", "Apply", "Moderate"),
 ("A farmer who finds a crack in the handle of a shared hoe should",
  ["report it and have it replaced before use", "hide the crack with paint",
   "keep using it quietly", "give it to a child"],
  "A", "15.4", "Apply", "Moderate"),
 ("Assembling farm tools from the community helps pupils to",
  ["sell them at the market", "break them quickly",
   "see and handle the tools they are learning about", "avoid farm work"],
  "C", "15.4", "Understand", "Easy"),
 ("One way the community can keep shared tools in good condition is to",
  ["leave them out in the rain",
   "set rules about who uses them and how they are cared for",
   "let only one person use them", "use them without cleaning"],
  "B", "15.4", "Understand", "Moderate"),
 ("A report on a farm visit should include",
  ["the price of the land", "the names of the farmer's children", "the market price of maize",
   "the tools seen, how they were handled and how they were maintained"],
  "D", "15.4", "Apply", "Moderate"),
]

# ------------------------------------------------ SECTION B DIAGRAM + TABLE
HOE = [
 "                            (i)",
 "                             |",
 "                             v",
 "              +------------------------------+",
 "              |                              |",
 "              |                              |",
 "              +------------------------------+",
 "                             |",
 "                             |",
 "                  +----------------------+",
 "                  |                      |",
 "                  |         (ii)         |",
 "                  |                      |",
 "                  +----------------------+",
 "                             ^",
 "                             |",
 "                           (iii)",
]
HOE_KEY = "(i) handle, (ii) blade, (iii) cutting edge"

TOOL_HEADERS = ["Farm tool", "What it is used for"]
TOOL_ROWS = [
 ["Cutlass", "(i)"],
 ["Hoe", "(ii)"],
 ["Sickle", "(iii)"],
 ["Head pan", "(iv)"],
 ["Rake", "(v)"],
 ["Watering can", "(vi)"],
]

# ---------------------------------------------------------------- SECTION B
SECTION_B = [
 dict(
   num=1, total=10, topic="15.1",
   stem="Fig. 1 shows one of the basic tools used on a Ghanaian farm. Study it and answer the "
        "questions that follow.",
   diagram=True,
   parts=[
     ("(a)", "Name the parts labelled (i), (ii) and (iii) in Fig. 1.",
      3, "Understand", "15.1", "Moderate"),
     ("(b)", "Name four other basic or simple agricultural tools.",
      4, "Remember", "15.1", "Easy"),
     ("(c)", "State one use of each of the following tools: a watering can; a knapsack sprayer; "
             "a wheelbarrow.", 3, "Understand", "15.1", "Easy"),
   ]),
 dict(
   num=2, total=8, topic="15.1",
   stem="The table below shows some common farm tools. Study it and answer the questions that "
        "follow.",
   table="tools",
   parts=[
     ("(a)", "Copy and complete the table.", 6, "Understand", "15.1", "Challenging"),
     ("(b)", "Name two tools used on an animal farm and state one use of each.",
      2, "Apply", "15.1", "Easy"),
   ]),
 dict(
   num=3, total=9, topic="15.2",
   stem="Farm tools cost money, and a tool that is well cared for serves the farmer for many "
        "years.",
   parts=[
     ("(a)", "Explain what is meant by the handling of agricultural tools.",
      3, "Understand", "15.2", "Moderate"),
     ("(b)", "Explain what is meant by the maintenance of agricultural tools.",
      3, "Understand", "15.2", "Moderate"),
     ("(c)", "State three reasons why proper handling and maintenance of farm tools are "
             "important.", 3, "Understand", "15.2", "Easy"),
   ]),
 dict(
   num=4, total=8, topic="15.2",
   stem="A farmer who neglects his tools soon finds that they cost him more than he saved.",
   parts=[
     ("(a)", "State three things that can happen to a farm tool that is not properly maintained.",
      3, "Understand", "15.2", "Moderate"),
     ("(b)", "Explain why a rusty hoe is difficult and dangerous to use.",
      3, "Apply", "15.2", "Moderate"),
     ("(c)", "Your class is discussing whether it is better to buy cheap tools every year or to "
             "look after good ones. Which would you choose? Give two reasons.",
      2, "Evaluate", "15.2", "Moderate"),
   ]),
 dict(
   num=5, total=9, topic="15.3",
   stem="Most accidents on the farm happen because a basic rule of handling was not followed.",
   parts=[
     ("(a)", "State four basic rules for handling agricultural tools safely.",
      4, "Understand", "15.3", "Moderate"),
     ("(b)", "Explain why a blunt cutlass is more dangerous than a sharp one.",
      3, "Analyse", "15.3", "Challenging"),
     ("(c)", "State two things a farmer should do immediately after using a knapsack sprayer.",
      2, "Understand", "15.3", "Moderate"),
   ]),
 dict(
   num=6, total=7, topic="15.3",
   stem="Each tool has its own rules, and the rules depend on how the tool is used.",
   parts=[
     ("(a)", "For each of the following tools, state one rule for handling it safely: a cutlass; "
             "a hoe; a knapsack sprayer; a wheelbarrow.", 4, "Apply", "15.3", "Moderate"),
     ("(b)", "Describe how a hoe should be prepared and kept at the end of the day's work.",
      3, "Apply", "15.3", "Challenging"),
   ]),
 dict(
   num=7, total=9, topic="15.4",
   stem="Tools are also cared for at the level of the community, where farmers may share them.",
   parts=[
     ("(a)", "State three ways in which tools are maintained in the community.",
      3, "Understand", "15.4", "Moderate"),
     ("(b)", "Your class is going to visit a farm in the community to observe how tools are "
             "handled and maintained. Describe what you would do to prepare for the visit and "
             "what you would observe and record.", 4, "Create", "15.4", "Challenging"),
     ("(c)", "After the visit, your class must report what it found. State two things the report "
             "should contain.", 2, "Remember", "15.4", "Easy"),
   ]),
]

# ------------------------------------------------------- MARKING SCHEME
MARKING = {
 1: [
   ("(a)", ["(i) handle", "(ii) blade", "(iii) cutting edge"],
    "1 mark each for all THREE correct labels (3 marks). The number must be matched to the "
    "answer. Accept 'shaft' or 'stick' for the handle and 'sharp edge' for the cutting edge. Do "
    "NOT accept 'hoe' or 'metal' for any of them."),
   ("(b)", ["A cutlass", "A hoe", "A rake", "A spade or shovel", "A garden fork", "A trowel",
            "A watering can", "A wheelbarrow", "A knapsack sprayer", "A sickle", "An axe",
            "A dibber", "A head pan", "A mattock or pick-axe", "A pair of secateurs"],
    "1 mark each for any FOUR correct tools (4 marks). Accept any basic hand tool used on a "
    "farm. Do NOT accept a tractor, a combine harvester, a plough or any machine with an "
    "engine, and do NOT accept the hoe shown in Fig. 1."),
   ("(c)", ["A watering can - used to water young plants and seedlings.",
            "A knapsack sprayer - used to apply chemicals such as pesticides and weedicides.",
            "A wheelbarrow - used to carry soil, manure, harvested produce or other loads."],
    "1 mark for each correct use (3 marks). The tool and its use must be matched."),
 ],
 2: [
   ("(a)", ["(i) cutting and clearing bushes, weeding, or cutting grass",
            "(ii) digging, turning and loosening the soil, and making mounds",
            "(iii) harvesting rice, guinea corn or grass by cutting the stems",
            "(iv) carrying soil, manure or harvested produce",
            "(v) gathering leaves, grass and rubbish together, and levelling the soil",
            "(vi) watering young plants and seedlings"],
    "1 mark each for any SIX correct uses (6 marks). The blank number must be matched to the "
    "answer. Accept any correct use of that tool; do NOT accept a use that belongs to a "
    "different tool in the table."),
   ("(b)", ["A feeding trough - used to hold feed for the animals.",
            "A watering trough - used to hold drinking water for the animals.",
            "An egg tray or crate - used to hold and carry eggs.",
            "A spray pump - used to dip or spray animals against ticks and lice.",
            "A weighing scale - used to weigh the animals.",
            "A syringe and needle - used to give animals medicine or vaccines.",
            "A hoof trimmer or a de-beaking tool - used to trim hooves or beaks.",
            "An incubator - used to hatch eggs."],
    "1 mark for each of TWO correct animal-farm tools, and 1 mark between them for the two "
    "correct uses (2 marks). Accept any tool genuinely found on an animal farm."),
 ],
 3: [
   ("(a)", ["Handling is the way a tool is carried, used and kept while work is going on.",
            "It covers how the tool is picked up, carried to the farm, used and put down.",
            "Good handling means using the tool for the job it was made for and in the correct "
            "way."],
    "1 mark each for any THREE correct points (3 marks). The key ideas are carrying, using and "
    "keeping. Do NOT accept 'buying a tool' or 'the price of a tool'."),
   ("(b)", ["Maintenance is looking after a tool so that it stays in good working order.",
            "It includes cleaning, drying, sharpening, oiling and repairing the tool.",
            "It is done after use and during storage, so that the tool lasts longer."],
    "1 mark each for any THREE correct points (3 marks). The key ideas are looking after the "
    "tool and keeping it clean, sharp and sound."),
   ("(c)", ["Proper handling prevents accidents and injuries to the farmer and to others.",
            "Well-maintained tools last longer, so the farmer does not have to replace them "
            "often.", "The tools work better and faster, so more work is done in less time.",
            "Good maintenance saves money, because repairs and replacements are few.",
            "Clean, sharp tools do a better job, so crops and animals are better cared for."],
    "1 mark each for any THREE correct reasons (3 marks). Accept any sensible reason."),
 ],
 4: [
   ("(a)", ["The metal part rusts, so the tool becomes weak and blunt.",
            "The wooden handle rots or cracks and may break.",
            "The tool becomes blunt, so it does its work badly and slowly.",
            "The tool has to be repaired or replaced often, which costs money.",
            "A neglected tool can cause accidents and injuries.",
            "Moving parts seize up or the handle works loose."],
    "1 mark each for any THREE correct points (3 marks). Accept any sensible consequence."),
   ("(b)", ["Rust makes the blade weak, so it may bend or break during work.",
            "Rust makes the blade blunt, so it does not cut into the soil easily.",
            "A blunt blade needs much more force, so the farmer tires quickly.",
            "Because more force is used, the hoe is more likely to slip and cause an injury.",
            "The extra effort means less work is done in the day."],
    "1 mark each for any THREE correct points (3 marks). One of the three marks must come from "
    "the DIFFICULTY and one from the DANGER; award at most 2 marks if only one of the two is "
    "explained."),
   ("(c)", ["I would choose to look after good tools.",
            "Good tools cost more at first but last for many years, so they are cheaper in the "
            "long run.",
            "Looking after tools means fewer repairs and fewer replacements.",
            "Good, sharp tools do the work better and faster, so the farmer earns more.",
            "Accept a pupil who chooses cheap tools only if they give a good reason, such as "
            "that there is no money for better ones now."],
    "1 mark for a clear choice and 1 mark for any ONE good reason (2 marks). Both marks may be "
    "earned from either side of the argument, provided the reason supports the choice."),
 ],
 5: [
   ("(a)", ["Always cut away from the body.",
            "Carry tools with the blade or sharp edge pointing downwards.",
            "Use each tool only for the job it was made for.",
            "Put a tool that is not being used down safely, away from the working area.",
            "Wear protective clothing such as boots and gloves.",
            "Never leave tools lying on a path or in the grass where someone may step on them.",
            "Repair or report any damaged tool before using it again.",
            "Children should use tools only under the supervision of an adult.",
            "Read the label before using any chemical, and wash afterwards."],
    "1 mark each for any FOUR correct rules (4 marks). Do NOT accept a rule that belongs to "
    "maintenance rather than handling, such as 'oil the blade after use'."),
   ("(b)", ["A blunt cutlass does not bite into the material easily, so the farmer has to use "
            "much more force.",
            "The extra force makes the blade harder to control, so it is more likely to slip.",
            "When it slips it can cut the farmer's leg, hand or foot.",
            "A sharp cutlass cuts with a light, controlled stroke, so it goes where the farmer "
            "wants it to go.",
            "Rushing and forcing a blunt blade is what causes most cutlass accidents."],
    "1 mark each for any THREE correct points (3 marks). The key chain is: blunt needs more "
    "force, more force means less control, less control means the blade slips. Award at most "
    "1 mark for an answer that only says 'it can cut you'."),
   ("(c)", ["Wash the hands, face and any other exposed skin with soap and clean water.",
            "Wash or change the clothing worn during spraying.",
            "Clean the sprayer and put it away safely.",
            "Do not eat, drink or smoke before washing.",
            "Report any feeling of sickness or dizziness at once."],
    "1 mark each for any TWO correct points (2 marks). Accept any sensible safety step "
    "immediately after spraying."),
 ],
 6: [
   ("(a)", ["A cutlass - always cut away from the body, and carry it with the blade pointing "
            "downwards.",
            "A hoe - keep the blade pointing down when carrying it, and do not swing it near "
            "another person.",
            "A knapsack sprayer - read the label, wear a nose cover and gloves, and do not "
            "spray against the wind.",
            "A wheelbarrow - do not overload it, and keep the load balanced so that it does not "
            "tip over.",
            "Any other correct rule matched to the right tool."],
    "1 mark for each tool with a correct safety rule matched to it (4 marks). The rule must "
    "belong to that tool; award no mark for a correct rule attached to the wrong tool."),
   ("(b)", ["Wash or wipe off all the soil and moisture from the blade.",
            "Dry the hoe thoroughly in the sun or with a cloth.",
            "Sharpen the blade if it has become blunt.",
            "Oil or grease the metal part lightly to keep rust away.",
            "Hang it up or stand it in a dry, covered store rather than leaving it on the "
            "ground.",
            "Check the handle and tighten or replace it if it is loose or cracked."],
    "1 mark each for any THREE correct points (3 marks). The three ideas to look for are "
    "cleaning, drying and storing dry; the oiling and the sharpening are extra credit. Award at "
    "most 2 marks if the storing step is missing."),
 ],
 7: [
   ("(a)", ["Farmers clean, dry and oil shared tools after use.",
            "Tools are kept in a dry, locked community store.",
            "The community sets rules about who may use the tools and how they are cared for.",
            "Farmers meet to repair or replace damaged tools together.",
            "Pupils and farmers assemble tools from the community and practise using and "
            "maintaining them.",
            "A visit is made to a community farm to observe and report on how tools are "
            "handled."],
    "1 mark each for any THREE correct points (3 marks). Accept any sensible way in which a "
    "community looks after its tools."),
   ("(b)", ["Ask permission from the farm owner and agree a date and time with the class.",
            "Decide beforehand what the class is looking for, and prepare a short list or "
            "checklist.",
            "Move round the farm in a group, watching how each tool is carried, used and put "
            "down.",
            "Look at how the tools are cleaned, dried, sharpened and stored after work.",
            "Ask the farmer or workers questions about the rules they follow.",
            "Write down or draw each tool seen, with a note of its condition and how it is "
            "cared for.",
            "Keep clear of the working area so that the class does not cause an accident."],
    "1 mark each for any FOUR correct points (4 marks). This is a design task: award method "
    "marks for any sensible plan. Look for at least ONE point about preparing for the visit and "
    "at least ONE point about what would be observed or recorded; award at most 3 marks if the "
    "answer covers only one of the two."),
   ("(c)", ["The names of the tools seen on the farm.",
            "What each tool is used for.",
            "How each tool was handled.",
            "How each tool was maintained.",
            "The condition the tools were found in and anything that needed repair."],
    "1 mark each for any TWO correct points (2 marks). Accept any two sensible contents of a "
    "farm-visit report."),
 ],
}


# --------------------------------------------- derive summary statistics
def topic_totals():
    m = {k: 0 for k in TOPIC}
    it = {k: 0 for k in TOPIC}
    for q in MCQ:
        m[q[3]] += 1
        it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk
            it[key] += 1
    return m, it


def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}
    b = {k: 0 for k in order}
    for q in MCQ:
        a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            b[cog] += mk
    return order, a, b


def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ:
        d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            d[diff] += mk
    return d
