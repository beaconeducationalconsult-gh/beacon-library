# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "/home/user")
from build_farm import *

from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT

doc = Document()
sec = doc.sections[0]
sec.left_margin = Inches(0.7); sec.right_margin = Inches(0.7)
sec.top_margin = Inches(0.7); sec.bottom_margin = Inches(0.6)

st = doc.styles["Normal"]; st.font.name = "Calibri"; st.font.size = Pt(11)


def set_font(run, size=11, bold=False, italic=False, mono=False, color=None):
    run.font.size = Pt(size); run.bold = bold; run.italic = italic
    run.font.name = "Consolas" if mono else "Calibri"
    if color: run.font.color.rgb = color
    return run


def para(text="", size=11, bold=False, italic=False, align=None, mono=False,
         space_before=0, space_after=4, color=None):
    p = doc.add_paragraph()
    if align == "c": p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    elif align == "j": p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p.paragraph_format.space_before = Pt(space_before)
    p.paragraph_format.space_after = Pt(space_after)
    if text: set_font(p.add_run(text), size, bold, italic, mono, color)
    return p


def rule():
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(6); p.paragraph_format.space_before = Pt(2)
    set_font(p.add_run("_" * 78), 9, color=RGBColor(0x99, 0x99, 0x99))


def add_table(headers, rows, widths=None, size=9, head_size=9):
    t = doc.add_table(rows=1, cols=len(headers)); t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, h in enumerate(headers):
        c = t.rows[0].cells[i]; c.text = ""
        p = c.paragraphs[0]; p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_font(p.add_run(str(h)), head_size, bold=True)
    for row in rows:
        cells = t.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = ""
            p = cells[i].paragraphs[0]; p.paragraph_format.space_after = Pt(1)
            set_font(p.add_run(str(v)), size)
    if widths:
        for r_ in t.rows:
            for i, w in enumerate(widths): r_.cells[i].width = Inches(w)
    return t


def draw_diagram(lines, caption):
    t = doc.add_table(rows=2, cols=1); t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = t.rows[0].cells[0]
    for k, line in enumerate(lines):
        p = cell.paragraphs[0] if k == 0 else cell.add_paragraph()
        p.paragraph_format.space_after = Pt(0); p.paragraph_format.space_before = Pt(0)
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_font(p.add_run(line), 10, mono=True)
    c2 = t.rows[1].cells[0].paragraphs[0]
    c2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_font(c2.add_run(caption), 9, italic=True)
    t.rows[0].cells[0].width = Inches(6.6)
    t.rows[1].cells[0].width = Inches(6.6)


# ============================================================= TITLE BLOCK
para(SCHOOL, size=15, bold=True, align="c", space_after=2)
para(SUBJECT, size=13, bold=True, align="c", space_after=2)
para(EXAM, size=12, bold=True, align="c", space_after=2)
para(YEAR, size=10, italic=True, align="c", space_after=8)

info = doc.add_table(rows=1, cols=3); info.style = "Table Grid"
info.alignment = WD_TABLE_ALIGNMENT.CENTER
for i, v in enumerate([f"Class: {CLASS}", f"Time: {TIME}", f"Total Marks: {MARKS}"]):
    c = info.rows[0].cells[i]; c.text = ""
    set_font(c.paragraphs[0].add_run(v), 10, bold=True)
para("", space_after=6)

para("INSTRUCTIONS", size=11, bold=True, space_after=3)
for txt in [
    "1. Write your name and class clearly in the spaces provided on your answer sheet.",
    "2. This paper has TWO sections: Section A and Section B.",
    "3. Answer ALL the questions in both sections.",
    "4. Section A has 40 multiple-choice questions. Each question carries 1 mark. Choose the best answer "
    "(A, B, C or D) and record it on the answer sheet provided.",
    "5. Section B has 7 theory questions totalling 60 marks. Write your answers clearly and neatly in your "
    "answer booklet. Draw and label diagrams or tables where you are asked to.",
    "6. Read every question carefully before you answer it.",
    "7. Do not use correction fluid. Cancel any mistake neatly with a single line.",
    "8. Hand in your answer sheet and your answer booklet at the end of the examination.",
]:
    para(txt, size=10.5, space_after=2)
rule()

# =============================================================== SECTION A
para("SECTION A - OBJECTIVE TEST (40 marks)", size=12, bold=True, align="c", space_after=2)
para("Answer ALL questions. Each question carries 1 mark. Choose the BEST answer and write its letter "
     "(A, B, C or D) against the question number on your answer sheet.",
     size=10, italic=True, align="c", space_after=8)

for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(1); p.paragraph_format.space_before = Pt(4)
    set_font(p.add_run(f"{i}. {q}"), 10.5)
    for j, o in enumerate(opts):
        p2 = doc.add_paragraph()
        p2.paragraph_format.left_indent = Inches(0.28)
        p2.paragraph_format.space_after = Pt(0); p2.paragraph_format.space_before = Pt(0)
        set_font(p2.add_run(f"{'ABCD'[j]}. {o}"), 10.5)

doc.add_page_break()

# =============================================================== SECTION B
para("SECTION B - THEORY (60 marks)", size=12, bold=True, align="c", space_after=2)
para("Answer ALL questions. Write your answers in your answer booklet. The marks for each question are "
     "shown in brackets.", size=10, italic=True, align="c", space_after=8)

for qb in SECTION_B:
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(8); p.paragraph_format.space_after = Pt(2)
    set_font(p.add_run(f"Question {qb['num']}"), 11, bold=True)
    set_font(p.add_run(f"  [{qb['total']} marks]"), 10, bold=True, italic=True)
    para(qb["stem"], size=10.5, space_after=4)
    if qb.get("table") == "systems":
        add_table(SYS_HEADERS, SYS_ROWS, widths=[1.5, 2.6, 2.1], size=8.5, head_size=8.5)
        para("Table 1: The five farming systems", size=9, italic=True, align="c", space_after=6)
        para("", space_after=2)
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Inches(0.25)
        p.paragraph_format.space_after = Pt(3); p.paragraph_format.space_before = Pt(2)
        set_font(p.add_run(f"{lab} {text}  "), 10.5)
        set_font(p.add_run(f"[{mk} mark{'s' if mk > 1 else ''}]"), 10, bold=True)

doc.add_page_break()

# ============================================================== ANSWER KEY
para("ANSWER KEY", size=13, bold=True, align="c", space_after=6)
para("SECTION A - OBJECTIVE TEST", size=11, bold=True, space_after=4)
rows = [[i, ans, TOPIC[tp], cog] for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1)]
add_table(["Question", "Answer", "Curriculum Area (Topic)", "Cognitive Level"],
          rows, widths=[0.8, 0.7, 3.6, 1.5], size=9)
counts = {L: sum(1 for q in MCQ if q[2] == L) for L in "ABCD"}
para("", space_after=4)
para("Correct-answer distribution: " + ", ".join(f"{L} = {counts[L]}" for L in "ABCD") + " (30 items).",
     size=9, italic=True)

para("", space_after=8)
para("SECTION B - THEORY (summary answers; see the Marking Scheme for full detail)",
     size=11, bold=True, space_after=4)
sba = [
 ("1 (a)", "The particular way in which a farmer organises the land, the crops and the animals; the "
  "method or plan a farmer follows in using the land.", "10.1", "Understand"),
 ("1 (b)", "Any three of: land rotation; crop rotation; mixed cropping; mixed farming; organic "
  "farming.", "10.1", "Remember"),
 ("1 (c)", "Land rotation needs a lot of land, so it only suits places where land is plentiful; the "
  "crops wanted decide the system; mixed farming needs money to buy and feed animals while organic "
  "farming needs labour and bulky manure instead of cash.", "10.1", "Analyse"),
 ("2 (a)", "The farmer farms a piece of land for a few seasons, then leaves it to rest (fallow) for "
  "several years and moves to another piece.", "10.2", "Understand"),
 ("2 (b)", "Any three of: it lets the soil regain its fertility; it needs no artificial fertilizer "
  "and so costs little; it is simple and needs no special tools; it suits a place with plenty of "
  "land; it lets the bush grow back.", "10.2", "Understand"),
 ("2 (c)", "Any three of: it needs a very large area of land; trees and forest are destroyed each "
  "time new land is cleared; abandoned land can be eroded; the farmer must keep moving; it cannot "
  "feed many people on a small area.", "10.2", "Apply"),
 ("3 (a)", "Growing different crops one after another in a planned order on the same piece of land.",
  "10.3", "Understand"),
 ("3 (b)", "A sensible three-season rotation, e.g. maize, then a legume such as groundnuts or beans, "
  "then cassava or a vegetable; the legume goes in the middle because it puts nitrogen back, and "
  "changing the crop breaks the life cycle of pests that live on maize.", "10.3", "Create"),
 ("3 (c)", "Any three of: the soil stays fertile because different crops take different nutrients; "
  "pests and diseases die out when the host crop is not grown; the soil structure improves; the "
  "farmer gets a variety of produce; the same land can be used every year.", "10.3", "Understand"),
 ("4 (a)", "Growing two or more different crops together on the same piece of land at the same time.",
  "10.4", "Understand"),
 ("4 (b)", "Any three of: crops with different root depths use different layers of soil; if one crop "
  "fails the others may still do well; the family gets a variety of food from one plot; the leaves "
  "cover the soil and keep moisture in and weeds down; tall and short crops use the light at "
  "different heights.", "10.4", "Apply"),
 ("4 (c)", "Any three of: the crops compete for light, water and nutrients; it is difficult to weed, "
  "spray and harvest, and harder to use machines; the yield of each crop is often lower; it is hard "
  "to apply fertilizer to one crop alone; some crops may shade the others.", "10.4", "Understand"),
 ("5 (a)", "The system in which the farmer keeps animals and grows crops on the same farm, e.g. "
  "maize and cassava with goats or poultry.", "10.5", "Understand"),
 ("5 (b)", "The animals give droppings used as manure on the crops; the crops give waste, stalks, "
  "leaves and peelings used to feed the animals.", "10.5", "Understand"),
 ("5 (c)", "MIXED FARMING. Any two of: the animals may damage the crops if they are not fenced or "
  "tethered; it needs more land, labour, capital and knowledge; the animals need water and care all "
  "year; disease can kill the animals and that part of the income.", "10.5", "Analyse"),
 ("6 (a)", "Farming without artificial (synthetic) fertilizers, weedicides or pesticides, using only "
  "natural materials such as compost, manure, green manure and neem extract.", "10.6", "Understand"),
 ("6 (b)", "Any two of: compost; animal manure; green manure; crop residue; wood ash; decayed leaves.",
  "10.6", "Remember"),
 ("6 (c)", "Any three of: the yield may be lower at first so the farmer earns less; compost and "
  "manure are bulky and hard to carry and spread; it needs more labour; results take longer to "
  "show; pests and diseases are harder to control without chemicals.", "10.6", "Analyse"),
 ("7 (a)", "(i) farms a piece of land for a few seasons, then leaves it to rest and moves to "
  "another piece; (ii) it needs a very large area of land; (iii) it needs careful planning and "
  "knowledge of which crop should follow which; (iv) grows two or more different crops together on "
  "the same land at the same time; (v) keeps animals and grows crops on the same farm; (vi) the "
  "animals may damage the crops if they are not fenced or tethered.", "10.7", "Understand"),
 ("7 (b)", "Any four of: crop rotation changes the crop over time while mixed cropping grows several "
  "crops at the same time; only one crop occupies the land at a time in rotation; rotation is a plan "
  "across seasons while mixed cropping is a plan for one season; rotation varies the nutrients taken "
  "while mixed cropping uses different root depths; rotation is easier to weed, spray and harvest; "
  "rotation guards against pests while mixed cropping guards against the failure of one crop.",
  "10.7", "Analyse"),
]
add_table(["Question", "Expected Answer", "Curriculum Area", "Cognitive Level"],
          [list(r) for r in sba], widths=[0.8, 4.2, 1.2, 1.2], size=9)

doc.add_page_break()

# =========================================================== MARKING SCHEME
para("MARKING SCHEME - SECTION B (60 marks)", size=13, bold=True, align="c", space_after=4)
para("General rules: (1) Accept any other correct and relevant answer. (2) Award marks for correct points, "
     "not for repeating the question. (3) For procedures, award method marks. (4) Do not deduct marks for "
     "spelling unless the meaning is changed. (5) Where a candidate gives more answers than are asked for, "
     "mark only the first ones up to the number required.",
     size=9.5, italic=True, space_after=8)

for qb in SECTION_B:
    n = qb["num"]
    para(f"Question {n}  ({qb['total']} marks)", size=11, bold=True, space_before=8, space_after=3)
    for (lab, points, note) in MARKING[n]:
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(2)
        set_font(p.add_run(f"{lab} "), 10.5, bold=True)
        mkv = [p_[2] for p_ in qb["parts"] if p_[0] == lab]
        if mkv: set_font(p.add_run(f"[{mkv[0]} mark{'s' if mkv[0] > 1 else ''}]"), 10, bold=True)
        for pt in points:
            pp = doc.add_paragraph()
            pp.paragraph_format.left_indent = Inches(0.35); pp.paragraph_format.space_after = Pt(1)
            set_font(pp.add_run("- " + pt), 10.5)
        pp = doc.add_paragraph()
        pp.paragraph_format.left_indent = Inches(0.35); pp.paragraph_format.space_after = Pt(6)
        set_font(pp.add_run("Marking note: " + note), 9.5, italic=True)

doc.add_page_break()

# ================================================================ BLUEPRINT
para("CURRICULUM ASSESSMENT BLUEPRINT", size=13, bold=True, align="c", space_after=3)
para(f"Strand: {STRAND}   |   Sub-strand: {SUBSTRAND}   |   Class: {CLASS}",
     size=10, italic=True, align="c", space_after=3)
para(f"Content Standard: {CS} - {CS_TEXT}", size=9, italic=True, align="c", space_after=3)
para("Source: NaCCA Science Common Core Programme Curriculum (B7/JHS1-B9/JHS3), September 2020, "
     "Strand 3: Systems, Sub-strand 4: Farming Systems, pp. 23-24. Indicators are quoted, not "
     "invented.",
     size=9, italic=True, space_after=8)

hdr = ["Qn", "Sub-strand", "Content Standard", "Indicator (NaCCA) - Indicator Text", "Topic / Content",
       "Cognitive Level", "Marks"]

rows = [[f"A{i}", SUBSTRAND, CS_BY_TOPIC[tp], f"{IND[tp]} - {IND_TEXT[tp]}", TOPIC[tp], cog, 1]
        for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1)]
add_table(hdr, rows, widths=[0.35, 0.75, 0.75, 1.75, 1.4, 0.8, 0.35], size=7, head_size=7.5)

para("", space_after=8)
rows = []
for qb in SECTION_B:
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        key = tp if tp in TOPIC else tp.split(",")[0].strip()
        rows.append([f"B{qb['num']}{lab.strip('()')}", SUBSTRAND, CS_BY_TOPIC[key],
                     f"{IND[key]} - {IND_TEXT[key]}", TOPIC[key], cog, mk])
add_table(hdr, rows, widths=[0.35, 0.75, 0.75, 1.75, 1.4, 0.8, 0.35], size=7, head_size=7.5)

doc.add_page_break()

# ----------------------------------------------------------------- helpers
def topic_totals():
    m = {k: 0 for k in TOPIC}; it = {k: 0 for k in TOPIC}
    for q in MCQ:
        m[q[3]] += 1; it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk; it[key] += 1
    return m, it

def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}; b = {k: 0 for k in order}
    for q in MCQ: a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: b[cog] += mk
    return order, a, b

def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ: d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: d[diff] += mk
    return d

m, it = topic_totals(); diff = difficulty_totals(); order, ca, cb = cognitive_by_section()

para("SUMMARY 1 - COVERAGE BY CURRICULUM AREA (TOPIC)", size=12, bold=True, space_after=4)
rows = [[TOPIC[k], it[k], m[k], f"{(m[k]/100)*100:.1f}%", CC[k]] for k in TOPIC]
rows.append(["TOTAL", sum(it.values()), sum(m.values()), "100%", "-"])
add_table(["Topic / Content Area", "No. of Items", "Marks", "% of Total Marks", "Core Competencies"],
          rows, widths=[2.7, 0.8, 0.6, 1.0, 1.1], size=8.5)
para("CC = Communication and Collaboration; CP = Critical Thinking and Problem Solving; "
     "DL = Digital Literacy; CI = Creativity and Innovation.", size=8.5, italic=True, space_after=2)

para("", space_after=8)
para("SUMMARY 2 - COGNITIVE-LEVEL DISTRIBUTION (Bloom's Taxonomy)", size=12, bold=True, space_after=4)
rows = []
for lv in order:
    tot = ca[lv] + cb[lv]
    rows.append([lv, ca[lv], cb[lv], tot, f"{(tot/100)*100:.1f}%"])
rows.append(["TOTAL", sum(ca.values()), sum(cb.values()), sum(ca.values()) + sum(cb.values()), "100%"])
add_table(["Cognitive Level", "Section A Marks", "Section B Marks", "Total Marks", "% of Total"],
          rows, widths=[1.6, 1.3, 1.3, 1.1, 1.1], size=9.5)

para("", space_after=8)
para("SUMMARY 3 - DIFFICULTY DISTRIBUTION", size=12, bold=True, space_after=4)
rows = [[k, v, f"{(v/100)*100:.1f}%"] for k, v in diff.items()]
rows.append(["TOTAL", sum(diff.values()), "100%"])
add_table(["Difficulty", "Marks", "% of Total Marks"], rows, widths=[2.0, 1.2, 1.5], size=9.5)
para("Target in the master prompt: approximately 30% easy / 50% moderate / 20% challenging.",
     size=9, italic=True, space_after=2)

para("", space_after=8)
para("SUMMARY 4 - SECTION WEIGHTING", size=12, bold=True, space_after=4)
add_table(["Section", "Question Type", "Items", "Marks", "% of Total"],
          [["A", "Objective (multiple choice)", 40, 40, "40%"],
           ["B", "Theory / constructed response", 20, 60, "60%"],
           ["TOTAL", "-", 60, 100, "100%"]],
          widths=[0.9, 2.4, 0.8, 0.8, 1.0], size=9.5)

doc.add_page_break()

# ===================================================== QUALITY-CONTROL
para("QUALITY-CONTROL SUMMARY", size=13, bold=True, align="c", space_after=4)
para("Carried out against the 14-point validation list in the master prompt before the examination was "
     "finalised.", size=9.5, italic=True, space_after=8)

qc = [
 ("Does every question belong to the supplied curriculum scope?",
  "Yes. All 46 items trace to Strand 3 (Systems), Sub-Strand 4 (Farming Systems), topics 10.1-10.7, "
  "and to the two official B7 indicators (B7/JHS1.3.4.1.1 and B7/JHS1.3.4.1.2). Irrigation, "
  "mechanisation, plantation agriculture, farm accounting and marketing appear only as distractors, "
  "never as things pupils must answer on."),
 ("Is the examination appropriate for the stated class?",
  "Yes. The B7 curriculum requires learners to identify and define the types of farming system, "
  "discuss and compare their characteristics, classify descriptions under the five named systems, "
  "and group the systems prevailing in their own community. No yield calculation, no farm budgeting "
  "and no soil-chemistry detail are tested, as these fall outside the B7 indicator."),
 ("Are the questions genuinely BECE-style?",
  "Yes: Section A is 40 four-option objectives worth 1 mark each, and Section B is structured theory "
  "with sub-questions carrying printed mark allocations. A completion table is included, matching the "
  "BECE science convention and exemplar 3 of B7/JHS1.3.4.1.1, which asks pupils to compare and "
  "contrast the characteristics of the different systems."),
 ("Are there enough application and reasoning questions?",
  "Yes. 30 of 100 marks (30%) are at Apply level or above (Apply 11, Analyse 15, Evaluate 1, Create "
  "3). Analyse is well represented because the indicator itself opens with 'examine and discuss the "
  "differences', and Create appears through the crop-rotation plan in Question 3(b)."),
 ("Are the MCQ distractors plausible?",
  "Yes. Distractors are drawn from the same content family as the key: another named farming system "
  "(A5, A6, A19, A25), a farming method that is not one of the five (A2), a plausible but wrong "
  "reason (A15), and a real fertilizing material that is not organic (A31)."),
 ("Is there only one best answer for each MCQ?",
  "Yes. Every item was reviewed for a single defensible key. Special care was taken with A2, where "
  "'irrigation farming' is a real method but is not one of the five named in the B7 curriculum, and "
  "with A31, where wood ash is organic while the other three are manufactured."),
 ("Are the marks internally consistent?",
  "Yes. Section A = 40 items x 1 mark = 40. Section B = 8 + 9 + 9 + 8 + 8 + 8 + 10 = 60. "
  "Each Section B sub-question's printed marks match its marking-scheme allocation."),
 ("Does the total add up correctly?",
  "Yes: 40 + 60 = 100 marks, matching the stated total on the front page."),
 ("Are the answers in the answer key correct?",
  "Yes. All 40 objective keys and all 20 Section B answers were verified against the marking scheme."),
 ("Does the marking scheme match the questions?",
  "Yes. Every Section B sub-question has an expected-answer list and a marking note covering partial "
  "credit, acceptable alternatives, common wrong answers and method marks. The completion table, the "
  "rotation plan and the comparison have explicit marking grids so they can be marked consistently "
  "across a class."),
 ("Are the questions free from unnecessary ambiguity?",
  "Yes. Open items are anchored with 'state three', 'name two' and the mark allocation. Question 7(a) "
  "numbers every blank, (i) to (vi), and Question 5(c) states explicitly that the name of the system "
  "must be given. Question 4(a) and 5(a) warn against the common swap between mixed cropping and "
  "mixed farming."),
 ("Are Ghanaian contexts used naturally and accurately?",
  "Yes: maize, cassava, cocoyam, groundnuts and beans; goats, sheep, cattle and poultry; a maize "
  "farmer in the Ashanti Region, a group of farmers near Kumasi, the fallow period, the dry season, "
  "neem extract and wood ash, compost and poultry manure, and the bush growing back on abandoned "
  "land."),
 ("Has any content outside the supplied curriculum been introduced?",
  "No. Every item sits inside topics 10.1-10.7. Questions 2 to 6 each take one of the five named "
  "systems; Question 1 is built on exemplar 1 of B7/JHS1.3.4.1.1; and Question 7 on exemplar 3, the "
  "comparison and contrast of characteristics."),
 ("Are the questions sufficiently varied?",
  "Yes. Item types include definition, listing, explaining a choice, defining and giving problems for "
  "each of five systems, planning a rotation, explaining mutual benefit, completing a comparison "
  "table, and stating differences between two systems."),
]
for i, (q, a) in enumerate(qc, start=1):
    p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(2)
    set_font(p.add_run(f"{i}. {q}"), 10.5, bold=True)
    p2 = doc.add_paragraph()
    p2.paragraph_format.left_indent = Inches(0.3); p2.paragraph_format.space_after = Pt(6)
    set_font(p2.add_run(a), 10)

para("", space_after=8)
para("EXAMINER NOTES (for the teacher, not for candidates)", size=11, bold=True, space_after=4)
for n in [
 "The single most common error in this topic is the swap between MIXED CROPPING (several crops "
 "together at the same time) and CROP ROTATION (different crops one after another on the same land). "
 "Question 7(b) is written to test exactly that, and the marking note insists that each point must "
 "contrast the two systems, not just describe one of them.",
 "The second most common error is the swap between MIXED CROPPING (crops + crops) and MIXED FARMING "
 "(crops + animals). Question 5(c) makes pupils name the system before they earn the marks.",
 "Question 3(b) is a design task: a three-season rotation. Award method marks - any sensible order "
 "earns credit provided the pupil says WHY the crops are in that order. Putting a legume in the "
 "middle is the answer to look for.",
 "Question 7(a) is the comparison table. The six blanks are numbered (i) to (vi), so marking is "
 "quick and fair: 1 mark each, and the blank number must be matched to the answer.",
 "Topic weightings are deliberately even here - every system carries 13 to 15 marks - because the "
 "indicator asks for the differences AMONG the systems rather than for depth on any one of them. If "
 "you want to stress one system, move marks towards Questions 2 to 6.",
 "B7 does not expect the words 'shifting cultivation' or 'slash-and-burn'. Accept them if a pupil "
 "offers them, but the expected answer is that the farmer moves on and leaves the land to rest.",
 "If your school has a farm or a garden, walk the class round it before the mock and ask them to "
 "classify what they see - that is exemplar 2 of B7/JHS1.3.4.1.2, which asks pupils to group the "
 "farming systems prevailing in their own community.",
 "Edit the school name, academic year and examination title on page 1 before printing.",
 "This is an original, teacher-made mock. It is not a reproduction of any WAEC or NaCCA examination "
 "paper.",
]:
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Inches(0.3); p.paragraph_format.space_after = Pt(3)
    set_font(p.add_run("- " + n), 10)

doc.save("/home/user/Basic7_Integrated_Science_Mock_Strand3_FarmingSystems.docx")
print("docx written")

print("Section A:", len(MCQ), "items")
print("Section B total:", sum(q["total"] for q in SECTION_B))
print("Topic marks:", m, "sum", sum(m.values()))
print("Difficulty:", diff, "sum", sum(diff.values()))
print("Cognitive A:", ca)
print("Cognitive B:", cb)
print("Answer counts:", counts)
print("Totals:", sum(m.values()), sum(diff.values()),
      sum(ca.values()) + sum(cb.values()))
