# -*- coding: utf-8 -*-
"""Basic 7 Integrated Science mock - Strand 4 Sub-strand 4: FORCE AND MOTION, part 2 of 2.
Covers topics 14.9 to 14.11 (simple machines, the three classes of lever, and work input, work
output and efficiency of machines). 100 marks.
Indicators sourced from the official NaCCA Science CCP curriculum (B7/JHS1-B9/JHS3, Sept 2020),
Strand 4: Forces and Energy, Sub-strand 4: Force and Motion, printed pages 38-40.
Content standard: B7/JHS1.4.4.2. Force, motion, inertia, Newton's First Law and magnets
(B7/JHS1.4.4.1) are in the companion paper."""

SCHOOL = "[SCHOOL NAME]"
SUBJECT = "INTEGRATED SCIENCE (SCIENCE)"
EXAM = "END-OF-TERM MOCK EXAMINATION"
CLASS = "Basic 7 (JHS 1)"
TIME = "2 hours (Suggested: Section A - 40 min; Section B - 80 min)"
MARKS = "100"
YEAR = "2025/2026 Academic Year"

STRAND = "Forces and Energy"
SUBSTRAND = "Force and Motion (Part 2: Simple Machines)"

TOPIC = {
    "14.9": "14.9 Simple Machines and Their Types",
    "14.10": "14.10 Types and Functions of Levers",
    "14.11": "14.11 Work Input, Work Output and Efficiency",
}

CS = "B7/JHS1.4.4.2"
CS_BY_TOPIC = {k: "B7/JHS1.4.4.2" for k in ["14.9", "14.10", "14.11"]}
CS_TEXT = ("Recognise some simple machines, and show understanding of their efficiency in doing "
           "work")

IND = {
    "14.9": "B7/JHS1.4.4.2.1 (Ex. 1)",
    "14.10": "B7/JHS1.4.4.2.2 (Ex. 1, 2)",
    "14.11": "B7/JHS1.4.4.2.3 (Ex. 1-4)",
}
IND_TEXT = {
    "14.9": "Identify simple machines. Ex. 1: List examples of simple machines.",
    "14.10": "Describe the types and functions of levers. Ex. 1, 2: Name the types of levers and "
             "explain their general functions; classify levers into first, second and third "
             "classes and demonstrate how the principles involved in each class make work easier "
             "in everyday life.",
    "14.11": "Know work input, and output and efficiency as they apply to machines. Ex. 1-4: "
             "Explain the terms work input, work output and efficiency; explain efficiency of a "
             "machine as the ratio of work output to work input expressed as a percentage; "
             "explain the concept of efficiency of a machine; describe how efficiency of simple "
             "machines can be improved, e.g. by oiling its parts to reduce friction.",
}
CC = {"14.9": "DL, CC", "14.10": "DL, CC, CP", "14.11": "CC, DL, CP, CI"}

# ---------------------------------------------------------------- SECTION A
# (question, [A,B,C,D], answer, topic, cognitive, difficulty)
MCQ = [
 ("A simple machine is",
  ["a machine with an engine",
   "a machine that works by itself", "a device that makes work easier", "a machine that makes its own electricity"],
  "C", "14.9", "Remember", "Easy"),
 ("Which of these is a simple machine?",
  ["a lever", "a television set", "a car engine", "a radio"],
  "A", "14.9", "Remember", "Easy"),
 ("An inclined plane is",
  ["a flat table", "a round wheel", "a pointed nail", "a sloping surface used to raise a load"],
  "D", "14.9", "Remember", "Easy"),
 ("A pulley is",
  ["a long sloping plank",
   "a wheel with a rope running over it", "a sharp blade", "a spiral rod"],
  "B", "14.9", "Remember", "Easy"),
 ("A wheel and axle consists of",
  ["a large wheel joined to a smaller rod so that they turn together",
   "two wheels joined side by side", "a wheel with a rope round it", "a wheel with teeth cut round its edge"],
  "A", "14.9", "Understand", "Moderate"),
 ("A screw is",
  ["a smooth round rod",
   "a bar that turns about a fixed point", "a rod with a spiral thread cut round it", "a flat sloping surface"],
  "C", "14.9", "Remember", "Easy"),
 ("A wedge is",
  ["a piece of metal or wood that is thick at one end and thin at the other",
   "a wheel with a groove", "a rope running over a wheel", "a long flat plank"],
  "A", "14.9", "Understand", "Moderate"),
 ("Which of these is NOT a simple machine?",
  ["a lever", "a pulley", "a wedge", "an electric motor"],
  "D", "14.9", "Understand", "Moderate"),
 ("A ramp is used to push a heavy drum of palm oil into a lorry. The ramp is an example of",
  ["a pulley", "a screw", "an inclined plane", "a wedge"],
  "C", "14.9", "Apply", "Easy"),
 ("A cutlass used for splitting a coconut is an example of",
  ["a lever", "a wedge", "a pulley", "a wheel and axle"],
  "B", "14.9", "Apply", "Moderate"),
 ("A flag is raised up a tall pole at school using",
  ["a screw", "a wedge", "an inclined plane", "a pulley"],
  "D", "14.9", "Apply", "Easy"),
 ("The winding handle used to draw water from a well is an example of",
  ["a wheel and axle", "a wedge", "a pulley", "an inclined plane"],
  "A", "14.9", "Apply", "Moderate"),
 ("A see-saw in a playground is an example of",
  ["a screw", "a pulley", "a lever", "a wedge"],
  "C", "14.9", "Apply", "Easy"),
 ("The spiral edge on the top of a bottle is an example of",
  ["a wedge", "a screw", "a lever", "a pulley"],
  "B", "14.9", "Apply", "Moderate"),
 ("People use simple machines mainly to",
  ["make work easier", "make work harder", "use more fuel", "make things heavier"],
  "A", "14.9", "Understand", "Moderate"),
 ("A lever is",
  ["a sloping surface",
   "a bar that turns about a fixed point", "a wheel with a groove", "a spiral thread cut round a rod"],
  "B", "14.10", "Remember", "Easy"),
 ("The fixed point about which a lever turns is called the",
  ["load", "effort", "fulcrum", "the bar"],
  "C", "14.10", "Remember", "Easy"),
 ("The force applied to a lever to make it work is called the",
  ["load", "fulcrum", "friction", "effort"],
  "D", "14.10", "Remember", "Easy"),
 ("The object or weight that a lever moves is called the",
  ["load", "effort", "fulcrum", "machine"],
  "A", "14.10", "Remember", "Easy"),
 ("In a first-class lever, the fulcrum is",
  ["at one end of the lever",
   "between the effort and the load", "at the same place as the load", "above the effort"],
  "B", "14.10", "Understand", "Moderate"),
 ("In a second-class lever, the load is",
  ["at the same place as the effort",
   "at one end of the lever", "between the fulcrum and the effort", "above the fulcrum"],
  "C", "14.10", "Understand", "Moderate"),
 ("In a third-class lever, the effort is",
  ["at one end of the lever",
   "above the load", "at the same place as the fulcrum", "between the fulcrum and the load"],
  "D", "14.10", "Understand", "Challenging"),
 ("A wheelbarrow is an example of",
  ["a second-class lever", "a first-class lever", "a third-class lever", "a pulley"],
  "A", "14.10", "Apply", "Moderate"),
 ("A pair of sugar tongs is an example of",
  ["a first-class lever", "a second-class lever", "a third-class lever", "a wedge"],
  "C", "14.10", "Apply", "Challenging"),
 ("A claw hammer used to pull a nail out of a piece of wood is an example of",
  ["a wedge", "a first-class lever", "a second-class lever", "a third-class lever"],
  "B", "14.10", "Apply", "Moderate"),
 ("Work input is",
  ["the useful work done by a machine",
   "the work a machine refuses to do", "the work done on a machine", "the weight of the machine"],
  "C", "14.11", "Remember", "Easy"),
 ("Work output is",
  ["the work done on a machine",
   "the weight of the load", "the fuel put into a machine", "the useful work done by a machine"],
  "D", "14.11", "Remember", "Easy"),
 ("Work is measured in",
  ["joules", "newtons", "watts", "metres"],
  "A", "14.11", "Remember", "Easy"),
 ("The efficiency of a machine is",
  ["the work a machine can do in one hour",
   "the ratio of work output to work input, given as a percentage", "the weight of the load a machine can lift", "the amount of fuel a machine uses"],
  "B", "14.11", "Understand", "Moderate"),
 ("Efficiency is calculated as",
  ["(work input / work output) x 100%",
   "work output - work input", "(work output / work input) x 100%", "work input + work output"],
  "C", "14.11", "Remember", "Moderate"),
 ("A machine is given 100 J of work input and gives out 80 J of work output. Its efficiency is",
  ["8%", "20%", "125%", "80%"],
  "D", "14.11", "Apply", "Moderate"),
 ("A machine is given 200 J of work input and gives out 50 J of work output. Its efficiency is",
  ["25%", "4%", "40%", "150%"],
  "A", "14.11", "Apply", "Challenging"),
 ("The work output of a machine is always less than the work input because",
  ["the machine keeps some work for later",
   "some of the energy is used to overcome friction and is wasted as heat and sound", "the machine is badly made", "the load is too heavy"],
  "B", "14.11", "Understand", "Moderate"),
 ("Which of these is a form in which energy is wasted in a machine?",
  ["the useful work the machine does",
   "the load the machine lifts", "the fuel put into the machine", "heat produced by friction in the moving parts"],
  "D", "14.11", "Understand", "Moderate"),
 ("The efficiency of a simple machine can be improved by",
  ["making the machine heavier",
   "using it more often", "painting it a bright colour", "oiling its moving parts to reduce friction"],
  "D", "14.11", "Remember", "Easy"),
 ("A machine can never be 100 per cent efficient because",
  ["some energy is always lost as heat and sound",
   "it is too expensive to build one", "the load is always too heavy", "the machine gets tired"],
  "A", "14.11", "Understand", "Moderate"),
 ("A machine has an efficiency of 60 per cent. This means that",
  ["60 per cent of the work input is wasted",
   "60 per cent of the work input comes out as useful work", "the machine wastes 60 J every minute", "the machine works for 60 minutes"],
  "B", "14.11", "Understand", "Moderate"),
 ("Oiling the chain and the wheel bearings of a bicycle makes it more efficient because it",
  ["makes the bicycle heavier",
   "makes the tyres harder", "reduces friction in the moving parts", "makes the bicycle look new"],
  "C", "14.11", "Apply", "Moderate"),
 ("Which of these would NOT improve the efficiency of a machine?",
  ["oiling the moving parts",
   "keeping the parts clean and free of rust", "using ball bearings to reduce friction", "making the machine much heavier"],
  "D", "14.11", "Analyse", "Challenging"),
 ("A pulley system is given 500 J of work and gives out 400 J of useful work. The energy wasted is",
  ["400 J", "100 J", "500 J", "900 J"],
  "B", "14.11", "Apply", "Challenging"),
]

# ------------------------------------------------ SECTION B DIAGRAM + TABLE
LEVER = [
    "  (i)                                                   (iii)",
    "   |                                                     |",
    "   v                                                     v",
    "   +-----------------------------------------------------+",
    "   |                         BAR                         |",
    "   +-----------------------------------------------------+",
    "                              ^",
    "                              |",
    "                             / \\",
    "                            /   \\    <-- (ii)",
    "                           /     \\",
    "                          /       \\",
    "  ------------------------------------------------------------"
]
LEVER_KEY = "(i) effort, (ii) fulcrum, (iii) load"

SM_HEADERS = ["Simple machine", "What it is", "One place it is used"]
SM_ROWS = [
 ["Lever", "a bar that turns about a fixed point", "(i)"],
 ["Inclined plane", "(ii)", "a ramp used to push a drum into a lorry"],
 ["Pulley", "a wheel with a rope running over it", "(iii)"],
 ["Wheel and axle", "(iv)", "the winding handle of a well"],
 ["Screw", "a rod with a spiral thread cut round it", "(v)"],
 ["Wedge", "(vi)", "a cutlass used for splitting a coconut"],
]

# ---------------------------------------------------------------- SECTION B
SECTION_B = [
 dict(
   num=1, total=9, topic="14.9",
   stem="People use simple machines every day at home, on the farm and in the workshop.",
   parts=[
     ("(a)", "Explain what is meant by a simple machine.", 3, "Understand", "14.9", "Easy"),
     ("(b)", "Name four examples of simple machines.", 4, "Remember", "14.9", "Easy"),
     ("(c)", "Explain why people use simple machines.", 2, "Understand", "14.9", "Moderate"),
   ]),
 dict(
   num=2, total=8, topic="14.9",
   stem="Your class has been asked to examine the common simple machines. Study the incomplete "
        "table below and answer the questions that follow.",
   table="machines",
   parts=[
     ("(a)", "Copy and complete the table.", 6, "Understand", "14.9", "Moderate"),
     ("(b)", "Choose one machine from the table and describe a job it would be used for at home "
             "or on the farm.", 2, "Apply", "14.9", "Easy"),
   ]),
 dict(
   num=3, total=9, topic="14.10",
   stem="Fig. 1 shows a lever being used. Study it and answer the questions that follow.",
   diagram=True,
   parts=[
     ("(a)", "Name the parts labelled (i), (ii) and (iii) in Fig. 1.",
      3, "Understand", "14.10", "Moderate"),
     ("(b)", "Explain what is meant by a lever.", 3, "Understand", "14.10", "Easy"),
     ("(c)", "State where the fulcrum is placed in a first-class lever, and name one example of a "
             "first-class lever.", 3, "Understand", "14.10", "Moderate"),
   ]),
 dict(
   num=4, total=9, topic="14.10",
   stem="Levers are put into three classes according to the order in which the fulcrum, the load "
        "and the effort come.",
   parts=[
     ("(a)", "Explain what is meant by a second-class lever, and name one example.",
      3, "Understand", "14.10", "Moderate"),
     ("(b)", "Explain what is meant by a third-class lever, and name one example.",
      3, "Understand", "14.10", "Moderate"),
     ("(c)", "Describe how you would decide whether a lever belongs to the first, the second or "
             "the third class, giving an example of each.",
      3, "Analyse", "14.10", "Challenging"),
   ]),
 dict(
   num=5, total=8, topic="14.10",
   stem="Levers of all three classes can be found in the home, on the farm and in the workshop.",
   parts=[
     ("(a)", "State the class of lever for each of the following: a claw hammer pulling a nail "
             "out of wood; a wheelbarrow; a broom being used to sweep; a nutcracker.",
      4, "Apply", "14.10", "Challenging"),
     ("(b)", "Choose two of the levers named in (a) and explain how each one makes the work "
             "easier.", 2, "Understand", "14.10", "Moderate"),
     ("(c)", "Plan a short demonstration your class could carry out to show that a longer handle "
             "makes a lever easier to use.", 2, "Create", "14.10", "Challenging"),
   ]),
 dict(
   num=6, total=9, topic="14.11",
   stem="A machine is used to lift a heavy load on a building site.",
   parts=[
     ("(a)", "Explain what is meant by work input and by work output, and state the unit in which "
             "work is measured.", 4, "Understand", "14.11", "Moderate"),
     ("(b)", "A boy uses a machine and puts in 200 J of work. The machine gives out 150 J of "
             "useful work. Explain what has happened to the rest of the energy.",
      3, "Apply", "14.11", "Challenging"),
     ("(c)", "Explain why the work output of a machine is always less than the work input.",
      2, "Understand", "14.11", "Moderate"),
   ]),
 dict(
   num=7, total=8, topic="14.11",
   stem="No machine is perfect. Some of the work put into a machine never comes out as useful "
        "work.",
   parts=[
     ("(a)", "Explain what is meant by the efficiency of a machine.",
      3, "Understand", "14.11", "Moderate"),
     ("(b)", "A machine has a work input of 400 J and a work output of 300 J. Calculate its "
             "efficiency.", 3, "Apply", "14.11", "Challenging"),
     ("(c)", "Your school has two machines that do the same job. One is 40 per cent efficient and "
             "the other is 75 per cent efficient. Which one would you advise the school to use? "
             "Give a reason for your answer.", 2, "Evaluate", "14.11", "Easy"),
   ]),
]

# ------------------------------------------------------- MARKING SCHEME
MARKING = {
 1: [
   ("(a)", ["A simple machine is a device that makes work easier.",
            "It is a device that lets a small effort move a large load.",
            "It has few or no moving parts, and it is worked by hand or by a single force.",
            "It changes the size or the direction of the force applied."],
    "1 mark each for any THREE correct points (3 marks). The key idea is MAKING WORK EASIER. Do "
    "NOT accept 'a machine with an engine'."),
   ("(b)", ["A lever", "A pulley", "An inclined plane", "A wheel and axle", "A screw", "A wedge"],
    "1 mark each for any FOUR correct simple machines (4 marks). Accept any four of the six. Do "
    "NOT accept 'a car engine', 'a bicycle', 'a sewing machine' or any compound machine."),
   ("(c)", ["Simple machines make work easier, so a smaller effort can move a bigger load.",
            "They let a force be applied in a more convenient direction.",
            "They save time and energy and reduce the effort a person has to make."],
    "1 mark each for any TWO correct points (2 marks). Accept any sensible reason."),
 ],
 2: [
   ("(a)", ["(i) a crowbar lifting a stone; a see-saw; the handle of a hand pump; a bottle "
            "opener",
            "(ii) a sloping surface or a slope used to raise a load",
            "(iii) raising a bucket from a well; raising a flag up a pole; lifting a load on a "
            "building site",
            "(iv) a large wheel joined to a smaller rod (the axle) so that the two turn together",
            "(v) holding two pieces of wood together; a corkscrew; a car jack",
            "(vi) a piece of metal or wood that is thick at one end and thin at the other, used "
            "for splitting or cutting"],
    "1 mark each for any SIX correct entries (6 marks). The blank number must be matched to the "
    "answer. For (i), (iii) and (v) accept any correct place where that machine is used. For (ii) "
    "the key word is 'sloping' or 'slope'. For (iv) the key idea is a wheel and a rod turning "
    "together. For (vi) the key idea is thick at one end and thin at the other."),
   ("(b)", ["A lever - a crowbar is used to lift a heavy stone or to pull out a nail.",
            "An inclined plane - a ramp is used to push a drum of palm oil into a lorry.",
            "A pulley - used to raise a bucket of water from a well.",
            "A wheel and axle - used to wind up a rope on a well or to steer a car.",
            "A screw - used to hold two pieces of wood together or to lift a car with a jack.",
            "A wedge - a cutlass or an axe is used to split a coconut or a log."],
    "1 mark for choosing a machine that is in the table and 1 mark for a correct job it would be "
    "used for (2 marks). The machine must be one that appears in the table."),
 ],
 3: [
   ("(a)", ["(i) effort", "(ii) fulcrum", "(iii) load"],
    "1 mark each for all THREE correct labels (3 marks). The number must be matched to the "
    "answer. Accept 'the force applied' for effort."),
   ("(b)", ["A lever is a bar or a rigid rod that turns about a fixed point.",
            "The fixed point about which it turns is called the fulcrum.",
            "A lever is used to move a load when an effort is applied to it."],
    "1 mark each for any THREE correct points (3 marks). The two ideas to look for are: a bar, "
    "and a fixed point it turns about."),
   ("(c)", ["In a first-class lever the fulcrum is BETWEEN the effort and the load.",
            "One end is pushed down as the effort while the other end goes up and lifts the "
            "load.",
            "Examples: a see-saw; a pair of scissors; a claw hammer pulling out a nail; the "
            "handle of a hand pump; a pair of pliers."],
    "1 mark for the position of the fulcrum, 1 mark for a correct example and 1 mark for any "
    "other correct point (3 marks). The key words are 'between the effort and the load'."),
 ],
 4: [
   ("(a)", ["A second-class lever is one in which the LOAD lies between the fulcrum and the "
            "effort.",
            "The effort and the load are on the same side of the fulcrum.",
            "Examples: a wheelbarrow; a nutcracker; a bottle opener; a paper cutter."],
    "1 mark each for any THREE correct points (3 marks). The position of the load is essential; "
    "award at most 2 marks if only the example is given."),
   ("(b)", ["A third-class lever is one in which the EFFORT lies between the fulcrum and the "
            "load.",
            "The effort and the load are on the same side of the fulcrum, but the effort is the "
            "nearer of the two.",
            "Examples: a pair of sugar tongs; a broom being used to sweep; a fishing rod; the "
            "human forearm."],
    "1 mark each for any THREE correct points (3 marks). The position of the effort is essential; "
    "award at most 2 marks if only the example is given."),
   ("(c)", ["Look at the order of the three parts along the lever: fulcrum, load and effort.",
            "If the FULCRUM is in the middle, between the effort and the load, it is a "
            "first-class lever, e.g. a see-saw.",
            "If the LOAD is in the middle, between the fulcrum and the effort, it is a "
            "second-class lever, e.g. a wheelbarrow.",
            "If the EFFORT is in the middle, between the fulcrum and the load, it is a "
            "third-class lever, e.g. a pair of sugar tongs.",
            "Find the fulcrum first, then see which of the other two lies nearer to it."],
    "1 mark each for any THREE correct points (3 marks). One mark is available for each class "
    "correctly described with an example; award at most 2 marks if the examples are missing."),
 ],
 5: [
   ("(a)", ["A claw hammer pulling a nail out of wood - FIRST class.",
            "A wheelbarrow - SECOND class.",
            "A broom being used to sweep - THIRD class.",
            "A nutcracker - SECOND class."],
    "1 mark each for all FOUR correct classes (4 marks). Accept the answer only if the class and "
    "the tool are matched. The broom and the nutcracker are the two that pupils most often get "
    "wrong."),
   ("(b)", ["A claw hammer: the long handle means a small effort at the handle produces a large "
            "pulling force on the nail.",
            "A wheelbarrow: the load sits between the wheel (the fulcrum) and the handles, so "
            "lifting the handles lifts a heavy load with a small effort.",
            "A broom: the small movement of the upper hand makes the far end of the broom sweep "
            "over a large area.",
            "A nutcracker: the effort at the handles is applied further from the hinge than the "
            "nut, so a small squeeze gives a large crushing force."],
    "1 mark for each of TWO levers correctly explained (2 marks). The levers must be two of the "
    "four named in (a)."),
   ("(c)", ["Use a lever such as a crowbar or a spanner on a bolt, and try it first with a short "
            "handle and then with a long one.",
            "Push on the very end of the handle each time, and compare the effort needed.",
            "The class would find that the longer handle needs a much smaller effort to do the "
            "same job.",
            "Keep the load and the position of the fulcrum the same, so that only the length of "
            "the handle changes."],
    "1 mark for a sensible set-up and 1 mark for what the class would find (2 marks). This is a "
    "design task: award method marks for any fair test that is clearly described. Look for the "
    "idea that only the length of the handle changes."),
 ],
 6: [
   ("(a)", ["Work input is the work done ON a machine, that is, the work put into it.",
            "Work output is the useful work done BY the machine, that is, the work that comes "
            "out of it.",
            "Both are measured in joules (J).",
            "Work is calculated as force x distance moved in the direction of the force."],
    "1 mark each for any FOUR correct points (4 marks). Both terms must be defined and the unit "
    "given; award at most 3 marks if the unit is missing."),
   ("(b)", ["50 J of the energy did not come out as useful work.",
            "It was used to overcome friction in the moving parts of the machine.",
            "It was changed into heat, and some into sound, which spread out into the "
            "surroundings.",
            "The energy was not destroyed - it changed into forms that are not useful.",
            "200 J in minus 150 J out leaves 50 J wasted."],
    "1 mark each for any THREE correct points (3 marks). The key ideas are: 50 J is missing, it "
    "went to overcome friction, and it became heat and sound. Award at most 2 marks if the pupil "
    "says the energy was destroyed."),
   ("(c)", ["Some of the work put in is always used to overcome friction in the moving parts.",
            "Some of it is used to lift the moving parts of the machine itself.",
            "That energy is changed into heat and sound, which are not useful.",
            "Because of these losses, the useful work out is always less than the work put in."],
    "1 mark each for any TWO correct points (2 marks). The word to look for is friction."),
 ],
 7: [
   ("(a)", ["Efficiency is the ratio of work output to work input, given as a percentage.",
            "It measures how much of the work put into a machine comes out as useful work.",
            "A more efficient machine wastes less of the work put into it.",
            "Efficiency = (work output / work input) x 100%."],
    "1 mark each for any THREE correct points (3 marks). The formula earns one of the three "
    "marks. Accept 'how good a machine is at turning work in into useful work out'."),
   ("(b)", ["Efficiency = (work output / work input) x 100%",
            "Efficiency = (300 / 400) x 100%", "Efficiency = 0.75 x 100%",
            "Efficiency = 75%"],
    "1 mark for the formula, 1 mark for the correct substitution (300 / 400) and 1 mark for the "
    "answer 75% (3 marks). Award the substitution and answer marks even if the formula is not "
    "written, provided the working is shown. Allow the method mark if the arithmetic is wrong but "
    "the substitution is right."),
   ("(c)", ["The school should use the machine that is 75 per cent efficient.",
            "It turns more of the work put into it into useful work.",
            "It wastes less energy as heat and sound.",
            "It will cost less to run, because less effort or less fuel is wasted."],
    "1 mark for choosing the 75 per cent machine and 1 mark for any ONE correct reason "
    "(2 marks). Accept a pupil who chooses the 40 per cent machine only if they give a good "
    "reason for it, such as that it is the only one the school can afford or repair."),
 ],
}


# --------------------------------------------- derive summary statistics
def topic_totals():
    m = {k: 0 for k in TOPIC}
    it = {k: 0 for k in TOPIC}
    for q in MCQ:
        m[q[3]] += 1
        it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk
            it[key] += 1
    return m, it


def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}
    b = {k: 0 for k in order}
    for q in MCQ:
        a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            b[cog] += mk
    return order, a, b


def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ:
        d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            d[diff] += mk
    return d
