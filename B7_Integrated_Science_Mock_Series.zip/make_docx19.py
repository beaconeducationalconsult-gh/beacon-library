# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "/home/user")
from build_virus import *

from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT

doc = Document()
sec = doc.sections[0]
sec.left_margin = Inches(0.7); sec.right_margin = Inches(0.7)
sec.top_margin = Inches(0.7); sec.bottom_margin = Inches(0.6)

st = doc.styles["Normal"]; st.font.name = "Calibri"; st.font.size = Pt(11)


def set_font(run, size=11, bold=False, italic=False, mono=False, color=None):
    run.font.size = Pt(size); run.bold = bold; run.italic = italic
    run.font.name = "Consolas" if mono else "Calibri"
    if color: run.font.color.rgb = color
    return run


def para(text="", size=11, bold=False, italic=False, align=None, mono=False,
         space_before=0, space_after=4, color=None):
    p = doc.add_paragraph()
    if align == "c": p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    elif align == "j": p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p.paragraph_format.space_before = Pt(space_before)
    p.paragraph_format.space_after = Pt(space_after)
    if text: set_font(p.add_run(text), size, bold, italic, mono, color)
    return p


def rule():
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(6); p.paragraph_format.space_before = Pt(2)
    set_font(p.add_run("_" * 78), 9, color=RGBColor(0x99, 0x99, 0x99))


def add_table(headers, rows, widths=None, size=9, head_size=9):
    t = doc.add_table(rows=1, cols=len(headers)); t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, h in enumerate(headers):
        c = t.rows[0].cells[i]; c.text = ""
        p = c.paragraphs[0]; p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_font(p.add_run(str(h)), head_size, bold=True)
    for row in rows:
        cells = t.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = ""
            p = cells[i].paragraphs[0]; p.paragraph_format.space_after = Pt(1)
            set_font(p.add_run(str(v)), size)
    if widths:
        for r_ in t.rows:
            for i, w in enumerate(widths): r_.cells[i].width = Inches(w)
    return t


def draw_diagram(lines, caption):
    t = doc.add_table(rows=2, cols=1); t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = t.rows[0].cells[0]
    for k, line in enumerate(lines):
        p = cell.paragraphs[0] if k == 0 else cell.add_paragraph()
        p.paragraph_format.space_after = Pt(0); p.paragraph_format.space_before = Pt(0)
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_font(p.add_run(line), 10, mono=True)
    c2 = t.rows[1].cells[0].paragraphs[0]
    c2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_font(c2.add_run(caption), 9, italic=True)
    t.rows[0].cells[0].width = Inches(6.6)
    t.rows[1].cells[0].width = Inches(6.6)


# ============================================================= TITLE BLOCK
para(SCHOOL, size=15, bold=True, align="c", space_after=2)
para(SUBJECT, size=13, bold=True, align="c", space_after=2)
para(EXAM, size=12, bold=True, align="c", space_after=2)
para(YEAR, size=10, italic=True, align="c", space_after=8)

info = doc.add_table(rows=1, cols=3); info.style = "Table Grid"
info.alignment = WD_TABLE_ALIGNMENT.CENTER
for i, v in enumerate([f"Class: {CLASS}", f"Time: {TIME}", f"Total Marks: {MARKS}"]):
    c = info.rows[0].cells[i]; c.text = ""
    set_font(c.paragraphs[0].add_run(v), 10, bold=True)
para("", space_after=6)

para("INSTRUCTIONS", size=11, bold=True, space_after=3)
for txt in [
    "1. Write your name and class clearly in the spaces provided on your answer sheet.",
    "2. This paper has TWO sections: Section A and Section B.",
    "3. Answer ALL the questions in both sections.",
    "4. Section A has 40 multiple-choice questions. Each question carries 1 mark. Choose the best answer "
    "(A, B, C or D) and record it on the answer sheet provided.",
    "5. Section B has 7 theory questions totalling 60 marks. Write your answers clearly and neatly in your "
    "answer booklet. Draw and label diagrams or tables where you are asked to.",
    "6. Read every question carefully before you answer it.",
    "7. Do not use correction fluid. Cancel any mistake neatly with a single line.",
    "8. Hand in your answer sheet and your answer booklet at the end of the examination.",
]:
    para(txt, size=10.5, space_after=2)
rule()

# =============================================================== SECTION A
para("SECTION A - OBJECTIVE TEST (40 marks)", size=12, bold=True, align="c", space_after=2)
para("Answer ALL questions. Each question carries 1 mark. Choose the BEST answer and write its letter "
     "(A, B, C or D) against the question number on your answer sheet.",
     size=10, italic=True, align="c", space_after=8)

for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(1); p.paragraph_format.space_before = Pt(4)
    set_font(p.add_run(f"{i}. {q}"), 10.5)
    for j, o in enumerate(opts):
        p2 = doc.add_paragraph()
        p2.paragraph_format.left_indent = Inches(0.28)
        p2.paragraph_format.space_after = Pt(0); p2.paragraph_format.space_before = Pt(0)
        set_font(p2.add_run(f"{'ABCD'[j]}. {o}"), 10.5)

doc.add_page_break()

# =============================================================== SECTION B
para("SECTION B - THEORY (60 marks)", size=12, bold=True, align="c", space_after=2)
para("Answer ALL questions. Write your answers in your answer booklet. The marks for each question are "
     "shown in brackets.", size=10, italic=True, align="c", space_after=8)

for qb in SECTION_B:
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(8); p.paragraph_format.space_after = Pt(2)
    set_font(p.add_run(f"Question {qb['num']}"), 11, bold=True)
    set_font(p.add_run(f"  [{qb['total']} marks]"), 10, bold=True, italic=True)
    para(qb["stem"], size=10.5, space_after=4)
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Inches(0.25)
        p.paragraph_format.space_after = Pt(3); p.paragraph_format.space_before = Pt(2)
        set_font(p.add_run(f"{lab} {text}  "), 10.5)
        set_font(p.add_run(f"[{mk} mark{'s' if mk > 1 else ''}]"), 10, bold=True)

doc.add_page_break()

# ============================================================== ANSWER KEY
para("ANSWER KEY", size=13, bold=True, align="c", space_after=6)
para("SECTION A - OBJECTIVE TEST", size=11, bold=True, space_after=4)
rows = [[i, ans, TOPIC[tp], cog] for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1)]
add_table(["Question", "Answer", "Curriculum Area (Topic)", "Cognitive Level"],
          rows, widths=[0.8, 0.7, 3.6, 1.5], size=9)
counts = {L: sum(1 for q in MCQ if q[2] == L) for L in "ABCD"}
para("", space_after=4)
para("Correct-answer distribution: " + ", ".join(f"{L} = {counts[L]}" for L in "ABCD") + " (30 items).",
     size=9, italic=True)

para("", space_after=8)
para("SECTION B - THEORY (summary answers; see the Marking Scheme for full detail)",
     size=11, bold=True, space_after=4)
sba = [
 ("1 (a)", "A viral disease is an illness caused by a virus. It is infectious, so it can spread from one person to another, and the virus enters the body and multiplies inside the body's living cells. Examples are COVID-19, Ebola, H1N1 influenza, measles and chicken pox.", "17.4", "Understand"),
 ("1 (b)", "Any three: a virus is much smaller than a bacterium; a virus can only multiply inside a living cell while many bacteria can multiply outside cells; antibiotics kill bacteria but have no effect on viruses; bacteria are living cells while a virus is not a complete cell; viral diseases can often be prevented by vaccination.", "17.4", "Understand"),
 ("1 (c)", "Antibiotics are medicines that kill bacteria or stop them multiplying. A virus is not a bacterium and does not have the parts that antibiotics attack, and because a virus multiplies inside the body's own cells a medicine that attacked it would also harm the body's cells. Taking antibiotics when they are not needed can also make bacteria resistant to them later.", "17.4", "Understand"),
 ("2 (a)", "Any three: through droplets released into the air when an infected person coughs, sneezes or talks; by touching surfaces or objects that have the virus on them and then touching the mouth, nose or eyes; by close contact such as shaking hands, hugging or sharing cups and plates; through body fluids, as with Ebola.", "17.4", "Understand"),
 ("2 (b)", "An infected person travels by tro-tro, bus, taxi or plane to another town or country while still infectious. People move from place to place for markets, funerals, school and work, carrying the virus with them. In the new place the person passes the virus to others, who pass it on again, and because travel is now fast a virus can reach many countries within days.", "17.4", "Understand"),
 ("2 (c)", "Any two: people are close together so droplets reach others easily; many people touch the same surfaces such as door handles, rails and money; there is less fresh air and less room to keep a distance; one infectious person can pass the virus to many people in a short time.", "17.4", "Understand"),
 ("3 (a)", "The germ is the corona virus, often written SARS-CoV-2. Any three symptoms: a high temperature or fever; a dry, persistent cough; difficulty in breathing or shortness of breath; loss of taste or smell; tiredness and body aches; a sore throat or headache.", "17.5", "Remember"),
 ("3 (b)", "It spreads mainly through droplets released when an infected person coughs, sneezes, talks or sings. A person nearby breathes in those droplets, or they land on the mouth, nose or eyes, and a person can also pick up the virus by touching a surface that has droplets on it and then touching the face. It spreads most easily indoors and in crowded places.", "17.5", "Understand"),
 ("3 (c)", "Any two: schools were closed for a long time and pupils lost lessons; markets, churches and funerals were restricted or stopped; people were asked to wear face masks and keep a distance; travel between towns and into the country was restricted; many people lost work or income; hospitals were put under great strain.", "17.5", "Understand"),
 ("4 (a)", "Any four: wash the hands often with soap under running water, or use an alcohol hand sanitiser; wear a face mask properly in crowded or enclosed places; keep a distance from other people and avoid crowds; cover the mouth and nose with a bent elbow or tissue when coughing or sneezing; stay at home and report to a health facility when unwell; get vaccinated when the vaccine is offered; clean surfaces that are touched often.", "17.5", "Understand"),
 ("4 (b)", "Either side, with reasons. For: closing schools kept large numbers of children and teachers apart so the virus could not spread easily among them, it protected pupils, teachers and the older people they live with, and it gave the health service time to prepare. Against: pupils lost a lot of learning and some children went hungry without school meals.", "17.5", "Evaluate"),
 ("5 (a)", "Any three: fever and severe headache; body aches, weakness and tiredness; bleeding from the gums, nose, eyes or other body openings; vomiting and diarrhoea; stomach pain.", "17.6", "Remember"),
 ("5 (b)", "Through direct contact with the blood, saliva, sweat, urine, stool or other body fluids of an infected person; by touching or caring for a sick person without gloves and other protection; by washing or touching the body of someone who has died of Ebola during burial preparations; or by touching clothes, bedding or instruments soiled with body fluids. It does not spread through the air over a long distance like flu.", "17.6", "Understand"),
 ("5 (c)", "Ebola spreads very easily through contact with body fluids, so everyone near the person is at risk, and the disease is severe and kills many of those it infects. The person needs skilled treatment at a health facility that the community cannot give, and leaving them at home means carers and family are infected and carry it to others. There is no cure the family can give at home, so delay costs lives.", "17.6", "Apply"),
 ("6 (a)", "H1N1 is a viral disease, a kind of influenza or flu that affects people, first called swine flu because the virus is related to flu viruses found in pigs. Any two symptoms: fever and chills; a cough and sore throat; a running or blocked nose; body aches, headache and tiredness; vomiting or diarrhoea.", "17.6", "Understand"),
 ("6 (b)", "Any two similarities: both are caused by a virus and both can be declared a pandemic; both spread through droplets from coughing and sneezing; both cause fever, cough and tiredness and can make breathing difficult; both are prevented by handwashing, masks, distance and avoiding crowds. Any one difference: Ebola spreads through body fluids rather than mainly through the air and causes bleeding, or Ebola kills a far larger share of the people it infects, or H1N1 is a flu that most people recover from while Ebola is much more severe.", "17.6", "Analyse"),
 ("6 (c)", "Any two: wash the hands often with soap and water; cover the mouth and nose when coughing or sneezing; keep away from crowds and keep a distance from anyone coughing; get the seasonal flu vaccine where it is available; stay at home and rest when unwell; clean surfaces that are touched often and keep rooms well aired.", "17.6", "Apply"),
 ("7 (a)", "The individual should wash hands regularly, wear a mask in crowded places, report sickness early and follow the health rules. The community should report cases early, support families who are isolating, and stop spreading false information. The government should provide testing, treatment and isolation centres, give clear health education, and supply protective equipment to health workers.", "17.7", "Understand"),
 ("7 (b)", "A short clear message such as 'Wash your hands, wear your mask, keep your distance'; pictures showing hands being washed, a mask being worn and someone covering a cough; the signs of the disease and what to do about them; a phone number or place to report to. Use very few words and large letters, pictures and symbols rather than long sentences because some people cannot read, the local language as well as English, bright colours, and put the message at the top.", "17.7", "Create"),
 ("7 (c)", "Any two with a reason: at the market, because many people pass there every day; at the clinic or health centre, where people already come for health matters; at the school, so pupils and parents both see it; at the church or mosque, where the community gathers; at the lorry station, where travellers pass through.", "17.7", "Apply"),
]
add_table(["Question", "Expected Answer", "Curriculum Area", "Cognitive Level"],
          [list(r) for r in sba], widths=[0.8, 4.2, 1.2, 1.2], size=9)

doc.add_page_break()

# =========================================================== MARKING SCHEME
para("MARKING SCHEME - SECTION B (60 marks)", size=13, bold=True, align="c", space_after=4)
para("General rules: (1) Accept any other correct and relevant answer. (2) Award marks for correct points, "
     "not for repeating the question. (3) For procedures, award method marks. (4) Do not deduct marks for "
     "spelling unless the meaning is changed. (5) Where a candidate gives more answers than are asked for, "
     "mark only the first ones up to the number required.",
     size=9.5, italic=True, space_after=8)

for qb in SECTION_B:
    n = qb["num"]
    para(f"Question {n}  ({qb['total']} marks)", size=11, bold=True, space_before=8, space_after=3)
    for (lab, points, note) in MARKING[n]:
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(2)
        set_font(p.add_run(f"{lab} "), 10.5, bold=True)
        mkv = [p_[2] for p_ in qb["parts"] if p_[0] == lab]
        if mkv: set_font(p.add_run(f"[{mkv[0]} mark{'s' if mkv[0] > 1 else ''}]"), 10, bold=True)
        for pt in points:
            pp = doc.add_paragraph()
            pp.paragraph_format.left_indent = Inches(0.35); pp.paragraph_format.space_after = Pt(1)
            set_font(pp.add_run("- " + pt), 10.5)
        pp = doc.add_paragraph()
        pp.paragraph_format.left_indent = Inches(0.35); pp.paragraph_format.space_after = Pt(6)
        set_font(pp.add_run("Marking note: " + note), 9.5, italic=True)

doc.add_page_break()

# ================================================================ BLUEPRINT
para("CURRICULUM ASSESSMENT BLUEPRINT", size=13, bold=True, align="c", space_after=3)
para(f"Strand: {STRAND}   |   Sub-strand: {SUBSTRAND}   |   Class: {CLASS}",
     size=10, italic=True, align="c", space_after=3)
para(f"Content Standard: {CS} - {CS_TEXT}", size=9, italic=True, align="c", space_after=3)
para("Source: NaCCA Science Common Core Programme Curriculum (B7/JHS1-B9/JHS3), September 2020, "
     "Strand 5: Humans and the Environment, Sub-strand 2: Human Health "
     "(topics 17.4-17.7), p. 46. Indicators are quoted, not invented.",
     size=9, italic=True, space_after=8)

hdr = ["Qn", "Sub-strand", "Content Standard", "Indicator (NaCCA) - Indicator Text", "Topic / Content",
       "Cognitive Level", "Marks"]

rows = [[f"A{i}", SUBSTRAND, CS_BY_TOPIC[tp], f"{IND[tp]} - {IND_TEXT[tp]}", TOPIC[tp], cog, 1]
        for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1)]
add_table(hdr, rows, widths=[0.35, 0.75, 0.75, 1.75, 1.4, 0.8, 0.35], size=7, head_size=7.5)

para("", space_after=8)
rows = []
for qb in SECTION_B:
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        key = tp if tp in TOPIC else tp.split(",")[0].strip()
        rows.append([f"B{qb['num']}{lab.strip('()')}", SUBSTRAND, CS_BY_TOPIC[key],
                     f"{IND[key]} - {IND_TEXT[key]}", TOPIC[key], cog, mk])
add_table(hdr, rows, widths=[0.35, 0.75, 0.75, 1.75, 1.4, 0.8, 0.35], size=7, head_size=7.5)

doc.add_page_break()

# ----------------------------------------------------------------- helpers
def topic_totals():
    m = {k: 0 for k in TOPIC}; it = {k: 0 for k in TOPIC}
    for q in MCQ:
        m[q[3]] += 1; it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk; it[key] += 1
    return m, it

def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}; b = {k: 0 for k in order}
    for q in MCQ: a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: b[cog] += mk
    return order, a, b

def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ: d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: d[diff] += mk
    return d

m, it = topic_totals(); diff = difficulty_totals(); order, ca, cb = cognitive_by_section()

para("SUMMARY 1 - COVERAGE BY CURRICULUM AREA (TOPIC)", size=12, bold=True, space_after=4)
rows = [[TOPIC[k], it[k], m[k], f"{(m[k]/100)*100:.1f}%", CC[k]] for k in TOPIC]
rows.append(["TOTAL", sum(it.values()), sum(m.values()), "100%", "-"])
add_table(["Topic / Content Area", "No. of Items", "Marks", "% of Total Marks", "Core Competencies"],
          rows, widths=[2.7, 0.8, 0.6, 1.0, 1.1], size=8.5)
para("CC = Communication and Collaboration; CP = Critical Thinking and Problem Solving; "
     "DL = Digital Literacy; CI = Creativity and Innovation.", size=8.5, italic=True, space_after=2)

para("", space_after=8)
para("SUMMARY 2 - COGNITIVE-LEVEL DISTRIBUTION (Bloom's Taxonomy)", size=12, bold=True, space_after=4)
rows = []
for lv in order:
    tot = ca[lv] + cb[lv]
    rows.append([lv, ca[lv], cb[lv], tot, f"{(tot/100)*100:.1f}%"])
rows.append(["TOTAL", sum(ca.values()), sum(cb.values()), sum(ca.values()) + sum(cb.values()), "100%"])
add_table(["Cognitive Level", "Section A Marks", "Section B Marks", "Total Marks", "% of Total"],
          rows, widths=[1.6, 1.3, 1.3, 1.1, 1.1], size=9.5)

para("", space_after=8)
para("SUMMARY 3 - DIFFICULTY DISTRIBUTION", size=12, bold=True, space_after=4)
rows = [[k, v, f"{(v/100)*100:.1f}%"] for k, v in diff.items()]
rows.append(["TOTAL", sum(diff.values()), "100%"])
add_table(["Difficulty", "Marks", "% of Total Marks"], rows, widths=[2.0, 1.2, 1.5], size=9.5)
para("Target in the master prompt: approximately 30% easy / 50% moderate / 20% challenging.",
     size=9, italic=True, space_after=2)

para("", space_after=8)
para("SUMMARY 4 - SECTION WEIGHTING", size=12, bold=True, space_after=4)
add_table(["Section", "Question Type", "Items", "Marks", "% of Total"],
          [["A", "Objective (multiple choice)", 40, 40, "40%"],
           ["B", "Theory / constructed response", 20, 60, "60%"],
           ["TOTAL", "-", 60, 100, "100%"]],
          widths=[0.9, 2.4, 0.8, 0.8, 1.0], size=9.5)

doc.add_page_break()

# ===================================================== QUALITY-CONTROL
para("QUALITY-CONTROL SUMMARY", size=13, bold=True, align="c", space_after=4)
para("Carried out against the 14-point validation list in the master prompt before the examination was "
     "finalised.", size=9.5, italic=True, space_after=8)

qc = [
 ("Does every question belong to the supplied curriculum scope?",
  "Yes. All 60 items - 40 objectives and 20 theory sub-questions - trace to Strand 5 (Humans "
  "and the Environment), Sub-Strand 2 (Human Health), topics 17.4-17.7, and to the single "
  "official B7 indicator B7/JHS1.5.2.2.1 under content standard B7/JHS1.5.2.2. Only viral "
  "diseases are tested. Deficiency diseases, food nutrients, and night blindness, rickets, "
  "scurvy, kwashiorkor and anaemia are deliberately excluded - they belong to the companion "
  "paper on B7/JHS1.5.2.1."),
 ("Is the examination appropriate for the stated class?",
  "Yes. The B7 curriculum requires learners to discuss the nature of viral diseases; to search "
  "for information and present on COVID-19, Ebola and H1N1 and how they pass from person to "
  "person, community to community and country to country; to describe their symptoms, effects "
  "and prevention and why they are declared pandemic; to describe the roles of individuals, "
  "communities and government in managing them; and to design a poster to educate the "
  "community. Nothing beyond that is tested."),
 ("Are the questions genuinely BECE-style?",
  "Yes: Section A is 40 four-option objectives worth 1 mark each, and Section B is structured "
  "theory with sub-questions carrying printed mark allocations. There are 'state', 'name', "
  "'describe' and 'explain' items, an argument task, a comparison task and a poster-design "
  "task."),
 ("Are there enough application and reasoning questions?",
  "Yes. 34 of 100 marks (34%) are at Apply level or above (Apply 22, Analyse 4, Evaluate 4, "
  "Create 4). Create appears in Question 7(b), where pupils must design a poster; Analyse in "
  "Question 6(b), where they must compare H1N1 with COVID-19 or Ebola; and Evaluate in "
  "Question 4(b), where they must judge the closing of schools."),
 ("Are the MCQ distractors plausible?",
  "Yes. Distractors are drawn from the same content family as the key: a real disease caused by "
  "something other than a virus (A3, A5, A25), a symptom belonging to a different disease "
  "(A11, A18, A22), a genuine activity that is not protective (A13, A14, A20, A28), a real "
  "statement about the wrong group (A30, A31), and a genuine poster item that is simply the "
  "least useful (A40)."),
 ("Is there only one best answer for each MCQ?",
  "Yes. Every item was reviewed for a single defensible key, and each option list was checked "
  "so that the declared key sits on the correct answer. Special care was taken with A3, where "
  "malaria, cholera and typhoid are all diseases but none is viral, with A24, where malaria, "
  "cholera and kwashiorkor are all real diseases but only the common flu matches the way H1N1 "
  "spreads, and with A40, where three of the four options are genuinely useful on a poster."),
 ("Are the marks internally consistent?",
  "Yes. Section A = 40 items x 1 mark = 40. Section B = 9 + 8 + 9 + 8 + 9 + 8 + 9 = 60. "
  "Each Section B sub-question's printed marks match its marking-scheme allocation, and every "
  "N-mark sub-question asks for N things."),
 ("Does the total add up correctly?",
  "Yes: 40 + 60 = 100 marks, matching the stated total on the front page."),
 ("Are the answers in the answer key correct?",
  "Yes. All 40 objective keys and all 20 Section B answers were verified against the marking "
  "scheme. The three transmission routes were checked apart: COVID-19 and H1N1 spread mainly "
  "through droplets, while Ebola spreads through contact with body fluids and not through the "
  "air over a distance."),
 ("Does the marking scheme match the questions?",
  "Yes. Every Section B sub-question has an expected-answer list and a marking note covering "
  "partial credit, acceptable alternatives, common wrong answers and method marks. Question "
  "2(b) caps the answer at 2 if it describes only person-to-person spread without explaining "
  "movement between places; Question 5(b) caps it at 2 if it says Ebola spreads through the "
  "air; and Question 7(b) requires both what the poster shows and how it is made clear to "
  "someone who cannot read."),
 ("Are the questions free from unnecessary ambiguity?",
  "Yes. Open items are anchored with 'state three', 'state four', 'state two' and the mark "
  "allocation. Question 7(a) asks for one role each of three named groups, and the note "
  "withholds the mark when a correct action is attached to the wrong group; Question 6(b) asks "
  "for two similarities and one difference; Question 3(a) asks for the germ AND three "
  "symptoms; and Question 1(c) asks why antibiotics do not work, not merely whether they do."),
 ("Are Ghanaian contexts used naturally and accurately?",
  "Yes: tro-tros, buses and taxis carrying people between towns, markets, churches, mosques and "
  "funerals, the lorry station, the chief's palace, the clinic and health centre, school "
  "closures and lost lessons, lockdowns and travel restrictions, and posters written in the "
  "local language as well as English."),
 ("Has any content outside the supplied curriculum been introduced?",
  "No. Every item sits inside topics 17.4-17.7. Deficiency diseases and food nutrients are not "
  "required anywhere in the paper, and the biology of viruses is not taken beyond 'a virus "
  "multiplies only inside a living cell' and 'antibiotics act on bacteria, not viruses'. No "
  "virus is named beyond the corona virus, Ebola and H1N1."),
 ("Are the questions sufficiently varied?",
  "Yes. Item types include defining a viral disease, contrasting a virus with a bacterium, "
  "explaining why antibiotics fail, describing three routes of spread, explaining spread "
  "between communities and countries, explaining why crowds are risky, naming the cause and "
  "symptoms of COVID-19, explaining droplet spread, listing effects on Ghana, listing four "
  "preventive measures, arguing about school closures, listing Ebola symptoms, explaining "
  "Ebola's transmission, justifying removal of a suspected case, explaining H1N1, comparing it "
  "with another viral disease, preventing flu, giving the roles of individual, community and "
  "government, designing a poster, and choosing where to put it up."),
]
for i, (q, a) in enumerate(qc, start=1):
    p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(2)
    set_font(p.add_run(f"{i}. {q}"), 10.5, bold=True)
    p2 = doc.add_paragraph()
    p2.paragraph_format.left_indent = Inches(0.3); p2.paragraph_format.space_after = Pt(6)
    set_font(p2.add_run(a), 10)

para("", space_after=8)
para("EXAMINER NOTES (for the teacher, not for candidates)", size=11, bold=True, space_after=4)
for n in [
 "Question 1(c) is the item that separates understanding from rote learning. Pupils who have "
 "only memorised a list will say 'antibiotics do not work'. The marks are on why: antibiotics "
 "attack bacteria, a virus has none of the parts they attack, and a virus hides inside the "
 "body's own cells. Worth teaching the reason, not just the rule.",
 "Questions 5(b) and 3(b) sit next to each other on purpose, because pupils merge the two "
 "routes. COVID-19 and H1N1 travel in droplets from the breath; Ebola travels in body fluids "
 "and NOT through the air over a distance. Both notes cap the answer at 2 if the route is "
 "given for the wrong disease, so drill the pair together.",
 "Question 7(b) is the design task, and it is marked on two halves: what the poster SHOWS or "
 "SAYS, and how it is made clear to someone who cannot read. Many pupils will produce a good "
 "slogan and forget the second half. The note caps them at 3 of 4 for that.",
 "Question 4(b) is deliberately open. Pupils who lived through the school closures have real "
 "views about it, and the note credits either side provided the reasons support the position. "
 "Do not mark down a pupil who argues that closing schools was wrong, if the reasons are good.",
 "Question 6(b) asks for two similarities and one difference, and pupils may compare H1N1 with "
 "either COVID-19 or Ebola. Both are accepted. The one answer to watch for is a 'difference' "
 "that is really a similarity written twice.",
 "Topic weighting is 26 marks for 17.4, 28 for 17.5, 24 for 17.6 and 22 for 17.7. If you spent "
 "longer on community roles than on the nature of viruses, move marks towards Question 7.",
 "Two cheap activities that raise marks sharply: (1) put glitter or flour on one pupil's hands "
 "and let the class see how far it travels by touch in five minutes, and (2) have the class "
 "design a real poster and then read it to a pupil from a lower class to test whether the "
 "message lands. The first teaches Question 2, the second teaches Question 7.",
 "The companion paper covers topics 17.1 to 17.3 - food nutrients, deficiency diseases, and "
 "night blindness, rickets, scurvy, kwashiorkor and anaemia - under content standard "
 "B7/JHS1.5.2.1. Use the two papers together for a full end-of-term examination on this "
 "sub-strand, or separately as two class tests.",
 "Edit the school name, academic year and examination title on page 1 before printing.",
 "This is an original, teacher-made mock. It is not a reproduction of any WAEC or NaCCA examination "
 "paper.",
]:
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Inches(0.3); p.paragraph_format.space_after = Pt(3)
    set_font(p.add_run("- " + n), 10)

doc.save("/home/user/Basic7_Integrated_Science_Mock_Strand5_HumanHealth2.docx")
print("docx written")

print("Section A:", len(MCQ), "items")
print("Section B total:", sum(q["total"] for q in SECTION_B))
print("Topic marks:", m, "sum", sum(m.values()))
print("Difficulty:", diff, "sum", sum(diff.values()))
print("Cognitive A:", ca)
print("Cognitive B:", cb)
print("Answer counts:", counts)
print("Totals:", sum(m.values()), sum(diff.values()),
      sum(ca.values()) + sum(cb.values()))
