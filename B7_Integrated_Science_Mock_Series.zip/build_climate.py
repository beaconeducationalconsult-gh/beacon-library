# -*- coding: utf-8 -*-
"""Basic 7 Integrated Science mock - Strand 5 Sub-strand 4: CLIMATE CHANGE AND GREEN ECONOMY
(rebuild). Covers topics 19.1 to 19.4 (what sustainable energy is; greenhouse effects on the
environment; sustainable energy choices and scientific ideas; and designing local energy
solutions). 100 marks.
Indicators sourced from the official NaCCA Science CCP curriculum (B7/JHS1-B9/JHS3, Sept 2020),
Strand 5: Humans and the Environment, Sub-strand 4: Climate Change and Green Economy, printed
page 48. Content standard: B7/JHS1.5.4.1. One content standard and one indicator, so this is a
single paper and not split.
This is a full rebuild: every question is new and none is repeated from the earlier version."""

SCHOOL = "[SCHOOL NAME]"
SUBJECT = "INTEGRATED SCIENCE (SCIENCE)"
EXAM = "END-OF-TERM MOCK EXAMINATION"
CLASS = "Basic 7 (JHS 1)"
TIME = "2 hours (Suggested: Section A - 40 min; Section B - 80 min)"
MARKS = "100"
YEAR = "2025/2026 Academic Year"

STRAND = "Humans and the Environment"
SUBSTRAND = "Climate Change and Green Economy"

TOPIC = {
    "19.1": "19.1 What is Sustainable Energy?",
    "19.2": "19.2 Greenhouse Effects on the Environment",
    "19.3": "19.3 Sustainable Energy Choices and Scientific Ideas",
    "19.4": "19.4 Designing Local Energy Solutions",
}

CS = "B7/JHS1.5.4.1"
CS_BY_TOPIC = {k: "B7/JHS1.5.4.1" for k in ["19.1", "19.2", "19.3", "19.4"]}
CS_TEXT = ("Demonstrate understanding of sustainable energy choices and their impact on the "
           "environment")

IND = {
    "19.1": "B7/JHS1.5.4.1.1 (Ex. 1)",
    "19.2": "B7/JHS1.5.4.1.1 (Ex. 2)",
    "19.3": "B7/JHS1.5.4.1.1 (Ex. 1, 2)",
    "19.4": "B7/JHS1.5.4.1.1 (Ex. 3)",
}
IND_TEXT = {
    "19.1": "Search for information on ways sustainable energy choices and scientific ideas are "
            "used to protect the environment. Ex. 1: Describe how people use sustainable energy "
            "choices and scientific ideas to protect the environment.",
    "19.2": "Search for information on ways sustainable energy choices and scientific ideas are "
            "used to protect the environment. Ex. 2: Analyse greenhouse effects on the "
            "environment and show how they can be minimised.",
    "19.3": "Search for information on ways sustainable energy choices and scientific ideas are "
            "used to protect the environment. Ex. 1, 2: Describe how people use sustainable "
            "energy choices and scientific ideas to protect the environment; analyse greenhouse "
            "effects on the environment and show how they can be minimised.",
    "19.4": "Search for information on ways sustainable energy choices and scientific ideas are "
            "used to protect the environment. Ex. 3: Design a project to show how energy can be "
            "locally sustained through the use of scientific processes to protect the "
            "environment.",
}
CC = {"19.1": "CP, DL, CC, CI", "19.2": "CP, DL, CC, CI",
      "19.3": "CP, DL, CC, CI", "19.4": "CP, DL, CC, CI"}

# ---------------------------------------------------------------- SECTION A
# (question, [A,B,C,D], answer, topic, cognitive, difficulty)
MCQ = [
 ("A village gets its cooking fuel from the trees around it. The wood will keep coming only if",
  ["the trees are replaced as fast as they are cut", "the wood is burnt in an open fire", "the village buys charcoal from the town", "the village cuts more trees each year"],
  "A", "19.1", "Remember", "Easy"),
 ("Which of these sources of energy will never run out?",
  ["kerosene", "coal", "petrol", "wind"],
  "D", "19.1", "Remember", "Easy"),
 ("A source of energy that will not run out is called",
  ["expensive", "renewable", "stored", "wasted"],
  "B", "19.1", "Understand", "Easy"),
 ("Biogas is made when",
  ["animal dung and food waste rot without air", "petrol is mixed with water", "salt is dissolved in water", "wood is burnt in a stove"],
  "A", "19.1", "Understand", "Moderate"),
 ("Which of these is NOT a sustainable source of energy?",
  ["the wind", "water behind a dam", "diesel", "the sun"],
  "C", "19.1", "Understand", "Easy"),
 ("The heat inside the earth can be used as a source of",
  ["biogas", "wind energy", "solar energy", "geothermal energy"],
  "D", "19.1", "Remember", "Easy"),
 ("A village dam that generates electricity is using",
  ["energy from burning coal", "energy from the wind", "energy from the sun", "energy from moving water"],
  "D", "19.1", "Understand", "Easy"),
 ("Firewood becomes a non-renewable source of energy when",
  ["it is burnt in a stove", "the wood is very dry", "trees are cut down faster than they can grow back", "it is carried a long way"],
  "C", "19.1", "Analyse", "Challenging"),
 ("A family has sunshine for most of the year. The best choice for lighting their home is",
  ["a large pile of firewood", "solar panels", "a drum of diesel", "a bag of charcoal"],
  "B", "19.1", "Apply", "Moderate"),
 ("The main advantage of a renewable source of energy is that it",
  ["is replaced naturally and will not run out", "needs no equipment at all", "is always the cheapest", "comes only from other countries"],
  "A", "19.1", "Understand", "Easy"),
 ("Which gas is given out when charcoal burns?",
  ["oxygen", "carbon dioxide", "helium", "nitrogen"],
  "B", "19.2", "Remember", "Easy"),
 ("Methane is given out when",
  ["the wind blows", "water boils", "wood is chopped", "waste rots and when cattle digest their food"],
  "D", "19.2", "Understand", "Easy"),
 ("The greenhouse effect is caused by gases that",
  ["trap heat near the surface of the earth", "block all the sunlight from reaching us", "make the rain fall", "blow the clouds away"],
  "A", "19.2", "Understand", "Moderate"),
 ("If there were no greenhouse gases in the air at all, the earth would be",
  ["much colder than it is now", "much hotter than it is now", "exactly the same", "completely covered in water"],
  "A", "19.2", "Understand", "Moderate"),
 ("Cutting down a forest increases the carbon dioxide in the air because",
  ["the trees give out carbon dioxide", "there are fewer trees left to take it in", "the soil gives out carbon dioxide", "the rain stops falling"],
  "B", "19.2", "Understand", "Easy"),
 ("Bush burning adds to the greenhouse effect because it",
  ["stops the wind from blowing", "makes the soil harder", "releases the carbon dioxide that was stored in the plants", "cools the air around the farm"],
  "C", "19.2", "Understand", "Moderate"),
 ("A coastal town in Ghana is flooded more often than it used to be. The most likely cause is",
  ["the sea level rising as the earth gets warmer", "more rain falling everywhere", "the tides stopping", "the town sinking into the sand"],
  "A", "19.2", "Analyse", "Challenging"),
 ("Which of these would reduce the amount of carbon dioxide in the air?",
  ["cutting down the forest", "planting trees", "driving more cars", "burning more charcoal"],
  "B", "19.2", "Understand", "Easy"),
 ("A farmer notices that the rains now come at different times from when he was a boy. This is most likely due to",
  ["climate change", "the soil becoming too rich", "the farmer planting the wrong seeds", "too many clouds over the farm"],
  "A", "19.2", "Analyse", "Challenging"),
 ("Using a tro-tro instead of many private cars reduces the greenhouse effect because",
  ["the passengers walk part of the way", "the tro-tro travels a shorter road", "the tro-tro is painted green", "less fuel is burnt for each person carried"],
  "D", "19.2", "Apply", "Moderate"),
 ("A solar cooker works by",
  ["boiling water over a fire", "burning charcoal inside a box", "using electricity from a battery", "using heat from the sun to cook food"],
  "D", "19.3", "Understand", "Easy"),
 ("A solar water heater is usually painted dark because",
  ["a dark surface reflects all the heat away", "dark paint is the cheapest", "dark paint keeps the water clean", "a dark surface takes in more of the sun's heat"],
  "D", "19.3", "Understand", "Easy"),
 ("A wind pump is useful in a village because it",
  ["makes the wind blow harder", "draws water without burning any fuel", "works only at night", "needs petrol brought from the city"],
  "B", "19.3", "Apply", "Moderate"),
 ("An improved cookstove saves wood mainly because it",
  ["burns the wood very quickly", "is made of metal", "is smaller than an open fire", "keeps the heat in and sends it up to the pot"],
  "D", "19.3", "Understand", "Easy"),
 ("Drying cassava in a solar dryer is better than drying it on the ground because",
  ["the cassava takes longer to dry", "the cassava is protected from dust, flies and rain", "the cassava needs no sunshine at all", "the cassava cooks as it dries"],
  "B", "19.3", "Apply", "Moderate"),
 ("A family wants to make use of the food waste from their kitchen. The best choice is",
  ["a wind turbine", "a charcoal kiln", "a biogas digester", "a kerosene stove"],
  "C", "19.3", "Apply", "Moderate"),
 ("Switching off the lights when leaving a room saves energy because",
  ["the electricity is not being used while nobody needs it", "the room stays cooler", "the switch wears out more slowly", "the bulbs last for ever"],
  "A", "19.3", "Understand", "Easy"),
 ("Insulating the roof of a house saves energy because",
  ["the house becomes darker", "less heat enters the house, so less electricity is used on a fan", "the rain runs off faster", "the roof becomes heavier"],
  "B", "19.3", "Understand", "Moderate"),
 ("A solar panel should be placed",
  ["on the north wall of the building", "flat on the ground in the shade", "where it faces the sun and is not shaded by trees", "inside the house near a window"],
  "C", "19.3", "Apply", "Moderate"),
 ("Before designing a project, a group should first",
  ["find out what the problem is and what is available", "write the final report", "invite visitors to come and see it", "buy all the materials"],
  "A", "19.4", "Understand", "Moderate"),
 ("A good project plan should include",
  ["only a list of the people", "only how much it costs", "the materials, the steps and how the project will be tested", "only the name of the project"],
  "C", "19.4", "Understand", "Moderate"),
 ("A school wants to light a classroom that is not connected to the national grid. The best project is",
  ["more kerosene lanterns", "solar panels with a battery", "a large pile of firewood", "a diesel generator"],
  "B", "19.4", "Apply", "Moderate"),
 ("Testing a project means",
  ["making it more expensive", "showing it to the head teacher", "checking whether it does what it was built to do", "writing it up neatly"],
  "C", "19.4", "Understand", "Moderate"),
 ("A project that is left with nobody to look after it will",
  ["produce more energy each year", "go on working for ever", "repair itself when it breaks", "break down and stop working after a time"],
  "D", "19.4", "Understand", "Easy"),
 ("Which is the best way to know whether a school biogas digester is working?",
  ["the burner lights and stays lit while the food cooks", "the tank was bought from the city", "the pupils like the colour of the tank", "the digester looks clean from the outside"],
  "A", "19.4", "Apply", "Moderate"),
 ("A group is choosing a site for a wind pump. They should first",
  ["choose the nearest hill", "choose the site closest to the road", "check that the wind blows strongly and often there", "paint the pump first"],
  "C", "19.4", "Apply", "Moderate"),
 ("Keeping spare parts and training someone to repair a project is called",
  ["designing", "maintenance", "research", "testing"],
  "B", "19.4", "Understand", "Easy"),
 ("A project should use local materials where possible because",
  ["they are given out free by the assembly", "they always last longer than anything else", "they look better than imported materials", "they are cheaper, easy to replace, and people already know how to work with them"],
  "D", "19.4", "Analyse", "Moderate"),
 ("A group has finished building their energy project. The BEST way to show the school that it works is to",
  ["take a photograph of the group standing next to it", "tell only the pupils in their own class", "run it in front of everyone and explain what it does and how much it saves", "write a long report and lock it in a cupboard"],
  "C", "19.4", "Evaluate", "Challenging"),
 ("Which of these uses the sun's energy DIRECTLY, without first changing it into electricity?",
  ["an LED lamp", "a solar panel", "a solar dryer", "a radio set"],
  "C", "19.3", "Apply", "Moderate"),
]

# ---------------------------------------------------------------- SECTION B
GREEN_HEADERS = ["Human Activity", "Greenhouse Gas Released", "How It Can Be Reduced"]
GREEN_ROWS = [
 ["Burning firewood and charcoal", "(i)", "Use an improved cookstove, biogas or LPG"],
 ["(ii)", "carbon dioxide", "Stop bush burning and plant trees"],
 ["Keeping cattle and rotting waste", "(iii)", "Put the waste into a biogas digester"],
 ["Burning petrol in cars and generators", "carbon dioxide", "(iv)"],
]

SECTION_B = [
 dict(
   num=1, total=9, topic="19.1",
   stem="Two families live in the same village. One cooks with firewood, and the other cooks "
        "with gas from a biogas digester fed by the waste from their goat pen.",
   parts=[
     ("(a)", "Name FOUR sources of energy that will not run out.",
      4, "Remember", "19.1", "Easy"),
     ("(b)", "Explain what makes a source of energy renewable.",
      3, "Understand", "19.1", "Moderate"),
     ("(c)", "Give TWO reasons why the village would be better off if more families used "
      "biogas.", 2, "Understand", "19.1", "Moderate"),
   ]),
 dict(
   num=2, total=8, topic="19.1",
   stem="A family in the village is deciding whether to keep cooking with charcoal or to change "
        "to something else.",
   parts=[
     ("(a)", "State TWO reasons why charcoal is not a sustainable source of energy.",
      2, "Understand", "19.1", "Easy"),
     ("(b)", "Name THREE sustainable sources of energy the family could use instead of "
      "charcoal.", 3, "Understand", "19.1", "Moderate"),
     ("(c)", "Explain ONE difficulty the family might face in changing to a sustainable source "
      "of energy.", 3, "Apply", "19.1", "Challenging"),
   ]),
 dict(
   num=3, total=9, topic="19.2",
   stem="Some of the gases in the air act like the glass of a greenhouse.",
   parts=[
     ("(a)", "Name TWO greenhouse gases.", 2, "Remember", "19.2", "Easy"),
     ("(b)", "Explain how these gases warm the earth.", 4, "Understand", "19.2", "Moderate"),
     ("(c)", "Explain why the greenhouse effect is both helpful and harmful.",
      3, "Understand", "19.2", "Challenging"),
   ]),
 dict(
   num=4, total=8, topic="19.2", table="green",
   stem="The table below shows some human activities that add greenhouse gases to the air. "
        "Complete it by filling in the spaces numbered (i) to (iv).",
   parts=[
     ("(i)", "The gas released when firewood and charcoal burn.",
      2, "Understand", "19.2", "Easy"),
     ("(ii)", "A human activity that releases carbon dioxide from plants.",
      2, "Understand", "19.2", "Moderate"),
     ("(iii)", "The gas released by rotting waste and by cattle.",
      2, "Understand", "19.2", "Moderate"),
     ("(iv)", "One way to reduce the gas released by burning petrol in cars and generators.",
      2, "Understand", "19.2", "Moderate"),
   ]),
 dict(
   num=5, total=9, topic="19.3",
   stem="A school wants to cut down the amount of energy it uses and the harm it does to the "
        "environment.",
   parts=[
     ("(a)", "Name THREE sustainable energy choices the school could make.",
      3, "Remember", "19.3", "Easy"),
     ("(b)", "For TWO of the choices you named in (a), explain the scientific idea behind the "
      "way it works.", 4, "Understand", "19.3", "Moderate"),
     ("(c)", "Explain ONE way the school could check whether the change has actually saved "
      "energy.", 2, "Apply", "19.3", "Moderate"),
   ]),
 dict(
   num=6, total=8, topic="19.3",
   stem="A fishmonger at a lakeside town dries her fish in the open, on the ground, where dust "
        "and flies spoil much of it.",
   parts=[
     ("(a)", "Explain how a solar dryer would help the fishmonger.",
      4, "Apply", "19.3", "Moderate"),
     ("(b)", "Evaluate whether the whole community benefits when she dries her fish this way, "
      "or only she does.", 4, "Evaluate", "19.3", "Challenging"),
   ]),
 dict(
   num=7, total=9, topic="19.4",
   stem="Your class has been asked to design a project that will bring energy to a clinic in a "
        "village that has no electricity, using only what can be found nearby.",
   parts=[
     ("(a)", "State THREE things the class must find out before it designs anything.",
      3, "Understand", "19.4", "Moderate"),
     ("(b)", "Design the project. Say what it will be, what materials are needed, and the steps "
      "you would follow to build it.", 3, "Create", "19.4", "Challenging"),
     ("(c)", "Explain how the class will know that the project has succeeded, and how it will "
      "be kept running.", 3, "Apply", "19.4", "Challenging"),
   ]),
]

# ------------------------------------------------------------ MARKING SCHEME
MARKING = {
 1: [("(a)", [
      "Any four: the sun or solar energy; the wind; moving water or water behind a dam; biogas "
      "from animal dung and food waste; crops and crop waste grown again each season; the heat "
      "inside the earth.",
     ], "1 mark each for any FOUR correct sources (4 marks). Do NOT accept firewood, charcoal, "
        "petrol, diesel, kerosene, coal or LPG - none of these will last. Do NOT accept "
        "'electricity' on its own, because it depends on the source it is made from."),
     ("(b)", [
      "A renewable source is one that is replaced naturally as fast as people use it, so it "
      "never runs out.",
      "It is also a source that can go on being used without spoiling the air, the land or the "
      "climate for people in the future.",
     ], "Up to 3 marks. 1 mark for 'it is replaced naturally'; 1 mark for 'as fast as it is "
        "used, so it does not run out'; and 1 mark for 'without harming the environment'. An "
        "answer that only says 'it is good energy' earns 0."),
     ("(c)", [
      "Any two: fewer trees are cut down, so the woodland around the village is saved; the "
      "goat waste is used instead of being left to rot; the gas burns without smoke, so the "
      "kitchen and the family's lungs stay cleaner; the slurry left over is a good manure for "
      "the farm; the family spends less on charcoal or firewood; the gas is free once the "
      "digester is built.",
     ], "1 mark each for any TWO correct reasons (2 marks). Credit 'the trees are saved', 'the "
        "waste is used', 'no smoke', 'free manure' and 'it costs less'. Do NOT credit a "
        "reason that just repeats 'it is renewable'.")],

 2: [("(a)", [
      "Any two: it is made from trees, and trees take many years to grow back; making it "
      "destroys the forest around the village; the wood is being used faster than it can be "
      "replaced; burning it gives out smoke and carbon dioxide.",
     ], "1 mark each for any TWO correct reasons (2 marks). The reason must be about the "
        "SOURCE running out or being used up, not merely that it is dirty or expensive."),
     ("(b)", [
      "Any three: the sun, using a solar cooker or solar panels; biogas from the goat pen and "
      "the kitchen waste; LPG; an improved cookstove, which is not a source but cuts the wood "
      "used very sharply; wind or water power if the village has them.",
     ], "1 mark each for any THREE correct alternatives (3 marks). Credit the improved "
        "cookstove only if the pupil is clear that it reduces the wood used rather than "
        "replacing the source. Do NOT accept firewood or charcoal, which is what they are "
        "moving away from."),
     ("(c)", [
      "Accept any one real difficulty, explained. The digester or the cooker costs money to "
      "buy or build, and the family may not have it. A biogas digester needs dung and water "
      "every day, and a family with no animals has none. A solar cooker works only when the "
      "sun is out, so it cannot cook the evening meal or work in the rainy season. LPG "
      "cylinders must be refilled, and the dealer may be far away. Nobody in the family may "
      "know how to look after the new equipment.",
     ], "Up to 3 marks. 1 mark for naming a real difficulty; 1 mark for explaining why it is a "
        "problem for THIS family; and 1 mark for a difficulty that shows real thought, such as "
        "the season, the distance to a supplier, or the daily work of feeding a digester. Cap "
        "at 1 if the difficulty is vague or would apply to anything at all.")],

 3: [("(a)", [
      "Any two: carbon dioxide, methane, nitrous oxide, water vapour.",
     ], "1 mark each for any TWO correct gases (2 marks). Do NOT accept oxygen or nitrogen, "
        "which make up most of the air but do not trap heat in this way."),
     ("(b)", [
      "Heat from the sun reaches the earth and warms the ground. The warm ground gives the "
      "heat back out again, as infrared radiation.",
      "Greenhouse gases in the air let the sun's heat pass down but they absorb much of the "
      "heat going back up, and they send some of it back towards the ground instead of "
      "letting it escape into space.",
      "So the heat is held near the surface, and the air near the ground stays warmer than it "
      "would otherwise be.",
     ], "Up to 4 marks. 1 mark for heat from the sun reaching the earth; 1 mark for the earth "
        "giving heat back out; 1 mark for the gases absorbing that heat; and 1 mark for the "
        "heat being sent back down or trapped near the surface. An answer that only says "
        "'they trap heat' earns 1."),
     ("(c)", [
      "HELPFUL: without any greenhouse gases the earth would be far too cold for living "
      "things, so the natural greenhouse effect keeps the planet warm enough for us to live "
      "on.",
      "HARMFUL: people are now adding far more of these gases - by burning fuel, cutting down "
      "the forest and keeping cattle - so too much heat is being trapped and the earth is "
      "warming too fast.",
      "That extra warming brings floods at the coast, unreliable rain, crop failure and "
      "hunger, so it is the EXTRA greenhouse effect that harms us, not the effect itself.",
     ], "Up to 3 marks. 1 mark for the helpful part - the earth would be too cold without it; "
        "1 mark for the harmful part - extra gas traps too much heat; and 1 mark for a "
        "consequence such as flooding, unreliable rain or crop failure. A pupil who says only "
        "that the greenhouse effect is bad earns at most 1.")],

 4: [("(i)", ["Carbon dioxide."],
      "2 marks for carbon dioxide. 1 mark if the name is misspelled in a way that could be "
        "another word. Do NOT accept 'smoke' or 'carbon monoxide'."),
     ("(ii)", ["Cutting down and burning the forest.", "Also accept bush burning, or "
               "clearing land for farming by burning."],
      "2 marks for cutting down and burning the forest or bush burning. 1 mark for 'cutting "
        "down trees' alone, since it is the burning that releases the stored carbon quickly. "
        "Do NOT accept 'planting trees', which does the opposite."),
     ("(iii)", ["Methane."],
      "2 marks for methane. 1 mark if the name is misspelled in a way that could be another "
        "word. Do NOT accept carbon dioxide here - the clue in the table is rotting waste and "
        "cattle, which give out methane."),
     ("(iv)", ["Walk, ride a bicycle, use a tro-tro, or share transport instead of driving "
               "alone.", "Also accept: use the generator less, keep the engine serviced, or "
               "switch to solar power instead of a generator."],
      "Up to 2 marks. 1 mark for a sensible way of burning less petrol; the second mark for a "
        "reason or a second example. Do NOT accept 'stop using cars altogether', which is not "
        "a practical answer for most people.")],

 5: [("(a)", [
      "Any three: fit solar panels on the roof; use a solar water heater; cook with an improved "
      "cookstove or LPG instead of firewood; install a biogas digester for the dining-hall "
      "waste; use LED bulbs instead of filament bulbs; use a wind pump to draw water; switch "
      "off lights, fans and computers when they are not needed; insulate the roof; plant trees "
      "round the compound for shade.",
     ], "1 mark each for any THREE correct choices (3 marks). Do NOT accept 'use electricity' "
        "on its own - the point is where the energy comes from. Do NOT accept the same choice "
        "written twice in different words."),
     ("(b)", [
      "Accept any two correctly explained. Solar panels: materials in the panel take in light "
      "energy from the sun and change it straight into electrical energy, with nothing burnt "
      "and no smoke. Improved cookstove: a wall round the fire keeps the heat in and sends it "
      "up to the pot, and the controlled air lets the wood burn more completely, so less wood "
      "boils the same pot. LED bulb: it gives out light without first getting hot, so far less "
      "of the electricity is wasted as heat. Biogas digester: bacteria rot the waste without "
      "air and give off methane, which burns as a fuel.",
     ], "Up to 4 marks: 2 marks for each of the two explanations. For each, 1 mark for the "
        "science and 1 mark for saying why it saves energy or helps the environment. A "
        "description with no scientific idea earns only 1."),
     ("(c)", [
      "Accept any sensible check, for example: read the electricity meter before and after and "
      "compare the bills; count how many bags of firewood the kitchen buys each term and "
      "compare with last term; keep a daily record of how long the lights are on; check that "
      "the LED bulbs are still working after a term.",
     ], "Up to 2 marks. 1 mark for a check that MEASURES something real, and 1 mark for "
        "comparing it with what happened before - the comparison is what shows a saving. A "
        "pupil who says only 'we will see if it works' earns 0.")],

 6: [("(a)", [
      "A solar dryer is a closed box or cabinet, often with a clear cover, that lets the sun's "
      "heat in and keeps it there, so the air inside gets hotter than the air outside and the "
      "water in the fish evaporates faster.",
      "Because the fish is inside a covered box, it is protected from dust, flies and sudden "
      "rain, so much less of it is spoiled.",
      "The fish dries evenly and more quickly, keeps its quality, and so fetches a better "
      "price at the market.",
     ], "Up to 4 marks. 1 mark for the sun's heat being trapped or the air inside getting "
        "hotter; 1 mark for the water evaporating from the fish; 1 mark for protection from "
        "dust, flies and rain; and 1 mark for the result - better fish and a better price. "
        "Cap at 2 if the pupil only says 'it dries the fish faster'."),
     ("(b)", [
      "The whole community benefits, not only she does. Less fish is spoiled, so more food "
      "reaches the market and families nearby have fish to buy; good dried fish travels "
      "further, so it can be sold in other towns and brings money into the town; because the "
      "fish keeps, it can be eaten in the lean season when the catch is poor; and less spoiled "
      "fish is thrown away, so there is less waste and fewer flies breeding near the market.",
      "A strong answer may add that she herself gains the most directly, since her income "
      "rises, but that the benefit spreads well beyond her.",
     ], "Up to 4 marks. 1 mark for taking a clear position; 1 mark for a benefit to people "
        "other than the fishmonger; 1 mark for a second such benefit, such as food in the lean "
        "season or money coming into the town; and 1 mark for an extra point such as less "
        "waste or fewer flies. A pupil who says only she benefits can earn 1 mark for the "
        "position but no more, unless the argument is genuinely developed.")],

 7: [("(a)", [
      "Any three: what the clinic actually needs the energy for - light at night, a "
      "refrigerator for vaccines, or power for a small machine; how much sunshine, wind or "
      "flowing water the village has; what materials can be found nearby and what must be "
      "bought; how much money is available; whether anyone in the village can repair the "
      "equipment; where the project would be safe from damage and theft.",
     ], "1 mark each for any THREE sensible things to find out (3 marks). Credit questions "
        "about need, about what the site can supply, about materials and money, and about who "
        "will repair it. Do NOT credit 'how long it will take to build', which is not what "
        "the question asks."),
     ("(b)", [
      "Accept any sensible project. For example, a solar system for the clinic: mount solar "
      "panels on the clinic roof facing the sun where no tree shades them; fix a frame, a "
      "charge controller, a battery and wiring; connect LED lamps inside and a small "
      "refrigerator for vaccines; test each lamp and the refrigerator; label the switches.",
      "MATERIALS: solar panels, a battery, a charge controller, cable, switches, LED lamps, "
      "a frame and fixings - and for a biogas or wind project, the equivalent list.",
      "STEPS: survey the roof, buy or collect the parts, fit the frame, mount the panels, wire "
      "the controller and battery, run the cable inside, fit the lamps, test, and hand over "
      "with instructions.",
     ], "Up to 3 marks. 1 mark for a project that would genuinely work for a clinic with no "
        "grid supply; 1 mark for a sensible list of materials; and 1 mark for the steps in a "
        "sensible order. Cap at 1 if the project is named but the materials and steps are "
        "missing. 0 marks for a project that burns charcoal, firewood or diesel, since the "
        "question is about sustaining energy locally without harming the environment."),
     ("(c)", [
      "KNOWING IT WORKS: check that the clinic has light at night and that the refrigerator "
      "keeps vaccines cold; read a meter or keep a daily record for a few weeks; compare the "
      "clinic's bills or its kerosene use with what it was before.",
      "KEEPING IT RUNNING: name a person at the clinic and one pupil or teacher to check it; "
      "clean the panels; keep a few spare parts and the number of someone who can repair it; "
      "fix a card of instructions near the switch; show the next class how it works so the "
      "knowledge does not leave with the pupils who built it.",
     ], "Up to 3 marks. 1 mark for how they will know it works - a real check, not just 'we "
        "will see'; 1 mark for maintenance - a named person and what they will do; and 1 mark "
        "for spares, repairs, written instructions or passing the knowledge on. An answer that "
        "says only 'we will test it' earns 0.")],
}


# ----------------------------------------------------------------- helpers
def topic_totals():
    m = {k: 0 for k in TOPIC}; it = {k: 0 for k in TOPIC}
    for q in MCQ:
        m[q[3]] += 1; it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk; it[key] += 1
    return m, it


def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}; b = {k: 0 for k in order}
    for q in MCQ: a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: b[cog] += mk
    return order, a, b


def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ: d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: d[diff] += mk
    return d
