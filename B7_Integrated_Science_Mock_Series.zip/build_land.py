# -*- coding: utf-8 -*-
"""Basic 7 Integrated Science mock - Strand 5 Sub-strand 5: UNDERSTANDING THE ENVIRONMENT.
Covers topics 20.1 to 20.5 (landforms in Ghana; plants and animals found in different
landforms; how animals adapt; how plants survive; and the associations of mutualism,
parasitism and commensalism). 100 marks.
Indicators sourced from the official NaCCA Science CCP curriculum (B7/JHS1-B9/JHS3, Sept 2020),
Strand 5: Humans and the Environment, Sub-strand 5: Understanding the Environment, printed
pages 49-50. Content standard: B7/JHS1.5.5.1, with TWO indicators, B7/JHS1.5.5.1.1 (topics
20.1-20.4) and B7/JHS1.5.5.1.2 (topic 20.5). One content standard, so this is a single paper
and not split."""

SCHOOL = "[SCHOOL NAME]"
SUBJECT = "INTEGRATED SCIENCE (SCIENCE)"
EXAM = "END-OF-TERM MOCK EXAMINATION"
CLASS = "Basic 7 (JHS 1)"
TIME = "2 hours (Suggested: Section A - 40 min; Section B - 80 min)"
MARKS = "100"
YEAR = "2025/2026 Academic Year"

STRAND = "Humans and the Environment"
SUBSTRAND = "Understanding the Environment"

TOPIC = {
    "20.1": "20.1 Landforms in Ghana: Plateau, Plain, Mountain and Valley",
    "20.2": "20.2 Plants and Animals Found in Different Landforms",
    "20.3": "20.3 How Animals Adapt to Different Landforms",
    "20.4": "20.4 How Plants Survive in Different Landforms",
    "20.5": "20.5 Associations Among Plants and Animals",
}

CS = "B7/JHS1.5.5.1"
CS_BY_TOPIC = {k: "B7/JHS1.5.5.1" for k in ["20.1", "20.2", "20.3", "20.4", "20.5"]}
CS_TEXT = ("Demonstrate understanding of different plants and animals found in different land "
           "forms and how they survive (with emphasis land forms in Ghana)")

IND = {
    "20.1": "B7/JHS1.5.5.1.1 (Ex. 1)",
    "20.2": "B7/JHS1.5.5.1.1 (Ex. 1, 4)",
    "20.3": "B7/JHS1.5.5.1.1 (Ex. 2)",
    "20.4": "B7/JHS1.5.5.1.1 (Ex. 3)",
    "20.5": "B7/JHS1.5.5.1.2 (Ex. 1, 2)",
}
IND_TEXT = {
    "20.1": "List and describe the different types of plants and animals that live in different "
            "land forms such as plateau plain, mountain valley and others (with emphasis on "
            "land forms in Ghana). Ex. 1: Identify different types of plants and animals found "
            "in different landforms (plateau plain, mountain valley and others).",
    "20.2": "List and describe the different types of plants and animals that live in different "
            "land forms such as plateau plain, mountain valley and others (with emphasis on "
            "land forms in Ghana). Ex. 1, 4: Identify different types of plants and animals "
            "found in different landforms; make an album of different types of plants and "
            "animals that live in different landforms.",
    "20.3": "List and describe the different types of plants and animals that live in different "
            "land forms such as plateau plain, mountain valley and others (with emphasis on "
            "land forms in Ghana). Ex. 2: Describe the characteristics that enable different "
            "types of animals to live in different landforms (plateau plain, mountain valley "
            "and others).",
    "20.4": "List and describe the different types of plants and animals that live in different "
            "land forms such as plateau plain, mountain valley and others (with emphasis on "
            "land forms in Ghana). Ex. 3: Describe the characteristics that enable different "
            "types of plants to survive in different landforms (plateau plain, mountain valley "
            "and others).",
    "20.5": "Explain the nature of associations that exist among plants and animals in "
            "different landforms and their mechanisms for survival. Ex. 1, 2: Describe the "
            "nature of associations such as mutualism, parasitism, commensalism among plants "
            "and animals and explain the effects on their habitats; carry out research about "
            "the different ways that different plants and animals survive in the landforms in "
            "which they are found.",
}
CC = {"20.1": "CP, DL, CC, CI", "20.2": "CP, DL, CC, CI", "20.3": "CP, DL, CC, CI",
      "20.4": "CP, DL, CC, CI", "20.5": "CP, DL, CC, CI"}

# ---------------------------------------------------------------- SECTION A
# (question, [A,B,C,D], answer, topic, cognitive, difficulty)
MCQ = [
 ("A plain is different from a plateau mainly because the plain is",
  ["low and flat, while the plateau is raised high above the land around it", "found only in the north of Ghana", "smaller than a hill", "always covered in water"],
  "A", "20.1", "Understand", "Easy"),
 ("Which Ghanaian landform is best for growing maize, millet and rice on a large scale?",
  ["a steep mountain side", "a narrow valley floor", "the edge of an escarpment", "a broad, level plain"],
  "D", "20.1", "Apply", "Moderate"),
 ("Mount Afadjato, the highest point in Ghana, is found in",
  ["the Greater Accra Region", "the Volta Region", "the Northern Region", "the Western Region"],
  "B", "20.1", "Remember", "Easy"),
 ("A town built on a plateau is usually cooler than a town on the plain below it. The best explanation is that",
  ["the air gets cooler the higher you go above the sea", "there are more trees on a plateau", "the wind cannot reach a plateau", "the sun does not shine on a plateau"],
  "A", "20.1", "Understand", "Moderate"),
 ("Waterfalls such as Wli and Boti are found where the land drops suddenly. That steep drop is called",
  ["a valley floor", "a delta", "an escarpment", "a plain"],
  "C", "20.1", "Understand", "Easy"    ),
 ("Which of these is NOT a landform?",
  ["a mountain", "a valley", "a plateau", "a river"],
  "D", "20.1", "Understand", "Easy"),
 ("A valley usually has more plant life than the dry land around it because",
  ["the sun is hotter there", "no animals go there", "the soil there is made only of rock", "water runs down into it and collects in the soil"],
  "D", "20.1", "Understand", "Moderate"),
 ("A pupil is asked to pick out a landform that is broad, nearly level and lies low. She should pick",
  ["a plateau", "a mountain", "a plain", "an escarpment"],
  "C", "20.1", "Understand", "Easy"),
 ("A pupil visits a wooded plateau in the Ashanti Region. Which animal is she most likely to see there?",
  ["a camel", "a monkey", "a crocodile", "a whale"],
  "B", "20.2", "Understand", "Easy"),
 ("Which of these trees is most likely to be found on the dry savanna plains of northern Ghana?",
  ["the baobab", "the oil palm", "the raphia palm", "the mahogany"],
  "A", "20.2", "Understand", "Easy"),
 ("A pupil finds frogs, dragonflies and freshwater crabs in large numbers in one place. That place is most likely",
  ["the flat top of a plateau", "a valley with water in it", "a bare mountain peak", "an open, dry plain"],
  "B", "20.2", "Apply", "Moderate"),
 ("A class is sorting living things for an album. Which one belongs on the page for the dry, open plain?",
  ["the mango tree", "the freshwater crab", "the water lily", "the grasscutter"],
  "D", "20.2", "Understand", "Easy"),
 ("Which of these would you NOT expect to find on a dry, open plain?",
  ["a tadpole", "a grasshopper", "a guinea fowl", "a ground squirrel"],
  "A", "20.2", "Understand", "Easy"    ),
 ("A pupil digs up a small plant with soft, broad green leaves. It wilted as soon as she took it home. The plant most likely came from",
  ["a damp, shady valley", "a sandy beach", "an open, dry plain", "a windy mountain top"],
  "A", "20.2", "Apply", "Moderate"),
 ("A bird with long legs and a long beak, which wades in shallow water and catches fish, is most likely to be seen",
  ["on the flat top of a plateau", "in a valley with a river", "on a dry plain", "on a mountain peak"],
  "B", "20.2", "Apply", "Moderate"),
 ("The best reason why different landforms have different kinds of plants is that",
  ["the plants choose where they want to grow", "people plant different crops in different places", "each landform has its own soil, water supply and temperature", "the wind carries only one kind of seed to each place"],
  "C", "20.2", "Understand", "Moderate"),
 ("A farmer moves his goats from the plains to a steep, rocky hillside. The goats will need",
  ["hard hooves that grip the rock", "webbed feet for swimming", "bright colours to warn enemies", "a very long tail for balance"],
  "A", "20.3", "Apply", "Moderate"),
 ("The large ears of an elephant help it to live on the hot plains because they",
  ["store water for the dry season", "give off heat to the air and so cool the animal down", "keep the sun off its back", "help it to hear enemies from far away only"],
  "B", "20.3", "Understand", "Moderate"),
 ("A small animal living on an open plain with little cover escapes the heat and its enemies by",
  ["living in a burrow under the ground", "climbing to the top of the tallest tree", "swimming across the river every day", "growing a thicker coat each year"],
  "A", "20.3", "Understand", "Easy"),
 ("In the dry season the pools on a plain dry up. Animals that need water usually",
  ["change into fish", "stop drinking for the rest of their lives", "wait for the rain without moving at all", "move to another place where there is still water"],
  "D", "20.3", "Apply", "Moderate"),
 ("A snake that lives on a dry plain is the same colour as the dry grass. This helps it because it",
  ["can go without food for a whole year", "can run faster than the other snakes", "needs less water than other snakes", "is hard for both its enemies and its prey to see"],
  "D", "20.3", "Analyse", "Challenging"),
 ("A goat that lives on a dry, rocky hillside has hard hooves that grip the rock. This is an example of",
  ["an association", "a landform", "a habitat", "an adaptation"],
  "D", "20.3", "Understand", "Easy"),
 ("Fish and other small water animals in a stream that dries up in the dry season must be able to",
  ["travel to the sea and back each year", "survive in the mud until the rains return", "breathe without any water at all", "climb trees to find water"],
  "B", "20.3", "Understand", "Easy"    ),
 ("Which of these animals would be best suited to live high on a cool, wet mountain slope?",
  ["an animal with a thin coat and long legs for running", "an animal with webbed feet and a flat tail", "an animal that stores water in its hump", "an animal with a thick coat and strong legs for climbing rock"],
  "D", "20.3", "Apply", "Moderate"),
 ("Many trees on the dry plains lose their leaves in the dry season. This helps them because",
  ["the leaves can be used again next year", "no water is lost from the leaves while there is none in the soil", "animals cannot find the tree", "the tree can grow much taller"],
  "B", "20.4", "Understand", "Easy"    ),
 ("The leaves of a plant that grows on a hot, dry plain often have a shiny, waxy surface. This surface helps by",
  ["keeping the leaf warm at night", "letting in more sunlight for the plant", "stopping water from escaping out of the leaf", "making the leaf taste bad to animals"],
  "C", "20.4", "Understand", "Easy"    ),
 ("A plant on a dry plain survives right through the dry season because it sends a very long root deep down. This root lets the plant",
  ["reach water far below the surface", "hold on against the wind", "catch insects for food", "make many more flowers"],
  "A", "20.4", "Apply", "Moderate"),
 ("Some plants on the plains die back to a bulb or a swollen stem underground in the dry season and grow again when the rains come. This is a way of",
  ["spreading to a new landform", "surviving until there is water again", "escaping from animals that eat them", "making new plants from seeds"],
  "B", "20.4", "Understand", "Easy"    ),
 ("Plants on an exposed mountain top are often small and grow close together in a low cushion. This shape helps them to",
  ["drop their seeds further away", "stop animals from stepping on them", "keep out of the wind and hold on to warmth", "catch more sunlight than taller plants"],
  "C", "20.4", "Understand", "Moderate"),
 ("Trees on the savanna plains often have thick, corky bark. The main advantage of this bark is that it",
  ["protects the tree from bush fires", "keeps the roots cool", "makes the tree grow faster", "stores food for the dry season"],
  "A", "20.4", "Understand", "Easy"    ),
 ("Plants in a valley often have broad, thin leaves, while plants on a dry plateau have small, tough ones. The best explanation is that",
  ["the soil in the valley has no food in it", "there is more wind in the valley", "water is plentiful in the valley, so those plants do not need to save it", "the valley plants are older than the plateau plants"],
  "C", "20.4", "Analyse", "Challenging"),
 ("The seed of a plant on a dry plain does not start to grow until the first heavy rain. This is helpful because",
  ["the seed needs the rain to make its hard case soft", "the young plant will not start to grow when there is too little water to keep it alive", "the rain washes the seed deeper into the soil", "the seed can wait for a bird to carry it away"],
  "B", "20.4", "Analyse", "Challenging"),
 ("Bees visit flowers to take nectar, and in doing so they carry pollen from one flower to another. This is an example of",
  ["competition", "commensalism", "mutualism", "parasitism"],
  "C", "20.5", "Understand", "Moderate"),
 ("A tick attaches itself to a goat and feeds on its blood. In this association the goat is the",
  ["predator", "parasite", "competitor", "host"],
  "D", "20.5", "Remember", "Easy"),
 ("A small bird builds its nest in a tree. The bird gets a safe place and the tree is neither helped nor harmed. This is",
  ["commensalism", "parasitism", "mutualism", "predation"],
  "A", "20.5", "Understand", "Moderate"),
 ("A fig seed grows high on the branch of another tree and sends roots down to the ground. The fig grows well and the other tree is slowly killed. This is",
  ["commensalism", "competition, because both plants need sunlight", "parasitism", "mutualism"],
  "C", "20.5", "Apply", "Moderate"),
 ("The main difference between parasitism and commensalism is that in parasitism",
  ["both living things are harmed", "one living thing is harmed, but in commensalism it is not affected", "nothing happens to either of them", "both living things benefit"],
  "B", "20.5", "Understand", "Moderate"),
 ("A bird eats the ticks off the back of a cow. The bird gets food and the cow is freed of the ticks. This is",
  ["commensalism", "competition", "parasitism", "mutualism"],
  "D", "20.5", "Understand", "Easy"    ),
 ("Which association is most likely to reduce the number of living things in a habitat?",
  ["mutualism, because both living things grow too fast", "none of them, because associations never affect numbers", "parasitism, because the parasites weaken the living things they feed on", "commensalism, because one of them takes all the food"],
  "C", "20.5", "Analyse", "Challenging"),
 ("A pupil says that whenever two living things are found together, both of them must be benefiting. The best reply is that",
  ["the pupil is right, but only for plants and not for animals", "no association can ever help either of them", "only some associations help both; in others one is harmed, or one gains while the other is not affected", "the pupil is right, because living things never harm each other"],
  "C", "20.5", "Evaluate", "Challenging"),
]

# ---------------------------------------------------------------- SECTION B
LANDFORM_HEADERS = ["Landform", "Plants Found There", "Animals Found There"]
LANDFORM_ROWS = [
 ["Dry savanna plain", "(i)", "grasscutter, guinea fowl, antelope and ground squirrel"],
 ["Wooded plateau", "oil palm, cocoa, wattle and forest shrubs", "(ii)"],
 ["Mountain", "(iii)", "baboons, rock hyrax, mountain birds and lizards"],
 ["Valley", "bamboo, ferns, algae and water-loving plants", "(iv)"],
]

SECTION_B = [
 dict(
   num=1, total=9, topic="20.1",
   stem="Ghana has several different kinds of landform. Each one has its own shape, its own "
        "soil and its own weather.",
   parts=[
     ("(a)", "Name FOUR different landforms found in Ghana.", 4, "Remember", "20.1", "Easy"),
     ("(b)", "State THREE ways in which a plateau is different from a plain.",
      3, "Understand", "20.1", "Moderate"),
     ("(c)", "Give ONE named example of a mountain in Ghana and ONE named example of a plain, "
      "and say where each one is found.", 2, "Understand", "20.1", "Easy"    ),
   ]),
 dict(
   num=2, total=8, topic="20.2", table="landform",
   stem="The table below shows some of the living things found in four landforms in Ghana. "
        "Complete it by filling in the spaces numbered (i) to (iv).",
   parts=[
     ("(i)", "One type of plant found on a dry savanna plain.", 2, "Understand", "20.2", "Easy"),
     ("(ii)", "One type of animal found on a wooded plateau.", 2, "Understand", "20.2", "Easy"),
     ("(iii)", "One type of plant found on a mountain.", 2, "Understand", "20.2", "Moderate"),
     ("(iv)", "One type of animal found in a valley.", 2, "Understand", "20.2", "Moderate"),
   ]),
 dict(
   num=3, total=9, topic="20.3",
   stem="Animals that live on the open plains look and behave very differently from animals "
        "that live high on a mountain or down in a valley.",
   parts=[
     ("(a)", "Explain what is meant by adaptation, and give ONE example.",
      3, "Understand", "20.3", "Moderate"),
     ("(b)", "Describe TWO characteristics that enable animals to live on open plains, and "
      "explain how each one helps.", 4, "Understand", "20.3", "Moderate"),
     ("(c)", "Give ONE way in which an animal that lives on a mountain would differ from one "
      "that lives on a plain, and explain the reason.", 2, "Apply", "20.3", "Challenging"),
   ]),
 dict(
   num=4, total=8, topic="20.4",
   stem="A plant cannot move to a better place when conditions turn against it, so each one "
        "must be built to survive where it grows.",
   parts=[
     ("(a)", "Explain FOUR different ways in which a plant on a dry plain is able to survive "
      "the long dry season.", 4, "Understand", "20.4", "Moderate"),
     ("(b)", "Explain TWO reasons why the plants in a valley are usually larger, with broader "
      "leaves, than the plants on a dry plateau.", 4, "Apply", "20.4", "Challenging"),
   ]),
 dict(
   num=5, total=9, topic="20.5",
   stem="Living things in the same habitat do not simply live side by side. They live in "
        "associations with one another.",
   parts=[
     ("(a)", "Explain what is meant by commensalism, and give ONE example.",
      3, "Understand", "20.5", "Moderate"),
     ("(b)", "For EACH of mutualism and parasitism, give ONE example and say which living "
      "thing benefits and which is harmed.", 4, "Understand", "20.5", "Moderate"),
     ("(c)", "Which of the three associations is most likely to reduce the number of living "
      "things in a habitat? Explain your answer.", 2, "Analyse", "20.5", "Challenging"),
   ]),
 dict(
   num=6, total=8, topic="20.5",
   stem="Cattle graze on a plain near a village. Cattle egrets walk among the cattle and eat "
        "the insects the cattle disturb. Ticks attach themselves to the cattle and feed on "
        "their blood. A fig has grown high on another tree and is slowly killing it.",
   parts=[
     ("(a)", "Name the association shown by each of these: (i) the egrets and the cattle, "
      "(ii) the ticks and the cattle, (iii) the fig and the other tree.",
      3, "Apply", "20.5", "Moderate"),
     ("(b)", "Evaluate which of these associations is most harmful to the farmer, and say why.",
      3, "Evaluate", "20.5", "Challenging"),
     ("(c)", "Suggest TWO things the farmer could do to reduce the harm, and say how each one "
      "would work.", 2, "Apply", "20.5", "Moderate"),
   ]),
 dict(
   num=7, total=9, topic="20.2",
   stem="Your class has been asked to make an album of the different plants and animals that "
        "live in the landforms of Ghana.",
   parts=[
     ("(a)", "State TWO things the album should show for each landform.",
      2, "Understand", "20.2", "Easy"),
     ("(b)", "Design the album. Say how many pages it will have, how you will organise it, "
      "and what you will put on each page.", 4, "Create", "20.2", "Challenging"),
     ("(c)", "Describe how you would collect the information and the pictures, and how you "
      "would check that they are correct.", 3, "Apply", "20.2", "Moderate"),
   ]),
]

# ------------------------------------------------------------ MARKING SCHEME
MARKING = {
 1: [("(a)", [
      "Any four: plateau, plain, mountain, valley, hill, escarpment, ridge, basin, coastal "
      "plain, savanna plain.",
     ], "1 mark each for any FOUR different landforms (4 marks). Do NOT accept things that "
        "are not landforms, such as 'forest', 'river', 'sea', 'farm' or 'road'. Do NOT accept "
        "the same landform written twice."),
     ("(b)", [
      "A plateau stands high above the land around it and is flat or gently undulating on "
      "top, while a plain lies low and is nearly level.",
      "A plateau usually ends in a steep side or an escarpment, while a plain has no steep "
      "edge.",
      "A plateau is usually cooler than a plain, because the air gets cooler the higher you "
      "go above the sea.",
      "A plateau is often harder to reach and harder to farm on machinery, while a plain is "
      "easy to build and farm on.",
     ], "1 mark each for any THREE correct differences (3 marks). Accept 'a plateau is high "
        "and a plain is low' once only - the other two must be different points. Do NOT "
        "accept statements that are true of both, such as 'both have soil'."),
     ("(c)", [
      "A mountain: Mount Afadjato, in the Volta Region. Also accept Mount Gemi or the "
      "Akwapim-Togo ranges.",
      "A plain: the Accra Plains, in the Greater Accra Region. Also accept the Keta sand "
      "plains or the savanna plains of the Northern Region.",
     ], "1 mark for a correct NAMED mountain in Ghana and 1 mark for a correct NAMED plain "
        "(2 marks). A pupil who writes 'a mountain in the Volta Region' without naming it "
        "earns 0 for that part. Do NOT accept a landform outside Ghana.")],
 2: [("(i)", [
      "Any one plant of the dry savanna plains: baobab, shea, dawadawa, neem, acacia, kapok, "
      "or any of the savanna grasses.",
     ], "2 marks for a correct plant of the dry savanna plains. Accept any named savanna "
        "tree, shrub or grass. Do NOT accept raphia palm, oil palm, cocoa, banana or plantain "
        "- these need plenty of water. Do NOT accept a plant that is not found in Ghana."),
     ("(ii)", [
      "Any one animal of a wooded plateau: monkey, duiker, bushbuck, forest bird, squirrel, "
      "snake.",
     ], "2 marks for a correct animal of a wooded plateau. Accept any named animal that lives "
        "in forest or thick bush. Do NOT accept animals of open water such as fish, crab or "
        "crocodile, or of the sea such as whale."),
     ("(iii)", [
      "Any one plant of a mountain: moss, fern, lichen, or a small hard-leaved mountain "
      "shrub.",
     ], "2 marks for a correct plant of a cool mountain slope. Accept moss, fern, lichen or a "
        "named mountain shrub. Do NOT accept baobab, oil palm, raphia palm or any large "
        "lowland tree."),
     ("(iv)", [
      "Any one animal of a valley: frog, toad, crocodile, fish, freshwater crab, heron, "
      "kingfisher, dragonfly.",
     ], "2 marks for a correct animal of a valley. Accept any named animal that lives in or "
        "near water. Do NOT accept animals of dry open country, such as camel, or of the "
        "sea, such as whale.")],
 3: [("(a)", [
      "Adaptation is any feature or behaviour of a living thing that helps it to survive in "
      "the place where it lives.",
      "For example, a grasscutter has strong front teeth for cutting tough roots, and it "
      "lives in a burrow to escape the heat of the day.",
     ], "Up to 3 marks: up to 2 for a correct definition that says the feature or behaviour "
        "HELPS the living thing to SURVIVE WHERE IT LIVES, and 1 for a correct example. A "
        "definition that says only 'it is when an animal changes to fit in' earns 1 at most, "
        "because an adaptation is a feature the animal already has, not one it chooses."),
     ("(b)", [
      "Long legs, so that the animal can run fast across open ground where there is nowhere "
      "to hide.",
      "A coat the same colour as the dry grass, so that enemies cannot see it easily.",
      "Living in a burrow, which is cooler than the open ground and hides the animal from "
      "enemies.",
      "Large ears or thin skin, which let the body give off heat and keep cool.",
      "The ability to go for a long time without drinking.",
     ], "Up to 4 marks: up to 2 for each of TWO characteristics, 1 for naming it and 1 for "
        "explaining HOW it helps. Give 0 for a characteristic that is named but not "
        "explained. Do NOT accept a bare list of animals."),
     ("(c)", [
      "An animal on a mountain would need thicker covering against the cold and feet that "
      "grip rock, while an animal on a plain needs to run fast and to keep cool.",
      "The reason is that the mountain is colder, wetter and steeper, while the plain is "
      "hot, dry and open.",
     ], "Up to 2 marks: 1 for a sensible difference and 1 for a correct reason that refers to "
        "the conditions in each landform. A pupil who names a difference but cannot say why "
        "it matters earns 1. Do NOT accept 'they are different because they live in "
        "different places'.")],
 4: [("(a)", [
      "It may shed its leaves in the dry season, so that no water is lost from them while "
      "there is none in the soil.",
      "It may have small, tough or waxy leaves, which lose water very slowly.",
      "It may store water in a swollen trunk, a thick stem or an underground bulb.",
      "It may send a very long root down to reach water far below the surface.",
      "It may die back to a bulb or a swollen root underground and grow again when the rains "
      "come.",
      "Its seeds may lie in the soil and wait until there has been enough rain.",
     ], "1 mark each for any FOUR different ways (4 marks). Give no more than 1 mark in total "
        "for ways that are only named and not explained. Do NOT accept 'it stores water' with "
        "nothing said about where, and do NOT accept the same way written twice in different "
        "words."),
     ("(b)", [
      "Water is plentiful in the valley and scarce on the plateau, so valley plants can "
      "afford broad, thin leaves, while a plant with broad leaves on a dry plateau would "
      "lose water faster than its roots could replace it.",
      "The valley is sheltered and its soil is usually deeper and richer, so plants there can "
      "grow larger, while the plateau is open to wind and strong sun.",
     ], "Up to 4 marks: up to 2 for each of TWO reasons, 1 for the difference in conditions "
        "and 1 for explaining how that produces the difference in the plants. A pupil who "
        "says only 'the valley has more water' earns 1. Do NOT accept 'valley plants are just "
        "bigger'.")],
 5: [("(a)", [
      "Commensalism is an association between two living things in which one benefits and the "
      "other is neither helped nor harmed.",
      "For example, a small bird builds its nest in a tree. The bird gets a safe place and "
      "the tree is not affected.",
     ], "Up to 3 marks: up to 2 for a correct definition that says ONE BENEFITS and the OTHER "
        "IS NOT AFFECTED, and 1 for a correct example. A definition that says 'both benefit' "
        "earns 0, because that is mutualism. Do NOT accept an example in which the second "
        "living thing is harmed."),
     ("(b)", [
      "Mutualism - for example, bees and flowering plants. The bee gets nectar for food and "
      "the plant gets its pollen carried to another flower so that it can make seeds. Both "
      "benefit.",
      "Parasitism - for example, a tick on a goat, or mistletoe on a tree. The tick gets "
      "blood and the goat loses blood and may grow weak or fall sick, so the parasite "
      "benefits and the host is harmed.",
     ], "Up to 4 marks: up to 2 for each association, 1 for a correct named example and 1 for "
        "correctly saying who benefits and who is harmed. Give 0 for a correct example with "
        "no statement of the effect. Do NOT accept an example of commensalism under either "
        "heading."),
     ("(c)", [
      "Parasitism, because the parasite takes food or blood from its host, so the host grows "
      "slowly, becomes weak and may die before it can reproduce.",
      "Accept also: a heavy growth of mistletoe or a strangler fig can kill the trees, which "
      "then removes the shelter and the food that other living things depend on.",
     ], "Up to 2 marks: 1 for naming parasitism and 1 for explaining that the host is weakened "
        "or killed. A pupil who names parasitism with no reason earns 1. Accept commensalism "
        "or mutualism only if it is argued soundly, and then cap the answer at 1.")],
 6: [("(a)", [
      "(i) The egrets and the cattle - commensalism. The egrets get the insects the cattle "
      "disturb, and the cattle are not affected.",
      "(ii) The ticks and the cattle - parasitism. The ticks get blood and the cattle are "
      "harmed.",
      "(iii) The fig and the other tree - parasitism. The fig gets support and light, and "
      "the other tree is killed.",
     ], "1 mark each for the three correct associations (3 marks). Accept 'mutualism' for the "
        "egrets only if the pupil explains that the cattle are also freed of insects. Give 0 "
        "if the pupil names the right association but pairs it with the wrong living things."),
     ("(b)", [
      "The ticks are the most harmful, because they feed on the cattle's blood, make them "
      "weak and can give them disease, so the farmer loses milk, meat and work from the "
      "animals.",
      "Accept also the fig, if it is argued well: it kills a tree that gives shade, fruit or "
      "protection to the soil on the farm.",
     ], "Up to 3 marks: 1 for a clear choice, 1 for explaining the harm and 1 for saying what "
        "the farmer loses. A pupil who chooses but gives no reason earns 1 only. Do NOT "
        "accept 'all of them are equally harmful' unless it is argued in detail."),
     ("(c)", [
      "Spray or dip the cattle to kill the ticks, and do it again so that the eggs which "
      "hatch later are killed too.",
      "Clear the bushes where the ticks wait, or move the cattle to another pasture for a "
      "time to break the cycle.",
      "Keep the cattle in a clean, dry kraal at night and check them often for ticks.",
      "Cut down the fig before it kills the tree, and plant another tree in its place.",
     ], "Up to 2 marks: 1 mark each for any TWO sensible actions, each with what it does. "
        "Give no more than 1 mark for a bare list with no explanation. Do NOT accept 'kill "
        "the cattle'.")],
 7: [("(a)", [
      "The name of the landform and where in Ghana it is found, for example the Kwahu "
      "Plateau in the Eastern Region.",
      "Pictures or drawings of the plants and animals found there, each one named.",
      "A note on the conditions there - whether it is wet or dry, hot or cool.",
      "A note on any adaptation that helps a plant or an animal to survive there.",
     ], "1 mark each for any TWO sensible contents (2 marks). Do NOT accept contents that "
        "have nothing to do with landforms, such as 'a list of the class' or 'the date it "
        "was made'."),
     ("(b)", [
      "Accept any sensible design. For example: the album will have ten pages - a title "
      "page, two pages for each of the four landforms (plateau, plain, mountain and valley), "
      "and a page at the back comparing them. Each landform gets a left-hand page with a "
      "drawing of its shape and a short note on its soil, water and weather, and a "
      "right-hand page with pictures of three plants and three animals found there, each "
      "named underneath. A contents page at the front lists the four landforms. Every page "
      "is titled with the landform and the region of Ghana where it is found.",
     ], "Up to 4 marks: 1 for saying how many pages there will be or how the album is "
        "divided, 1 for what goes on each page, 1 for how it is organised or ordered, and 1 "
        "for naming the landforms it covers. Give no more than 2 for 'we will put pictures in "
        "it' with no structure. Do NOT accept an album that covers only one landform."),
     ("(c)", [
      "Find the information from the class textbook, the school library, the internet or the "
      "district agriculture office, and check each plant and animal against a second source "
      "or a person who knows, such as the science teacher or an elder who farms there.",
      "Draw the plants and animals from life during a field visit, or print pictures and "
      "check the name under each one before using it.",
      "Take the finished album to the science teacher to check, and correct anything that is "
      "wrong before making the final copy.",
     ], "Up to 3 marks: 1 for where or how the information is collected, 1 for HOW IT IS "
        "CHECKED and 1 for a second check or a named source or person. An answer that says "
        "only 'we will look on the internet' earns 1 at most, and 0 if nothing is said about "
        "checking.")],
}

# ----------------------------------------------------------------- helpers
def topic_totals():
    m = {k: 0 for k in TOPIC}; it = {k: 0 for k in TOPIC}
    for q in MCQ:
        m[q[3]] += 1; it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk; it[key] += 1
    return m, it


def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}; b = {k: 0 for k in order}
    for q in MCQ: a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: b[cog] += mk
    return order, a, b


def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ: d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: d[diff] += mk
    return d
