# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "/home/user")
from build_elec import *

from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT

doc = Document()
sec = doc.sections[0]
sec.left_margin = Inches(0.7); sec.right_margin = Inches(0.7)
sec.top_margin = Inches(0.7); sec.bottom_margin = Inches(0.6)

st = doc.styles["Normal"]; st.font.name = "Calibri"; st.font.size = Pt(11)


def set_font(run, size=11, bold=False, italic=False, mono=False, color=None):
    run.font.size = Pt(size); run.bold = bold; run.italic = italic
    run.font.name = "Consolas" if mono else "Calibri"
    if color: run.font.color.rgb = color
    return run


def para(text="", size=11, bold=False, italic=False, align=None, mono=False,
         space_before=0, space_after=4, color=None):
    p = doc.add_paragraph()
    if align == "c": p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    elif align == "j": p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p.paragraph_format.space_before = Pt(space_before)
    p.paragraph_format.space_after = Pt(space_after)
    if text: set_font(p.add_run(text), size, bold, italic, mono, color)
    return p


def rule():
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(6); p.paragraph_format.space_before = Pt(2)
    set_font(p.add_run("_" * 78), 9, color=RGBColor(0x99, 0x99, 0x99))


def add_table(headers, rows, widths=None, size=9, head_size=9):
    t = doc.add_table(rows=1, cols=len(headers)); t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, h in enumerate(headers):
        c = t.rows[0].cells[i]; c.text = ""
        p = c.paragraphs[0]; p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_font(p.add_run(str(h)), head_size, bold=True)
    for row in rows:
        cells = t.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = ""
            p = cells[i].paragraphs[0]; p.paragraph_format.space_after = Pt(1)
            set_font(p.add_run(str(v)), size)
    if widths:
        for r_ in t.rows:
            for i, w in enumerate(widths): r_.cells[i].width = Inches(w)
    return t


def draw_diagram(lines, caption):
    t = doc.add_table(rows=2, cols=1); t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = t.rows[0].cells[0]
    for k, line in enumerate(lines):
        p = cell.paragraphs[0] if k == 0 else cell.add_paragraph()
        p.paragraph_format.space_after = Pt(0); p.paragraph_format.space_before = Pt(0)
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_font(p.add_run(line), 10, mono=True)
    c2 = t.rows[1].cells[0].paragraphs[0]
    c2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_font(c2.add_run(caption), 9, italic=True)
    t.rows[0].cells[0].width = Inches(6.6)
    t.rows[1].cells[0].width = Inches(6.6)


# ============================================================= TITLE BLOCK
para(SCHOOL, size=15, bold=True, align="c", space_after=2)
para(SUBJECT, size=13, bold=True, align="c", space_after=2)
para(EXAM, size=12, bold=True, align="c", space_after=2)
para(YEAR, size=10, italic=True, align="c", space_after=8)

info = doc.add_table(rows=1, cols=3); info.style = "Table Grid"
info.alignment = WD_TABLE_ALIGNMENT.CENTER
for i, v in enumerate([f"Class: {CLASS}", f"Time: {TIME}", f"Total Marks: {MARKS}"]):
    c = info.rows[0].cells[i]; c.text = ""
    set_font(c.paragraphs[0].add_run(v), 10, bold=True)
para("", space_after=6)

para("INSTRUCTIONS", size=11, bold=True, space_after=3)
for txt in [
    "1. Write your name and class clearly in the spaces provided on your answer sheet.",
    "2. This paper has TWO sections: Section A and Section B.",
    "3. Answer ALL the questions in both sections.",
    "4. Section A has 40 multiple-choice questions. Each question carries 1 mark. Choose the best answer "
    "(A, B, C or D) and record it on the answer sheet provided.",
    "5. Section B has 7 theory questions totalling 60 marks. Write your answers clearly and neatly in your "
    "answer booklet. Draw and label diagrams or tables where you are asked to.",
    "6. Read every question carefully before you answer it.",
    "7. Do not use correction fluid. Cancel any mistake neatly with a single line.",
    "8. Hand in your answer sheet and your answer booklet at the end of the examination.",
]:
    para(txt, size=10.5, space_after=2)
rule()

# =============================================================== SECTION A
para("SECTION A - OBJECTIVE TEST (40 marks)", size=12, bold=True, align="c", space_after=2)
para("Answer ALL questions. Each question carries 1 mark. Choose the BEST answer and write its letter "
     "(A, B, C or D) against the question number on your answer sheet.",
     size=10, italic=True, align="c", space_after=8)

for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(1); p.paragraph_format.space_before = Pt(4)
    set_font(p.add_run(f"{i}. {q}"), 10.5)
    for j, o in enumerate(opts):
        p2 = doc.add_paragraph()
        p2.paragraph_format.left_indent = Inches(0.28)
        p2.paragraph_format.space_after = Pt(0); p2.paragraph_format.space_before = Pt(0)
        set_font(p2.add_run(f"{'ABCD'[j]}. {o}"), 10.5)

doc.add_page_break()

# =============================================================== SECTION B
para("SECTION B - THEORY (60 marks)", size=12, bold=True, align="c", space_after=2)
para("Answer ALL questions. Write your answers in your answer booklet. The marks for each question are "
     "shown in brackets.", size=10, italic=True, align="c", space_after=8)

for qb in SECTION_B:
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(8); p.paragraph_format.space_after = Pt(2)
    set_font(p.add_run(f"Question {qb['num']}"), 11, bold=True)
    set_font(p.add_run(f"  [{qb['total']} marks]"), 10, bold=True, italic=True)
    para(qb["stem"], size=10.5, space_after=4)
    if qb.get("diagram"):
        draw_diagram(CIRCUIT, "Fig. 1: A simple electronic circuit (not drawn to scale)")
        para("", space_after=2)
    if qb.get("table") == "components":
        add_table(CMP_HEADERS, CMP_ROWS, widths=[1.1, 2.5, 2.4], size=8.5, head_size=8.5)
        para("Table 1: Electronic components", size=9, italic=True, align="c", space_after=6)
        para("", space_after=2)
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Inches(0.25)
        p.paragraph_format.space_after = Pt(3); p.paragraph_format.space_before = Pt(2)
        set_font(p.add_run(f"{lab} {text}  "), 10.5)
        set_font(p.add_run(f"[{mk} mark{'s' if mk > 1 else ''}]"), 10, bold=True)

doc.add_page_break()

# ============================================================== ANSWER KEY
para("ANSWER KEY", size=13, bold=True, align="c", space_after=6)
para("SECTION A - OBJECTIVE TEST", size=11, bold=True, space_after=4)
rows = [[i, ans, TOPIC[tp], cog] for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1)]
add_table(["Question", "Answer", "Curriculum Area (Topic)", "Cognitive Level"],
          rows, widths=[0.8, 0.7, 3.6, 1.5], size=9)
counts = {L: sum(1 for q in MCQ if q[2] == L) for L in "ABCD"}
para("", space_after=4)
para("Correct-answer distribution: " + ", ".join(f"{L} = {counts[L]}" for L in "ABCD") + " (30 items).",
     size=9, italic=True)

para("", space_after=8)
para("SECTION B - THEORY (summary answers; see the Marking Scheme for full detail)",
     size=11, bold=True, space_after=4)
sba = [
 ("1 (a)", "Thermal electricity is generated by burning a fuel - coal, oil or natural gas - to boil water; the steam turns a turbine which turns the generator.", "12.1", "Understand"),
 ("1 (b)", "Nuclear electricity is generated from the heat released when atoms are split inside a nuclear reactor; the fuel is uranium, and the heat boils water to make steam for the turbine.", "12.1", "Understand"),
 ("1 (c)", "Any three of: thermal burns coal, oil or gas while nuclear uses uranium; thermal makes a lot of smoke and carbon dioxide while nuclear makes almost none; thermal makes ash while nuclear makes radioactive waste; thermal is cheaper to build; thermal needs a constant fuel supply while nuclear needs very little fuel but very careful control.", "12.1", "Analyse"),
 ("2 (a)", "Any three of: air pollution from smoke, carbon dioxide and sulphur dioxide; acid rain that damages crops and buildings; carbon dioxide adding to global warming; ash and dust settling on homes and crops; warm water killing fish in a river.", "12.2", "Understand"),
 ("2 (b)", "Any three of: radioactive waste that stays dangerous for thousands of years; the danger of an accident releasing radiation; warm water harming fish; damage from mining uranium; the great cost of closing the station down safely.", "12.2", "Understand"),
 ("2 (c)", "Either choice with three sensible supporting reasons - e.g. thermal because it is cheaper and quicker to build and the waste is easier to manage, or nuclear because it makes almost no smoke or carbon dioxide and a little fuel gives a lot of electricity.", "12.2", "Evaluate"),
 ("3 (a)", "(i) gives out light when current flows through it; (ii) limits or controls the amount of current flowing; (iii) a battery charger, a radio or an adapter; (iv) a radio, a television set or a phone charger; (v) stores energy in a magnetic field and opposes changes in the current; (vi) opens and closes the circuit, switching the current on and off.", "12.3", "Understand"),
 ("3 (b)", "Any two of: an LED uses much less current so the battery lasts longer; it does not get hot; it is much smaller and so fits small gadgets; it lasts far longer.", "12.3", "Understand"),
 ("3 (c)", "The coloured bands show the resistance value of the resistor in ohms. A technician reads the bands in order and uses a colour code chart to find the value, so he can pick the right resistor without measuring it first.", "12.3", "Apply"),
 ("4 (a)", "Two 1.5 V dry cells in a holder in series to make 3 V, a switch, a resistor, an LED and wires; join the battery positive to the switch, the switch to the resistor, the resistor to the longer (positive) leg of the LED, and the shorter leg back to the battery negative, then close the switch to test.", "12.4", "Create"),
 ("4 (b)", "When the switch is closed the circuit is complete, so current flows and the LED lights. When the switch is opened there is a break in the circuit, so no current flows and the LED goes out.", "12.4", "Understand"),
 ("4 (c)", "Any two of: it limits the current so the LED is not damaged; without it the LED would burn out; it protects the battery from being drained too quickly; it helps to control the brightness.", "12.4", "Understand"),
 ("5 (a)", "The P region is the positive region, called the anode; the N region is the negative region, called the cathode; the two meet at the junction, which is why a diode allows current to flow in one direction only.", "12.5", "Understand"),
 ("5 (b)", "Any two of: the negative end is marked with a band or ring round the body; the leg at the negative end is the shorter one; some packages have a flat side at the negative end.", "12.5", "Understand"),
 ("5 (c)", "Connected the right way round (P side to the battery positive) the diode allows current to flow, so the LED lights. Connected the wrong way round the diode blocks the current, so the LED stays off; nothing is damaged until the diode is turned round.", "12.5", "Apply"),
 ("6 (a)", "1 - switch: opens and closes the circuit. 2 - resistor: limits or controls the current. 3 - battery (two dry cells in series): provides the voltage that pushes the current round. 4 - LED: changes electrical energy into light and shows that current is flowing.", "12.6", "Understand"),
 ("6 (b)", "Any two of: each part has a job and the circuit works only if all of them do theirs; the battery alone cannot light the LED without wires and a closed switch; the resistor decides how much current reaches the LED; if any part is missing or faulty the loop is broken and the whole circuit stops.", "12.6", "Analyse"),
 ("6 (c)", "The LED becomes dimmer, because the extra resistor increases the total resistance, so less current flows.", "12.6", "Apply"),
 ("7 (a)", "Any four of: resistors (limit the current); capacitors (store charge); diodes (allow current one way); LEDs (show the radio is on); inductors or coils (store energy in a magnetic field and help tuning); a switch or volume control; connecting wires or a circuit board.", "12.6", "Remember"),
 ("7 (b)", "Any three of: the parts form one circuit so each depends on the others; the power supply alone cannot make the radio work; the resistors and capacitors set the conditions the other parts need; one missing or faulty part stops the whole radio; that is what interdependence means.", "12.6", "Analyse"),
]
add_table(["Question", "Expected Answer", "Curriculum Area", "Cognitive Level"],
          [list(r) for r in sba], widths=[0.8, 4.2, 1.2, 1.2], size=9)

doc.add_page_break()

# =========================================================== MARKING SCHEME
para("MARKING SCHEME - SECTION B (60 marks)", size=13, bold=True, align="c", space_after=4)
para("General rules: (1) Accept any other correct and relevant answer. (2) Award marks for correct points, "
     "not for repeating the question. (3) For procedures, award method marks. (4) Do not deduct marks for "
     "spelling unless the meaning is changed. (5) Where a candidate gives more answers than are asked for, "
     "mark only the first ones up to the number required.",
     size=9.5, italic=True, space_after=8)

for qb in SECTION_B:
    n = qb["num"]
    para(f"Question {n}  ({qb['total']} marks)", size=11, bold=True, space_before=8, space_after=3)
    for (lab, points, note) in MARKING[n]:
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(2)
        set_font(p.add_run(f"{lab} "), 10.5, bold=True)
        mkv = [p_[2] for p_ in qb["parts"] if p_[0] == lab]
        if mkv: set_font(p.add_run(f"[{mkv[0]} mark{'s' if mkv[0] > 1 else ''}]"), 10, bold=True)
        for pt in points:
            pp = doc.add_paragraph()
            pp.paragraph_format.left_indent = Inches(0.35); pp.paragraph_format.space_after = Pt(1)
            set_font(pp.add_run("- " + pt), 10.5)
        pp = doc.add_paragraph()
        pp.paragraph_format.left_indent = Inches(0.35); pp.paragraph_format.space_after = Pt(6)
        set_font(pp.add_run("Marking note: " + note), 9.5, italic=True)

doc.add_page_break()

# ================================================================ BLUEPRINT
para("CURRICULUM ASSESSMENT BLUEPRINT", size=13, bold=True, align="c", space_after=3)
para(f"Strand: {STRAND}   |   Sub-strand: {SUBSTRAND}   |   Class: {CLASS}",
     size=10, italic=True, align="c", space_after=3)
para(f"Content Standard: {CS} - {CS_TEXT}", size=9, italic=True, align="c", space_after=3)
para("Source: NaCCA Science Common Core Programme Curriculum (B7/JHS1-B9/JHS3), September 2020, "
     "Strand 4: Forces and Energy, Sub-strand 2: Electricity and Electronics, pp. 30-32. "
     "Indicators are quoted, not invented.",
     size=9, italic=True, space_after=8)

hdr = ["Qn", "Sub-strand", "Content Standard", "Indicator (NaCCA) - Indicator Text", "Topic / Content",
       "Cognitive Level", "Marks"]

rows = [[f"A{i}", SUBSTRAND, CS_BY_TOPIC[tp], f"{IND[tp]} - {IND_TEXT[tp]}", TOPIC[tp], cog, 1]
        for i, (q, opts, ans, tp, cog, diff) in enumerate(MCQ, start=1)]
add_table(hdr, rows, widths=[0.35, 0.75, 0.75, 1.75, 1.4, 0.8, 0.35], size=7, head_size=7.5)

para("", space_after=8)
rows = []
for qb in SECTION_B:
    for (lab, text, mk, cog, tp, diff) in qb["parts"]:
        key = tp if tp in TOPIC else tp.split(",")[0].strip()
        rows.append([f"B{qb['num']}{lab.strip('()')}", SUBSTRAND, CS_BY_TOPIC[key],
                     f"{IND[key]} - {IND_TEXT[key]}", TOPIC[key], cog, mk])
add_table(hdr, rows, widths=[0.35, 0.75, 0.75, 1.75, 1.4, 0.8, 0.35], size=7, head_size=7.5)

doc.add_page_break()

# ----------------------------------------------------------------- helpers
def topic_totals():
    m = {k: 0 for k in TOPIC}; it = {k: 0 for k in TOPIC}
    for q in MCQ:
        m[q[3]] += 1; it[q[3]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]:
            key = tp if tp in m else tp.split(",")[0].strip()
            m[key] += mk; it[key] += 1
    return m, it

def cognitive_by_section():
    order = ["Remember", "Understand", "Apply", "Analyse", "Evaluate", "Create"]
    a = {k: 0 for k in order}; b = {k: 0 for k in order}
    for q in MCQ: a[q[4]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: b[cog] += mk
    return order, a, b

def difficulty_totals():
    d = {"Easy": 0, "Moderate": 0, "Challenging": 0}
    for q in MCQ: d[q[5]] += 1
    for qb in SECTION_B:
        for (lab, text, mk, cog, tp, diff) in qb["parts"]: d[diff] += mk
    return d

m, it = topic_totals(); diff = difficulty_totals(); order, ca, cb = cognitive_by_section()

para("SUMMARY 1 - COVERAGE BY CURRICULUM AREA (TOPIC)", size=12, bold=True, space_after=4)
rows = [[TOPIC[k], it[k], m[k], f"{(m[k]/100)*100:.1f}%", CC[k]] for k in TOPIC]
rows.append(["TOTAL", sum(it.values()), sum(m.values()), "100%", "-"])
add_table(["Topic / Content Area", "No. of Items", "Marks", "% of Total Marks", "Core Competencies"],
          rows, widths=[2.7, 0.8, 0.6, 1.0, 1.1], size=8.5)
para("CC = Communication and Collaboration; CP = Critical Thinking and Problem Solving; "
     "DL = Digital Literacy; CI = Creativity and Innovation.", size=8.5, italic=True, space_after=2)

para("", space_after=8)
para("SUMMARY 2 - COGNITIVE-LEVEL DISTRIBUTION (Bloom's Taxonomy)", size=12, bold=True, space_after=4)
rows = []
for lv in order:
    tot = ca[lv] + cb[lv]
    rows.append([lv, ca[lv], cb[lv], tot, f"{(tot/100)*100:.1f}%"])
rows.append(["TOTAL", sum(ca.values()), sum(cb.values()), sum(ca.values()) + sum(cb.values()), "100%"])
add_table(["Cognitive Level", "Section A Marks", "Section B Marks", "Total Marks", "% of Total"],
          rows, widths=[1.6, 1.3, 1.3, 1.1, 1.1], size=9.5)

para("", space_after=8)
para("SUMMARY 3 - DIFFICULTY DISTRIBUTION", size=12, bold=True, space_after=4)
rows = [[k, v, f"{(v/100)*100:.1f}%"] for k, v in diff.items()]
rows.append(["TOTAL", sum(diff.values()), "100%"])
add_table(["Difficulty", "Marks", "% of Total Marks"], rows, widths=[2.0, 1.2, 1.5], size=9.5)
para("Target in the master prompt: approximately 30% easy / 50% moderate / 20% challenging.",
     size=9, italic=True, space_after=2)

para("", space_after=8)
para("SUMMARY 4 - SECTION WEIGHTING", size=12, bold=True, space_after=4)
add_table(["Section", "Question Type", "Items", "Marks", "% of Total"],
          [["A", "Objective (multiple choice)", 40, 40, "40%"],
           ["B", "Theory / constructed response", 20, 60, "60%"],
           ["TOTAL", "-", 60, 100, "100%"]],
          widths=[0.9, 2.4, 0.8, 0.8, 1.0], size=9.5)

doc.add_page_break()

# ===================================================== QUALITY-CONTROL
para("QUALITY-CONTROL SUMMARY", size=13, bold=True, align="c", space_after=4)
para("Carried out against the 14-point validation list in the master prompt before the examination was "
     "finalised.", size=9.5, italic=True, space_after=8)

qc = [
 ("Does every question belong to the supplied curriculum scope?",
  "Yes. All 60 items - 40 objectives and 20 theory sub-questions - trace to Strand 4 (Forces and "
  "Energy), Sub-Strand 2 (Electricity and Electronics), topics 12.1-12.6, and to the five official "
  "B7 indicators (B7/JHS1.4.2.1.1, B7/JHS1.4.2.1.2, B7/JHS1.4.2.2.1, B7/JHS1.4.2.2.2 and "
  "B7/JHS1.4.2.2.3). Hydro, solar and wind generation, transformers, transistors, Ohm's law "
  "calculations, and the resistor colour-code chart itself appear only as context or as "
  "distractors, never as things pupils must answer on."),
 ("Is the examination appropriate for the stated class?",
  "Yes. The B7 curriculum requires learners to describe the forms of electricity generation, "
  "explain the impact of generation on the environment, examine and arrange LEDs, P-N junction "
  "diodes, colour-code resistors and capacitors, construct a 3 V circuit of two dry cells, a "
  "switch and an LED, explain what happens when the switch is opened and closed, identify the P "
  "and N regions, and discuss the roles of the LED, resistor, diode and inductor and how they "
  "affect each other. No circuit calculation, no Ohm's law arithmetic and no transistor theory "
  "are tested, as these fall outside the B7 indicator."),
 ("Are the questions genuinely BECE-style?",
  "Yes: Section A is 40 four-option objectives worth 1 mark each, and Section B is structured "
  "theory with sub-questions carrying printed mark allocations. A labelled diagram and a "
  "completion table are both included, matching the BECE science convention and the 'produce "
  "diagrams' and 'examine components' exemplars."),
 ("Are there enough application and reasoning questions?",
  "Yes. 30 of 100 marks (30%) are at Apply level or above (Apply 11, Analyse 12, Evaluate 3, "
  "Create 4). Create is well represented because exemplar 2 of B7/JHS1.4.2.2.2 asks pupils to "
  "construct a circuit, and Evaluate because exemplar 1 of B7/JHS1.4.2.1.2 asks for a debate."),
 ("Are the MCQ distractors plausible?",
  "Yes. Distractors are drawn from the same content family as the key: another electronic "
  "component (A15, A17, A18, A37), the wrong fuel (A2, A5, A6), a wrong effect of generation "
  "(A9, A12), a real but wrong method of reducing harm (A13), and a correct-sounding but inverted "
  "statement about the diode (A30, A36)."),
 ("Is there only one best answer for each MCQ?",
  "Yes. Every item was reviewed for a single defensible key. Special care was taken with A6, where "
  "coal and gas are real fuels but not the ones used in a nuclear reactor, with A16, where a "
  "capacitor also affects a circuit but does not control the current, and with A35, where the "
  "diode is the only one of the four whose main job is one-way conduction."),
 ("Are the marks internally consistent?",
  "Yes. Section A = 40 items x 1 mark = 40. Section B = 9 + 9 + 10 + 9 + 8 + 8 + 7 = 60. "
  "Each Section B sub-question's printed marks match its marking-scheme allocation, and every "
  "N-mark sub-question asks for N things."),
 ("Does the total add up correctly?",
  "Yes: 40 + 60 = 100 marks, matching the stated total on the front page."),
 ("Are the answers in the answer key correct?",
  "Yes. All 40 objective keys and all 20 Section B answers were verified against the marking "
  "scheme. The series-voltage item was checked: two 1.5 V cells in series give 3.0 V."),
 ("Does the marking scheme match the questions?",
  "Yes. Every Section B sub-question has an expected-answer list and a marking note covering "
  "partial credit, acceptable alternatives, common wrong answers and method marks. The labelled "
  "diagram, the completion table and the circuit-construction task have explicit marking grids so "
  "they can be marked consistently across a class."),
 ("Are the questions free from unnecessary ambiguity?",
  "Yes. Open items are anchored with 'state three', 'name four' and the mark allocation. Question "
  "3(a) numbers every blank, (i) to (vi). Question 6(a) requires both the name AND the function of "
  "each labelled part, and Question 7(a) says so explicitly. Question 1(c) asks for differences, "
  "not descriptions, and Question 5(c) requires both orientations of the diode."),
 ("Are Ghanaian contexts used naturally and accurately?",
  "Yes: the Akosombo Dam, thermal generation, a district choosing between a thermal plant and a "
  "nuclear plant, a box of components given to a class, a spoilt radio dismantled for a school "
  "project, a mobile phone charger, a television indicator light, and a radio."),
 ("Has any content outside the supplied curriculum been introduced?",
  "No. Every item sits inside topics 12.1-12.6. Only the five components named in the indicators "
  "are tested (LED, diode, resistor, capacitor, inductor) together with the switch that exemplar 2 "
  "of B7/JHS1.4.2.2.2 puts in the circuit. No transistor, transformer or Integrated Circuit is "
  "required, and pupils are not asked to remember the resistor colour-code chart."),
 ("Are the questions sufficiently varied?",
  "Yes. Item types include explaining two forms of generation, comparing them, listing "
  "environmental effects, making and justifying a choice, completing a component table, explaining "
  "an advantage, reading colour bands, describing how to build a circuit, explaining a switch, "
  "identifying P and N regions, predicting what a reversed diode does, labelling a diagram, and "
  "explaining interdependence."),
]
for i, (q, a) in enumerate(qc, start=1):
    p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(2)
    set_font(p.add_run(f"{i}. {q}"), 10.5, bold=True)
    p2 = doc.add_paragraph()
    p2.paragraph_format.left_indent = Inches(0.3); p2.paragraph_format.space_after = Pt(6)
    set_font(p2.add_run(a), 10)

para("", space_after=8)
para("EXAMINER NOTES (for the teacher, not for candidates)", size=11, bold=True, space_after=4)
for n in [
 "Fig. 1 is drawn with text characters because this is a plain Word file. Before printing, "
 "redraw it with the standard circuit symbols so that the dry cell has one long plate and one "
 "short plate and so that the LED carries the two arrows that show it gives out light. The "
 "numbering (1-4) is what the questions depend on. Key: 1 = switch, 2 = resistor, 3 = battery "
 "(two dry cells in series), 4 = LED.",
 "Question 4(a) is the design task, and it comes straight from exemplar 2 of B7/JHS1.4.2.2.2 - "
 "'construct a simple electronic circuit comprising a 3V battery made of two dry cells in series "
 "with a switch and an LED'. Award method marks: any workable plan that is clearly described "
 "deserves credit. The two things to look for are the cells joined positive-to-negative in series, "
 "and the longer leg of the LED on the positive side.",
 "Question 6(a) asks for the name AND the function of each labelled part, so a pupil who only "
 "names four parts earns half marks. Say this to the class before the paper if you use it for "
 "practice.",
 "Question 2(c) is a debate question with no single right answer - that is deliberate, and it "
 "follows exemplar 1 of B7/JHS1.4.2.1.2. Both choices are valid. Award the three reasons only if "
 "they actually support the choice the pupil made, and accept a pupil who rejects both and argues "
 "for solar or hydro instead.",
 "B7 pupils are NOT expected to remember the resistor colour-code chart. Question 3(c) only asks "
 "what the bands are FOR, and the marking note says so explicitly.",
 "Keep the inductor light. It is named in exemplar 1 of B7/JHS1.4.2.2.3, but 'stores energy in a "
 "magnetic field and opposes changes in the current' is as far as B7 goes; do not ask for coil "
 "calculations or reactance.",
 "Topic weighting is even at 16 to 17 marks for each of topics 12.1 to 12.5, with 19 for 12.6, "
 "because 12.6 carries three of the five indicators. If your scheme of work spent longer on "
 "generation than on components, move marks towards Questions 1 and 2.",
 "If your school has a science kit, let the class actually build the circuit in Question 4 before "
 "the mock. Pupils who have handled a resistor and an LED write far better answers, and it is the "
 "activity the indicator asks for.",
 "Edit the school name, academic year and examination title on page 1 before printing.",
 "This is an original, teacher-made mock. It is not a reproduction of any WAEC or NaCCA examination "
 "paper.",
]:
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Inches(0.3); p.paragraph_format.space_after = Pt(3)
    set_font(p.add_run("- " + n), 10)

doc.save("/home/user/Basic7_Integrated_Science_Mock_Strand4_ElectricityAndElectronics.docx")
print("docx written")

print("Section A:", len(MCQ), "items")
print("Section B total:", sum(q["total"] for q in SECTION_B))
print("Topic marks:", m, "sum", sum(m.values()))
print("Difficulty:", diff, "sum", sum(diff.values()))
print("Cognitive A:", ca)
print("Cognitive B:", cb)
print("Answer counts:", counts)
print("Totals:", sum(m.values()), sum(diff.values()),
      sum(ca.values()) + sum(cb.values()))
